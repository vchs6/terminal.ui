#!/usr/bin/env python3
"""Construct adversarial TOML source bytes; no TOML parsing or schema/resolver oracle."""
from pathlib import Path

PREFIX = 'schema_version=1\nname="Case"\n'

def generate(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    def put(name, text):
        (directory / name).parent.mkdir(parents=True, exist_ok=True)
        (directory / name).write_bytes(text.encode('utf-8') if isinstance(text, str) else text)
    put('source.toml', PREFIX)
    for literal in ('~', '$HOME', '${HOME}', 'https:literal', 'https:/literal.test/theme.toml'):
        put(literal, 'schema_version=1\nname="Literal"\n')
    put('invalid-utf8.toml', PREFIX.encode() + b'#\xff\xfe')
    put('integer-too-high.toml', PREFIX + 'spacing.min_width=9223372036854775808\n')
    put('integer-too-low.toml', PREFIX + 'decoration.shadow_offset_x=-9223372036854775809\n')
    # Large comment is one comment payload, not an array/table nesting signal.
    at = PREFIX + '#' + 'x' * (1048576 - len(PREFIX.encode()) - 1)
    assert len(at.encode()) == 1048576
    put('bytes-at.toml', at)
    put('bytes-over.toml', at + 'x')
    put('bytes-over-unicode.toml', PREFIX + '#' + '界' * 349526)
    put('string-brackets.toml', 'schema_version=1\nname="' + '[' * 70000 + '"\n')
    put('comment-tokens-at.toml', PREFIX + '#[\n' * 32764)
    put('comment-tokens-over.toml', PREFIX + '#[\n' * 32765)
    for depth, slug in ((16, 'at'), (17, 'over'), (10000, '10000')):
        put(f'depth-{slug}.toml', PREFIX + 'text.bold=' + '[' * depth + '0' + ']' * depth)
    for depth, slug in ((16, 'at'), (17, 'over')):
        put(f'path-{slug}.toml', PREFIX + '.'.join('k' + str(i) for i in range(depth)) + '=true\n')
    # Each local key is short; only table-prefix + dotted + inline totals exceed 16.
    table = '.'.join('p' + str(i) for i in range(8))
    put('table-dotted-over.toml', PREFIX + '[' + table + ']\n' + '.'.join('q' + str(i) for i in range(9)) + '=true\n')
    inline = '{a={b={c={d={e={f={g={h={i=true}}}}}}}}}'
    put('table-inline-over.toml', PREFIX + '[' + table + ']\n' + 'v=' + inline + '\n')
    put('table-inline-at.toml', PREFIX + '[' + table + ']\nv={a={b={c={d={e={f={g=true}}}}}}}\n')
    put('array-inline-at.toml', PREFIX + '[' + table + ']\nv=[{a={b={c={d={e={f={g=true}}}}}}},{a={b={c={d={e={f={g=true}}}}}}}]\nshort=true\n')
    put('array-inline-over.toml', PREFIX + '[' + table + ']\nv=[' + inline + ']\n')
    put('quoted-dot.toml', PREFIX + '"' + 'a.' * 40 + 'a"=true\n')
    # Names may contain punctuation; brackets/dots in strings and comments are inert.
    put('quoted-brackets.toml', 'schema_version=1\nname="[[[[{....}}]]]]"\n#' + '[{.' * 500 + '\n"text"."bold"=true\n')
    put('key-at.toml', PREFIX + '"' + '界' * 341 + 'x"=true\n')  # 1024 UTF8 bytes
    put('key-over.toml', PREFIX + '"' + '界' * 341 + 'xx"=true\n')
    for count, slug in ((4096, 'at'), (4097, 'over')):
        put(f'variables-{slug}.toml', PREFIX + '[variables]\n' + ''.join(f'v{i}={{type="bool",value=false}}\n' for i in range(count)))
        put(f'styles-{slug}.toml', PREFIX + '[styles]\n' + ''.join(f's{i}={{}}\n' for i in range(count)))
    for count, slug in ((128, 'at'), (129, 'over')):
        put(f'variable-name-{slug}.toml', PREFIX + '[variables]\n' + 'v' * count + '={type="bool",value=false}\n')
        put(f'style-name-{slug}.toml', PREFIX + '[styles]\n' + 's' * count + '={}\n')
    # Public upstream Lexer measured: PREFIX=8 non-EOF tokens; dotted assignment
    # text.bold=[...] contributes 6 structural/key tokens plus one per integer.
    for count, slug in ((65522, 'at'), (65523, 'over')):
        put(f'tokens-{slug}.toml', PREFIX + 'text.bold=[' + ','.join('0' for _ in range(count)) + ']\n')
    # [x] emits 3 non-EOF tokens and one declaration. Duplicate semantics belong
    # to Parser: exactly-at guard must reach SyntaxError, over must stop earlier.
    for count, slug in ((16384, 'at'), (16385, 'over')):
        put(f'declarations-{slug}.toml', '[x]\n' * count)

if __name__ == '__main__':
    generate(Path(__file__).resolve().parent / '.scratch')
