# Theme foundation evidence archive

Initial086 full source review: CHANGES_REQUIRED,3Important/1Minor reproduced or confirmed. Original failure preserved,not relabeled by later closure.

[Original report](report.md) and [source-to-copy/hash/provenance index](archive-index.json) retain original bytes,verdicts and failures.

Actual sealed index entries:30;unchanged original index adds1,total31original files. This archive README/index add2 files. No original README/report/index overwritten.

C1 negative-fixture input identity was captured post-run; this archive does not invent historical pre-run source/compiler proof or claim negatives reran on final8d. The dependency lock drift is the same five exact dependency records in a different order,not a new dependency set; original hashes and failed checks remain unchanged.

Wholechecker actualexit1/themes allowlist plus missing composition/benchmarks remain T087-G01/final023OPEN. Foundation x/y observations are not full027 controls/showcase. XTerm normal basic-color projection differs from VTE256/RGB handling. External provenance hashes/omission inventories do not claim those binaries or source trees are archived.
