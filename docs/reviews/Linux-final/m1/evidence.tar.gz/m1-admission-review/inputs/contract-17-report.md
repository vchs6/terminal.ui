# M2 三项发现限定复核

结论：**三项设计发现均 verified；design_reviewed，execution_ready=false。** 固定受审修订为`c7328d0b674bd177d19361c65aa6f8472bd0897c`。本结论仅关闭07a50d93初审的设计缺口，不代表产品实现、公开API编译、性能或上游验收通过。初审目录原件保持不变，复核结果另存本目录。

| 初审发现 | 复核结果 | 闭合依据 |
|---|---|---|
| M2-PF-001 / Glyph策略缓存与验收 | verified | M011明确目标、文本行/测量/绘制缓存包含影响generatedEllipsis的有效policy内容；不能只按Auto枚举、对象地址或文本revision。device/offline分别消费策略，同mode同epoch配对。133/138/143追加Unicode→Ascii→Unicode手算golden和同投影零grid更新。 |
| M2-PF-002 / M1冻结与基准编译顺序 | verified | M006/M012把124前冻结对象限定为功能完整且无M2优化的M1库source/cjp/deps/SDK/native及示例证据；143/144在142后交基准，146前冻结共同源。取消旧稿提前冻结bench源的要求符合原AC，不需要坚持初审建议的早期交付步骤。 |
| M2-PF-003 / 来源定位 | verified | source-hashes.tsv已入change，27项历史commit/path摘要全部匹配；历史交互绝对原件及SHA一致；固定tree的R20/tools/probe-report.md与外部原件逐byte一致。manifest已区分当前合同、历史调查、外部原始证据与尚待接受产品。 |

M012的编译边界足够明确：`compat`与`workloads`是正常CJPM入口/共享库，只使用完整M1已有API及八个Stats字段，同份源码对旧/新普通包构建，仅修改依赖manifest路径。三个新增诊断在共同入口记`not_available`，没有把缺测伪装为0。最终库专用主项目复用相同workloads，读取三个新增字段，并只对新库编译；因此不存在用运行时分支绕过旧库缺成员的假兼容。旧/新TTY的CPU、heap/GC、RSS、真实输出仍由共同入口与外部工具测量，同库headless对照承担精确阶段工作/Cell槽证据。无新增生产M1开关、私有diff消费者或全heap精确分配门槛。

第11节矩阵已预声明且保留，不得结果出来后只挑赢家；correctness和timing隔离、同epoch门控、完整M1功能与示例范围均未缩减。完整M1库尚无最终benchmark文件不被冒称为最终Linux release，023/024仍承担最终制品及整体验收。上述改定消除了原阶段回环，同时保持原031/022目标。

M011区分布局生成策略与终端投影：`abcdef`宽5的离线Unicode/Ascii结果不同，必须使相应缓存无效；若生成marker不变而终端profile变化，可复用逻辑Frame，但后端必须用旧/新各自profile比较真实投影。`中→文`或`中→??`同style、同两列投影时零grid更新，仍不能跳过已有caret-only控制及失败恢复围栏。该规则未引入第二Unicode/布局/终端Frame。

DQ-05/06/09/12在当前planned设计阶段改为pass；其余初审判断复用，修订未改变其依据。**实际准入仍未满足**：完整功能M1上游产品、测试和证据固定SHA仍PENDING；任何候选合同或本次设计复核不能把review FAIL的产品变为接受源。正式任务仍按A→B→C→D→E、五独立角色和共享代码写屏障执行。

验证仅为固定commit差异/相关合同核对、文档来源hash检查和OpenSpec strict（exit0、1项通过）。未重跑微探针、旧suite或产品构建，未修改主仓/产品/正式测试，也未读取实现者自评。27项摘要检查是新归档表的来源验证；原18次运行及43项探针索引仍复用初审证据。

详细处置在[findings.json](findings.json)，DQ在[dq.json](dq.json)，固定来源摘要在[reviewed-hashes.json](reviewed-hashes.json)，本次核验原件在[evidence/provenance-check.json](evidence/provenance-check.json)与[evidence/openspec-validation.json](evidence/openspec-validation.json)。
