from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path('/workspace/work/terminal.ui');O=Path('/workspace/work/m1-freeze-manifest');REF='d654ae59da4749a43c946e1541c21b08e9b3ffba'
def h(b):return hashlib.sha256(b).hexdigest()
def rec(path):
 p=R/path;b=subprocess.check_output(['git','-C',str(R),'show',REF+':'+path]);return {'logical_path':str(p),'git_locator':REF+':'+path,'bytes':len(b),'sha256':h(b)}
def local(p):
 b=p.read_bytes();return {'path':str(p.relative_to(O)),'bytes':len(b),'sha256':h(b)}
def write(n,x):
 p=O/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return local(p)
e=json.loads((O/'evidence-map.json').read_text())
for a in e['evidence']:
 if a['id']=='Runtime075':a['accepted_source']='0912436b647f701e1de607fe03ce1bfba6a9bbf4'
 if a['id']=='AC010':a['accepted_source']='13e7880ce96d1331fc9e12a2b62275a307183e9a'
 if a['id']=='S157':a['accepted_source']='1df1325f7b51777d8adab62f950c936051aa5876'
 # Session152 and current final feature sources retain their exact prior accepted identities.
e['evidence'] += [{'id':'LayoutDecoration057_054_060','accepted_source':'40aa4db6c2b7673bb3e8c9a80fdb5b4e385cb940','accepted_scope':'Original AC011/012/054–060 finite Linux constrained layout, borders/shadow and lifecycle repair. Metadata integration91ff224 is source-equal; later accepted runtime/interaction/M1 consumers cover affected paths. No full old source tree equals final source.','references':[rec('docs/reviews/R9/verification/verification.md'),rec('docs/reviews/R9/verification/final-integration-results.json'),rec('docs/reviews/R9/verification/logs.sha256')]},{'id':'LinuxNativeFirstSlice053','accepted_source':'2ad6c5ceeb0068d3b2b2d5efe010059965b9415a','metadata_final':'e162f7962ce2c211a9be0ef2bf03c77c907538b6','accepted_scope':'Original AC048–053 finite normal native integration/firstLinux slice and clean ordinary consumer; original bundle skips are historical limitations, later normal mandatory CJP evidence supersedes current bundle quality claim. No full041 claim.','references':[rec('docs/reviews/R8/verification/verification.md'),rec('docs/reviews/R8/verification/final-state-check.json'),rec('docs/reviews/R8/verification/native-artifact-check.json')]}]
eref=write('evidence-map-complete-v1.json',e)
m=json.loads((O/'manifest.json').read_text());m['artifacts']['evidence-map.json']= {'superseded_for_admission_identity_detail':True,'replacement':eref,'original_retained':m['artifacts']['evidence-map.json']}
m['admission_rows'][0]['exact_reused_scope']+=' Exact075 accepted source0912436b647f701e1de607fe03ce1bfba6a9bbf4;080 source216b2ab5f2315f4be19467b7e49f4047aec78ab9.'
m['admission_rows'][5]['evidence_ids']+=['LayoutDecoration057_054_060','LinuxNativeFirstSlice053']
m['admission_rows'][5]['exact_reused_scope']+=' Direct original011/012 acceptance and first-slice native source/metadata now additionally indexed.'
m['supplemental_identity_detail']='This complete version adds direct accepted R8/R9 references and fills exact075/010/157 source identities. Original sealed manifest/index remain byte-identical.'
mref=write('manifest-complete-v1.json',m)
a={'schema':1,'kind':'immutable identity-completion addendum1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_index':local(O/'index.json'),'original_index_sha256':'3eb4566595fe5326ee98abb43649906d00706dc4f4a589c51c9f58c2cc1a5a52','amendments':['Exact Runtime075 accepted source0912436b647f701e1de607fe03ce1bfba6a9bbf4; AC010 accepted main13e7880ce96d1331fc9e12a2b62275a307183e9a; S157 source1df1325f7b51777d8adab62f950c936051aa5876.','Pin original R9 accepted constrained layout/decoration011/012 and R8 finite native/firstLinux source plus final metadata. These existing accepted ranges are reused, no suite rerun.','335 is total tar members,283 regular files, all matching frozenGit.285 scoped committed product files include placeholders omitted normally fromCJP.'],'replacement_evidence_map':eref,'replacement_complete_manifest':mref,'files':[local(O/'complete-identities.py'),eref,mref],'preparation_errors_preserved':[{'operation':'Read assumed R9/acceptance andR8/acceptance paths','result':'ENOENT; no mutation. Resolved actual canonical R9/verification andR8/verification via acceptance matrix; hashes above use committed Git blobs.'}],'root_review_and_product_GO':False,'immutability':'Original index/files unchanged. This is a separate sealed factual addendum; selfhash supplied independently.'}
write('identity-addendum-v1.json',a)
print(json.dumps(local(O/'identity-addendum-v1.json'),indent=2))
