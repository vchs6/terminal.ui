from pathlib import Path
import json,hashlib,subprocess,time,os
B=Path('/workspace/work/session-lifecycle-execution'); R=B/'raw'; S=B/'source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
rows=[]
for p in sorted(R.glob('gui-r2-*')):
 if not p.is_dir():continue
 result=read(p/'result.json');check=read(p/'child/host-check.json');assert result['runner_exit']==result['direct_exit']==0 and check['passed'];assert len(read(p/'host-identity.json')['identities'])==1
 rows.append({'path':str(p.relative_to(B)),'case':check['case'],'cursor':check['cursor'],'host':'xterm' if 'xterm' in p.name else 'vte','directExit':result['direct_exit'],'hostRunnerExit':result['runner_exit'],'before':read(p/'child/host-before.json')['observations'],'after':read(p/'child/host-after.json')['observations'],'pngs':[{'path':str(f.relative_to(B)),'sha256':sha(f)} for f in sorted(p.glob('*.png'))]})
assert len(rows)==52
assert {x['cursor'] for x in rows}=={'visible','hidden'}
for host in ['xterm','vte']:
 for cursor in ['visible','hidden']:assert len([x for x in rows if x['host']==host and x['cursor']==cursor])==13
for name in ['build','prepare','matrix-auto-r2','matrix-declared-r2','nested-r2','fixture-auto-r2','fixture-declared-r2','gui-batch']:assert (R/(name+'.exit')).read_text().strip()=='0',name
summary=read(R/'finite-summary.json');assert all(v['processes']==v['passing']==64 for v in summary['finite'].values())
(R/'gui-summary.json').write_text(json.dumps({'rows':rows,'total':52,'originalPNGs':sum(len(r['pngs']) for r in rows),'actualHostObservations':'actual /dev/tty reports forwarded by frozen script transport, zero fabricated replies, unchanged actual TERM','title':'default Auto no title scope; actual X11 properties retained','captures':'original ImageMagick X11 window PNGs; transport focus request recorded; later capture events include XGetInputFocus confirmation','resourceFreeBytes':os.statvfs(B).f_bavail*os.statvfs(B).f_frsize},indent=2)+'\n')
report='''TASK020.d independent execution evidence; acceptance remains separate.
Fixed source: e35d407a87ab197537ccc931c143c9927458a75f; tracked source unchanged.
Normal public consumer build: exit0; SDK1.2.0; official registry and existing warm cache.
Binary: source/tests/session_lifecycle/target/release/bin/main
SHA256: 6448608e02572b788a162ddf1dcb25d4401d378ad6e2e1aa0c90d97d33529c12
Build/runtime provenance: raw/{build-provenance,runtime-provenance}.json.
First runtime attempts omitted SDK runtime env; loader127 retained. Fresh r2 launches sourced envsetup.sh, no rebuild.
Finite Auto: 64/64 processes exit0; 63 safe rows ×2 runs plus1 destroyed endpoint.
Finite Declared: 64/64 processes exit0; 63 safe rows ×2 runs plus1 destroyed endpoint.
Both destroyed endpoints: actual read0/EOF(-4), EIO/unavailable post-termios; no restoration/restart claim.
prepare-check and both frozen oracle fixture sets: exit0, expected negative mutations rejected.
Nested real kernel PTYs: four positive runner0; child-drift expected negative runner1/direct child0; wrapper0.
GUI actual XTerm398 and XFCE4Terminal1.1.4/libVTE0.80.1: 13 exits ×visible/hidden×2 hosts =52 rows, all direct/runner0.
Each row: fixed host oracle, actual before/after DECRQM, full same-child termios/native resources and second-run isolation.
Requested prior2004 off/on separately confirmed by actual probes; owned disable confirmed, not preservation of prior on.
Default Auto/no optional title requests; actual X11 title properties preserved.
Original active-layer, restart, restored PNGs; prevented rows add live prevented original.
Host PID/executable/hash/argv/library maps/config/geometry, native files, raw wire/input/timing and direct.exit retained per row.
Catalogue: raw/gui-summary.json; finite facts: raw/finite-summary.json; complete hashes: index.json.
VT work belongs to separate parent-dispatched executor; this evidence makes no VT/M1/final020/Linux/release verdict.
No source/test/spec/main edits, SDK/cache copies, push or ad-hoc cleanup.
'''
(B/'report.md').write_text(report)
files={}
for base in [R,B/'tools']:
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.is_symlink():files[str(p.relative_to(B))]={'sha256':sha(p),'bytes':p.stat().st_size}
files['report.md']={'sha256':sha(B/'report.md'),'bytes':(B/'report.md').stat().st_size}
index={'schema':1,'status':'execution-evidence-sealed; independent acceptance pending','utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip(),'sourceDiff':subprocess.check_output(['git','-C',str(S),'diff'],text=True),'binary':str(S/'tests/session_lifecycle/target/release/bin/main'),'binarySha256':sha(S/'tests/session_lifecycle/target/release/bin/main'),'files':files}
assert index['sourceDiff']==''
(B/'index.json').write_text(json.dumps(index,indent=2)+'\n')
print('sealed',len(files),'files',sum(len(r['pngs']) for r in rows),'PNG',sha(B/'index.json'))
