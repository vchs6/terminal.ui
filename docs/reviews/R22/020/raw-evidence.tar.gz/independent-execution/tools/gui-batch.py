import pathlib,subprocess,json,os
B=pathlib.Path('/workspace/work/session-lifecycle-execution');cases=['stop','ctrl-c','prevented','signal-int','signal-term','callback','getter','draw','post','cleanup','callback-cleanup','close','callback-close'];results=[]
for host in ['xterm','vte']:
 for cursor in ['visible','hidden']:
  for case in cases:
   if host=='xterm' and cursor=='visible' and case=='stop':continue
   paste='on' if cursor=='hidden' else 'off'
   log=B/'raw'/('launch-'+host+'-'+cursor+'-'+case+'.log')
   with log.open('wb') as stream:r=subprocess.run(['python',str(B/'tools/gui.py'),host,cursor,case,paste],stdout=stream,stderr=subprocess.STDOUT)
   results.append({'host':host,'cursor':cursor,'case':case,'exit':r.returncode,'log':str(log)})
   (B/'raw/gui-batch-progress.json').write_text(json.dumps(results,indent=2))
   if r.returncode:raise SystemExit(r.returncode)
