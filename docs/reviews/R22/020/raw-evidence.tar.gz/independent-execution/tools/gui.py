import os,pathlib,subprocess,time,json,shlex,signal,hashlib,sys,datetime
sys.path.insert(0,'/workspace/work/keyboard-execution/tools');from xtest import Keyboard, X
import ctypes
B=pathlib.Path('/workspace/work/session-lifecycle-execution');host,cursor,case,paste=sys.argv[1:];out=B/'raw'/('gui-r2-'+host+'-'+cursor+'-'+case);out.mkdir();home=out/'home';home.mkdir();env=dict(os.environ,DISPLAY=':199',HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'),LANG='C.UTF-8',LC_ALL='C.UTF-8',CJTUI_020_ROOT_GO='1',CJTUI_020_ADMISSION='/workspace/work/terminal.ui/.superpowers/sdd/tasks-complete-linux-integration/task-020-input-manifest.json')
for k in ['XAUTHORITY','DBUS_SESSION_BUS_ADDRESS','SESSION_MANAGER','GTK_MODULES','CJTUI_020_HOST_TITLE_STRESS']:env.pop(k,None)
os.environ['DISPLAY']=':199';keyboard=Keyboard();title='TASK020 '+host+' '+cursor+' '+case
binary=B/'source/tests/session_lifecycle/target/release/bin/main';child=['python3',str(B/'tools/gui-supervisor.py'),str(out),cursor,case,str(binary),paste]
cmd=['/workspace/work/cross-terminal-recon/hosts/xterm/usr/bin/xterm','-geometry','60x12+20+20','-T',title,'-fa','DejaVu Sans Mono','-fs','16','-e',*child] if host=='xterm' else ['dbus-run-session','--','xfce4-terminal','--disable-server','--hide-menubar','--geometry=60x12+20+20','--title='+title,'--command='+shlex.join(child)]
(out/'launch.json').write_text(json.dumps(dict(argv=cmd,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),config={k:env[k] for k in ['DISPLAY','HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']}),indent=2)+'\n')
p=subprocess.Popen(cmd,env=env,stdout=(out/'host.stdout').open('wb'),stderr=(out/'host.stderr').open('wb'),start_new_session=True);events=[];C=out/'child'
def wait(fn,label):
 end=time.monotonic()+20
 while time.monotonic()<end:
  if fn():return
  if p.poll() is not None:raise RuntimeError('host exited before '+label)
  time.sleep(.02)
 raise TimeoutError(label)
def file(n):return (C/n).read_text() if (C/n).exists() else ''
def raw():return (C/'wire.bin').read_bytes() if (C/'wire.bin').exists() else b''
def key(*names):keyboard.chord(*names);events.append(dict(keys=list(names),monotonic_ns=time.monotonic_ns()))
def capture(name):
 focus=ctypes.c_ulong(); revert=ctypes.c_int(); X.XGetInputFocus.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong),ctypes.POINTER(ctypes.c_int)]; X.XGetInputFocus(keyboard.display,ctypes.byref(focus),ctypes.byref(revert)); assert focus.value==int(win,16), ('capture focus',focus.value,win); events.append(dict(actual_focus=hex(focus.value),capture_window=win,monotonic_ns=time.monotonic_ns())); (out/(name+'-title.txt')).write_text(subprocess.check_output(['xprop','-display',':199','-id',win,'_NET_WM_NAME','WM_NAME'],text=True))
 subprocess.run(['import','-display',':199','-window',win,str(out/(name+'.png'))],env=env,check=True,timeout=10);events.append(dict(capture=name,monotonic_ns=time.monotonic_ns()))
def probe(n):
 expected='original-'+cursor;end=time.monotonic()+10
 while file('probe-'+str(n))!=expected and time.monotonic()<end:key('r')
 assert file('probe-'+str(n))==expected,('actual host probe',file('probe-'+str(n)))
try:
 wait(lambda:(C/'pid').exists(),'direct child pid');tree=subprocess.check_output(['xwininfo','-display',':199','-root','-tree'],env=env,text=True);(out/'window-tree.txt').write_text(tree);win=next(line.split()[0] for line in tree.splitlines() if title in line);keyboard.focus(win)
 identities=[]
 for row in subprocess.check_output(['ps','-eo','pid,comm,args'],text=True).splitlines():
  f=row.strip().split(None,2)
  if len(f)==3 and title in f[2] and f[1] in ['xterm','xfce4-terminal']:
   pid=int(f[0]);exe=pathlib.Path('/proc',str(pid),'exe').resolve();maps=pathlib.Path('/proc',str(pid),'maps').read_text();(out/('maps-'+str(pid)+'.txt')).write_text(maps);libs=sorted(set(x.split()[-1] for x in maps.splitlines() if 'libvte-' in x));identities.append(dict(pid=pid,exe=str(exe),exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),vte={v:hashlib.sha256(pathlib.Path(v).read_bytes()).hexdigest() for v in libs},argv=pathlib.Path('/proc',str(pid),'cmdline').read_bytes().decode().split('\0')))
 (out/'host-identity.json').write_text(json.dumps(dict(identities=identities,version=subprocess.check_output(['/workspace/work/cross-terminal-recon/hosts/xterm/usr/bin/xterm','-version'] if host=='xterm' else ['xfce4-terminal','--version'],env=env,text=True),geometry=subprocess.check_output(['xwininfo','-display',':199','-id',win],text=True),title_before=subprocess.check_output(['xprop','-display',':199','-id',win,'_NET_WM_NAME','WM_NAME'],text=True)),indent=2))
 probe(1);key('o');wait(lambda:b'LAYER1' in raw(),'rendered layer');capture('active-layer');key('s');wait(lambda:file('state-1')=='original-'+cursor,'first readiness')
 if case in ['callback','getter','draw','post','callback-cleanup','callback-close']:key('x')
 elif case in ['signal-int','signal-term']:
  pid=int(file('pid'));sig=signal.SIGINT if case=='signal-int' else signal.SIGTERM;os.kill(pid,sig);events.append(dict(signal=sig.name,pid=pid,monotonic_ns=time.monotonic_ns()))
 elif case in ['ctrl-c','prevented']:
  key('Control_L','c')
  if case=='prevented':wait(lambda:file('prevented')=='yes','prevented Ctrl-C');assert not (C/'closed-1').exists();os.kill(int(file('pid')),0);capture('prevented');key('q')
 else:key('q')
 wait(lambda:file('closed-1')=='0/0/0/0','first closed');probe(2);key('s');wait(lambda:file('state-2')=='original-'+cursor,'restart readiness');capture('restart');key('q');wait(lambda:(out/'runner.exit').exists(),'runner direct exit');capture('restored')
 result={'runner_exit':int((out/'runner.exit').read_text()),'direct_exit':int(file('direct.exit')),'events':events,'title_after':subprocess.check_output(['xprop','-display',':199','-id',win,'_NET_WM_NAME','WM_NAME'],text=True)};(out/'result.json').write_text(json.dumps(result,indent=2));assert result['runner_exit']==result['direct_exit']==0
 (out/'release').write_text('yes');p.wait(timeout=10)
except BaseException as e:(out/'failure.json').write_text(json.dumps(dict(error=repr(e),events=events),indent=2));raise
finally:
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
print(host,cursor,case,'exit0')
