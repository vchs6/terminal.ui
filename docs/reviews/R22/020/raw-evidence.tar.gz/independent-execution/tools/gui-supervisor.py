import os,pathlib,subprocess,sys,time,json
root=pathlib.Path('/workspace/work/session-lifecycle-execution'); out=pathlib.Path(sys.argv[1]); cursor=sys.argv[2];case=sys.argv[3];binary=sys.argv[4]
os.write(1,b'\x1b[?25h' if cursor=='visible' else b'\x1b[?25l')
os.write(1,b'\x1b[?2004h' if sys.argv[5]=='on' else b'\x1b[?2004l')
(out/'environment.json').write_text(json.dumps({'TERM':os.environ.get('TERM'),'tty':os.ttyname(0),'uname':list(os.uname()),'requested_prior25':cursor,'requested_prior2004':sys.argv[5],'geometry':subprocess.check_output(['stty','size'],text=True)},indent=2))
rc=subprocess.call(['bash',str(root/'source/tests/session_lifecycle/host_run.sh'),binary,str(out/'child'),case])
(out/'runner.exit').write_text(str(rc))
end=time.monotonic()+30
while not (out/'release').exists() and time.monotonic()<end:time.sleep(.02)
sys.exit(rc)
