#!/bin/sh
export PATH=/bin TERM=linux LD_LIBRARY_PATH=/lib/x86_64-linux-gnu LC_ALL=C.UTF-8 PYTHONHOME=/py PYTHONDONTWRITEBYTECODE=1
mount -t devtmpfs devtmpfs /dev
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mkdir -p /evidence
/bin/busybox chown 1000:1000 /dev/tty1 /evidence
cat /proc/cmdline >/evidence/boot-cmdline.txt
cat /sys/module/vt/parameters/default_utf8 >/evidence/vt-default-utf8.txt
scene=stop
for arg in $(cat /proc/cmdline); do case "$arg" in scene=*) scene=${arg#scene=};; esac; done
export CJTUI_020_CASE=$scene CJTUI_020_OUTPUT=/evidence CJTUI_020_HOST_AUTO=1 CJTUI_SESSION_NATIVE=/evidence/native.tsv CJTUI_SESSION_CLOSE_FAIL=0
case "$scene" in close|callback-close) export CJTUI_SESSION_CLOSE_FAIL=1;; esac
setsid sh -c 'exec /vt-supervisor '"$scene"' </dev/tty1 >/dev/tty1 2>&1'
echo INIT_CHILD_EXIT=$? >/dev/ttyS0
echo EVIDENCE_TAR_BASE64_BEGIN >/dev/ttyS0
tar -C /evidence -cf - . | base64 >/dev/ttyS0
echo EVIDENCE_TAR_BASE64_END >/dev/ttyS0
poweroff -f
