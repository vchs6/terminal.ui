import pathlib,gzip,hashlib,json,subprocess,stat,sys
B=pathlib.Path('/workspace/work/session-lifecycle-vt-execution');base=pathlib.Path('/workspace/work/viewport-execution/packages/vt-viewport.cpio.gz');binary=pathlib.Path('/workspace/work/session-lifecycle-execution/source/tests/session_lifecycle/target/release/bin/main');dest=B/'payload-v2.cpio.gz'
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='6448608e02572b788a162ddf1dcb25d4401d378ad6e2e1aa0c90d97d33529c12'
code="import sys;sys.path.insert(0,'"+str(B/'source/tests/session_lifecycle')+"');import host_probe,encodings.utf_8,encodings.ascii,encodings.latin_1;print('\\n'.join(sorted({m.__file__ for m in sys.modules.values() if getattr(m,'__file__',None) and m.__file__.startswith('/usr/lib/python3.13/')})))"
files=subprocess.check_output(['/usr/bin/python3','-S','-c',code],text=True).splitlines();replacements={'init':B/'tools/vt-init.sh','vt-supervisor':B/'tools/vt-supervisor','apps/lifecycle':binary,'py/bin/python3':pathlib.Path('/usr/bin/python3.13'),'fixture/host_probe.py':B/'source/tests/session_lifecycle/host_probe.py'}
for p in files:
 p=pathlib.Path(p);replacements['py/lib/python3.13/'+str(p.relative_to('/usr/lib/python3.13'))]=p
for p in list(replacements.values()):
 if p.read_bytes()[:4]!=b'\x7fELF':continue
 result=subprocess.run(['ldd',str(p)],capture_output=True,text=True)
 for line in result.stdout.splitlines():
  fields=line.split();libs=[x for x in fields if x.startswith('/')]
  for lib in libs:
   path=pathlib.Path(lib);replacements['lib/x86_64-linux-gnu/'+path.name]=path
records=[];seen=set();dirs=set()
with gzip.open(base,'rb') as inp,gzip.GzipFile(filename=str(dest),mode='wb',mtime=0) as out:
 def emit(name,mode,data,source):
  if name in seen:return
  parent=str(pathlib.PurePosixPath(name).parent)
  if parent!='.' and parent not in seen:emit(parent,stat.S_IFDIR|0o755,b'','generated parent')
  seen.add(name);nb=name.encode()+b'\0';fields=[len(records)+1,mode,0,0,1,0,len(data),0,0,0,0,len(nb),0];blob=b'070701'+b''.join(f'{x:08x}'.encode() for x in fields)+nb;blob+=b'\0'*(-len(blob)%4);blob+=data;blob+=b'\0'*(-len(data)%4);out.write(blob);records.append(dict(source=source,guest='/'+name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 while True:
  header=inp.read(110);assert header[:6]==b'070701';f=[int(header[6+i*8:14+i*8],16) for i in range(13)];size,nsize=f[6],f[11];name=inp.read(nsize)[:-1].decode();inp.read(-(110+nsize)%4);data=inp.read(size);inp.read(-size%4)
  if name=='TRAILER!!!':break
  if name.startswith('apps/') or name in ('deny-map','dlmopen-check','font-map','vt-product-supervisor'):continue
  if name in replacements:continue
  emit(name,f[1],data,str(base)+'!'+name)
 for name,p in replacements.items():emit(name,stat.S_IFREG|0o755,p.read_bytes(),str(p))
 emit('TRAILER!!!',0,b'','cpio terminator')
(B/'raw/payload-v2-manifest.json').write_text(json.dumps(dict(base=str(base),base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),archive=str(dest),archive_bytes=dest.stat().st_size,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),members=records),indent=2)+'\n')
print(json.dumps(dict(archive_bytes=dest.stat().st_size,members=len(records),uncompressed_bytes=sum(x['bytes'] for x in records))))
