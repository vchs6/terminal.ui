import pathlib,os,time,json,datetime
b=pathlib.Path('/workspace/work/session-lifecycle-vt-execution');expected=json.loads((b/'source/tests/session_lifecycle/cases.json').read_text())['cases'][:13]
with (b/'raw/resource-samples.jsonl').open('a') as f:
 while True:
  v=os.statvfs(b);f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=v.f_bavail*v.f_frsize,completed=sum((b/'raw'/('vt-'+x['id'])/'result.json').exists() for x in expected)))+'\n');f.flush()
  if all((b/'raw'/('vt-'+x['id'])/'raw-compression.json').exists() for x in expected):break
  if any((b/'raw'/('vt-'+x['id'])/'failure.json').exists() for x in expected):break
  time.sleep(1)
