import pathlib,json,gzip,hashlib,re,subprocess,datetime,os
from PIL import Image,ImageChops
B=pathlib.Path('/workspace/work/session-lifecycle-vt-execution');binary=pathlib.Path('/workspace/work/session-lifecycle-execution/source/tests/session_lifecycle/target/release/bin/main');cases=json.loads((B/'source/tests/session_lifecycle/cases.json').read_text())['cases'][:13]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def text(path):return gzip.decompress(path.read_bytes()).decode() if path.suffix=='.gz' else path.read_text()
rows=[];screens=0
for case in cases:
 out=B/'raw'/('vt-'+case['id']);r=json.loads((out/'result.json').read_text());assert (r['verifier_exit'],r['product_exit'],r['qemu_exit'])==(0,0,0);assert not (out/'failure.json').exists()
 for entry in json.loads((out/'raw-compression.json').read_text()):
  data=gzip.decompress((out/entry['lossless_gzip']).read_bytes());assert len(data)==entry['original_bytes'] and hashlib.sha256(data).hexdigest()==entry['original_sha256']
 for png in out.glob('*.png'):
  ppm=png.with_suffix('.ppm');a=Image.open(ppm).convert('RGB');b=Image.open(png).convert('RGB');assert ImageChops.difference(a,b).getbbox() is None;screens+=1
 serial=text(out/'serial.log.gz');trace=text(out/'evidence/product.strace.gz');pid=r['product_pid'];signals=re.findall(r'ACTUAL_SIGNAL[^\r\n]+',serial)
 host=re.search(r'^HOST .*$',serial,re.M)[0];app=re.search(r'^PRODUCT_ID .*$',serial,re.M)[0];font=re.search(r'^FONT .*$',serial,re.M)[0];assert 'tty=/dev/tty1 rdev=4:1' in host and 'grid=80x25' in host and 'stdin=/dev/tty1 stdout=/dev/tty1' in app
 snapshots=[json.loads((out/'evidence'/f'native-termios-before-{n}.json').read_text()) for n in (1,2)];assert all(x['endpoint']['rdev']==1025 for x in snapshots)
 device=[line[:500] for line in trace.splitlines() if re.match(r'^'+str(pid)+r'\s+ioctl\(1, (KDGETMODE|GIO_UNIMAP)',line)];assert len(device)==4
 launch=json.loads((out/'launch.json').read_text());payload=pathlib.Path(launch['argv'][launch['argv'].index('-initrd')+1]);assert sha(payload)==launch['payload_sha256']
 rows.append(dict(case=case['id'],result=str((out/'result.json').relative_to(B)),frozen_oracle_result=str((out/'evidence/host-check.json').relative_to(B)),host=host,app=app,font=font,actual_signals=signals,device_probe_trace_lines=device,actual_consumer_pid=pid,consumer_exit=r['product_exit'],qemu_exit=r['qemu_exit'],oracle_exit=r['verifier_exit'],payload=str(payload),payload_sha256=sha(payload),runner_version='tools/run-v1.py' if case['id']=='stop' else ('tools/run-v1b.py' if payload.name=='payload.cpio.gz' else 'tools/run-v2.py'),native_endpoint=snapshots[0]['endpoint']))
assert sha(binary)=='6448608e02572b788a162ddf1dcb25d4401d378ad6e2e1aa0c90d97d33529c12'
assert subprocess.check_output(['git','-C',str(B/'source'),'rev-parse','HEAD'],text=True).strip()=='e35d407a87ab197537ccc931c143c9927458a75f'
assert not subprocess.check_output(['git','-C',str(B/'source'),'diff','--name-only'],text=True)
resources=[json.loads(line) for line in (B/'raw/resource-samples.jsonl').read_text().splitlines()];minimum=min(x['free_bytes'] for x in resources)
report=f'''Executed the frozen 13 ordinary lifecycle cases on actual Linux kernel VT tty1 (VM, not physical hardware).
Source e35d407a87ab197537ccc931c143c9927458a75f; independent producer build exit0; consumer SHA256 {sha(binary)}.
All 13 recorded consumer exits, QEMU exits and unchanged host_verify.py exits are0; no product/test/spec changes or Cangjie rebuild.
Every consumer fd0/fd1 is direct /dev/tty1, rdev4:1; no script/inner PTY. Native snapshots plus KDGETMODE/GIO_UNIMAP strace retained.
Kernel Linux6.12.107+deb13-amd64; QEMU10.0.13 TCG/max/pc/oneCPU/512MiB; tty1 active, fixed80x25, TERM=linux, UTF8=1, uid/euid1000.
Default kernel console font metadata8x16/256glyphs; actual console720x400; bootargs, font buffer and ABI/tool context retained.
Actual QMP keyboard generated r/o/s plus q/x/CtrlC; SIGINT/TERM delivered in guest to actual tested PID, with successful kill and child wait recorded.
Both runs per case retain exact same-child full Linux termios fields/endpoint, native handlers/flags/masks, owner, buffer/free and public resources/restart files.
Actual mode25/2004 queries returned empty before/after. Cursor physical visibility remains Unknown; zero25h/l/s/r; own2004h/l exactly twice, prior2004 restoration unclaimed.
Auto/NoTitleRequest and NoImageAdapterUnsupported verified by frozen consumer; no title scope or injected replies/TERM substitutions.
{screens} original QMP PPMs plus pixel-identical lossless PNG conversions retain active/layer/restart/afterrestore states; prevented case adds live prevented state.
Raw serial/strace/tar are retained as lossless gzip with original-byte SHA256 and checked decompression; native/public/wire/input files are retained directly.
Immutable v1/v2 guest payloads and full member source/destination byte/SHA manifests retained; v2 changes only post-test tar export compression.
Guest Python closure runs the exact frozen host_probe.py; util-linux script was neither packaged nor invoked because transport is direct VT.
Minimum free disk sampled during the monitored remainder: {minimum} bytes; final local evidence size is indexed; no disk block/retry occurred.
Scope: these13 surviving-endpoint ordinary VT rows only. Separate matrix/GUI, destroyed-endpoint, accepted unchanged unsafe-output scopes and independent acceptance remain separate.
No M1/AC020/041, full-Linux or release verdict is made here.
'''
(B/'report.md').write_text(report)
files=[]
for root in ['tools','raw']:
 for p in sorted((B/root).rglob('*')):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:files.append(dict(path=str(p.relative_to(B)),bytes=p.stat().st_size,sha256=sha(p)))
for rel in subprocess.check_output(['git','-C',str(B/'source'),'ls-files'],text=True).splitlines():
 p=B/'source'/rel
 if p.is_file():files.append(dict(path='source/'+rel,bytes=p.stat().st_size,sha256=sha(p)))
for p in [B/'report.md',B/'payload.cpio.gz',B/'payload-v2.cpio.gz']:
 files.append(dict(path=str(p.relative_to(B)),bytes=p.stat().st_size,sha256=sha(p)))
index=dict(schema=1,role='independent actual Linux VT transport execution only',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source='e35d407a87ab197537ccc931c143c9927458a75f',source_tracked_diff='',producer_binary=str(binary),producer_binary_bytes=binary.stat().st_size,producer_binary_sha256=sha(binary),build_provenance='raw/build-provenance.json',scope='first13 frozen ordinary cases; actual VM kernel console, no acceptance verdict',frozen_oracle='source/tests/session_lifecycle/host_verify.py',cases=rows,original_ppm_count=screens,png_conversion='Pillow lossless format conversion only; pixel equality checked against every QMP PPM original',compressed_raw='Original-byte lengths/SHA256 and gzip lengths/SHA256 in each raw-compression.json; all decompressions checked',resources=dict(minimum_monitored_free_bytes=minimum,final_free_bytes=os.statvfs(B).f_bavail*os.statvfs(B).f_frsize,no_space_block=True),transport=dict(consumer='direct /dev/tty1 fd0/fd1; no inner PTY',observer='serial file/control sockets only; does not inject terminal input',keyboard='QMP actual emulated keyboard -> Linux kernel VT',guest_signal='kill actual consumer PID, not VM termination',capture='QMP actual VGA screendump PPM, PNG lossless conversion; no ANSI redraw',payload_v1='payload.cpio.gz',payload_v2='payload-v2.cpio.gz',difference='v2 init compresses completed evidence tar before serial base64; binary/runtime/frozen fixture/C supervisor unchanged'),skills=['superpowers:using-superpowers (subagent exemption)','superpowers:verification-before-completion'],limits=['No physical hardware','mode25 physical visibility Unknown','prior2004 Unknown; owned request cleanup only','No title request/scope','No final acceptance or full Linux/release claim'],files=files)
(B/'index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(dict(cases=len(rows),all_exits_zero=True,ppm_png_pairs=screens,index_sha256=sha(B/'index.json'),report_lines=len(report.splitlines()),minimum_monitored_free_bytes=minimum,source_tracked_diff='')))
