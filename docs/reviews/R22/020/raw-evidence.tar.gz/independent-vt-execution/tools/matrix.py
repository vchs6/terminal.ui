import subprocess,sys,pathlib,json,os,time
B=pathlib.Path('/workspace/work/session-lifecycle-vt-execution');cases=json.loads((B/'source/tests/session_lifecycle/cases.json').read_text())['cases'][:13]
for case in cases:
 if case['id']=='stop':continue
 free=os.statvfs(B).f_bavail*os.statvfs(B).f_frsize
 if free<30*1024*1024:raise RuntimeError('concrete space block: '+str(free)+' bytes free; >=30MiB temporary row required')
 run=subprocess.run([sys.executable,str(B/'tools/run.py'),case['id']]);print('MATRIX row='+case['id']+' command_exit='+str(run.returncode)+' free_bytes='+str(free),flush=True)
 if run.returncode:sys.exit(run.returncode)
