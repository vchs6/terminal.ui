import os,pathlib,subprocess,time,socket,json,re,base64,tarfile,io,hashlib,sys,datetime
sys.path.insert(0,'/workspace/work/keyboard-execution/tools');from trace_bytes import extract
from PIL import Image
B=pathlib.Path('/workspace/work/session-lifecycle-vt-execution');case=sys.argv[1];out=B/'raw'/('vt-'+case);out.mkdir(exist_ok=False);host=pathlib.Path('/workspace/work/linux-console-hosts');env=dict(os.environ,LD_LIBRARY_PATH=str(host/'hosts/debian/usr/lib/x86_64-linux-gnu'))
cmd=[str(host/'hosts/debian/usr/bin/qemu-system-x86_64'),'-accel','tcg','-cpu','max','-machine','pc','-m','512','-smp','1','-no-reboot','-nic','none','-L',str(host/'hosts/debian/usr/share/qemu'),'-bios',str(host/'hosts/debian/usr/share/seabios/bios-256k.bin'),'-device','VGA,romfile='+str(host/'hosts/debian/usr/share/seabios/vgabios-stdvga.bin'),'-vga','none','-display','none','-serial','file:'+str(out/'serial.log'),'-chardev','socket,id=probe,path='+str(out/'control.sock')+',server=on,wait=off','-serial','chardev:probe','-qmp','unix:'+str(out/'qmp.sock')+',server=on,wait=off','-kernel',str(host/'packages/linux'),'-initrd',str(B/'payload-v2.cpio.gz'),'-append','console=tty0 console=ttyS0,115200 rdinit=/init nomodeset vga=normal loglevel=4 scene='+case]
(out/'launch.json').write_text(json.dumps(dict(argv=cmd,virtual_hardware=True,connection='QEMU keyboard -> Linux VT tty1 -> consumer fd0/fd1 directly; serial observer carries no keyboard bytes',source='e35d407a87ab197537ccc931c143c9927458a75f',binary_sha256='6448608e02572b788a162ddf1dcb25d4401d378ad6e2e1aa0c90d97d33529c12',kernel_sha256=hashlib.sha256((host/'packages/linux').read_bytes()).hexdigest(),payload_sha256=hashlib.sha256((B/'payload-v2.cpio.gz').read_bytes()).hexdigest(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),disk_free_start=os.statvfs(B).f_bavail*os.statvfs(B).f_frsize),indent=2)+'\n')
p=subprocess.Popen(cmd,env=env,stdout=(out/'qemu.stdout').open('wb'),stderr=(out/'qemu.stderr').open('wb'));q=None;control=None;log=None;events=[]
def serial():return (out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
def wait(fn,label,seconds=60,allow_exit=False):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  value=fn()
  if value:return value
  if p.poll() is not None and not allow_exit:raise RuntimeError('VM ended before '+label)
  time.sleep(.03)
 raise TimeoutError(label)
try:
 wait(lambda:(out/'qmp.sock').exists(),'QMP socket');q=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);q.settimeout(10);q.connect(str(out/'qmp.sock'));f=q.makefile('rwb',buffering=0);log=(out/'qmp.jsonl').open('w');seq=0
 def receive():
  d=json.loads(f.readline());log.write(json.dumps(dict(receive=d,monotonic_ns=time.monotonic_ns()))+'\n');log.flush();return d
 def command(name,args=None):
  global seq
  seq+=1;d=dict(execute=name,id=seq)
  if args:d['arguments']=args
  log.write(json.dumps(dict(send=d,monotonic_ns=time.monotonic_ns()))+'\n');log.flush();f.write((json.dumps(d)+'\n').encode())
  while True:
   r=receive()
   if r.get('id')==seq:
    if 'error' in r:raise RuntimeError(r)
    return r
 receive();command('qmp_capabilities');command('query-version');command('query-kvm');wait(lambda:'TRACER_PID=' in serial(),'probe/consumer start');control=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);control.connect(str(out/'control.sock'))
 def key(*keys):
  for down,order in [(True,keys),(False,reversed(keys))]:
   for name in order:command('input-send-event',dict(events=[dict(type='key',data=dict(down=down,key=dict(type='qcode',data=name)))]))
  events.append(dict(keys=list(keys),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),monotonic_ns=time.monotonic_ns()))
 def observe():
  old=len(re.findall(r'DUMP_DONE seq=',serial()));control.sendall(b's');wait(lambda:len(re.findall(r'DUMP_DONE seq=',serial()))>old,'native observer response',5)
  text=serial();grids=re.findall(r'GRID seq=\d+ phase=\S+ n=(\d+) hex=([0-9a-f]+)',text);raw=bytes.fromhex(grids[-1][1]) if grids else b''
  files={name:bytes.fromhex(data).decode(errors='replace') for name,data in re.findall(r'ACK seq=\d+ name=(\S+) hex=([0-9a-f]+)',text)}
  if 'assertion' in files:raise RuntimeError('frozen consumer assertion: '+files['assertion'])
  return raw,files
 def wait_file(name,value=None):
  def observed():
   raw,files=observe();return files.get(name) if value is None else files.get(name)==value
  return wait(observed,'public file '+name+'='+str(value))
 def wait_cells(marker):return wait(lambda:marker in observe()[0][4::2],'native cells '+repr(marker))
 def capture(name):
  raw,files=observe();(out/(name+'-vcsa.bin')).write_bytes(raw);command('screendump',dict(filename=str(out/(name+'.ppm')),format='ppm'));Image.open(out/(name+'.ppm')).save(out/(name+'.png'));events.append(dict(capture=name,monotonic_ns=time.monotonic_ns()))
 wait_cells(b'BASE');capture('active');key('r');wait_file('probe-1','unknown-timeout');key('o');wait_file('opened','queued');wait_cells(b'LAYER1');capture('layer');key('s');wait_file('state-1','unknown-timeout')
 if case in ('signal-int','signal-term'):
  control.sendall(b'i' if case=='signal-int' else b't');wait(lambda:'ACTUAL_SIGNAL pid=' in serial(),'actual guest signal')
 elif case in ('ctrl-c','prevented'):
  key('ctrl','c')
  if case=='prevented':wait_file('prevented','yes');capture('prevented');key('q')
 elif case in ('callback','getter','draw','post','callback-cleanup','callback-close'):key('x')
 else:key('q')
 wait_file('closed-1','0/0/0/0');wait_cells(b'NEXT');key('r');wait_file('probe-2','unknown-timeout');key('s');wait_file('state-2','unknown-timeout');capture('restart');key('q')
 wait(lambda:'EXIT_CAPTURE_BARRIER' in serial(),'actual exit plus frozen after probe');capture('restored');control.sendall(b'e');wait(lambda:'EVIDENCE_TAR_BASE64_END' in serial(),'guest raw export',allow_exit=True);qexit=p.wait(timeout=20);text=serial();block=text.split('EVIDENCE_TAR_BASE64_BEGIN',1)[1].split('EVIDENCE_TAR_BASE64_END',1)[0];compressed=base64.b64decode(''.join(block.split()));(out/'guest-export.tar.gz').write_bytes(compressed);data=__import__('gzip').decompress(compressed);(out/'guest-evidence.tar').write_bytes(data)
 with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(out/'evidence',filter='data')
 trace=(out/'evidence/product.strace').read_text();inp,ins=extract(trace,0,'read');wire,outs=extract(trace);(out/'evidence/input.bin').write_bytes(inp);(out/'evidence/wire.bin').write_bytes(wire)
 check=subprocess.run([sys.executable,str(B/'source/tests/session_lifecycle/host_verify.py'),'--output',str(out/'evidence'),'--case',case],capture_output=True,text=True);(out/'verify.stdout').write_text(check.stdout);(out/'verify.stderr').write_text(check.stderr)
 encoded=''.join('\\x%02x'%x for x in b'/apps/lifecycle');m=re.search(r'^(\d+)\s+execve\("'+re.escape(encoded)+r'".* = 0$',trace,re.M);pid=int(m[1]) if m else None;ex=re.search(r'^'+str(pid)+r'\s+\+\+\+ exited with (\d+) \+\+\+$',trace,re.M);product_exit=int(ex[1]) if ex else None
 result=dict(case=case,verifier_exit=check.returncode,qemu_exit=qexit,product_pid=pid,product_exit=product_exit,events=events,wire_stats=dict(input=ins,output=outs),actual_endpoint='direct /dev/tty1, character device 4:1 (native snapshots and strace)',virtual_hardware=True,cursor_physical_visibility='Unknown (no actual DECRQM response; zero 25 h/l/s/r)',mode2004='Unknown prior; owned h/l checked, original state restoration not claimed',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),disk_free_end=os.statvfs(B).f_bavail*os.statvfs(B).f_frsize);(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 if check.returncode or product_exit!=0 or qexit!=0 or ins['unparsedTarget'] or outs['unparsedTarget']:raise RuntimeError('actual execution/verifier result '+str(result))
 subprocess.run([sys.executable,str(B/'tools/compress.py'),str(out)],check=True)
 print(json.dumps(dict(case=case,verifier_exit=check.returncode,product_exit=product_exit,endpoint='direct tty1')))
except BaseException as e:
 (out/'failure.json').write_text(json.dumps(dict(error=repr(e),events=events),indent=2)+'\n');raise
finally:
 if control:control.close()
 if q:q.close()
 if log:log.close()
 if p.poll() is None:p.terminate();p.wait(timeout=10)
