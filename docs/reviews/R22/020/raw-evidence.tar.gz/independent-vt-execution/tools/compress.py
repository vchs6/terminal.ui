import pathlib,gzip,hashlib,json,sys
out=pathlib.Path(sys.argv[1]);records=[]
for rel in ['serial.log','guest-evidence.tar','evidence/product.strace']:
 p=out/rel;data=p.read_bytes();dest=p.with_name(p.name+'.gz')
 with gzip.GzipFile(filename=str(dest),mode='wb',mtime=0) as f:f.write(data)
 assert gzip.decompress(dest.read_bytes())==data
 records.append(dict(original=rel,original_bytes=len(data),original_sha256=hashlib.sha256(data).hexdigest(),lossless_gzip=str(dest.relative_to(out)),compressed_bytes=dest.stat().st_size,compressed_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()));p.unlink()
(out/'raw-compression.json').write_text(json.dumps(records,indent=2)+'\n')
