# TASK021 independent PTY retry 3
- Source HEAD `03c719e99ae9854423f0339a70d668eccbc2f7d4` = fixed product `e3016afe` plus TESTONLY `6dbece66`, `d07a6933`, `95b6d780`; tracked diff empty.
- Reused original SDK 1.2.0 ELFs: minimal SHA256 `bf7da646f091436f0ef7bf3663b3a18d18436f73b0f8aec93be634c8a70f3a0e`, composition `69e94b7afac0670c1fac08183d6e75e76b4f140e89a97c2b3192cc572e2de0c1`. No rebuild or direct smoke rerun.
- `node tests/composition/application/pty.mjs` exit 1 (Node 24.22.1). Minimal and three startup sizes pass; interactions reach shared editor focus, log scroll/filter/sort, first real worker review, modal-blocked F6, second real completion and latest data after closing modal.
- Stop at `pty.mjs:235`: actual full row9 is `Done` plus 76 spaces = 80 columns with no stale phase tail; fixture expects `Done` plus 77 spaces = 81 columns. Remaining acknowledgement/resize/quit assertions and actual GUI not run.
- Original raw/events/frames and termios-before in `raw/pty-retry3/pty-BQP53p`; no direct normal exit/termios-after because assertion stopped the harness. Prior indexes and reports remain unchanged; `index-retry3.json` binds this attempt.
