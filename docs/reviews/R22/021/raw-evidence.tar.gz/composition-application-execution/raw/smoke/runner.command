node tests/composition/application/smoke.mjs
