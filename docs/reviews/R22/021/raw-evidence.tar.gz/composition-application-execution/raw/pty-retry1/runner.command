node tests/composition/application/pty.mjs
