#!/bin/sh
stty rows "$3" cols "$4"
stty -g > "$2/before"
tty > "$2/tty"
"$1" < /dev/tty &
p=$!
echo "$p" > "$2/pid"
wait "$p"
status=$?
printf "%s\n" "$status" > "$2/direct.exit"
stty -g > "$2/after"
exit "$status"
