# TASK021 independent execution, initial attempt
- Source HEAD `9c0bd3d6f0751a38dd0fdec9250d19d57770c0e8` = product `e3016afe` + test patch `6dbece66`; sparse source, tracked diff empty.
- SDK/CJPM 1.2.0; Node 24.22.1; official registry, shared read-only cache, fixed UCD archive and stdx environment.
- Ordinary `cjpm build` exit 0 in both `examples/minimal` and `examples/composition`; final ELF SHA256 in `raw/build/binaries.sha256`.
- `node tests/composition/application/smoke.mjs` exit 0: six direct-binary cases passed, including invalid argument nonzero exits.
- Initial PTY launcher exit 1 before app start because executor sparse checkout omitted fixed `tests/colors/pty.mjs`; exact stderr retained in `raw/pty`. Added only that sparse path.
- Corrected `node tests/composition/application/pty.mjs` retry exit 1: minimal and three startup sizes pass. Interactions stop at F3 Light background: expected `rgb:255,255,255`, observed `default` at cell 79,22. All 1918 Light-frame cells have default background; raw ANSI contains no `48;2` SGR.
- Failed interaction session has `before` termios and raw/events/frames, but app was killed by harness on assertion; it did not reach ordinary quit or `after` termios. Later functional steps and actual GUI remain untested.
- Original files and SHA256/byte bindings: `index-initial.json`; raw retry directory `raw/pty-retry1/pty-HiG4xF`.
