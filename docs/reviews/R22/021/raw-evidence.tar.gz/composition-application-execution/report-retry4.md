# TASK021 independent synthetic PTY retry 4
- Source HEAD `b77307b3b70423739f56855952c56acedbdc17b6` = product `e3016afe` plus TESTONLY `6dbece66`, `d07a6933`, `95b6d780`, `384a9005`; tracked diff empty.
- Reused SDK/CJPM 1.2.0 build ELFs without rebuilding: minimal SHA256 `bf7da646f091436f0ef7bf3663b3a18d18436f73b0f8aec93be634c8a70f3a0e`, composition `69e94b7afac0670c1fac08183d6e75e76b4f140e89a97c2b3192cc572e2de0c1`.
- `node tests/composition/application/pty.mjs` exit 0, Node 24.22.1, synthetic `xterm-256color` PTY with declared caret response: 5/5 cases pass, including full interaction, worker review/completion, acknowledgement, 80x24→40x12→16x6→80x24 and ordinary quit.
- All five direct binaries exited 0; each before/after termios file is byte equal. Actual GUI/VT host conclusions are outside this synthetic result and pending admission.
- Raw attempt `raw/pty-retry4/pty-kB448g`; 5 frame JSON files were losslessly gzip compressed before sealing, with original path/SHA256/bytes and gzip path/SHA256/bytes in `compression-map-retry4.json`. All recovered originals verified byte-for-byte.
- `index-retry4.json` binds compressed raw, map, configs, test inputs, ELF and prior sealed retry3 index/report. Prior attempts remain unchanged.
