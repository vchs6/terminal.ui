#!/usr/bin/python3
"""Own ordinary X11 selections long enough for a real terminal paste."""
import pathlib
import sys
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gdk, Gtk

text = sys.argv[1]
ready = pathlib.Path(sys.argv[2])
for selection in (Gdk.SELECTION_CLIPBOARD, Gdk.SELECTION_PRIMARY):
    clipboard = Gtk.Clipboard.get(selection)
    clipboard.set_text(text, -1)
ready.write_text('Gtk X11 PRIMARY and CLIPBOARD selection owned; UTF-8 bytes='+text.encode().hex()+'\n')
Gtk.main()
