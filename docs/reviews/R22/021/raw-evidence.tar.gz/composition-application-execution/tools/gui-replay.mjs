// Reuse the fixed composition PTY oracle against actual host stdout writes.
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {WireScreen} from '../source/tests/composition/application/pty.mjs';

const file=process.argv[2];
const raw=readFileSync(file);
const lines=(file.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8').split('\n');
const initialW=Number(process.argv[3]??80),initialH=Number(process.argv[4]??24);
const view=new WireScreen(initialW,initialH);
const sizes=[];let pending=null,w=initialW,h=initialH,writes=0,bytes=0;
for(const line of lines){
  const size=line.match(/^\d+ ioctl\(1, TIOCGWINSZ, \{ws_row=(\d+), ws_col=(\d+),/);
  if(size){
    const nextW=Number(size[2]),nextH=Number(size[1]);
    if(nextW!==w||nextH!==h){
      if(pending)throw Error(`unfinished resize ${pending}`);
      view.screen.beginResize(nextW,nextH);pending=[nextW,nextH];
      sizes.push({width:nextW,height:nextH,readback:'product ioctl(1,TIOCGWINSZ)'});
    }
  }
  const write=line.match(/^\d+ write\(1, "((?:\\x[0-9a-fA-F]{2})*)", (\d+)\) = (\d+)$/);
  if(write){
    const data=Buffer.from(write[1].replaceAll('\\x',''),'hex');
    if(data.length!==Number(write[2])||data.length!==Number(write[3]))throw Error('incomplete write');
    view.feed(data);writes++;bytes+=data.length;
    if(pending&&view.screen.targetComplete(...pending)){
      view.screen.finishResize(...pending);[w,h]=pending;pending=null;
    }
  }
}
if(pending)throw Error(`pending resize ${pending}`);
const rows=view.rows();
console.log(JSON.stringify({writes,bytes,sizes,width:w,height:h,rows:rows.map(row=>row.text),
  phaseForeground:rows[9]?.cells[0]?.fg}));
