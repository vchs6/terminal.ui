#!/usr/bin/python3
"""Poll actual product writes for a visible 80x24 predicate, recording the frame."""
import datetime
import json
import pathlib
import subprocess
import sys
import time

directory = pathlib.Path(sys.argv[1])
label = sys.argv[2]
need = sys.argv[3]
exclude = sys.argv[4] if len(sys.argv) > 4 else None
deadline = time.monotonic() + 10
extract = pathlib.Path(__file__).with_name('extract-strace.py')
screen = pathlib.Path(__file__).with_name('screen.mjs')
while time.monotonic() < deadline:
    subprocess.run(['python3',str(extract),str(directory/'product.strace'),str(directory/'stdout.raw')],
                   capture_output=True,check=True)
    result = subprocess.run(['node',str(screen),str(directory/'stdout.raw'),'80','24'],
                            capture_output=True,text=True)
    if result.returncode == 0:
        frame = json.loads(result.stdout)
        visible = '\n'.join(frame['rows'])
        if need in visible and (exclude is None or exclude not in visible):
            record = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      'label':label,'required':need,'excluded':exclude,
                      'rawBytes':(directory/'stdout.raw').stat().st_size,
                      'rows':frame['rows']}
            with (directory/'gui-frames.jsonl').open('a') as output:
                output.write(json.dumps(record,ensure_ascii=False)+'\n')
            print(label, 'PASS', 'rawBytes', record['rawBytes'])
            print('\n'.join(row.rstrip() for row in frame['rows'] if row.strip())[:1000])
            sys.exit(0)
    time.sleep(.1)
raise RuntimeError(f'visible predicate timeout: {label}: {need!r}, exclude={exclude!r}')
