#!/usr/bin/python3
"""Extract exact stdout write payloads from the host's preserved strace text."""
import pathlib
import re
import sys

source = pathlib.Path(sys.argv[1])
dest = pathlib.Path(sys.argv[2])
pattern = re.compile(rb'^\d+\s+write\(1, "((?:\\x[0-9a-fA-F]{2})*)", (\d+)\) = (\d+)$', re.M)
raw = source.read_bytes()
pieces = []
for match in pattern.finditer(raw):
    data = bytes.fromhex(match[1].replace(b'\\x', b'').decode())
    requested, written = int(match[2]), int(match[3])
    if len(data) != requested or written != requested:
        raise RuntimeError(f'partial/truncated write at source byte {match.start()}')
    pieces.append(data)
dest.write_bytes(b''.join(pieces))
print(f'writes={len(pieces)} bytes={dest.stat().st_size} sourceBytes={len(raw)}')
