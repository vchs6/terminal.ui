#!/usr/bin/python3
"""Record a single actual XTEST event or original window PNG for TASK021."""
import datetime
import json
import os
import pathlib
import subprocess
import sys

directory = pathlib.Path(sys.argv[1])
window = sys.argv[2]
action = sys.argv[3]
args = sys.argv[4:]
if os.statvfs(directory).f_bavail * os.statvfs(directory).f_frsize < 8 * 1024 * 1024:
    raise RuntimeError('pause: <8 MiB free before GUI write')
entry = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'window':window, 'action':action, 'args':args}
if action in ('key','type','resize'):
    command = ['/usr/bin/python3',str(pathlib.Path(__file__).with_name('xtest.py')),window,action,*args]
    result = subprocess.run(command, capture_output=True, text=True,
                            env={**os.environ,'DISPLAY':os.getenv('DISPLAY',':199')})
    entry.update({'command':command,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    if result.returncode:
        raise RuntimeError(entry)
elif action == 'capture':
    filename = args[0]
    command = ['import','-window',window,str(directory/filename)]
    result = subprocess.run(command,capture_output=True,text=True,
                            env={**os.environ,'DISPLAY':os.getenv('DISPLAY',':199')})
    entry.update({'command':command,'exit':result.returncode,'stderr':result.stderr})
    if result.returncode:
        raise RuntimeError(entry)
else:
    raise ValueError(action)
with (directory/'gui-events.jsonl').open('a') as output:
    output.write(json.dumps(entry,ensure_ascii=False)+'\n')
print(json.dumps(entry,ensure_ascii=False))
