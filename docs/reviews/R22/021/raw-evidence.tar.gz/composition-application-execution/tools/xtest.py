#!/usr/bin/python3
"""Send ordinary XTEST keyboard events and X11 resizes to an actual host window."""
import ctypes as c
import sys
import time

x = c.CDLL('libX11.so.6')
t = c.CDLL('libXtst.so.6')
x.XOpenDisplay.argtypes = [c.c_char_p]
x.XOpenDisplay.restype = c.c_void_p
x.XStringToKeysym.argtypes = [c.c_char_p]
x.XStringToKeysym.restype = c.c_ulong
x.XKeysymToKeycode.argtypes = [c.c_void_p, c.c_ulong]
x.XKeysymToKeycode.restype = c.c_uint
x.XSetInputFocus.argtypes = [c.c_void_p, c.c_ulong, c.c_int, c.c_ulong]
x.XResizeWindow.argtypes = [c.c_void_p, c.c_ulong, c.c_uint, c.c_uint]
x.XSync.argtypes = [c.c_void_p, c.c_int]
t.XTestFakeKeyEvent.argtypes = [c.c_void_p, c.c_uint, c.c_int, c.c_ulong]

display = x.XOpenDisplay(None)
if not display:
    raise RuntimeError('cannot open actual X11 display')
window = int(sys.argv[1], 0)
action = sys.argv[2]
x.XSetInputFocus(display, window, 1, 0)
x.XSync(display, 0)

def key(name, modifiers=()):
    codes = []
    for item in [*modifiers, name]:
        sym = x.XStringToKeysym(item.encode())
        code = x.XKeysymToKeycode(display, sym)
        if not code:
            raise ValueError(f'unmapped X keysym: {item}')
        codes.append(code)
    for code in codes:
        assert t.XTestFakeKeyEvent(display, code, 1, 0)
    for code in reversed(codes):
        assert t.XTestFakeKeyEvent(display, code, 0, 0)
    x.XSync(display, 0)

if action == 'key':
    key(sys.argv[3], sys.argv[4:])
elif action == 'type':
    for char in sys.argv[3]:
        if char == ' ':
            key('space')
        elif char == '\n':
            key('Return')
        elif char.isascii() and char.isprintable():
            key(char.lower(), ('Shift_L',) if char.isupper() else ())
        else:
            raise ValueError(f'cannot type via current X map: {char!r}')
elif action == 'resize':
    x.XResizeWindow(display, window, int(sys.argv[3]), int(sys.argv[4]))
    x.XSync(display, 0)
else:
    raise ValueError(action)
print(f'window={window:#x} action={action} args={sys.argv[3:]} utc={time.time()}')
