#!/usr/bin/python3
"""Record an ordinary app on an actual terminal's PTY."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import select
import subprocess
import sys
import termios
import time
import tty

binary = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def serial(value):
    return [*value[:6], [item.hex() if isinstance(item, bytes) else item for item in value[6]]]

def mode25(label):
    saved = termios.tcgetattr(0)
    received = bytearray()
    try:
        tty.setraw(0)
        os.write(1, b'\x1b[?25$p')
        end = time.monotonic() + .9
        while time.monotonic() < end:
            if select.select([0], [], [], max(0, end-time.monotonic()))[0]:
                received.extend(os.read(0, 4096))
                if re.search(rb'\x1b\[\?25;[0-4]\$y', received):
                    break
    finally:
        termios.tcsetattr(0, termios.TCSANOW, saved)
    statuses = [int(x) for x in re.findall(rb'\x1b\[\?25;([0-4])\$y', received)]
    result = {'utc': now(), 'queryHex': b'\x1b[?25$p'.hex(), 'actualReplyHex': received.hex(),
              'status': statuses[-1] if statuses else None,
              'termiosRestored': termios.tcgetattr(0) == saved,
              'method': 'actual host reply to external DECRQM query; no fabricated response'}
    (out / ('mode25-'+label+'.json')).write_text(json.dumps(result, indent=2)+'\n')
    return result

before = termios.tcgetattr(0)
pre = mode25('before')
(out / 'terminal-before.json').write_text(json.dumps({
    'utc': now(), 'tty': os.ttyname(0), 'size': list(os.get_terminal_size(0)),
    'termios': serial(before), 'TERM': os.getenv('TERM'), 'COLORTERM': os.getenv('COLORTERM'),
    'LANG': os.getenv('LANG'), 'LC_ALL': os.getenv('LC_ALL'),
    'binarySha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'mode25': pre,
}, indent=2)+'\n')
cmd = ['strace', '-f', '-xx', '-s', '65535', '-e',
       'trace=read,write,ioctl,execve',
       '-o', str(out/'product.strace'), str(binary)]
(out/'product-command.json').write_text(json.dumps({'utc': now(), 'argv': cmd}, indent=2)+'\n')
with (out/'product.stderr').open('wb') as err:
    rc = subprocess.Popen(cmd, stderr=err).wait()
after = termios.tcgetattr(0)
post = mode25('after')
trace = (out/'product.strace').read_text(errors='replace')
encoded = ''.join('\\x%02x' % value for value in str(binary).encode())
match = re.search(r'^(\d+)\s+execve\("'+re.escape(encoded)+r'".* = 0$', trace, re.M)
pid = int(match[1]) if match else None
exit_match = re.search(r'^'+str(pid)+r'\s+\+\+\+ exited with (\d+) \+\+\+$', trace, re.M)
(out/'terminal-after.json').write_text(json.dumps({
    'utc': now(), 'tty': os.ttyname(0), 'size': list(os.get_terminal_size(0)),
    'termios': serial(after), 'termiosEqual': before == after,
    'productPid': pid, 'directProductExit': int(exit_match[1]) if exit_match else None,
    'tracerExit': rc, 'mode25': post,
    'knownOriginalModeRestored': pre['status'] == post['status'] if pre['status'] is not None else None,
}, indent=2)+'\n')
end = time.monotonic() + 20
while not (out/'exit-release').exists() and time.monotonic() < end:
    time.sleep(.05)
sys.exit(rc)
