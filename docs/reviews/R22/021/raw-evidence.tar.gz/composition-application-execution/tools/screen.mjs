import {readFileSync} from 'node:fs';
import {WireScreen} from '../source/tests/composition/application/pty.mjs';
const [rawPath,width,height,offset] = process.argv.slice(2);
const bytes = readFileSync(rawPath).subarray(Number(offset ?? 0));
const screen = new WireScreen(Number(width),Number(height));
screen.feed(bytes);
if (screen.incompleteRow) throw Error('incomplete renderer row');
const rows=screen.rows();
process.stdout.write(JSON.stringify({rows:rows.map(row=>row.text),cells:rows.map(row=>row.cells),updates:screen.screen.updates.length})+'\n');
