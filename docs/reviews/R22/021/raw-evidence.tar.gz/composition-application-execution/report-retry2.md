# TASK021 independent PTY retry 2
- Source HEAD `abb289a59d17789684f47d20fe4b8a63e6b03de7` = fixed product `e3016afe` plus TESTONLY `6dbece66` and `d07a6933`; tracked diff empty.
- Reused original SDK 1.2.0 `cjpm build` outputs: minimal ELF `bf7da646f091436f0ef7bf3663b3a18d18436f73b0f8aec93be634c8a70f3a0e`, composition ELF `69e94b7afac0670c1fac08183d6e75e76b4f140e89a97c2b3192cc572e2de0c1`. No rebuild or direct smoke rerun.
- `node tests/composition/application/pty.mjs` exit 1, Node 24.22.1. Minimal and three startup-size cases pass; interaction now reaches visible Light/Classic colors, editor undo, modal popup, disabled skip, nested cancel, and F9 ancestor closure.
- Interactions stop at `pty.mjs:202`: after F9 and input `!`, final raw screen row 4 is `Shared !ote`; wait expected `Shared note!`. Underlying editor visibly received input in the middle of the note; caret ownership and expected insertion position need independent review.
- Failure session raw, events, frames and termios-before: `raw/pty-retry2/pty-8wZyWz`; no direct normal exit or termios-after because harness killed it on failure. Later interactions and actual GUI not run.
- Initial attempt is retained unchanged as `index-initial.json`/`report-initial.md`; new SHA256/byte bindings are `index-retry2.json`.
