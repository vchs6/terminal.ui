import assert from'node:assert/strict';import{readFileSync}from'node:fs';
import{WireScreen}from'../source/tests/composition/application/pty.mjs';
const screen=new WireScreen(80,24);screen.feed(readFileSync('/workspace/work/composition-application-execution/raw/pty-retry2/pty-8wZyWz/interactions/stdout.raw'));
assert(screen.rows().map(row=>row.text).join('\n').includes('Shared note!'),'old append expectation after F9 contradicts retained selection');
