import assert from'node:assert/strict';import{readFileSync}from'node:fs';
import{WireScreen}from'../source/tests/composition/application/pty.mjs';
const screen=new WireScreen(80,24);screen.feed(readFileSync('/workspace/work/composition-application-execution/raw/pty-retry2/pty-8wZyWz/interactions/stdout.raw'));
const visible=screen.rows().map(row=>row.text).join('\n');
assert(visible.includes('Shared !ote'),'source-derived exact retained-selection result');
for(const wrong of ['Shared note!','Shared !note','!Shared note'])assert(!visible.includes(wrong),'incorrect caret position must not satisfy expectation');
console.log('PASS replay-only: captured note agrees with manual [7,8] replacement; append/collapse/start alternatives rejected');
