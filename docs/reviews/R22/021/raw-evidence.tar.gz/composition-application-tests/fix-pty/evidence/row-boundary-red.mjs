import assert from 'node:assert/strict';
import {WireScreen} from '../source/tests/composition/application/pty.mjs';
// Literal wire from fixed Frame/encodeTerminalRow contract, not captured output.
const rows=new WireScreen(4,2);
rows.feed(Buffer.from('\x1b[0m\x1b[1;1H\x1b[36mAB\x1b[0m  \x1b[2;1HCD  \x1b[0m'));
assert.deepEqual(rows.rows().map(row=>row.text),['AB  ','CD  ']);
console.log('PASS source-derived complete rows without per-row reset');
