// Replay only: no process launch/build. Expected grid is source-derived fixture.
import assert from'node:assert/strict';import{readFileSync}from'node:fs';
import{WireScreen}from'../source/tests/composition/application/pty.mjs';
import{minimalPtyGolden}from'../source/tests/composition/application/fixtures.mjs';
const bytes=readFileSync('/workspace/work/composition-application-implementation/evidence/pty-first/pty-Uc9Dkk/minimal/stdout.raw');
for(const chunkSize of [1,7,bytes.length]){
 const screen=new WireScreen(16,3);
 for(let offset=0;offset<bytes.length;offset+=chunkSize)screen.feed(bytes.subarray(offset,offset+chunkSize));
 assert.deepEqual(screen.finish().map(row=>row.text),minimalPtyGolden.rows,'existing diagnostic capture matches independently derived Auto grid');
 assert.equal(screen.rows()[0].cells[0].fg,'named:36');
}
console.log('PASS replay-only: existing raw parsed under 1/7/all-byte chunking; literal Auto grid and cyan Text style checked');
