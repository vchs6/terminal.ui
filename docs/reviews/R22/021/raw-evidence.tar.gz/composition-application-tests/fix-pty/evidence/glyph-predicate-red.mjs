import assert from 'node:assert/strict';import{readFileSync}from'node:fs';
const raw=readFileSync('/workspace/work/composition-application-implementation/evidence/pty-first/pty-Uc9Dkk/minimal/stdout.raw','utf8');
assert(raw.includes('中文 👩‍💻'),'old ordinary-PTY wait predicate requires raw ZWJ contrary to G012 Auto projection');
