// Existing executor failure reproduced by replay only, no application launch.
import assert from'node:assert/strict';import{readFileSync}from'node:fs';
const frames=JSON.parse(readFileSync('/workspace/work/composition-application-execution/raw/pty-retry1/pty-HiG4xF/interactions/frames.json','utf8'));
const frame=frames.at(-1);
assert(frame.rows[23].text.includes('Light'),'old label-only wait passes');
assert.equal(frame.rows[22].cells[79].bg,'rgb:255,255,255','old immediate applied-color assertion races pending request');
