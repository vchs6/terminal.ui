#!/usr/bin/env bash
set -u
source /workspace/work/validation/sdk/cangjie/envsetup.sh
cd /workspace/work/composition-application-tests/fix-shadow/source
evidence=/workspace/work/composition-application-tests/fix-shadow/evidence
run_case(){ label=$1;shift;"$@" > "$evidence/$label.stdout" 2> "$evidence/$label.stderr";actual_exit=$?;printf '%s\n' "$actual_exit" > "$evidence/$label.exit"; }
run_case fixture-after node "$evidence/check-shadow-glyph.mjs" tests/composition/application/goldens/modal.json
run_case oracle-selftest node tests/composition/application/oracle-selftest.mjs
run_case syntax-check node --check tests/composition/application/pty.mjs
run_case whitespace git diff --check
