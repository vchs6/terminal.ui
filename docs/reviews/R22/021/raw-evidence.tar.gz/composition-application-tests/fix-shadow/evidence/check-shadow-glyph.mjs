// Tools-only check of two manually authored fixtures against public ░ semantics.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const frames=JSON.parse(readFileSync(process.argv[2],'utf8'));
for(const frame of frames){
  const glyphs=frame.rows.join('').match(/░/gu)??[];
  assert.equal(glyphs.length,40,`${frame.width}x${frame.height}: 8 exposed right cells + 32 bottom cells must be public shadow glyph ░`);
}
console.log('PASS tools-only: both hand-authored modal grids contain exactly40 public shadow glyphs; no application execution');
