#!/usr/bin/env bash
set -u
source /workspace/work/validation/sdk/cangjie/envsetup.sh
export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env
export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip
cd /workspace/work/composition-application-tests/source
evidence=/workspace/work/composition-application-tests/evidence
run_case() {
  label=$1
  shift
  "$@" > "$evidence/$label.stdout" 2> "$evidence/$label.stderr"
  actual_exit=$?
  printf '%s\n' "$actual_exit" > "$evidence/$label.exit"
}
date -u +%Y-%m-%dT%H:%M:%SZ > "$evidence/start.utc"
run_case syntax-bash bash -n tests/composition/run.sh tests/composition/application/run.sh
for file in tests/composition/application/*.mjs; do
  run_case "syntax-$(basename "$file" .mjs)" node --check "$file"
done
run_case oracle-selftest node tests/composition/application/oracle-selftest.mjs
run_case delivery-red node tests/composition/application/delivery.mjs
run_case application-runner-red bash tests/composition/application/run.sh
run_case unchanged-old-product git diff --exit-code e35d407a87ab197537ccc931c143c9927458a75f -- tests/composition/src tests/composition/cjpm.toml tests/composition/verify-files.mjs src native examples
run_case whitespace git diff --check
run_case sdk-compiler cjc -v
run_case sdk-project-manager cjpm --version
run_case node-version node --version
run_case pty-host-version script --version
date -u +%Y-%m-%dT%H:%M:%SZ > "$evidence/end.utc"
