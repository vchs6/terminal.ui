import assert from'node:assert/strict';import{readFileSync}from'node:fs';
const frames=JSON.parse(readFileSync('/workspace/work/composition-application-execution/raw/pty-retry3/pty-BQP53p/interactions/frames.json','utf8'));
const row=frames.at(-1).rows[9].text;
assert.equal(row.length,80,'capture uses declared viewport width');
assert.equal(row,'Done'+' '.repeat(76),'source-independent4+76 arithmetic yields literal80-column phase');
assert.notEqual(row,'Done'+' '.repeat(75)+'x','same-width stale suffix rejected');
console.log('PASS replay-only: Done4+76spaces=80; exact row rejects nonspace stale tail');
