import assert from'node:assert/strict';import{readFileSync}from'node:fs';
const frames=JSON.parse(readFileSync('/workspace/work/composition-application-execution/raw/pty-retry3/pty-BQP53p/interactions/frames.json','utf8'));
assert.equal(frames.at(-1).rows[9].text,'Done'+' '.repeat(77),'old phase literal accidentally requires81 columns in80-column viewport');
