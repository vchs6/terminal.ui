import base64,datetime,gzip,hashlib,io,json,os,pathlib,re,socket,subprocess,sys,tarfile,time
from PIL import Image,ImageChops

B=pathlib.Path('/workspace/work/composition-application-vt-execution')
HOST=pathlib.Path('/workspace/work/linux-console-hosts')
scene=sys.argv[1]
assert scene in ('minimal','composition')
variant=sys.argv[3] if len(sys.argv)>3 else 'standard'
out=B/'raw'/(sys.argv[2] if len(sys.argv)>2 else scene)
out.mkdir(exist_ok=False)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda data:hashlib.sha256(data).hexdigest()
env=dict(os.environ,LD_LIBRARY_PATH=str(HOST/'hosts/debian/usr/lib/x86_64-linux-gnu'))
cmd=[str(HOST/'hosts/debian/usr/bin/qemu-system-x86_64'),'-accel','tcg','-cpu','max','-machine','pc',
     '-m','512','-smp','1','-no-reboot','-nic','none','-L',str(HOST/'hosts/debian/usr/share/qemu'),
     '-bios',str(HOST/'hosts/debian/usr/share/seabios/bios-256k.bin'),
     '-device','VGA,romfile='+str(HOST/'hosts/debian/usr/share/seabios/vgabios-stdvga.bin'),
     '-vga','none','-display','none','-serial','file:'+str(out/'serial.log'),
     '-chardev','socket,id=probe,path='+str(out/'control.sock')+',server=on,wait=off',
     '-serial','chardev:probe','-qmp','unix:'+str(out/'qmp.sock')+',server=on,wait=off',
     '-kernel',str(HOST/'packages/linux'),'-initrd',str(B/'payload.cpio.gz'),
     '-append','console=tty0 console=ttyS0,115200 rdinit=/init nomodeset vga=normal loglevel=4 scene='+scene]
(out/'launch.json').write_text(json.dumps(dict(argv=cmd,utc=utc(),virtual_hardware=True,
    connection='QMP keyboard -> Linux kernel VT tty1 -> direct consumer fd0/fd1',
    payload_sha256=sha((B/'payload.cpio.gz').read_bytes()),
    kernel_sha256=sha((HOST/'packages/linux').read_bytes()),
    binary_sha256=sha((pathlib.Path('/workspace/work/composition-application-execution/source/examples')/scene/'target/release/bin/main').read_bytes()),
    free_bytes_start=os.statvfs(B).f_bavail*os.statvfs(B).f_frsize),indent=2)+'\n')
p=subprocess.Popen(cmd,env=env,stdout=(out/'qemu.stdout').open('wb'),stderr=(out/'qemu.stderr').open('wb'))
q=None;control=None;qlog=None;events=[];images=[]
def serial():return (out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
def wait(fn,label,seconds=35,allow_exit=False):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        value=fn()
        if value:return value
        if p.poll() is not None and not allow_exit:raise RuntimeError('VM ended before '+label)
        time.sleep(.12)
    raise TimeoutError(label)
try:
    wait(lambda:(out/'qmp.sock').exists(),'QMP socket')
    q=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);q.settimeout(10);q.connect(str(out/'qmp.sock'))
    qf=q.makefile('rwb',buffering=0);qlog=(out/'qmp.jsonl').open('w');seq=0
    def receive():
        data=json.loads(qf.readline());qlog.write(json.dumps(dict(receive=data,utc=utc()))+'\n');qlog.flush();return data
    def command(name,args=None):
        global seq
        seq+=1;data=dict(execute=name,id=seq)
        if args:data['arguments']=args
        qlog.write(json.dumps(dict(send=data,utc=utc()))+'\n');qlog.flush();qf.write((json.dumps(data)+'\n').encode())
        while True:
            answer=receive()
            if answer.get('id')==seq:
                if 'error' in answer:raise RuntimeError(answer)
                return answer
    receive();command('qmp_capabilities');command('query-version');command('query-kvm')
    wait(lambda:'TRACER_PID=' in serial(),'consumer start',50)
    control=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);control.connect(str(out/'control.sock'))
    def key(*keys):
        for down,order in ((True,keys),(False,list(reversed(keys)))):
            for name in order:command('input-send-event',dict(events=[dict(type='key',data=dict(down=down,key=dict(type='qcode',data=name)))]))
        events.append(dict(kind='key',keys=list(keys),utc=utc()))
        if variant in ('target','finish','scroll'):time.sleep(.35)
    def typing(value):
        for ch in value:
            if ch==' ':key('spc')
            elif ch=='\n':key('ret')
            elif ch.islower() or ch.isdigit():key(ch)
            elif ch.isupper():key('shift',ch.lower())
            elif ch=='!':key('shift','1')
            else:raise ValueError('unsupported physical key char '+repr(ch))
    def observe():
        prior=len(re.findall(r'DUMP_DONE seq=',serial()))
        control.sendall(b's')
        wait(lambda:len(re.findall(r'DUMP_DONE seq=',serial()))>prior,'native grid dump',8)
        lines=re.findall(r'GRID seq=\d+ phase=\S+ n=(\d+) hex=([0-9a-f]+)',serial())
        assert lines
        data=bytes.fromhex(lines[-1][1]);assert len(data)==int(lines[-1][0])
        rows,cols=data[0],data[1]
        return [''.join(chr(data[4+2*(y*cols+x)]) for x in range(cols)) for y in range(rows)],data
    def cells():return '\n'.join(observe()[0])
    def has(value,seconds=20):return wait(lambda:value in cells() and True,'visible '+repr(value),seconds)
    def absent(value,seconds=20):return wait(lambda:value not in cells() and True,'absent '+repr(value),seconds)
    def capture(name):
        if variant in ('target','finish','scroll'):time.sleep(.8)
        rows,grid=observe();(out/(name+'.vcsa')).write_bytes(grid)
        ppm=out/(name+'.ppm');png=out/(name+'.png')
        command('screendump',dict(filename=str(ppm),format='ppm'))
        source=ppm.read_bytes();original=dict(bytes=len(source),sha256=sha(source))
        with Image.open(ppm) as img:
            img.load();img.save(png);png_image=Image.open(png);png_image.load()
            assert img.mode==png_image.mode and img.size==png_image.size and ImageChops.difference(img,png_image).getbbox() is None
            size=img.size
        gz=out/(name+'.ppm.gz')
        with gzip.open(gz,'wb',compresslevel=9) as writer:writer.write(source)
        compressed=gz.read_bytes();assert gzip.decompress(compressed)==source
        ppm.unlink()
        record=dict(name=name,utc=utc(),cells=rows,vcsa_sha256=sha(grid),original_ppm=original,
                    ppm_gz=dict(bytes=len(compressed),sha256=sha(compressed),path=gz.name),
                    png=dict(bytes=png.stat().st_size,sha256=sha(png.read_bytes()),path=png.name),pixels=size,pixel_equal=True)
        images.append(record);events.append(dict(kind='capture',name=name,utc=record['utc']))
        (out/'captures.json').write_text(json.dumps(images,indent=2)+'\n')
        return rows
    if scene=='minimal':
        has('cjtui');capture('startup');key('q')
    elif variant=='scroll':
        has('Tasks | Ready 0/2 | Classic')
        key('f2');has('Logs | 24/24 | Classic');time.sleep(1)
        for _ in range(4):key('tab')
        capture('logs-top')
        key('pgdn');wait(lambda:cells().splitlines()[7].startswith('008 '),'physical PageDown scroll');capture('logs-page-down')
        key('f3');has('Logs | 24/24 | Light');wait(lambda:cells().splitlines()[7].startswith('008 '),'scroll preserved theme');capture('logs-page-down-light')
        key('f4');wait(lambda:'Job 01 Parse' in cells().splitlines()[9],'modal over scrolled logs');capture('modal-over-scrolled-logs')
        key('f9');wait(lambda:'Job 01 Parse' not in cells().splitlines()[9],'modal closed');wait(lambda:cells().splitlines()[7].startswith('008 '),'scroll preserved layers');capture('logs-scroll-after-layer')
        key('f10')
    elif variant=='finish':
        has('Tasks | Ready 0/2 | Classic')
        key('f2');has('Logs | 24/24 | Classic');time.sleep(1)
        for _ in range(4):key('tab')
        capture('logs-before-scroll')
        key('pgdn');capture('logs-after-pagedown')
        key('f3');has('Logs | 24/24 | Light');capture('logs-scroll-after-theme')
        key('f1');has('Tasks | Ready 0/2 | Light')
        key('f3');has('Tasks | Ready 0/2 | Classic')
        key('f5');has('Tasks | Review 1/2 | Classic')
        key('f6');has('Tasks | Done 2/2 | Classic');capture('done-before-ack')
        key('f4');wait(lambda:'Job 01 Parse' in cells().splitlines()[9],'modal visible')
        key('tab');key('ret');has('Inspect')
        key('down');key('ret');has('Confirm?');capture('nested-confirm-before-f9')
        key('f9');absent('Confirm?');wait(lambda:'Job 01 Parse' not in cells().splitlines()[9],'ancestor closed');capture('done-after-nested-f9')
        key('f4');wait(lambda:'Job 01 Parse' in cells().splitlines()[9],'modal reopened')
        key('tab');key('ret');has('Inspect')
        key('down');key('ret');has('Confirm?')
        key('ret');absent('Confirm?');capture('modal-acknowledged')
        key('f9');wait(lambda:'Job 01 Parse' not in cells().splitlines()[9],'modal closed');capture('done-after-ack')
        before=(out/'done-after-nested-f9.vcsa').read_bytes();after=(out/'done-after-ack.vcsa').read_bytes()
        same_chars=before[:4]==after[:4] and before[4::2]==after[4::2]
        different_attrs=before[5::2]!=after[5::2]
        with Image.open(out/'done-after-nested-f9.png') as left, Image.open(out/'done-after-ack.png') as right:
            pixel_changed=ImageChops.difference(left,right).getbbox() is not None
        color=dict(same_characters=same_chars,different_vcsa_attributes=different_attrs,pixels_changed=pixel_changed,
                   before_vcsa_sha256=sha(before),after_vcsa_sha256=sha(after),utc=utc())
        (out/'ack-color.json').write_text(json.dumps(color,indent=2)+'\n')
        key('f10')
    elif variant=='target':
        has('Tasks | Ready 0/2 | Classic')
        focus=[]
        for _ in range(6):
            key('tab');rows,grid=observe();focus.append([grid[2],grid[3]])
        time.sleep(1.5)
        rows,grid=observe();focus.append([grid[2],grid[3]])
        events.append(dict(kind='focus-steps',cursor_xy=focus,utc=utc()))
        capture('textarea-focus')
        typing('note');has('note');key('ret');typing('line');has('line');capture('notes-multiline')
        key('ctrl','a');key('f3');has('Tasks | Ready 0/2 | Light');capture('notes-selected-theme')
        typing('x');capture('notes-selection-replaced')
        key('ctrl','z');capture('notes-undo-after-theme')
        key('f4');wait(lambda:'Job 01 Parse' in cells().splitlines()[9],'modal row',20);capture('modal-from-editor')
        key('f9');wait(lambda:'Job 01 Parse' not in cells().splitlines()[9],'modal close',20);capture('ancestor-closed')
        typing('y');capture('focus-return-typed')
        key('f2');has('Logs | 24/24 | Light');time.sleep(1)
        typing('record 03');has('Logs | 1/24');capture('logs-filtered')
        key('ctrl','a');key('backspace');has('Logs | 24/24');capture('logs-cleared')
        key('tab');key('spc');has('Logs | 8/24');capture('logs-errors')
        key('tab');key('tab');key('spc');has('024 ERROR record 24');capture('logs-reversed')
        key('f3');has('Logs | 8/24 | Classic');capture('logs-theme-preserved')
        key('f10')
    elif variant=='extended':
        has('Tasks | Ready 0/2 | Classic');capture('task-initial')
        for _ in range(5):key('tab')
        typing('note');key('ret');typing('line');capture('notes-physical-multiline')
        key('f3');has('Light');capture('notes-after-theme')
        key('f4');has('Actions');capture('modal-after-theme')
        key('f9');capture('after-f9-ancestor-close')
        key('f2');has('Logs | 24/24 | Light');capture('logs-initial')
        typing('record 03');capture('logs-filter')
        key('ctrl','a');key('backspace');capture('logs-filter-cleared')
        key('tab');key('spc');capture('logs-errors-only')
        key('tab');key('tab');key('spc');capture('logs-newest')
        key('f3');has('Classic');capture('logs-after-theme')
        key('f4');capture('modal-from-logs')
        key('f9');capture('logs-after-f9')
        key('f10')
    else:
        has('Tasks | Ready 0/2 | Classic');capture('tasks-startup')
        key('f2');has('Logs | 24/24 | Classic');capture('logs-startup')
        key('f1');has('Tasks | Ready 0/2 | Classic')
        typing('qrcvzy');has('qrcvzy');capture('task-typed')
        key('ctrl','a');typing('Parse');has('01 Ready Parse');capture('task-filter')
        key('ctrl','z');has('Pars');capture('physical-undo-one-key');key('ctrl','a');key('backspace');has('03 Done Export')
        key('tab');key('spc');has('[x] Hide done');capture('task-hide-done')
        key('spc');has('03 Done Export')
        key('tab');key('tab');key('spc');has('03 Done Export');capture('task-name-sort')
        key('shift','tab');key('spc');has('01 Ready Parse')
        key('f4');has('Actions');capture('modal-open')
        key('tab');key('ret');has('Inspect');capture('popup-open')
        key('down');key('ret');has('Confirm?');capture('confirm-open')
        key('esc');absent('Confirm?');key('esc');absent('Inspect');key('esc');absent('Actions  ║')
        key('f5');has('Tasks | Review 1/2');capture('review-half')
        key('f6');has('Tasks | Done 2/2');capture('done-full')
        key('f10')
    wait(lambda:'EXIT_CAPTURE_BARRIER' in serial(),'direct exit',25)
    capture('restored');control.sendall(b'e')
    wait(lambda:'EVIDENCE_TAR_BASE64_END' in serial(),'guest evidence export',allow_exit=True)
    qexit=p.wait(timeout=20)
    data=serial();block=data.split('EVIDENCE_TAR_BASE64_BEGIN',1)[1].split('EVIDENCE_TAR_BASE64_END',1)[0]
    packed=base64.b64decode(''.join(block.split()));(out/'guest-export.tar.gz').write_bytes(packed)
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed))) as archive:
        archive.extractall(out/'evidence',filter='data')
    direct=(out/'evidence/direct.exit').read_text().strip()
    before=(out/'evidence/outer-termios-before.bin').read_bytes();after=(out/'evidence/outer-termios-after.bin').read_bytes()
    result=dict(scene=scene,utc=utc(),qemu_exit=qexit,direct_exit=direct,outer_termios_equal=before==after,
                kernel_host=re.search(r'^HOST .*$',data,re.M).group(0),
                font=re.search(r'^FONT .*$',data,re.M).group(0),captures=len(images),events=len(events))
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
    raw=(out/'serial.log').read_bytes()
    with gzip.open(out/'serial.log.gz','wb',compresslevel=9) as writer:writer.write(raw)
    assert gzip.decompress((out/'serial.log.gz').read_bytes())==raw
    (out/'serial-original.json').write_text(json.dumps(dict(bytes=len(raw),sha256=sha(raw)),indent=2)+'\n')
    (out/'serial.log').unlink()
    trace=out/'evidence/product.strace';raw=trace.read_bytes()
    with gzip.open(out/'evidence/product.strace.gz','wb',compresslevel=9) as writer:writer.write(raw)
    assert gzip.decompress((out/'evidence/product.strace.gz').read_bytes())==raw
    (out/'evidence/trace-original.json').write_text(json.dumps(dict(bytes=len(raw),sha256=sha(raw)),indent=2)+'\n')
    trace.unlink()
    print(json.dumps(result))
    if qexit!=0 or direct!='0' or before!=after:raise RuntimeError('direct exit/termios result failed')
except BaseException as exc:
    (out/'failure.json').write_text(json.dumps(dict(error=repr(exc),utc=utc(),events=events),indent=2)+'\n')
    raise
finally:
    if control:control.close()
    if q:q.close()
    if qlog:qlog.close()
    if p.poll() is None:p.terminate();p.wait(timeout=10)
