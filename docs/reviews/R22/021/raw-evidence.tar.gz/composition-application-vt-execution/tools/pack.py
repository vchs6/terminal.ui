import pathlib,gzip,hashlib,json,stat

B=pathlib.Path('/workspace/work/composition-application-vt-execution')
base=pathlib.Path('/workspace/work/session-lifecycle-vt-execution/payload-v2.cpio.gz')
source=pathlib.Path('/workspace/work/composition-application-execution/source')
replacements={
    'init':B/'tools/vt-init.sh',
    'vt-supervisor':B/'tools/vt-supervisor',
    'apps/minimal':source/'examples/minimal/target/release/bin/main',
    'apps/composition':source/'examples/composition/target/release/bin/main',
}
expected={'apps/minimal':'bf7da646f091436f0ef7bf3663b3a18d18436f73b0f8aec93be634c8a70f3a0e',
          'apps/composition':'69e94b7afac0670c1fac08183d6e75e76b4f140e89a97c2b3192cc572e2de0c1'}
for name,digest in expected.items():
    assert hashlib.sha256(replacements[name].read_bytes()).hexdigest()==digest
dest=B/'payload.cpio.gz'
records=[];seen=set()
with gzip.open(base,'rb') as inp,gzip.GzipFile(filename=str(dest),mode='wb',mtime=0,compresslevel=9) as out:
    def emit(name,mode,data,source_name):
        if name in seen:return
        parent=str(pathlib.PurePosixPath(name).parent)
        if parent!='.' and parent not in seen:emit(parent,stat.S_IFDIR|0o755,b'','generated parent')
        seen.add(name)
        nb=name.encode()+b'\0'
        fields=[len(records)+1,mode,0,0,1,0,len(data),0,0,0,0,len(nb),0]
        blob=b'070701'+b''.join(f'{x:08x}'.encode() for x in fields)+nb
        blob+=b'\0'*(-len(blob)%4)
        blob+=data+b'\0'*(-len(data)%4)
        out.write(blob)
        records.append(dict(source=source_name,guest='/'+name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    while True:
        header=inp.read(110)
        assert header[:6]==b'070701'
        f=[int(header[6+i*8:14+i*8],16) for i in range(13)]
        size,nsize=f[6],f[11]
        name=inp.read(nsize)[:-1].decode()
        inp.read(-(110+nsize)%4)
        data=inp.read(size)
        inp.read(-size%4)
        if name=='TRAILER!!!':break
        if name in replacements or name.startswith(('apps/','py/','fixture/')) or name in ('apps','py','fixture'):continue
        if name.startswith('lib/x86_64-linux-gnu/libexpat.so') or name=='lib/x86_64-linux-gnu/libz.so.1':continue
        emit(name,f[1],data,str(base)+'!'+name)
    for name,path in replacements.items():emit(name,stat.S_IFREG|0o755,path.read_bytes(),str(path))
    emit('TRAILER!!!',0,b'','cpio terminator')
manifest=dict(base=str(base),base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),archive=str(dest),
    archive_bytes=dest.stat().st_size,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),members=records)
(B/'raw/payload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(archive_bytes=dest.stat().st_size,members=len(records),uncompressed_bytes=sum(x['bytes'] for x in records))))
