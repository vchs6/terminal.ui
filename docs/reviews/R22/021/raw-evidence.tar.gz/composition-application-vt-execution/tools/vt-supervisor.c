#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <poll.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <linux/kd.h>
#include <linux/vt.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/sysmacros.h>
static int logfd,control,seq;
static void save(const char *name,const void *data,size_t n){char p[256];snprintf(p,sizeof p,"/evidence/%s",name);int f=open(p,O_WRONLY|O_CREAT|O_TRUNC,0666);if(f<0||write(f,data,n)!=(ssize_t)n)exit(74);close(f);}
static void dump(const char *phase){
 unsigned char b[16384];int f=open("/dev/vcsa1",O_RDONLY);int n=f<0?-1:read(f,b,sizeof b);if(f>=0)close(f);dprintf(logfd,"GRID seq=%d phase=%s n=%d hex=",seq,phase,n);for(int i=0;i<n;i++)dprintf(logfd,"%02x",b[i]);dprintf(logfd,"\n");
 DIR *d=opendir("/evidence");struct dirent *e;while(d&&(e=readdir(d))){if(e->d_name[0]=='.'||strstr(e->d_name,"strace")||strstr(e->d_name,".bin"))continue;char p[512];snprintf(p,sizeof p,"/evidence/%s",e->d_name);f=open(p,O_RDONLY);n=f<0?0:read(f,b,sizeof b);if(f>=0)close(f);if(n>0){dprintf(logfd,"ACK seq=%d name=%s hex=",seq,e->d_name);for(int i=0;i<n;i++)dprintf(logfd,"%02x",b[i]);dprintf(logfd,"\n");}}if(d)closedir(d);dprintf(logfd,"DUMP_DONE seq=%d\n",seq++);
}
static void probe(const char *name){char p[256];snprintf(p,sizeof p,"/evidence/%s",name);pid_t c=fork();if(!c){execl("/py/bin/python3","python3","/fixture/host_probe.py",p,(char*)0);_exit(127);}int s;waitpid(c,&s,0);dprintf(logfd,"FROZEN_PROBE file=%s wait=%d\n",name,s);if(s)exit(73);}
static int signal_app(int sig){DIR*d=opendir("/proc");struct dirent*e;int pid=0;while(d&&(e=readdir(d))){int p=atoi(e->d_name);char ep[128],v[512];snprintf(ep,sizeof ep,"/proc/%d/exe",p);int n=readlink(ep,v,sizeof v-1);if(n<0)continue;v[n]=0;if(!strcmp(v,"/apps/lifecycle")){pid=p;break;}}if(d)closedir(d);int r=pid?kill(pid,sig):-1;dprintf(logfd,"ACTUAL_SIGNAL pid=%d sig=%d rc=%d errno=%d\n",pid,sig,r,errno);return r;}
int main(int argc,char**argv){if(argc!=2)return 2;const char *app=!strcmp(argv[1],"minimal")?"/apps/minimal":"/apps/composition";logfd=open("/dev/ttyS0",O_WRONLY|O_NOCTTY);control=open("/dev/ttyS1",O_RDWR|O_NOCTTY|O_NONBLOCK);struct termios ct;if(control>=0&&!tcgetattr(control,&ct)){cfmakeraw(&ct);tcsetattr(control,TCSANOW,&ct);}struct stat st;fstat(0,&st);struct utsname u;uname(&u);struct winsize w;ioctl(0,TIOCGWINSZ,&w);struct vt_stat v={0};int vr=ioctl(0,VT_GETSTATE,&v),kb=-1,kd=-1;ioctl(0,KDGKBMODE,&kb);ioctl(0,KDGETMODE,&kd);dprintf(logfd,"HOST tty=%s rdev=%u:%u uid=%u TERM=%s grid=%ux%u vt_rc=%d active=%u keyboardmode=%d kdmode=%d kernel=%s %s %s case=%s\n",ttyname(0),major(st.st_rdev),minor(st.st_rdev),getuid(),getenv("TERM"),w.ws_col,w.ws_row,vr,v.v_active,kb,kd,u.sysname,u.release,u.version,argv[1]);if(w.ws_col!=80||w.ws_row!=25||vr||v.v_active!=1)return 77;
 unsigned char font[32768]={0};struct console_font_op fo={.op=KD_FONT_OP_GET,.width=32,.height=32,.charcount=512,.data=font};int fr=ioctl(0,KDFONTOP,&fo);dprintf(logfd,"FONT rc=%d errno=%d width=%u height=%u charcount=%u\n",fr,errno,fo.width,fo.height,fo.charcount);if(!fr)save("console-font.bin",font,sizeof font);
 struct termios before={0},after={0};tcgetattr(0,&before);save("outer-termios-before.bin",&before,sizeof before);dump("BEFORE");
 pid_t c=fork();if(!c){if(setgid(1000)||setuid(1000))_exit(126);int er=open("/evidence/product.stderr",O_WRONLY|O_CREAT|O_TRUNC,0666);dup2(er,2);close(er);dprintf(logfd,"PRODUCT_ID uid=%u euid=%u stdin=%s stdout=%s\n",getuid(),geteuid(),ttyname(0),ttyname(1));execl("/usr/bin/strace","strace","-f","-xx","-s","65535","-e","trace=read,write,ioctl,newfstatat,fstat,openat,execve,prctl,rt_sigaction,poll,wait4,exit_group","-o","/evidence/product.strace",app,(char*)0);_exit(127);}dprintf(logfd,"TRACER_PID=%d\n",c);int status=0;while(waitpid(c,&status,WNOHANG)==0){struct pollfd p={control,POLLIN,0};if(poll(&p,1,50)>0){char b[128];int n=read(control,b,sizeof b);for(int i=0;i<n;i++){if(b[i]=='s')dump("RUNNING");if(b[i]=='i')signal_app(SIGINT);if(b[i]=='t')signal_app(SIGTERM);}}}int rc=WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);char val[32];int n=snprintf(val,sizeof val,"%d\n",rc);save("direct.exit",val,n);tcgetattr(0,&after);save("outer-termios-after.bin",&after,sizeof after);dprintf(logfd,"PRODUCT_EXIT=%d raw_wait=%d outer_termios_equal=%d\n",rc,status,memcmp(&before,&after,sizeof before)==0);dump("EXIT");dprintf(logfd,"EXIT_CAPTURE_BARRIER\n");for(int i=0;i<1200;i++){struct pollfd p={control,POLLIN,0};if(poll(&p,1,50)>0){char b;read(control,&b,1);if(b=='e')return rc;if(b=='s')dump("EXIT");}}return 75;}
