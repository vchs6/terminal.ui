#!/bin/sh
exec "/workspace/work/theme-showcase-implementation/source/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/theme-showcase-implementation/evidence/pty-v2/pty-7Hflwa/file-reload/selected.toml"
