import {Session} from '/workspace/work/theme-showcase-implementation/source/tests/composition/application/pty.mjs';
import {keys} from '/workspace/work/theme-showcase-implementation/source/tests/composition/application/fixtures.mjs';
import {resolve} from 'node:path';
const s=new Session('/workspace/work/theme-showcase-implementation/evidence/reload-raw',80,24,resolve('examples/theme_showcase/target/release/bin/main'));
try { await s.start(); await s.has('Gallery | Classic');
 await s.key('\x1b[18~',r=>r[9].text.includes('Load failed'),'reload preset has no file source');
 await s.key(keys.f2,r=>r[23].text.includes('Gallery | Dark')&&r[9].text.includes('Idle'),'preset clears failed result');
 await s.stop(); console.log('PASS preset reload failure and recovery');
} finally {await s.save()}
