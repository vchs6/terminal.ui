#!/bin/sh
exec "/workspace/work/theme-showcase-implementation/source/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/theme-showcase-implementation/evidence/r1-pty/pty-Ze9uLS/file-reload/selected.toml"
