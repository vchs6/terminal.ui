#!/bin/sh
exec "/workspace/work/theme-showcase-implementation/source/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/theme-showcase-implementation/evidence/pty-v1/pty-w8qrv9/file-reload/selected.toml"
