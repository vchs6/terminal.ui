import {Session} from '/workspace/work/theme-showcase-implementation/source/tests/composition/application/pty.mjs';
import {keys} from '/workspace/work/theme-showcase-implementation/source/tests/composition/application/fixtures.mjs';
import {resolve} from 'node:path';
const s = new Session('/workspace/work/theme-showcase-implementation/evidence/popup-raw',80,24,resolve('examples/theme_showcase/target/release/bin/main'));
const has = t => rows => rows.some(row => row.text.includes(t));
try {
 await s.start(); await s.has('Gallery | Classic');
 await s.key(keys.f5,has('Preview'),'open preview');
 await s.key(keys.enter,has('Inspect'),'open preview popup');
 await s.key(keys.esc,rows=>!has('Inspect')(rows),'close popup');
 await s.key(keys.f9,rows=>!rows.some(row=>row.text.includes('Theme sample')),'close preview');
 await s.key(keys.tab.repeat(7)+keys.enter,has('Inspect'),'open gallery popup');
 await s.key(keys.esc,rows=>!has('Inspect')(rows),'close gallery popup');
 await s.stop(); console.log('PASS preview and gallery popup');
} finally { await s.save(); }
