#!/bin/sh
exec "/workspace/work/theme-showcase-implementation/source/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/theme-showcase-implementation/evidence/r1-retry2-pty/pty-cX02xW/file-reload/selected.toml"
