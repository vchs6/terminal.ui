#!/usr/bin/python3
"""Losslessly compress completed text evidence, preserving source hashes."""
import gzip
import hashlib
import json
import pathlib

root = pathlib.Path('/workspace/work/theme-showcase-gui/raw')
paths = sorted(root.glob('frames/*.json')) + [root/'session/product.strace',
    root/'provenance/product.strace',root/'session/stdout.raw',root/'session/gui-frames.jsonl']
sha = lambda data: hashlib.sha256(data).hexdigest()
entries=[]
for path in paths:
    if not path.exists(): continue
    original=path.read_bytes(); packed=gzip.compress(original,compresslevel=9,mtime=0)
    target=path.with_name(path.name+'.gz'); target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes())==original
    entries.append({'originalPath':str(path),'originalSha256':sha(original),'originalBytes':len(original),
        'gzipPath':str(target),'gzipSha256':sha(packed),'gzipBytes':len(packed),'verified':True})
    path.unlink()
(root/'compression-map.json').write_text(json.dumps(entries,indent=2)+'\n')
print('files',len(entries),'originalBytes',sum(x['originalBytes'] for x in entries),
      'gzipBytes',sum(x['gzipBytes'] for x in entries))
