#!/usr/bin/python3
"""Create the immutable evidence index after all outputs are finalized."""
import datetime
import hashlib
import json
import pathlib

root=pathlib.Path('/workspace/work/theme-showcase-gui')
source=pathlib.Path('/workspace/work/theme-showcase-execution/source')
repo=pathlib.Path('/workspace/work/terminal.ui')
prior=pathlib.Path('/workspace/work/theme-showcase-execution')
plumbing=pathlib.Path('/workspace/work/composition-application-execution/tools')
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def item(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
external=[prior/'index.json',source/'examples/theme_showcase/target/release/bin/main',
    source/'tests/theme_showcase/public-api-basis.md',source/'tests/theme_showcase/fixtures.mjs',
    source/'tests/theme_showcase/checks.mjs',source/'tests/theme_showcase/retained-goldens.json',
    source/'tests/theme_showcase/pty-modal-goldens.json',
    repo/'AGENTS.md',repo/'openspec/changes/complete-linux-integration/design.md',
    repo/'.superpowers/sdd/tasks-implement-theme-styles/task-027-gui-brief.md',
    repo/'docs/reviews/R16/execution/raw/host-xorg-dummy.conf',
    pathlib.Path('/usr/bin/xfce4-terminal'),
    pathlib.Path('/usr/lib/x86_64-linux-gnu/libvte-2.91.so.0.8000.1'),
    pathlib.Path('/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative/libcangjie-runtime.so'),
    pathlib.Path('/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative/libboundscheck.so'),
    pathlib.Path('/usr/bin/import'),pathlib.Path('/usr/bin/strace')]
external+=sorted((source/'examples/theme_showcase/src').glob('*.cj'))
external+=sorted((repo/'openspec/changes/implement-theme-styles/fixtures/themes').glob('*.toml'))
external += [plumbing/x for x in ('gui-step.py','xtest.py','gui-check.py','screen.mjs','gui-replay.mjs','extract-strace.py')]
external += [pathlib.Path('/workspace/work/composition-application-execution/source/tests/composition/application/pty.mjs')]
own=sorted(p for p in root.rglob('*') if p.is_file() and p!=root/'index.json')
png=json.loads((root/'raw/png-manifest.json').read_text())
checks=json.loads((root/'raw/verification.json').read_text())
compression=json.loads((root/'raw/compression-map.json').read_text())
assert len(png)==23 and len({x['sha256'] for x in png if x['path'].endswith('-prepared.png') and 'return' not in x['path']})==4
assert all(x['fullGridMatchesLiteralWithInitialQuery'] and x['acceptedPalette'] for x in checks['base'].values())
assert all(x['verified'] for x in compression)
assert [tuple((x['width'],x['height'])) for x in checks['resize'].values()]==[(40,12),(16,6),(80,24)]
index={'scope':'TASK027 actual XFCE/VTE four-theme GUI evidence, no acceptance decision',
       'sealedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'sourceHead':'b5de3dd6610e90fcdcd951c5703a1429ec13b417',
       'sameElfSha256':'3887d29ff5728afae5cb9ab2b5a344ed10274645fd3079ae7a2a6659e50d4940',
       'predecessorFiniteIndexSha256':'768d1ad0ad00f02c2e9d36a0b8732418173155d1f2782acdc1171cc8c7d0bd05',
       'guiHost':'xfce4-terminal 1.1.4, VTE 0.80.1, X.Org :199',
       'actualLoadedVteSha256':'e2e719555735ebeb0d72c3add313ff0a16f7ca4f8191d533a0252bddd076aba2',
       'mainSessionDirectExit':0,'provenanceSessionDirectExit':0,
       'pngCount':len(png),'compressionCount':len(compression),
       'ownFiles':[item(p) for p in own], 'externalInputs':[item(p) for p in external]}
(root/'index.json').write_text(json.dumps(index,indent=2)+'\n')
print('indexSha256',sha(root/'index.json'),'own',len(own),'external',len(external))
