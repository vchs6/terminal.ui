#!/usr/bin/python3
"""Record the actual VTE PTY, traced gallery child, and native restoration."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import select
import subprocess
import sys
import termios
import time
import tty

out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
binary = pathlib.Path(sys.argv[2]); theme_file = pathlib.Path(sys.argv[3])
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value): (out / name).write_text(json.dumps(value, indent=2) + '\n')
def serial(v): return [*v[:6], [x.hex() if isinstance(x, bytes) else x for x in v[6]]]
def mode25(label):
    saved = termios.tcgetattr(0); received = bytearray()
    try:
        tty.setraw(0); os.write(1, b'\x1b[?25$p')
        end = time.monotonic() + 1.2
        while time.monotonic() < end:
            if select.select([0], [], [], max(0, end-time.monotonic()))[0]:
                received.extend(os.read(0, 4096))
                if re.search(rb'\x1b\[\?25;[0-4]\$y', received): break
    finally: termios.tcsetattr(0, termios.TCSANOW, saved)
    statuses = [int(x) for x in re.findall(rb'\x1b\[\?25;([0-4])\$y', received)]
    result = {'utc':now(), 'queryHex':b'\x1b[?25$p'.hex(), 'actualReplyHex':received.hex(),
              'status':statuses[-1] if statuses else None,
              'termiosRestored':termios.tcgetattr(0)==saved}
    save('mode25-'+label+'.json', result); return result

before = termios.tcgetattr(0); pre = mode25('before')
save('terminal-before.json', {'utc':now(), 'tty':os.ttyname(0), 'size':list(os.get_terminal_size(0)),
    'termios':serial(before), 'TERM':os.getenv('TERM'), 'COLORTERM':os.getenv('COLORTERM'),
    'LANG':os.getenv('LANG'), 'LC_ALL':os.getenv('LC_ALL'), 'mode25':pre})
cmd = ['strace','-f','-xx','-s','65535','-e','trace=read,write,ioctl,execve',
       '-o',str(out/'product.strace'),str(binary),'--theme-file',str(theme_file)]
save('product-command.json', {'utc':now(),'argv':cmd,'envSubset':{k:os.getenv(k) for k in
    ('DISPLAY','TERM','COLORTERM','LANG','LC_ALL','LD_LIBRARY_PATH','XDG_CONFIG_HOME')}})
with (out/'product.stderr').open('wb') as err:
    child = subprocess.Popen(cmd, stderr=err)
    save('tracer-pid.json', {'utc':now(),'pid':child.pid})
    # The strace child is the product. Preserve its executable and maps while alive.
    product_pid = None
    for _ in range(100):
        children = pathlib.Path(f'/proc/{child.pid}/task/{child.pid}/children')
        if children.exists():
            ids = children.read_text().split()
            if ids:
                product_pid = int(ids[0]); break
        time.sleep(.02)
    if product_pid is not None:
        proc = pathlib.Path(f'/proc/{product_pid}')
        maps = (proc/'maps').read_text(); (out/'product-maps.txt').write_text(maps)
        exe = os.readlink(proc/'exe')
        save('product-live.json', {'utc':now(),'pid':product_pid,'exe':exe,
            'exeSha256':hashlib.sha256(pathlib.Path(exe).read_bytes()).hexdigest(),
            'tty':os.ttyname(0),'mapsSha256':hashlib.sha256(maps.encode()).hexdigest()})
    rc = child.wait()
after = termios.tcgetattr(0); post = mode25('after')
trace = (out/'product.strace').read_text(errors='replace')
exit_match = re.search(r'^'+str(product_pid)+r'\s+\+\+\+ exited with (\d+) \+\+\+$',trace,re.M)
save('terminal-after.json', {'utc':now(), 'tty':os.ttyname(0), 'size':list(os.get_terminal_size(0)),
    'termios':serial(after),'termiosEqual':before==after,'productPid':product_pid,
    'directProductExit':int(exit_match[1]) if exit_match else None,'tracerExit':rc,
    'mode25':post,'knownOriginalModeRestored':pre['status']==post['status'] if pre['status'] is not None else None})
time.sleep(2)
sys.exit(rc)
