import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {cellAt,acceptedPalette} from '/workspace/work/theme-showcase-execution/source/tests/theme_showcase/checks.mjs';
import {frame,retainedGoldens,palette} from '/workspace/work/theme-showcase-execution/source/tests/theme_showcase/fixtures.mjs';
const base='/workspace/work/theme-showcase-gui/raw/frames/';
const load=(name)=>JSON.parse(existsSync(base+name+'.json')?readFileSync(base+name+'.json'):gunzipSync(readFileSync(base+name+'.json.gz')));
const names=[['Classic','classic'],['Dark','dark'],['Light','light'],['High contrast','high-contrast']];
const output={base:{},modal:{},popup:{},file:{},resize:{},popupNavigation:{}};
for(const [name,slug] of names){
  const f=load(slug+'-prepared');
  const rows=f.rows.map((text,i)=>({text,cells:f.cells[i]}));
  const expected=frame(retainedGoldens,name,80,24,'retained-scrolled').map(row=>row.replace('qrcvzy','Query '));
  output.base[name]={fullGridMatchesLiteralWithInitialQuery:JSON.stringify(f.rows)===JSON.stringify(expected),
    acceptedPalette:acceptedPalette(rows,name),selectedNameInverse:cellAt(rows,1,7).attributes.includes(7),
    disabledButtonDim:cellAt(rows,40,7).attributes.includes(2),
    disabledMenuDim:cellAt(rows,48,0).attributes.includes(2),
    background:cellAt(rows,79,22).bg,expectedBackground:palette[name].bg,
    firstRecord:f.rows[10].trim(),lastRecord:f.rows[22].trim(),footer:f.rows[23].trim()};
  const m=load(slug+'-modal');
  output.modal[name]={footer:m.rows[23].trim(),borderTop:m.rows[7].slice(24,56),borderBottom:m.rows[15].slice(24,57),
    sampleVisible:m.rows.join('').includes('Theme sample'),shadowAt56:m.rows[15][56]??null};
  const p=load(slug+'-popup');
  output.popup[name]={footer:p.rows[23].trim(),inspect:p.rows.join('').includes('Inspect'),
    disabledDelete:p.rows.join('').includes('Delete'),confirm:p.rows.join('').includes('Confirm')};
}
for(const n of ['file-dark','file-invalid','file-light']){
  const f=load(n);
  output.file[n]={phase:f.rows[9].slice(40).trim(),footer:f.rows[23].trim(),
    firstRecord:f.rows[10].trim(),lastRecord:f.rows[22].trim(),pin:f.rows[5].slice(0,8),name:f.rows[7].slice(0,8)};
}
for(const n of ['resize-40x12','resize-16x6','resize-restored']){
  const f=load(n+'-replay');
  output.resize[n]={width:f.width,height:f.height,sizes:f.sizes,rows:f.rows};
}
const before=load('dark-popup'),after=load('dark-popup-next');
output.popupNavigation={beforeInspectUnderline:before.cells[10][35].attributes.includes(4),
  afterInspectUnderline:after.cells[10][35].attributes.includes(4),
  afterDisabledDeleteDim:after.cells[11][36].attributes.includes(2),
  afterConfirmUnderline:after.cells[12][36].attributes.includes(4)};
writeFileSync('/workspace/work/theme-showcase-gui/raw/verification.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({base:output.base,modal:output.modal,popup:output.popup},null,2));
