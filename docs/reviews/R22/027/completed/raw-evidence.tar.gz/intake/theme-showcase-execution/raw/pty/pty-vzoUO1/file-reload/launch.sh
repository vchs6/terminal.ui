#!/bin/sh
exec "/workspace/work/theme-showcase-execution/source/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/theme-showcase-execution/raw/pty/pty-vzoUO1/file-reload/selected.toml"
