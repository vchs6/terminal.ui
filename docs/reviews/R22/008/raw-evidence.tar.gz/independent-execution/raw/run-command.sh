#!/bin/bash
set -uo pipefail
source /workspace/work/validation/sdk/cangjie/envsetup.sh
export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env
export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip
export CJTUI_RECOVERY_ARTIFACTS=/workspace/work/output-recovery-execution/raw/run
cd /workspace/work/output-recovery-execution/source
./tests/output_recovery/run.sh run > ../raw/run.log 2>&1
status=$?
printf '%s\n' "$status" > ../raw/run.exit
exit "$status"
