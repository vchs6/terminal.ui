#!/bin/bash
set -uo pipefail
source /workspace/work/validation/sdk/cangjie/envsetup.sh
export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env
export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip
cd /workspace/work/output-recovery-execution/source
{ date -u +%FT%TZ; cjc --version; cjpm --version; node --version; gcc --version | head -1; command -v cjc cjpm gcc node script; df -B1 /workspace; } > ../raw/environment.txt
./tests/output_recovery/run.sh build > ../raw/build.log 2>&1
status=$?
printf '%s\n' "$status" > ../raw/build.exit
exit "$status"
