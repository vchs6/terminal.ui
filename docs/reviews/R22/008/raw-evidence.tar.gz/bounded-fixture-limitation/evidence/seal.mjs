import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,stat,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {join,basename} from 'node:path';
const root='/workspace/work/output-caret-test-supplement', source=join(root,'source'), evidence=join(root,'evidence');
const hash=async path=>{const b=await readFile(path);return {path,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')};};
const commands=[];
const run=(command,args,cwd=source)=>{const r=spawnSync(command,args,{cwd,encoding:'utf8'});commands.push({command:[command,...args],cwd,status:r.status,stdout:r.stdout,stderr:r.stderr});assert.equal(r.status,0,r.stderr);return r.stdout.trim();};
assert.equal(run('git',['rev-parse','HEAD']),'9d224da8f74997fa8329a84c798c61e5a57d2fc9');
assert.equal(run('git',['status','--porcelain']),'');
assert.equal(run('git',['diff','--name-only','9d224da8f74997fa8329a84c798c61e5a57d2fc9']),'');
run('git',['diff','--check']);
run('node',['--check','tests/output_recovery/run.mjs']);
const frozen=[
['/workspace/work/output-recovery-tests/evidence/index.json','81282ca345b093bd0c487e7d01ed6d0e1ff903b465b0476cd01a0ab6fb3c2324'],
['/workspace/work/output-recovery-tests/evidence/artifacts.sha256','c20d69d54b20cae1ac697b7ea26f208f2be4b58d27a6eafa319d2dfe9211b281'],
['/workspace/work/output-recovery-tests/report.md','37080a7d981b1f06eb40ff1e8829475dce9802bace3c931c4c9088b64f2da293'],
['/workspace/work/output-recovery-tests/source/tests/output_recovery/target/release/bin/main','c77f87222831545d01e1a96b10c1ef7fc7c301a0a0297f8acc7d087ec339c527']];
const frozenInputs=[];
for(const [path,expected] of frozen){const item=await hash(path);assert.equal(item.sha256,expected);frozenInputs.push(item);}
for(const path of [source+'/AGENTS.md',source+'/tests/output_recovery/src/live.cj',source+'/tests/output_recovery/run.mjs',source+'/tests/output_recovery/README.md','/workspace/work/terminal.ui/.superpowers/sdd/tasks-complete-linux-integration/task-008-tests-brief.md','/workspace/work/terminal.ui/openspec/changes/implement-color-style-output/design.md','/workspace/work/terminal.ui/openspec/changes/implement-public-interaction/design.md','/workspace/work/validation/sdk/cangjie/envsetup.sh'])frozenInputs.push(await hash(path));
const dir=join(evidence,'baseline/normal-caret-profile-rewrite');
const summary=JSON.parse(await readFile(join(evidence,'baseline/summary.json'),'utf8'));
assert.equal(summary.cases,1);assert.equal(summary.failures,1);
assert.equal((await readFile(join(evidence,'run.exit'),'utf8')).trim(),'1');
const direct=JSON.parse(await readFile(join(dir,'exit.json'),'utf8'));assert.deepEqual(direct,{code:0,signal:null,finished:true});
assert.equal((await readFile(join(dir,'before'),'utf8')).trim(),(await readFile(join(dir,'after'),'utf8')).trim());
assert.equal(await readFile(join(dir,'result'),'utf8'),'false\n\n1\n0/0/0/0\n');
const native=await readFile(join(dir,'native.tsv'),'utf8');assert(native.includes('close\t0\t0\n'));
const signalLines=native.split('\n').filter(s=>s.startsWith('signal-restored\t'));assert.equal(signalLines.length,3);for(const line of signalLines)assert.equal(line.split('\t')[2],'1');
assert.equal((await readFile(join(dir,'rewrite-actual.bin'))).toString('hex'),'1b5b313b3348');
for(const path of [source+'/tests/output_recovery/target',source+'/tests/output_recovery/native/terminal-size']){let absent=false;try{await access(path);}catch(e){assert.equal(e.code,'ENOENT');absent=true;}assert(absent);}
await writeFile(join(evidence,'verification.json'),JSON.stringify({utc:new Date().toISOString(),commands,summary,direct,originalFrozenHashesUnchanged:true,noLocalTargetOrNativeHelper:true,termiosEqual:true,signalLines},null,2)+'\n');
const files=[];
async function walk(path){for(const name of (await readdir(path)).sort()){const child=join(path,name);if((await stat(child)).isDirectory())await walk(child);else if(!['index.json','index.sha256','artifacts.sha256'].includes(basename(child)))files.push(await hash(child));}}
await walk(evidence);files.push(await hash(join(root,'report.md')));
const index={schema:1,task:'ACTUAL008.a bounded caret supplement',status:'FIXTURE_PRECONDITION_NOT_MET_STOPPED',utc:new Date().toISOString(),base:'51529b7f5bce9c639d54876c378b54aa1cd3aaf2',fixedTests:'9d224da8f74997fa8329a84c798c61e5a57d2fc9',supplementCommit:null,sourceStatus:'clean; no product or test edits retained',attempt:'one positive-control attempt; no nonempty frame/profile rewrite produced',classification:'fixture failure, not adjudicated product RED',expectedProfileWireHex:'1b5b306d1b5b313b314841c3a920201b5b306d1b5b313b3348',actualProfileWireHex:'1b5b313b3348',wrapperExit:1,direct,cleanup:'UI once; 0/0/0/0 resources; termios equal; close0; all signals restored',command:join(evidence,'run-command.sh'),original338:'not rerun; original337GREEN/normal-caretRED retained under original index',builds:'none; exact existing binary via CJTUI_RECOVERY_BINARY; no native helper compilation',limit:'D030 equivalent default-style profiles emit no row update; current caret driver offers no text/emphasis mutation',requiredReview:'verify post-text CUP with unchanged logical visible caret',skills:['test-driven-development/SKILL.md','test-driven-development/writing-good-tests.md','verification-before-completion/SKILL.md','using-git-worktrees/SKILL.md','systematic-debugging/SKILL.md'].map(p=>'skill://plugins~Plugin_60aea7460bd4819199fd97a9553a5e12/'+p),skillProvenance:'cloud c6 snapshot read in this session; TDD requires no invented RED and user scope forbids full rerun/build',frozenInputs,artifacts:files};
await writeFile(join(evidence,'index.json'),JSON.stringify(index,null,2)+'\n');
await writeFile(join(evidence,'artifacts.sha256'),files.map(f=>`${f.sha256}  ${f.path}`).join('\n')+'\n');
const finalIndex=await hash(join(evidence,'index.json'));await writeFile(join(evidence,'index.sha256'),`${finalIndex.sha256}  ${finalIndex.path}\n`);
console.log(JSON.stringify({status:index.status,artifacts:files.length,index:finalIndex.sha256}));
