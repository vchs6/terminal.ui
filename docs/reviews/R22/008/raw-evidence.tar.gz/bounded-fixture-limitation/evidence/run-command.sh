#!/usr/bin/env bash
set -u
source /workspace/work/validation/sdk/cangjie/envsetup.sh
export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env
export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip
export CJTUI_RECOVERY_BINARY=/workspace/work/output-recovery-tests/source/tests/output_recovery/target/release/bin/main
export CJTUI_RECOVERY_ARTIFACTS=/workspace/work/output-caret-test-supplement/evidence/baseline
cd /workspace/work/output-caret-test-supplement/source
# Added after restoring the attempted test edits: refuse the original runner's
# unrecognized-flag fallback. Restore evidence/attempt.patch before replaying.
if ! rg --fixed-strings --quiet "const caretRewrite=process.argv.includes('--caret-rewrite');" tests/output_recovery/run.mjs; then
    printf '%s\n' 'Replay requires evidence/attempt.patch; refusing original-matrix fallback.' >&2
    exit 2
fi
./tests/output_recovery/run.sh run --caret-rewrite > /workspace/work/output-caret-test-supplement/evidence/run.stdout 2> /workspace/work/output-caret-test-supplement/evidence/run.stderr
recovery_status=$?
printf '%s\n' "$recovery_status" > /workspace/work/output-caret-test-supplement/evidence/run.exit
exit "$recovery_status"
