import os,pathlib,subprocess,time,json,shlex,hashlib,datetime,signal,sys
B=pathlib.Path('/workspace/work/visible-snapshot-execution');host=sys.argv[1];out=B/'raw'/('view-'+host);out.mkdir();home=out/'home';home.mkdir();(out/'snapshot.ansi').symlink_to(B/'raw/files/theme-local.ansi')
view='''#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
stty size | tee size.txt
(
    printf '\\033[0m\\033[2J\\033[H'
    cat -- snapshot.ansi
    printf '\\033[0m\\033[25;1H'
)
printf '0\\n' > view.exit
touch ready
while [[ ! -e release ]]; do sleep .1; done
'''
(out/'view.sh').write_text(view)
env=dict(os.environ,DISPLAY=':199',HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'),LANG='C.UTF-8',LC_ALL='C.UTF-8')
for k in ['XAUTHORITY','DBUS_SESSION_BUS_ADDRESS','SESSION_MANAGER','GTK_MODULES']:env.pop(k,None)
title='TASK010 offline snapshot '+host
child=['strace','-f','-s','4096','-xx','-e','trace=write,ioctl,execve','-o',str(out/'terminal.strace'),'bash',str(out/'view.sh')]
cmd=['/workspace/work/cross-terminal-recon/hosts/xterm/usr/bin/xterm','-geometry','80x25+20+20','-T',title,'-fa','DejaVu Sans Mono','-fs','16','-e',*child] if host=='xterm' else ['dbus-run-session','--','xfce4-terminal','--disable-server','--hide-menubar','--geometry=80x25+20+20','--title='+title,'--command='+shlex.join(child)]
(out/'launch.json').write_text(json.dumps(dict(argv=cmd,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),uid=os.getuid(),config={k:env[k] for k in ['DISPLAY','HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','LANG','LC_ALL']},source=str((out/'snapshot.ansi').resolve()),source_sha256=hashlib.sha256((out/'snapshot.ansi').read_bytes()).hexdigest(),scope='Offline same 3x1 file replay only; no full framework device acceptance'),indent=2)+'\n')
p=subprocess.Popen(cmd,env=env,stdout=(out/'host.stdout').open('wb'),stderr=(out/'host.stderr').open('wb'),start_new_session=True)
try:
 end=time.monotonic()+20
 while not (out/'ready').exists():
  if p.poll() is not None:raise RuntimeError('host exited '+str(p.returncode))
  if time.monotonic()>end:raise TimeoutError('view ready')
  time.sleep(.05)
 assert (out/'size.txt').read_text().strip()=='25 80'
 time.sleep(.3)
 tree=subprocess.check_output(['xwininfo','-display',':199','-root','-tree'],text=True);(out/'window-tree.txt').write_text(tree);win=next(x.split()[0] for x in tree.splitlines() if title in x)
 subprocess.run(['import','-display',':199','-window',win,str(out/'original.png')],env=env,check=True,timeout=10)
 identity=[]
 for row in subprocess.check_output(['ps','-eo','pid,comm,args'],text=True).splitlines():
  f=row.strip().split(None,2)
  if len(f)==3 and title in f[2] and f[1] in ['xterm','xfce4-terminal']:
   pid=int(f[0]);exe=pathlib.Path('/proc',str(pid),'exe').resolve();maps=pathlib.Path('/proc',str(pid),'maps').read_text();libs=sorted(set(x.split()[-1] for x in maps.splitlines() if 'libvte-' in x));identity.append(dict(pid=pid,exe=str(exe),exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),vte={v:hashlib.sha256(pathlib.Path(v).read_bytes()).hexdigest() for v in libs}))
 assert identity
 version=subprocess.check_output(['/workspace/work/cross-terminal-recon/hosts/xterm/usr/bin/xterm','-version'] if host=='xterm' else ['xfce4-terminal','--version'],env=env,text=True)
 (out/'identity.json').write_text(json.dumps(dict(host=host,identities=identity,version=version,window=win,capture_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),capture_command=['import','-display',':199','-window',win,str(out/'original.png')]),indent=2)+'\n')
 (out/'release').touch();rc=p.wait(timeout=10);(out/'host.exit').write_text(str(rc)+'\n');assert rc==0
finally:
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
print(host,'actual file replay and original capture complete')
