#!/usr/bin/env bash
set -u
base=/workspace/work/visible-snapshot-execution
cd "$base/source" || exit
source /workspace/work/validation/sdk/cangjie/envsetup.sh
export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env
export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip
export CJTUI_VISIBLE_SNAPSHOT_FILES="$base/raw/files"
{ date -u +%FT%TZ; id; cjc --version; cjpm --version; node --version; cc --version; df -k /workspace; readlink -f "$CJTUI_UCD_ARCHIVE"; sha256sum "$CJTUI_UCD_ARCHIVE"; git rev-parse HEAD HEAD:src HEAD:native; git diff ecbf0999a392e5298e6e5bd15bd796dd9d40e582 -- src native cjpm.toml build.cj; } > "$base/raw/provenance.txt" 2>&1
monitor() { while :; do date -u +%FT%TZ; df -k /workspace; sleep 1; done; }
monitor > "$base/raw/disk-monitor.txt" & monitor_pid=$!
trap 'kill "$monitor_pid" 2>/dev/null || :' EXIT
date -u +%FT%TZ > "$base/raw/cli.started"
PS4='+ ${BASH_SOURCE}:${LINENO}: ' bash -x tests/visible_snapshot/run.sh > "$base/raw/cli.stdout" 2> "$base/raw/cli.stderr"
result=$?
printf '%s\n' "$result" > "$base/raw/cli.exit"
date -u +%FT%TZ > "$base/raw/cli.ended"
{ stat -c '%n %a %U %u %s' "$base/raw/files/denied" "$base/raw/files/short.txt" "$base/raw/files/short.ansi"; git status --short; df -k /workspace; } > "$base/raw/postflight.txt" 2>&1
exit "$result"
