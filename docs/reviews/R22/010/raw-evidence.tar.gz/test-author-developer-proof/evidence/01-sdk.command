bash -c source /workspace/work/validation/sdk/cangjie/envsetup.sh; cjc --version; cjpm --version; node --version; cc --version; df -k /workspace
