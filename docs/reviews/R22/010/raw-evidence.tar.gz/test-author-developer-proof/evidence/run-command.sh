#!/usr/bin/env bash
set -u
label=$1
shift
out=/workspace/work/visible-snapshot-formal-tests/evidence
printf '%s\n' "$*" > "$out/$label.command"
date -u +%FT%TZ > "$out/$label.started"
"$@" > "$out/$label.stdout" 2> "$out/$label.stderr"
code=$?
printf '%s\n' "$code" > "$out/$label.exit"
date -u +%FT%TZ > "$out/$label.ended"
cat "$out/$label.stdout" "$out/$label.stderr"
exit "$code"
