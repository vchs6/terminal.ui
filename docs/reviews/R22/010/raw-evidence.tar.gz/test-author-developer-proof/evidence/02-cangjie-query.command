python /workspace/work/CangjieSkills/.agents/skills/cangjie-coding/scripts/search_docs.py --query String fromUtf8 --query File readFrom --query IllegalArgumentException --max-results 1
