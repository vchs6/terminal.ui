stty size  # 输出“行 列”；确认至少 25 行、80 列后再继续
(
    printf '\033[0m\033[2J\033[H'
    cat -- snapshot.ansi
    printf '\033[0m\033[25;1H'
)
