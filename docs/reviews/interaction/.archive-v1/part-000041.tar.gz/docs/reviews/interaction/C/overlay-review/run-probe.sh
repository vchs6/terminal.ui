#!/usr/bin/env bash
set -uo pipefail
source /workspace/work/linux-build-recon/env.sh
export CJTUI_UCD_ARCHIVE=/workspace/work/terminal.ui/.cjtui-build/UCD-17.0.0.zip
cd /workspace/work/overlay-review/probe
{ date -u +%FT%TZ; cjc --version; cjpm --version; } > ../raw/sdk.txt
date -u +%FT%TZ > ../raw/build.started.utc
cjpm build > ../raw/build.stdout 2> ../raw/build.stderr
status=$?;printf '%s\n' "$status" > ../raw/build.exit
date -u +%FT%TZ > ../raw/build.finished.utc
if [[ "$status" != 0 ]];then exit "$status";fi
date -u +%FT%TZ > ../raw/run.started.utc
./target/release/bin/main > ../raw/run.stdout 2> ../raw/run.stderr
status=$?;printf '%s\n' "$status" > ../raw/run.exit
date -u +%FT%TZ > ../raw/run.finished.utc
exit "$status"
