git diff --cached --check 
