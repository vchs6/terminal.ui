# Capability Specification

状态：待实现需求规格；实现 planned，验证 pending。登记需求不代表产品已实现或变更已归档。

需求全文及细化编号见 [需求说明](../../../docs/requirements.md) REQ-006。本文件维护对应的流程场景投影，变更时与全文及验收映射同步核对，不独立扩大范围。

## Purpose

规定使用者拿到的源码制品必须完整并可以离开开发仓库使用，同时明确开发治理文件的排除边界，避免将历史实现、开发工具、审查记录和凭据混入产品交付。

## Requirements

### Requirement: 产品范围

发行制品 SHALL 包含主库源码、独立示例与基准项目、产品说明、四套预置主题、覆盖组件及状态的展示应用、许可证和必要归属信息；制品内项目引用不得指向包外开发目录。

#### Scenario: 解包后使用

- **WHEN** 最终制品在干净目录解包
- **THEN** 可按产品文档构建主库、运行示例和基准，无需开发治理工具。

### Requirement: 开发资料隔离

CJPM 配置 SHALL 使用 include/exclude 限定产品范围，排除治理规范、OpenSpec、Superpowers、开发文档、CI、历史源码、构建缓存及凭据；实际 bundle 清单必须复核。

#### Scenario: 防止开发文件泄漏

- **WHEN** 生成待发布的 cjp 包
- **THEN** 仅包含允许路径；发现开发文件、包外路径、缺少必要项目时阻止交付。

### Requirement: 未实现不得发布

项目 SHALL 区分规划检查与产品验收；主库、示例或基准未实现时不得生成可发布通过结论，不能以目录存在或空测试通过替代验收。

#### Scenario: 规划阶段

- **WHEN** 本轮 CI 成功但 src 无框架实现
- **THEN** 只报告规划与仓库检查通过，产品构建/发布仍不可用。

### Requirement: 开发版本编号

产品版本 SHALL 使用三段非负整数的主版本.次版本.修订号；当前未发布开发状态标记0.0.0，不把版本字段或文档验收当作产品发布。

#### Scenario: 未实现开发版本

- **WHEN** 读取当前cjpm/package清单
- **THEN** 产品开发版本为0.0.0；工具和第三方依赖版本保留实际固定值，不被批量重置。

### Requirement: Target-specific clean build evidence

发行准备 SHALL 分别验证Linux、Windows、macOS、HarmonyOS冻结配置的源码消费、目标依赖/原生构建及示例运行，记录SDK、CPU/ABI与终端宿主。不能把宿主构建成功或Linux原生归档当作其他目标支持，也不要求同一二进制跨OS运行。

#### Scenario: Clean consumption for each required target

- **WHEN** 为必需平台准备最终源码制品并在干净消费环境构建
- **THEN** 各目标能构建并运行对应示例、主题展示与基准；缺失的构建/链接/运行或许可证据阻止完整跨平台发行结论。

#### Scenario: Native dependency portability

- **WHEN** 字符依赖需要生成数据和C/ASM归档
- **THEN** 用目标工具链/ABI生成并链接，运行分段/宽度样本；不能直接复用Linux归档并声称鸿蒙或其他平台已通过。

#### Scenario: Linux phase deliverable

- **WHEN** 当前为 Linux 优先实施阶段
- **THEN** 按 Linux 冻结配置验证全部功能、M1/M2、示例、主题、基准及干净制品；非 Linux 缺证不阻塞该阶段验收，但未验证平台不声称已支持，发布授权及许可门槛不被绕过。
