import pathlib,json,re,hashlib,gzip
P=pathlib.Path('/workspace/work/incremental-layout-execution');EXPECTED='c9eaf0d77b4c0e3613caaf7581f603394b786c023c2ee3ce3ff7cb36f8dd0a66'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pins():
 found={};pending=[P/'index.json'];seen=set();raw=[]
 assert sha(P/'index.json')==EXPECTED
 def add(path,digest):
  if pathlib.Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest):
   assert path not in found or found[path]==digest,(path,found.get(path),digest)
   found[path]=digest
 def walk(v):
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    add(v['path'],v['sha256'])
    if v['path'].endswith('.json') and pathlib.Path(v['path']).is_absolute():pending.append(pathlib.Path(v['path']))
    if 'original_sha256' in v:raw.append(v)
   for k,x in v.items():
    if isinstance(k,str) and k.startswith('/'):
     if isinstance(x,str):add(k,x)
     elif isinstance(x,dict) and isinstance(x.get('sha256'),str):add(k,x['sha256'])
    walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 while pending:
  p=pending.pop()
  if p in seen:continue
  seen.add(p)
  if str(p) in found:assert sha(p)==found[str(p)],str(p)
  walk(json.loads(p.read_text()))
 for p,h in found.items():assert sha(pathlib.Path(p))==h,p
 for d in raw:
  data=gzip.decompress(pathlib.Path(d['path']).read_bytes());assert hashlib.sha256(data).hexdigest()==d['original_sha256'] and len(data)==d['original_bytes']
 return found
if __name__=='__main__':
 f=pins();print('unique verified indexed objects',len(f))
 pathlib.Path('/workspace/work/validation/ended-126-consumer-intermediates-20261114/indexed-pins-before.json').write_text(json.dumps(f,indent=2)+'\n')
