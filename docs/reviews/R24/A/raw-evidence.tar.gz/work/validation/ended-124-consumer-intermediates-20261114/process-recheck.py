import pathlib,os,json
base='/workspace/work/incremental-layout-implementation/source/tests/incremental_layout';busy=[];denied=[];zombies=0;excluded=[]
expected={122:'runuser',151:'rootlesskit',161:'exe',186:'slirp4netns',195:'dockerd',214:'containerd'}
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  status=(p/'status').read_text()
  if '\nState:\tZ' in status:zombies+=1;continue
  if int(p.name) in expected:
   comm=(p/'comm').read_text().strip();uid=next(x for x in status.splitlines() if x.startswith('Uid:')).split()[1:]
   assert comm==expected[int(p.name)] and all(x==('0' if int(p.name)==122 else '2000') for x in uid)
   st=(p/'stat').read_text();start=st[st.rfind(')')+2:].split()[19]
   excluded.append({'pid':int(p.name),'comm':comm,'uids_in_escalated_namespace':uid,'sandbox_namespace_uid':'65534','starttime_ticks':start,'reason':'explicit root scope exclusion: unrelated nobody-owned container runtime service; inaccessible fds not asserted unused'})
   continue
  targets=[p/'cwd',p/'root',p/'exe']+list((p/'fd').iterdir())
 except FileNotFoundError:continue
 except PermissionError:denied.append(str(p));continue
 for t in targets:
  try:v=os.readlink(t)
  except FileNotFoundError:continue
  except PermissionError:denied.append(str(t));continue
  if any(v.startswith(base+'/'+c+'/target/release/') and v.endswith(('.a','.cjo')) for c in ('baseline','statistics')):busy.append({'entry':str(t),'target':v})
r={'busy':busy,'unexpected_denied':denied,'zombie_count':zombies,'explicitly_excluded_runtime_services':excluded}
pathlib.Path('/workspace/work/validation/ended-124-consumer-intermediates-20261114/process-final.json').write_text(json.dumps(r,indent=2)+'\n')
assert not busy and not denied,r
print(json.dumps(r))
