import pathlib,os,stat,hashlib,json,subprocess
P=pathlib.Path('/workspace/work/incremental-layout-implementation');S=P/'source';O=pathlib.Path('/workspace/work/validation/ended-124-final-intermediates-20261114');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def g(*a):return subprocess.check_output(['git',*a],cwd=S,env=env).decode()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,a):(O/n).write_text(json.dumps(a,indent=2)+'\n')
def free():
 s=os.statvfs(S);return s.f_bavail*s.f_frsize
def inv():
 out=[]
 for d,ds,fs in os.walk(P,followlinks=False):
  for n in sorted(ds+fs):
   p=pathlib.Path(d)/n;s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   r={'path':str(p.relative_to(P)),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
   if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
   elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
   else:raise AssertionError('unexpected special '+str(p))
   out.append(r)
 return sorted(out,key=lambda x:x['path'])
def state():return {'head':g('rev-parse','HEAD').strip(),'status':g('status','--porcelain=v1','--untracked-files=all'),'diff_sha256':hashlib.sha256(g('diff','--binary','HEAD').encode()).hexdigest(),'shared_config_sha256':sha(pathlib.Path(g('rev-parse','--git-common-dir').strip()).resolve()/'config')}
assert S.resolve()==S
beforestate=state();assert beforestate['head']=='4f7e853f821c334318e2038d4e20ab26e72c16c8'
roots=[S/r for r in ('target/release','tests/incremental_layout/baseline/target/release','tests/incremental_layout/statistics/target/release','tests/theme_canvas_integration/target/release','tests/layout/target/release')];candidates=[];provenance=[]
assert all(r.is_dir() for r in roots),'specified release directory missing'
write('actual-release-roots.json',[str(r) for r in roots])
allowed={'cjtui','ansies','unicode','unicodewidth','cangjie_toml','bitarray'}
for root in roots:
 assert root.resolve()==root
 for package in sorted(allowed):
  d=root/package
  assert d.is_dir() and not d.is_symlink()
  for p in sorted(d.iterdir()):
   if p.suffix not in ('.a','.cjo'):continue
   st=p.lstat();assert stat.S_ISREG(st.st_mode) and p.resolve()==p
   if p.suffix=='.a':
    pair=p.with_name(p.name[3:-2]+'.cjo');assert pair.is_file() and not pair.is_symlink(),str(p)
    members=subprocess.check_output(['ar','t',str(p)]).decode().splitlines();assert members and all(m.endswith('.o') and '/' not in m for m in members)
    assert all(m.startswith(package) for m in members),(p,members)
    provenance.append({'path':str(p),'paired_cjo':str(pair),'archive_members':members})
   else:
    with p.open('rb') as f:magic=f.read(8)
    assert magic[4:8]==b'CJOF',(p,magic)
   assert list((root/'.build-logs'/package).glob('*.errlog')),'missing package build logs'
   candidates.append(p)
assert len(candidates)>0
allbefore=inv();by={r['path']:r for r in allbefore};candrel={str(p.relative_to(P)) for p in candidates};chosen=[by[k] for k in sorted(candrel)]
write('all-producer-files-before.json',allbefore);write('candidate-inventory.json',chosen);write('archive-provenance.json',provenance);write('source-before.json',beforestate)
proc=json.loads((O/'process-final.json').read_text());assert not proc['busy'] and not proc['unexpected_denied']
# External evidence scan is empty; validate all sealed producer artifacts and raw gzip payloads.
assert sha(P/'index.json')=='38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81'
producer_index=json.loads((P/'index.json').read_text());pins=producer_index['artifacts']+producer_index['raw_gzip']
assert len(producer_index['artifacts'])==5 and len(producer_index['raw_gzip'])==17
for item in pins:
 q=pathlib.Path(item['path']);assert q not in candidates and sha(q)==item['sha256']
 if 'original_sha256' in item:
  import gzip
  raw=gzip.decompress(q.read_bytes());assert hashlib.sha256(raw).hexdigest()==item['original_sha256'] and len(raw)==item['original_bytes']
write('preserved-producer-pins.json',pins)
# Revalidate each path immediately and unlink only its own regular directory entry, using O_NOFOLLOW parent traversal.
start=free();allocated=sum(r['allocated_bytes'] for r in chosen);unique_allocated=sum(r['allocated_bytes'] for r in chosen if r['nlink']==1)
for p in candidates:
 r=by[str(p.relative_to(P))];s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p
 assert (s.st_dev,s.st_ino,s.st_size,s.st_nlink)==(r['device'],r['inode'],r['size'],r['nlink']) and sha(p)==r['sha256']
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  s=os.stat(p.name,dir_fd=fd,follow_symlinks=False);assert (s.st_dev,s.st_ino)==(r['device'],r['inode']);os.unlink(p.name,dir_fd=fd)
 finally:os.close(fd)
after=inv();assert after==[r for r in allbefore if r['path'] not in candrel],'noncandidate producer files changed'
assert state()==beforestate,'source dirty state changed'
for item in pins:assert sha(pathlib.Path(item['path']))==item['sha256']
assert sha(P/'index.json')=='38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81'
end=free();write('source-after.json',state());write('all-producer-files-after.json',after)
summary={'state':'complete','candidate_count':len(chosen),'candidate_allocated_bytes':allocated,'single_link_allocated_bytes':unique_allocated,'actual_free_recovered_bytes':end-start,'free_before_bytes':start,'free_after_bytes':end,'head':beforestate['head'],'source_dirty_state_and_all_noncandidate_files_unchanged':True,'preserved_file_count':len(after),'sealed_producer_artifact_count':5,'sealed_gzip_count':17,'producer_index_sha256':'38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81','preserved_scope':'all four ELF executables; every .cj/source/lock/config/native archive/CJP/build/raw log and all noncandidate root target files; no other filesystem paths mutated','reconstruction':'normal CJPM consumer rebuild from preserved source/lock/config/SDK/native inputs; generated compiler intermediates are not proof pins','external_evidence_scan':{'command':'rg *index*.json exact producer absolute target/release .a/.cjo namespaces /workspace/work','exit':1,'matches':0},'process_receipt':'process-final.json'}
write('summary.json',summary);print(json.dumps(summary,indent=2))
