import pathlib,json,hashlib,gzip,tarfile,subprocess
base=pathlib.Path('/workspace/work/incremental-layout-execution'); src=base/'source'; prod=pathlib.Path('/workspace/work/incremental-layout-implementation'); ix=prod/'index.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(src),*a])
assert sha(ix.read_bytes())=='38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81'
x=json.loads(ix.read_bytes()); checked=[]
for a in x['artifacts']:
 p=pathlib.Path(a['path']); assert sha(p.read_bytes())==a['sha256'] and p.stat().st_size==a['bytes']; checked.append(a)
raw=[]
for a in x['raw_gzip']:
 data=pathlib.Path(a['path']).read_bytes(); assert sha(data)==a['sha256']; dec=gzip.decompress(data); assert sha(dec)==a['original_sha256'] and len(dec)==a['original_bytes']; raw.append(a)
selected={}
for p in git('ls-tree','-rz','--name-only','HEAD','src','native','tests/layout','tests/theme_canvas_integration','cjpm.toml','build.cj','third_party','themes').decode().rstrip('\0').split('\0'):
 b=git('show','HEAD:'+p); pp=prod/'source'/p; assert pp.read_bytes()==b
 selected[p]=sha(b)
changed=git('diff','b4ccd47c9cf883288e9613d9c06f73f087788717','HEAD','--name-only').decode().splitlines(); members={}
cjp=prod/'source/target/cjtui-0.0.0.cjp'
with tarfile.open(cjp,'r:gz') as t:
 for p in changed:
  b=t.extractfile('cjtui-0.0.0/'+p).read(); assert b==git('show','HEAD:'+p); members[p]=sha(b)
assert len(members)==10
configs={}
for rel in ['cangjie-repo.toml','tests/incremental_layout/baseline/cangjie-repo.toml','tests/incremental_layout/statistics/cangjie-repo.toml']:
 a=(src/rel).read_bytes(); b=(prod/'source'/rel).read_bytes(); assert a==b; configs[rel]=sha(a)
raw_text={a['original_name']:gzip.decompress(pathlib.Path(a['path']).read_bytes()).decode(errors='replace') for a in raw}
for n in ['a3-theme-canvas-final.log','a3-old-layout-run.log','a3-bundle-final.log']:
 text=raw_text[n]; print(n+'\n'+text[-3000:])
result={'producer_index':{'path':str(ix),'sha256':sha(ix.read_bytes())},'audited_artifacts':checked,'audited_raw':raw,'selected_source_equivalence':selected,'config_equivalence':configs,'cjp_changed_members':members,'reused_scopes':['old layout direct exit 0','theme_canvas finite/control/subtree exit 0','normal cjpm bundle final exit 0 after G.EXP.03 correction'],'not_executed_here':['old layout','theme_canvas','cjpm bundle'],'reuse_authority':'AGENTS 11.1; tasks A126','limits':'No author report read; no old-suite rerun, GUI, performance, full M2 or acceptance claim.'}
(base/'reuse-audit.json').write_text(json.dumps(result,indent=2)+'\n')
