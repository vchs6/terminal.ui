import pathlib,json,hashlib,subprocess
base=pathlib.Path('/workspace/work/incremental-layout-execution'); src=base/'source'
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
inputs=[]
for p in [base/'brief.md',pathlib.Path('/workspace/work/terminal.ui/AGENTS.md'),pathlib.Path('/workspace/work/incremental-layout-tests/index.json'),pathlib.Path('/workspace/work/incremental-layout-review/index.json'),pathlib.Path('/workspace/work/validation/sdk/cangjie/envsetup.sh'),pathlib.Path('/workspace/work/validation/sdk/cangjie/tools/bin/cjpm'),pathlib.Path('/workspace/work/validation/sdk/cangjie/bin/cjc'),pathlib.Path('/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip')]:inputs.append(rec(p))
# Inputs only: dependency package source/data/manifests, excluding all compiler intermediates.
cache=pathlib.Path('/workspace/work/viewport-tests/cache/repository/source/default')
deps=[]
for name in ['ansies-1.3.113','unicode-0.1.0','unicodewidth-0.1.113','bitarray-0.1.0','cangjie_toml-0.2.3']:
 for p in sorted((cache/name).rglob('*')):
  if p.is_file() and not any(x in ['target','build-script-cache','.git'] for x in p.relative_to(cache/name).parts) and p.suffix not in ['.a','.cjo','.o','.bc']:deps.append(rec(p))
# The versioned authoritative OpenSpec contract stays in git in this sparse checkout.
contracts={}
for rel in ['openspec/changes/implement-incremental-rendering/tasks.md','openspec/changes/implement-incremental-rendering/design.md']:
 b=subprocess.check_output(['git','-C',str(src),'show','HEAD:'+rel]); contracts[rel]=sha(b)
(base/'inputs.json').write_text(json.dumps({'inputs':inputs,'dependency_sources':deps,'contract_sha256':contracts,'stdx_path':'/workspace/work/linux-build-recon/stdx-env','stdx_resolved':str(pathlib.Path('/workspace/work/linux-build-recon/stdx-env/linux_x86_64_llvm').resolve()),'excluded_intermediates':['.a','.cjo','.o','.bc','target','build-script-cache']},indent=2)+'\n')
print('hashed',len(inputs),'fixed environment/authority inputs and',len(deps),'dependency source inputs')
