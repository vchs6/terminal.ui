import pathlib,json,hashlib,gzip,subprocess,datetime,shutil
b=pathlib.Path('/workspace/work/incremental-layout-execution');s=b/'source'
def sha(x):return hashlib.sha256(x).hexdigest()
def record(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def git(*a):return subprocess.check_output(['git','-C',str(s),*a])
p=json.loads((b/'preflight.json').read_text()); commands=json.loads((b/'commands.json').read_text())
assert all(c['exit']==0 for c in commands) and len(commands)==5
fixed={k:sha((s/k).read_bytes()) for k in p['fixed_tests_before']};assert fixed==p['fixed_tests_before'];assert not git('diff','HEAD','--')
status=git('status','--porcelain').decode();expected={'?? tests/incremental_layout/baseline/cjpm.lock','?? tests/incremental_layout/statistics/cjpm.lock'};assert set(status.splitlines())==expected
(b/'postflight.json').write_text(json.dumps({'fixed_tests_after':fixed,'tracked_diff_empty':True,'status_porcelain':status,'expected_generated_locks':True,'free_bytes':shutil.disk_usage(b).free},indent=2)+'\n')
note=gzip.decompress((b/'raw/tooling-note.log.gz').read_bytes()).decode()+'Postflight driver required fully empty porcelain and exited after both successful builds/runs; only expected ordinary CJPM consumer lockfiles were untracked. Final postflight validates this exact allowlist, empty tracked diff, and fixed test equality; no execution rerun.\n'
(b/'raw/tooling-note.log.gz').write_bytes(gzip.compress(note.encode(),mtime=0))
raw=[]
for f in sorted((b/'raw').glob('*.gz')):
 r=record(f); original=gzip.decompress(f.read_bytes());r.update({'original_name':f.name[:-3],'original_sha256':sha(original),'original_bytes':len(original)});raw.append(r)
artifacts=[record(s/'tests/incremental_layout'/c/'target/release/bin/main') for c in ['baseline','statistics']]
locks=[]
for c in ['', 'tests/incremental_layout/baseline','tests/incremental_layout/statistics']:
 for n in ['cjpm.toml','cjpm.lock','cangjie-repo.toml']:
  f=s/c/n
  if f.exists():locks.append(record(f))
# Match normal consumer lock versions to the reused old consumers, disregarding TOML key order.
import tomllib
own=tomllib.loads((s/'tests/incremental_layout/baseline/cjpm.lock').read_text())
lock_equivalence={}
for c in ['baseline','statistics']:
 q=s/'tests/incremental_layout'/c/'cjpm.lock';assert tomllib.loads(q.read_text())==own
for c in ['layout','theme_canvas_integration']:
 q=pathlib.Path('/workspace/work/incremental-layout-implementation/source/tests')/c/'cjpm.lock';assert tomllib.loads(q.read_text())==own;lock_equivalence[str(q)]=record(q)
def mh(m):return sha(json.dumps(m,sort_keys=True,separators=(',',':')).encode())
source={k:v for k,v in p['versioned_source'].items() if k.startswith(('src/','native/')) or k in ['build.cj','cjpm.toml']}
report=f'''TASK126 independent deterministic execution; exact source {p['commit']} / tree {p['tree']}.
Execution-only task A126; using verification-before-completion; existing OpenSpec contract unchanged.
Fixed tests commit 34240845e4bf393cc5d83475a2c9860a8de10f0e; subtree 936d3ace17f40fc80e1fb452871809e66fb8cb08.
Fixed nine-file SHA256 manifest {mh(fixed)} matches before/after and the frozen test commit.
Source/native 193-file SHA256 manifest {mh(source)}; full versioned manifest is indexed.
ACTUALLY EXECUTED: own baseline ordinary cjpm build exit 0; own direct target/release/bin/main exit 0; cases 1–7 PASS, 0 failures.
ACTUALLY EXECUTED: own statistics ordinary cjpm build exit 0; own direct target/release/bin/main exit 0; cases 8–9 PASS.
Each consumer was built once from absent own ELF; no producer ELF execution or reuse for these nine cases.
Baseline ELF SHA256 {artifacts[0]['sha256']} ({artifacts[0]['bytes']} bytes).
Statistics ELF SHA256 {artifacts[1]['sha256']} ({artifacts[1]['bytes']} bytes).
REUSED ONLY: old layout build/direct exit 0; theme_canvas finite/control/subtree exit 0; final normal cjpm bundle exit 0.
Reuse authority AGENTS11.1/tasksA126: selected source/native/old tests/config bytes match HEAD; dependency lock values match.
Producer index SHA256 38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81 audited; all 5 artifacts and 17 gzip/original logs match.
CJP input SHA256 56a7318d7931490545ee5fd255628170ed0bdc32aca71a11bc549955cfa53b49; all 10 changed source/doc members exactly match HEAD.
Bundle reuse is the final successful run after G.EXP.03 correction; no second bundle or old-suite run here.
Every build/runtime shell sourced SDK envsetup, exported identical STDX/UCD; actual cjpm/cjc 1.2.0; official registry and shared cache configs indexed.
Eight environment/authority inputs and 362 dependency-source inputs hashed; no .a/.cjo/object pins.
Raw gzip maps retain compressed/original SHA256 and byte lengths; commands/cwd/direct exits and generated locks indexed.
Tracked diff empty; only two expected generated consumer locks untracked. Two evidence-driver bookkeeping corrections are documented in raw/tooling-note.
No source/test/main/config/sparse edits, author report/self-assessment, or subagents; no new acceptance, performance, full M2, or device/backend claim.
Free space {shutil.disk_usage(b).free//1048576} MiB at postflight; 12 MiB pre-large-write stop policy maintained.
'''
(b/'report.md').write_text(report)
index={'schema':1,'role':'TASK126 independent execution','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':p['commit'],'tree':p['tree'],'tests_commit':'34240845e4bf393cc5d83475a2c9860a8de10f0e','tests_subtree':'936d3ace17f40fc80e1fb452871809e66fb8cb08','fixed_test_manifest_sha256':mh(fixed),'source_native_manifest_sha256':mh(source),'all_versioned_manifest_sha256':mh(p['versioned_source']),'commands':commands,'actual_cases':{'baseline':7,'statistics':2,'failures':0},'artifacts':artifacts,'config_lock_inputs':locks,'reused_lock_equivalence':lock_equivalence,'raw_gzip':raw,'recursive_manifests':[record(b/f) for f in ['preflight.json','postflight.json','inputs.json','reuse-audit.json','commands.json']],'evidence_tools':[record(b/f) for f in ['execute.py','audit.py','index_inputs.py','finalize.py']],'report':record(b/'report.md'),'scope':'Fresh independent fixed9; audited reuse only for oldlayout/theme_canvas3/final normal bundle under AGENTS11.1. No acceptance/fullM2/performance/backend claim.'}
(b/'index.json').write_text(json.dumps(index,indent=2)+'\n');print('index SHA256',sha((b/'index.json').read_bytes()));print(report)
