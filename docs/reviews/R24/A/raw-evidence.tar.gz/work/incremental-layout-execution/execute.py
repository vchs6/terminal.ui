import subprocess,pathlib,json,hashlib,os,gzip,shutil,datetime
base=pathlib.Path('/workspace/work/incremental-layout-execution'); src=base/'source'; raw=base/'raw'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*a): return subprocess.check_output(['git','-C',str(src),*a])
def files():
 return {p:sha(git('show','HEAD:'+p)) for p in git('ls-tree','-rz','--name-only','HEAD').decode().rstrip('\0').split('\0')}
tracked=files(); fixed={p:sha((src/p).read_bytes()) for p in tracked if p.startswith('tests/incremental_layout/')}
assert fixed=={p:sha(git('show','34240845e4bf393cc5d83475a2c9860a8de10f0e:'+p)) for p in fixed}
assert git('rev-parse','HEAD').decode().strip()=='4f7e853f821c334318e2038d4e20ab26e72c16c8'
assert not git('status','--porcelain')
env='source /workspace/work/validation/sdk/cangjie/envsetup.sh\nexport CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env\nexport CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip\n'
commands=[]
def run(name,cmd,cwd):
 if shutil.disk_usage(base).free < 12*1024*1024: raise RuntimeError('STOP free <12MiB')
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); p=subprocess.run(['bash','-c',env+cmd],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 data=p.stdout; out=raw/(name+'.log.gz'); out.write_bytes(gzip.compress(data,mtime=0))
 rec={'name':name,'command':cmd,'cwd':str(cwd),'exit':p.returncode,'started_utc':start,'path':str(out),'sha256':sha(out.read_bytes()),'original_sha256':sha(data),'original_bytes':len(data)}; commands.append(rec)
 (base/'commands.json').write_text(json.dumps(commands,indent=2)+'\n'); print(name,'exit',p.returncode,'bytes',len(data),'freeMiB',shutil.disk_usage(base).free//1048576,flush=True); print(data.decode(errors='replace')[-2500:],flush=True)
 return p.returncode
run('environment','command -v cjpm cjc\ncjpm --version\ncjc --version\nprintf "CANGJIE_STDX_PATH=%s\\nCJTUI_UCD_ARCHIVE=%s\\n" "$CANGJIE_STDX_PATH" "$CJTUI_UCD_ARCHIVE"\nuname -a\ndf -Pk .',src)
(base/'preflight.json').write_text(json.dumps({'commit':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'versioned_source':tracked,'fixed_tests_before':fixed},indent=2)+'\n')
for consumer in ['baseline','statistics']:
 cwd=src/'tests/incremental_layout'/consumer
 assert not (cwd/'target/release/bin/main').exists()
 if run(consumer+'-build','cjpm build',cwd): raise SystemExit('build failed')
 run(consumer+'-direct','target/release/bin/main',cwd)
assert fixed=={p:sha((src/p).read_bytes()) for p in fixed}
assert not git('status','--porcelain')
(base/'postflight.json').write_text(json.dumps({'fixed_tests_after':fixed,'status_porcelain':git('status','--porcelain').decode(),'free_bytes':shutil.disk_usage(base).free},indent=2)+'\n')
