# Unit 124.A2 internal execution plan

- Move the target measurement root and each node's reusable layout result from RuntimeSession to its RuntimeNode; resolve cached children using the runtime sequence. Publish only after a successful measurement and discard each node's temporary lookup map; preview/reference results remain transient.
- Add an internal non-publishing Binding evaluation guard for reference Canvas measure/draw; keep persistent subscriptions and CanvasState measurement unchanged, while executing callbacks and recording real work. Do not detach existing observers.
- Pass glyph policy through each layout result for mounted reference rendering, without selecting or invalidating the persistent target policy or changing target validation size. Preserve stabilization and normal target path.
- Run normal root build and fixed baseline build/direct execution using SDK 1.2; retain logs and commit only source. New stats remain A3.
