# Unit 124.A1 internal execution plan

Goal: split the existing layout kernel into measurement, arrangement, and painting while retaining existing public behavior.

- `src/layout_node.cj`: replace stored ordered children with a render-local ID lookup shared by nodes; enumerate visible children from `RuntimeNode.sequence`, preserving the only committed order authority. Preserve previous measurement lookup for theme preview.
- `src/layout.cj`: change `layoutPass` to arrangement only, retaining viewport, finite fallback and overlay geometry. Store paint inputs in each transient layout result. Move decoration, text and Canvas drawing to a recursive `paint` consuming arranged values; retire allocation and geometry commits from paint.
- Keep existing root and overlay preflight/ensure sequencing; paint the last arranged geometry and do not modify tests or public API. Reference isolation and stats belong to A2/A3.
- Build with SDK 1.2.0 and run fixed baseline consumer. Cases 1–5 and 7 must remain green; case 6's known reference subscription failure may remain. Record actual result and commit only source changes.
