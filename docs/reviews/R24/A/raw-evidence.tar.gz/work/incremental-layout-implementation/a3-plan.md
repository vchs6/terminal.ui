# Unit 124.A3 internal execution plan

- Add three readonly RuntimeStats fields with package-private default named tail; session records arrangement during real target/reference layout, excluding candidate previews.
- Frame uses a per-instance optional session owner only while generating application targets and snapshot copies. Count successful Cell allocation at each Array<Cell> creation, initialized target cells and all assignments through one write helper; transfer's temporary Cell array contributes allocated slots. Clear ownership before caller can mutate a returned Frame.
- Preserve public Frame constructor/copy behavior and independent Frame operations. Avoid shared process counters and keep new session totals initialized to zero.
- Run fixed baseline and statistics normal consumers and affected prior consumers, verify frozen test tree, run normal cjpm bundle with tests and lint. Capture commands, exits, SHA of eligible artifacts; report scope and limitations without acceptance claims.
