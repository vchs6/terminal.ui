import json,hashlib,gzip,subprocess,tarfile
from pathlib import Path
out=Path('/workspace/work/incremental-layout-acceptance'); root=Path('/workspace/work')
source=root/'incremental-layout-execution/source'; producer=root/'incremental-layout-implementation/source'
checks=[]; failures=[]; seen=set()
def digest(b): return hashlib.sha256(b).hexdigest()
def check(path,expected,size=None,origin=None):
 p=Path(path); key=(str(p),expected)
 if key in seen:return
 seen.add(key)
 try:
  b=p.read_bytes(); actual=digest(b); ok=actual==expected and (size is None or len(b)==size)
  row={'path':str(p),'sha256':actual,'bytes':len(b),'match':ok}
 except Exception as e: row={'path':str(p),'match':False,'error':str(e)}
 if origin:row['manifest']=str(origin)
 checks.append(row)
 if not row['match']:failures.append(row)
def walk(obj,base,origin):
 if isinstance(obj,dict):
  if 'path' in obj and 'sha256' in obj:
   p=Path(obj['path']);p=p if p.is_absolute() else base/p
   check(p,obj['sha256'],obj.get('bytes'),origin)
   if obj.get('original_sha256'):
    b=gzip.decompress(p.read_bytes());ok=digest(b)==obj['original_sha256'] and len(b)==obj['original_bytes']
    checks.append({'gzip_original':str(p),'sha256':digest(b),'bytes':len(b),'match':ok})
    if not ok:failures.append(checks[-1])
  for v in obj.values():walk(v,base,origin)
 elif isinstance(obj,list):
  for v in obj:walk(v,base,origin)
pins={'execution':'c9eaf0d77b4c0e3613caaf7581f603394b786c023c2ee3ce3ff7cb36f8dd0a66','review':'c4777fad35cc4b3d43b6b9eae779fb3623e34dde7a1ddeb8845100fba494f00e','tests':'345ff318bc070a8535858e087fe44d605c1cec11c62354c58389698d5a828f64','implementation':'38f73e64cd3672c7cc9da9a3c16fee3c92d73ff4244ac4fbcf850da214ebbe81'}
for role,sha in pins.items():
 p=root/f'incremental-layout-{role}/index.json';check(p,sha);walk(json.loads(p.read_text()),p.parent,p)
e=root/'incremental-layout-execution'
for name in ['preflight','postflight','inputs','reuse-audit','commands']:
 p=e/(name+'.json');walk(json.loads(p.read_text()),e,p)
pre=json.loads((e/'preflight.json').read_text());inputs=json.loads((e/'inputs.json').read_text());reuse=json.loads((e/'reuse-audit.json').read_text())
blob_checks=[]
proc=subprocess.Popen(['git','-C',str(source),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for path,sha in pre['versioned_source'].items():
 if (source/path).exists(): check(source/path,sha,origin=e/'preflight.json')
 else:
  proc.stdin.write(('HEAD:'+path+'\n').encode());proc.stdin.flush()
  header=proc.stdout.readline().decode().split();size=int(header[2]);b=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
  ok=digest(b)==sha;row={'git_path':path,'sha256':digest(b),'bytes':len(b),'match':ok};blob_checks.append(row)
  if not ok:failures.append(row)
proc.stdin.close();assert proc.wait()==0
for path,sha in reuse['selected_source_equivalence'].items():
 check(source/path,sha,origin=e/'reuse-audit.json');check(producer/path,sha,origin=e/'reuse-audit.json')
for path,sha in inputs['contract_sha256'].items():check(root/'terminal.ui'/path,sha,origin=e/'inputs.json')
for path,sha in reuse['config_equivalence'].items():
 p=Path(path)
 if p.is_absolute():check(p,sha)
 else:check(source/p,sha);check(producer/p,sha)
git={}
for name,repo in [('independent',source),('producer',producer)]:
 def run(*a):return subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
 git[name]={'head':run('rev-parse','HEAD'),'tree':run('rev-parse','HEAD^{tree}'),'tracked_diff':run('diff','HEAD','--stat'),'test_tree':run('rev-parse','HEAD:tests/incremental_layout')}
 assert git[name]['head']=='4f7e853f821c334318e2038d4e20ab26e72c16c8' and git[name]['tree']=='0b72a9e87a2abc1fc7e19ba031bba9554000537b' and git[name]['tracked_diff']==''
fixed=subprocess.check_output(['git','-C',str(source),'rev-parse','34240845e4bf393cc5d83475a2c9860a8de10f0e:tests/incremental_layout']).decode().strip()
assert fixed==git['independent']['test_tree']==git['producer']['test_tree']
package=[]
with tarfile.open(producer/'target/cjtui-0.0.0.cjp') as t:
 for path,sha in reuse['cjp_changed_members'].items():
  matches=[m for m in t.getmembers() if m.name.endswith('/'+path) or m.name==path]
  assert len(matches)==1,(path,len(matches))
  b=t.extractfile(matches[0]).read();ok=digest(b)==sha
  package.append({'member':matches[0].name,'sha256':digest(b),'match':ok})
  if not ok:failures.append(package[-1])
result={'schema':1,'role':'TASK127 fresh read-only binding verification','pins':pins,'git':git,'fixed_test_tree':fixed,'file_binding_count':len(seen),'checks':checks,'sparse_git_object_checks':blob_checks,'tooling_note':'Initial read-only verifier tried to read every versioned manifest entry as a sparse-worktree file; corrected to validate absent paths through frozen Git objects. No source or test failure.','package_changed_members':package,'failures':failures,'limits':'No product/test edits, compilation, suite execution or source-author report read. Hash verification of report bytes does not inspect report content.'}
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'file_bindings':len(seen),'gzip_checks':sum('gzip_original'in c for c in checks),'package_members':len(package),'sparse_git_objects':len(blob_checks),'failure_count':len(failures),'git':git},indent=2))
assert not failures
