C1: Separate evaluation candidates from effective node invalidation and retain explicit notifications and lifecycle boundaries.
C2: Reuse bounded node measurements and geometry when their actual inputs remain valid, preserving the shared layout algorithm and transient reference isolation.
C3: Run the fixed consumer and relevant compatibility checks, record direct evidence and commit source changes for independent review.
