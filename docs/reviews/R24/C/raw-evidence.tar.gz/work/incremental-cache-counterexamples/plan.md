# TASK135 round-one independent counterexamples

Execution-only test task, fixed source f89d3726b76441e144ac501a5cba5a84549db6c8. Assigned Sol/high; serving configuration not independently verified. Original sealed TASK133 workspace is outside this task and untouched.

- Read verbatim independent findings F1–F5; consume public API plus frozen C requirements. No product-author plans/reports or product fixes.
- Keep all original19 test functions, assertions, helpers and oracles byte-identical; main changes only add names/registry entries.
- F1: initial focused Text wraps abcdef at width3; focusing following Z changes effective wrap, and M1 literal must be abc/Z/blank/blank while complete target Cells must agree.
- F2: independent changed StyleUse and changed VisualStates foreground-only cases must update raw Cell styles with zero measures/arranges.
- F4: three unrelated auto-height panels, each with nested Column and eight leaves; change one same-size leaf, no fixed-height barriers. Affected path has four nodes. Conservative arrange bound=4 path nodes x2 maximum finite/fallback passes x2 geometry walks (allocation summary and arrangement)=16. Tree has31 nodes; unrelated nested subtrees must not be recursively recomputed. No elapsed-time assertion.
- F5: root Canvas.viewport(Off), same width/new finite height; diagnostic callback count and stats captured before full render. Each actual measure callback requires truthful positive recorded measures. No Observable writes or hooks in callback instrumentation.
- F3: no public queue-size API; source-only boundedness obligation remains with independent source QA, with no capacity claim from public functional output.
- One normal own-consumer build and direct run authorized, fixed SDK/stdx/UCD and precreated official cache config. Preserve failures, pin actual current ELF only; alert below30MiB, stop before12MiB.
- Deliver test-only commit, <=25-line facts report, minimal source/raw/pin index. No old-suite repeats, unpacked run, subagents, or extra ELF copies.
