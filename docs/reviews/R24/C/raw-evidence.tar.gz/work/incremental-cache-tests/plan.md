# TASK133 test preparation

Execution task under implement-incremental-rendering TASK133; frozen design §§4/5/9/10/14 M001/M003/M004/M009/M011. Assigned Sol/high; actual serving configuration is not independently observable.

- Own source starts at c2f57414; accepted A + fixed B tests, without B product. Prepare only until root supplies fixed B132 input and build GO.
- Add a normal public CJPM consumer at tests/incremental_layout/invalidation_cache. Keep existing tests and product files unchanged; no dependencies, private hooks, runtime modes, or shared configuration changes.
- Test breaks: equal binding results spuriously invalidate layout; constant replacement leaves old subscriptions; explicit notify is swallowed; keyed/manual moves or hidden updates lose geometry; span/color/source changes invalidate measurement or miss paint; Canvas dependencies interfere; layout cache ignores flex, justification, wrap/insets, viewport/root fallback, or generated marker policy.
- Every paired observation uses the same mounted root, dimensions, glyph policy and synchronous business epoch. Compare every Cell field against full render independently of literal hand-derived layouts. Capture snapshot work before full render and report both deltas.
- Work checks derive from tree shape: zero measures/arranges for pure style or stable typed output; reduced measures for one changed leaf beside unrelated nested subtrees; zero remeasurement for position-only movement. Do not assert paint locality before D.
- Prepare public constant/getter, typed equality, all notify categories, same-width and geometry changes, ForEach/manual/If, hidden updates, RichText, theme masks/fill, Canvas, root/viewport and glyph cases.
- TDD + writing-good-tests and repository cangjie-coding skills read; language-reference queries used. CJPM scaffold created by SDK1.2 cjpm init. Build/red evidence intentionally deferred by explicit preparation gate; no green claim.
- After admission: fix input pin, run normal cjpm build + direct binary, preserve raw expected baseline failures separately from compiler/test defects; provide report.md <=25 lines and minimal index.json with pins/commands/raw files. Root handles unchanged-suite proof and integration.

## Admitted baseline facts

B132 accepted 275149c274df41d38ffc950f104b31185dea19a7; exact four files applied as 2389618ab0a5fb99d59236d02e054ffa0ebd63a9 after preparation c23adbd63afea032c184bd876e57b3eeeb15ba27. Root released build gate. SDK1.2 build01/02 diagnosed mutable-var capture and ambiguous None; final test-only correction 2358365eafa64375347fd1840b705487a585d8a9 uses immutable Array<Option> cells and qualified constructors. No oracle changes.

Build03 succeeded; run01 exited1 with ten early work failures. Parent approved collecting unchanged work assertions until exit. Build04 succeeded; run02 completed all19 correctness cases with correctness_failed0, work_failed_cases10/work_failed_assertions27 and exit1. Original raw logs remain intact. No further builds authorized/needed. Existing A/B tests and all admitted product source remain unchanged. No fresh unpacked-bundle run claimed; B package proof is reused only through exact source/public API/admitted index; TASK136/final E/023 package consumption remains mandatory.
