# TASK133 independent test preparation

Read this first: requirements below plus binding final design from /workspace/work/terminal.ui/openspec/changes/implement-incremental-rendering/design.md sections4/5/9/10/14 M001/M003/M004/M009/M011.

## Global Constraints

- 原TASK-031/022为完整验收责任归属；123–142实现031各单元，143–147实现022并供031成本验收。实际工程层级依原WP002/WP005，角色工作为独立L3，不把原L3强行嵌另一套L3树。主仓接入时031/022转为本tasks唯一状态引用，不能保留两份勾选权威。
- 单元A123–127已独立接受；128测试已固定、129实施中，其余仍planned；有上游合同不等于上游产品已通过。正式产品124前必须冻结全部功能M1源码/制品及下表最终SHA；禁止提前用c3d743d有限功能作性能基线。
- A→B→C→D→E顺序集成。测试可按冻结合同准备，但产品只消费前单元验收固定提交；共享Component/Layout/Frame禁止多个产品作者同时编辑。
- 每实体一个小写下划线.cj文件，最小可见性，原public调用兼容，新增RuntimeStats三项仅只读；无私有测试hook、无强制M1/M2模式开关。
- 测试作者Sol/high、产品Terra/high或适合仓颉任务的Sol/high、审核/验收Astra/high、执行Sol/medium；记录指定配置，无法核验serving时不冒充实测。
- 角色只交接合同、固定源码/测试SHA、公开命令和原始证据，不交产品作者自评。验收按原AC及实际工作量/CPU/分配/输出，不以测试数量代替。
- 不publish、不改共享SDK/seed/cache、正式基准不依赖探针或开发目录；正常CJPM和普通bundle消费者不可skip。


### C / 133–137（父031，REQ004.8/002，C/主题/Canvas合同）

文件：133扩tests/incremental_layout；134改runtime_node/session、binding结果提交、layout/node及theme resolver/Canvas依赖的已冻结接缝；必要node_dirty/measure_key/measure_result各实体文件。禁止第二children列表/第二resolver。

输入132；输出分类dirty、约束缓存、受影响measure/arrange集合及新旧几何。

- [ ] 133准备常量替getter、typed相等、notify各类别、ForEach keymove/manual、hidden→visible、纯span样式与文字、theme mask/fill、Canvas M/P独立失效；每批同root稳定M1对照。
- [ ] 133覆盖Row flex余数与兄弟重分配、Column后续/justify前后移动、宽wrap高度/四pad、root fallback与viewport clamp；固定能证明无关工作为零/减少的树形场景，不给凭空时间阈值。
- [ ] 134分开待求值与真正有效输出dirty；Content/Style/Layout/Structure不互相吞并，只有成功目标消费当期版本。
- [ ] 134有界intrinsic/实际约束缓存，位置变化复用文本测量；隐藏待算失效保留；依赖传播以真实输出/输入不变截断，不仅比父大小。
- [ ] 135审核缓存key、source mask/fill、独立Canvas依赖、真实C序列、cutoff之后通知与GC订阅资源；136独立执行133及相关生命周期/主题组合；137确认局部布局成立，paint局部仍待D。



Prepare test-only normal public consumers under tests/incremental_layout/invalidation_cache (or cohesive new independent project), one entity per file, keep all existing tests unchanged. No product edits, private hooks, fake timers/performance thresholds, new dependencies or flags. Each pair: same mounted root stable business epoch; snapshot plus same-size/policy full render; full Cell equality independent of specific layout expectations. Include independently hand-derived literal layouts and minimal necessary observable work bounds from tree shape, not author code. Check typed equality, explicit notify, inherited style masks, Canvas measure/draw independence, layout propagation, root/viewport and Glyph policy inputs from C card. No new behavior outside this approved unit.

Own source tree is precreated at main c2f57414: accepted A and fixed B tests, NOT B implementation. Current B129/130–132 underway; test preparation allowed by plan but C product cannot begin until B132. For now DESIGN+CODE ONLY, do not build until root releases budget and gives B132 fixed input; no dependency copies, shared target or SDK/global config modifications. No subagents. Use test-driven-development and relevant repository Cangjie reference tools, actual SDK1.2 facts preferred. Read AGENTS from main once, only relevant contracts/API from own src and product docs; do not read product-author drafts/reports.

SDK per every eventual build/runtime: source /workspace/work/validation/sdk/cangjie/envsetup.sh; CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env; CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip. Own ignored cangjie-repo.toml allowed root/newconsumer: repository.cache.path=/workspace/work/viewport-tests/cache, repository.home.registry=https://pkg.cangjie-lang.cn/registry. Never18973relay.

Write concise plan.md, test-source commit when coherent; report.md<=25lines and minimal index.json with source/raw/pins after eventual allowed build. Source/raw/commands facts only, not self-assessment. Message when code prepared and wait for fixed B admission/build GO. Root will reuse existing proof for unchanged tests. Assigned Sol/high for independent test design.
