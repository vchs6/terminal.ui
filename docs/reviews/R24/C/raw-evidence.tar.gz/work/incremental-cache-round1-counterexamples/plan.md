# TASK135 round1 new public regressions

Execution-only independent test task, fixed product source4e30434ac29b49a5aa1e6acdad4a2f5f8373dc4b, assigned Sol/high; actual serving configuration not independently verified. Read verbatim independent review R1-N1/R1-N2. All previous sealed TASK133 and58/f89 evidence remains untouched.

- Add only two public case functions plus main registry entries. Preserve prior24 cases, helpers, assertions and literal oracles byte-for-byte.
- N1: warm Column/Text(x) with inline width1 at3x1. No observable bindings or other pending work. One direct batch replaces inline width3, immediately calls that Text reference.ensureVisible(Rect(2,0,1,1)), then increments a nonobservable business epoch. No layout/snapshot/oracle between mutation and ensure. Require ordinary API completion and same-root full Cell/literal equality afterward; log/rethrow any actual UIException.
- N2: warm Column/Column/Text(observable abc), Unicode3x1. One direct batch changes text to q and increments a nonobservable epoch. Immediately snapshot Ascii3x1 before any oracle/helper refresh. Compare successful target against full M1 and independent literal q+two spaces; record actual exception if target fails.
- Prepare source only until explicit root CAPACITY GO at>=150MiB. Then one normal own-consumer build and direct run with fixed SDK/stdx/UCD and precreated official cache config; preserve all actual failures and runtime provenance. No product changes, fixes/guidance, old suites, unpacked builds, subagents, or ELF copies.
- Deliver fixed test-only commit, <=20-line factual report, minimal source/raw/config/current-ELF index and original24 byte-equivalence proof. If either prediction is not reproduced, report actual public scope without forcing failure.
