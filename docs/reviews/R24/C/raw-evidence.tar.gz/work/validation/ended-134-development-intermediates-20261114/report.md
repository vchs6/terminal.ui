Completed only explicitly authorized C134 capacity work. Actual layout differed from the initial request: only root source/target/release existed, and all consumers shared it; separate named consumer/Frame targets were absent. SourceHEAD107ef32c held five modified .cj files plus generated locks. Root superseded the partial-Frame restriction after both recorded Frame build logs said success, both runs showed7cases0failures, and current verify-frame_cow was present with no active compiler.

Phase1: removed61 unindexed paired generated Cangjie .a/.cjo regular files, releasing32,690,176B. CJOF/ar package-object provenance, local evidence pin scan and fresh process checks passed. All532 noncandidate files/artifacts/dirty source bytes stayed exact.

Phase2 (explicit bounded scope amendment): removed only redundant shared/bin verify-baseline, verify-invalidation_cache and verify-statistics after proving each had a distinct intact exact SHA+length copy under role artifacts/. Retained copies were hashed twice before unlink and again after; originals had fresh metadata/SHA proof and no exe/fd holders. Released57,778,176B. All57,762,624 original executable bytes remain physically intact in artifacts/. No new executable copies were written.

Total allocation recovery90,468,352B (86.28 MiB). Completion free99,708,928B (95.09 MiB), slightly below100MiB aim; exact authorized set exhausted. All529 other files, actual sourceHEAD/status/diff and five dirty source hashes, CJP, verify-frame_cow BIN, artifact copies, raw/native/config/locks/runner and main107 HEAD/tree/config/historical Git objects stayed exact. SDK/cache/other workspaces were untouched. No compiler/hash retention authority was deleted.

The old three BIN paths are logical aliases resolved by duplicate-alias-map.json, which records retained paths, exact bytes/SHA, mode/uid/gid/mtime and current physical state. No final author index existed during the pause; final proof should pin retained artifacts paths and preserve this mapping for command-path history. Original inode/ctime are historical only. Compiler objects are reproducible using ordinary CJPM builds with preserved current source/locks/config/SDK/native inputs.

Restore an old BIN path safely, with room for one copy:

```sh
python3 /workspace/work/validation/ended-134-development-intermediates-20261114/restore-duplicate.py ORIGINAL_ABSOLUTE_BIN_PATH
```

The helper refuses an existing path, verifies retained/copy bytes and SHA, restores mode/uid/gid/mtime, and publishes exclusively without overwrite. Retained artifacts remain intact. Author may record a fresh DIRECT Frame exit and finish commit/index after sealing; this cleanup requires no rebuild. Process proof used only the six documented unrelated service exclusions (643 zombies skipped).
