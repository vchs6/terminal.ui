import pathlib,json,hashlib,subprocess,tarfile,gzip,tomllib
W=pathlib.Path('/workspace/work'); out=W/'incremental-cache-acceptance'; src=W/'incremental-cache-implementation/source'; exe=W/'incremental-cache-execution/source'
head='ee84e7ac7a35bb6481a17ecb91f1ec07804b672a'; tests='4845df24b33f75432d26a68fb0b844abbb4e8528'
records=[]
def pin(p):
 p=pathlib.Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(d):
 r=pin(d['path']); assert r['sha256']==d['sha256'],r['path']; assert 'bytes' not in d or r['bytes']==d['bytes'],r['path']; records.append(r)
def walk(d):
 if isinstance(d,dict):
  if 'path' in d and 'sha256' in d: check(d)
  for v in d.values(): walk(v)
 elif isinstance(d,list):
  for v in d: walk(v)
def git(*args):return subprocess.check_output(['git','-C',str(src),*args])
roots={
 'incremental-cache-execution/index.json':'ecf8ee2741d96c4302426e84a3adf7a212d9ebf8bf8ea74179b351f2b8519ed8',
 'incremental-cache-implementation/index-round2.json':'1de4e2c1ff2a2c5c7d6e70055bad19e7c64fcbf7d8badea6174a0a57e1d1475e',
 'incremental-cache-review/index.json':'798053c043d18d8af2637bab7baca413a8fd40354159b2afb8289800beb7282c',
 'incremental-cache-review/round1/index.json':'ea6878cfb12231ab0c707941dc005534bc26712895824ad5d9899e345f033c53',
 'incremental-cache-review/round2/index.json':'1ffbfd531fed168292c4cf876e88aa26afc5101d7540936594f03add00c52008'}
root_pins=[];counts={}
for rel,h in roots.items():
 p=W/rel;check({'path':str(p),'sha256':h});root_pins.append(pin(p));d=json.loads(p.read_text())
 if rel in ['incremental-cache-execution/index.json','incremental-cache-implementation/index-round2.json']:
  n=len(records);walk(d);counts[rel]=len(records)-n
 else:
  for relfile,sha in d.get('output_sha256',{}).items(): check({'path':str(p.parent/relfile),'sha256':sha})
assert git('rev-parse','HEAD').decode().strip()==head
paths=git('ls-tree','-r','--name-only',head,'src','native','build.cj','cjpm.toml','tests/incremental_layout/baseline','tests/incremental_layout/statistics','tests/incremental_layout/frame_cow','tests/incremental_layout/invalidation_cache').decode().splitlines()
for path in paths:
 b=git('show',head+':'+path); assert (src/path).read_bytes()==b,path; assert (exe/path).read_bytes()==b,path
assert not git('diff',head,tests,'--','tests/incremental_layout/invalidation_cache')
assert not git('diff','4e30434ac29b49a5aa1e6acdad4a2f5f8373dc4b',head,'--','src/frame.cj','src/frame_row.cj','src/runtime_stats.cj','native','build.cj','cjpm.toml','tests/incremental_layout/frame_cow')
assert not git('diff','275149c274df41d38ffc950f104b31185dea19a7',head,'--','src/frame.cj','src/frame_row.cj','src/runtime_stats.cj','native','build.cj','cjpm.toml')
assert not git('diff','275149c274df41d38ffc950f104b31185dea19a7','107ef32cde77fdd343fd8f6762132aa01df0143a','--','src','native','build.cj','cjpm.toml')
old_main=git('show','d901cf39292230c11abbe1c1958126b123fb1794:tests/incremental_layout/invalidation_cache/src/main.cj').split(b'    var failures:')[1]
current_main=git('show',head+':tests/incremental_layout/invalidation_cache/src/main.cj').split(b'    var failures:')[1]
assert old_main==current_main
old_tests={}
for old in ['d901cf39292230c11abbe1c1958126b123fb1794','58d94a6d0d86bcec41c7abfb6ba0c3418b29dfc4']:
 ps=git('ls-tree','-r','--name-only',old,'tests/incremental_layout/invalidation_cache').decode().splitlines()
 for p in ps:
  if not p.endswith('/main.cj'): assert git('show',old+':'+p)==git('show',head+':'+p),p
 old_tests[old]=len(ps)-1
pins=json.loads((W/'incremental-cache-execution/source-config-dependency-pins.json').read_text());n=len(records);walk(pins);counts['explicit source/config/dependency files']=len(records)-n
native=[]
for p in sorted((src/'native').glob('*.a')):
 a=pin(p);b=pin(exe/'native'/p.name);assert a['sha256']==b['sha256'];native.extend([a,b])
cjp=W/'incremental-cache-implementation/artifacts/cjtui-round2.cjp';members=[]
with tarfile.open(cjp,'r:gz') as tf:
 for m in tf.getmembers():
  rel=m.name.split('/',1)[-1]
  if m.isfile() and (rel.startswith(('src/','native/')) or rel in ['build.cj','cjpm.toml']):
   b=tf.extractfile(m).read(); assert b==(src/rel).read_bytes(),rel;members.append({'member':m.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert len(members)==193
r1=json.loads((W/'incremental-cache-implementation/index-round1.json').read_text())
for r in [r for key in ['raw','config'] for r in r1[key] if 'frame' in r['path']]:check(r)
witness=json.loads((W/'incremental-cache-execution/frame-witness-audit.json').read_text());f=witness['frame'];check({'path':f['witness'],'sha256':f['witness_sha256'],'bytes':f['witness_bytes']})
h=hashlib.sha256();length=0
with gzip.open(f['witness'],'rb') as stream:
 while b:=stream.read(1048576):h.update(b);length+=len(b)
assert h.hexdigest()==f['original_sha256'] and length==f['original_bytes']
locks=[src/'cjpm.lock']+[src/'tests/incremental_layout'/name/'cjpm.lock' for name in ['baseline','statistics','frame_cow','invalidation_cache']]+[exe/'tests/incremental_layout/invalidation_cache/cjpm.lock']
expected=tomllib.loads(locks[0].read_text())
for p in locks:assert tomllib.loads(p.read_text())==expected,str(p)
history=[]
for rel in ['incremental-cache-counterexamples/index.json','incremental-cache-round1-counterexamples/index.json']:
 p=W/rel;d=json.loads(p.read_text());history.append(pin(p))
 for r in d['artifacts']:
  if r['path'].endswith(('/raw/run-01.txt','/raw/build-01.txt','/raw/original-tests-proof.json')):check(r)
for rel in ['incremental-layout-acceptance/index.json','frame-cow-acceptance/index.json']:
 p=W/rel;d=json.loads(p.read_text());history.append(pin(p))
 for r in d.get('artifacts',d.get('own_artifacts',[])):
  if pathlib.Path(r['path']).name in ['report.md','findings.json']:check(r)
run=(W/'incremental-cache-execution/run.log').read_text();assert run.count('\nCORRECT CASE ')==26 and sum(x.startswith('PAIR ') for x in run.splitlines())==101
assert 'RESULT cases=26 correctness_failed=0 work_failed_cases=0 work_failed_assertions=0' in run
for n in ['build','run','fixed-tests','frame-unchanged']:assert (W/'incremental-cache-execution'/f'{n}.exit').read_text().strip()=='0'
contracts=[out/'brief.md',src/'AGENTS.md',src/'docs/requirements.md',W/'terminal.ui/openspec/changes/implement-incremental-rendering/design.md']+[W/'terminal.ui/openspec/changes/implement-incremental-rendering/specs'/p/'spec.md' for p in ['ui-runtime','terminal-output','rendering-benchmark']]
result={'method':'Read-only SHA256/byte, Git fixed-blob, exact CJP member and streaming gzip payload audits; no build/test execution','source_commit':head,'test_commit':tests,'accepted_B_to_base107_product_exact':True,'old_main_assertion_body_unchanged':True,'root_inputs':root_pins,'root_binding_counts':counts,'source_paths_exact_in_both_workspaces':len(paths),'historical_tests_unchanged_excluding_main_registration':old_tests,'B_and_R1_Frame_native_build_config_comparisons':'exact relevant Git blobs','binding_checks':records,'native_archives':native,'locks_equal_when_parsed':[pin(p) for p in locks],'CJP_relevant_members':members,'frame_witness_payload':{'sha256':h.hexdigest(),'bytes':length,'logical_path':f['logical_original_path'],'physical_gzip':f['witness']},'history_inputs':history,'contracts':[pin(p) for p in contracts],'current_independent_raw':{'cases':26,'pairs':101,'correctness_failures':0,'work_failures':0},'mismatches':0,'inspection_correction':'Two audit attempts expected unbuilt baseline and root locks in the execution workspace and exited1 on their absence. Follow-up uses only the actual execution C consumer lock plus five producer root/reused consumer locks; all six parse to identical dependency versions. No product test/build failure.'}
if (out/'verification.json').exists():
 assert json.loads((out/'verification.json').read_text())==result, 'sealed verification content differs'
else:
 (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['root_binding_counts','source_paths_exact_in_both_workspaces','historical_tests_unchanged_excluding_main_registration','current_independent_raw','mismatches']},indent=2));print('CJP members',len(members),'native archives',len(native),'binding checks',len(records),'Frame payload',h.hexdigest())
