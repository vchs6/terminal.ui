# TASK137 independent Unit C acceptance

## Global Constraints

- 原TASK-031/022为完整验收责任归属；123–142实现031各单元，143–147实现022并供031成本验收。实际工程层级依原WP002/WP005，角色工作为独立L3，不把原L3强行嵌另一套L3树。主仓接入时031/022转为本tasks唯一状态引用，不能保留两份勾选权威。
- 单元A/B123–132已独立接受；133测试已固定，134实施中，135–147仍planned；有上游合同不等于上游产品已通过。正式产品124前必须冻结全部功能M1源码/制品及下表最终SHA；禁止提前用c3d743d有限功能作性能基线。
- A→B→C→D→E顺序集成。测试可按冻结合同准备，但产品只消费前单元验收固定提交；共享Component/Layout/Frame禁止多个产品作者同时编辑。
- 每实体一个小写下划线.cj文件，最小可见性，原public调用兼容，新增RuntimeStats三项仅只读；无私有测试hook、无强制M1/M2模式开关。
- 测试作者Sol/high、产品Terra/high或适合仓颉任务的Sol/high、审核/验收Astra/high、执行Sol/medium；记录指定配置，无法核验serving时不冒充实测。
- 角色只交接合同、固定源码/测试SHA、公开命令和原始证据，不交产品作者自评。验收按原AC及实际工作量/CPU/分配/输出，不以测试数量代替。
- 不publish、不改共享SDK/seed/cache、正式基准不依赖探针或开发目录；正常CJPM和普通bundle消费者不可skip。


### C / 133–137（父031，REQ004.8/002，C/主题/Canvas合同）

文件：133扩tests/incremental_layout；134改runtime_node/session、binding结果提交、layout/node及theme resolver/Canvas依赖的已冻结接缝；必要node_dirty/measure_key/measure_result各实体文件。禁止第二children列表/第二resolver。

输入132；输出分类dirty、约束缓存、受影响measure/arrange集合及新旧几何。

- [x] 133准备常量替getter、typed相等、notify各类别、ForEach keymove/manual、hidden→visible、纯span样式与文字、theme mask/fill、Canvas M/P独立失效；每批同root稳定M1对照。
- [x] 133覆盖Row flex余数与兄弟重分配、Column后续/justify前后移动、宽wrap高度/四pad、root fallback与viewport clamp；固定能证明无关工作为零/减少的树形场景，不给凭空时间阈值。
- [ ] 134分开待求值与真正有效输出dirty；Content/Style/Layout/Structure不互相吞并，只有成功目标消费当期版本。
- [ ] 134有界intrinsic/实际约束缓存，位置变化复用文本测量；隐藏待算失效保留；依赖传播以真实输出/输入不变截断，不仅比父大小。
- [ ] 135审核缓存key、source mask/fill、独立Canvas依赖、真实C序列、cutoff之后通知与GC订阅资源；136独立执行133及相关生命周期/主题组合；137确认局部布局成立，paint局部仍待D。



Candidate ee84e7ac7a35bb6481a17ecb91f1ec07804b672a, base107ef32c acceptedB275/AC132. Fixedexpandedtests4845df24b33f75432d26a68fb0b844abbb4e8528 (originald90119 +58five +4845two unchanged). OriginalCrequirements/design4/5/9/10/14M001/M003/M004/M009/M011 andthreeassociatedspecs +REQ004.8/002.6; AGENTS11.1/13.2/14. Rootread-onlycanonicalmainat107doesnotyetincludeCproduct, usefixedGit/sourceworkspace.

Accept ORIGINALCscope, notonlyclosedfindings/testcount: RuntimeNode/sequence/cacheauthority andsameLayoutNodealgorithm; effectivevs pendingdirty/notify/equality/styles/masks/fill; boundedintrinsic+actualconstraint/policykeys, visible/hiddenpendingwork/lifecycle; realRowflex/Column/wrap/fourinsets/rootfiniteoverflow/viewportdependencycutoff (unchangedparentoutputsandnecessaryinternalwork); CanvasM/P/readOnly dependencies andactualmeasuremisscount; M1fulltemporarycache/subscription/geometryisolation andcurrentfullCelloutput; success-onlyversionconsumption/cutoff/boundednotifications; originalFrame/metricsAPI andnormalCJPcompatibility. Public26sameepoch+literalpairs +sourceproof forqueuebound. Geometricreusemustnotfakecounters or ignorependingvalidations.

Reviewhistory mustremaintransparent: initial135sourcef89SPEC/QUALITYFAIL5, R1source4eaddresses5butnewP1N1/N2, R2sourceeeaddresses2nonew. Actualindependentpubliccounterexamples reproducedallfunctional/workclaims exceptF3structuralqueueboundsassourceproof. Check sourceQAcombineddispositions+raw/fixedsource identity, no headingpresumedoracle. Current136ownnormalconsumerbuild/direct26 required; oldA/Brawreuse onlyprecisesource/config/deps/paths/inputaudit under11.1, notfreshownexecution. Producer CURRENTindex-round2 SHA1de4e2c1ff2a2c5c7d6e70055bad19e7c64fcbf7d8badea6174a0a57e1d1475e factualsource/raw/config/artifact/commandsonly, noauthorplan/report/selfassessment. 136index/finalQAindicesprovidedondispatch. No rerunssolelyacceptancerole, no broadoldarchive/SDK/cachehashscan. AcceptedA127/B132inputstatus reusablebyfrozenSHA+relevantproductbytechecks.

CurrentR2CJP+3ELFsphysical whenproduced; olderf89/R1ELFsbinarypayloadslosslesslypreservedwithindicesunchangedlogicalhistoricalpathmaps under validation/failed-c-candidate-elf-witnesses...d1536 and round1-cache-fix-headroom...aa25. CounterI53ccgz526c..., counterII0c6currentunlesslatermigration. Don'ttreatoldlogicalpathsascurrentcorruption; useprovidedfrozenGit/blob/raw orwitnessifactuallynecessary. InheritedCanvascountergapF5fixedcurrentcode, frozenoldM1CJP29notbackfilled; stageEfairmetricsmustrespectoldlimit.

Write report<=40lines requirement→evidence table +findings/index in thisdirectory, actualinputbindings verified andscope explicit. No builds/tests/sourceedits/subagents. PASSonlyPASS_UNIT_C: measure/arrange/local-work proof, fullpaintstillD, CPU/heap/GC/RSS/end-toendperformanceE, full031/022/Linux/finalhostmatrix/023/024remainopen. No newPNGheadlessunit. Astra/high forindependentacceptancejudgment, sourceQAdoesnotreplaceacceptance. Startondispatchafter136fixedresults.
