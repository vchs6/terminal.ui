# TASK139 Unit D product implementation (not admitted until138fixed)

## Global Constraints

- 原TASK-031/022为完整验收责任归属；123–142实现031各单元，143–147实现022并供031成本验收。实际工程层级依原WP002/WP005，角色工作为独立L3，不把原L3强行嵌另一套L3树。主仓接入时031/022转为本tasks唯一状态引用，不能保留两份勾选权威。
- 单元A/B/C123–137已独立接受；138测试准备中，139–147仍planned；有上游合同不等于上游产品已通过。正式产品124前必须冻结全部功能M1源码/制品及下表最终SHA；禁止提前用c3d743d有限功能作性能基线。
- A→B→C→D→E顺序集成。测试可按冻结合同准备，但产品只消费前单元验收固定提交；共享Component/Layout/Frame禁止多个产品作者同时编辑。
- 每实体一个小写下划线.cj文件，最小可见性，原public调用兼容，新增RuntimeStats三项仅只读；无私有测试hook、无强制M1/M2模式开关。
- 测试作者Sol/high、产品Terra/high或适合仓颉任务的Sol/high、审核/验收Astra/high、执行Sol/medium；记录指定配置，无法核验serving时不冒充实测。
- 角色只交接合同、固定源码/测试SHA、公开命令和原始证据，不交产品作者自评。验收按原AC及实际工作量/CPU/分配/输出，不以测试数量代替。
- 不publish、不改共享SDK/seed/cache、正式基准不依赖探针或开发目录；正常CJPM和普通bundle消费者不可skip。


### D / 138–142（父031，REQ003/004/009，原008/018/020/037组合）

文件：138新增tests/incremental_composition公开消费者及适用已有设备故障驱动组合；139改layout/Frame/runtimeSession/application的既有合成与设备目标接缝，新增damage_rows/paint_state等单实体记录。测试驱动工具不进入生产。

输入137、完整008恢复及交互产品；输出完整M2目标、整行局部绘制、正确caret与baseline。

- [ ] 138冻结长→短/移动/隐藏/卸载/阴影、背景移除、透明hole与StyledSpace、目标宽簇伙伴、滚动/anchor、nested modal close/下层后台最新值、caret-only及opaque同字符遮挡。
- [ ] 138用受控Canvas记录draw次数和可观察clip，证明相交节点每目标至多一次、上下文不随damage改变；全量M1另运行不混计。
- [ ] 139以旧新paint bounds并集形成整行带，清初值后全场景顺序重绘相交前后节点/层；subtree bounds含后代阴影，不只dirty节点。
- [ ] 139缓存未draw节点caret请求、按焦点/geometry/层opaque覆盖重算；设备grid零差分也输出caret变化，输出成功才提交组合baseline。
- [ ] 140审未知lineage/profile、partial write/resize、缓存clean但设备失同步、异常清理围栏；141独立执行138与008受影响恢复矩阵/真实适用TTY；142核M1逐Cell等价与交互caret结果，保留E成本前置。



Bindingdesign6/7/8/9/10/14M001–M004/M009/M011 +threeassociatedspecs in /workspace/work/terminal.ui/openspec/changes/implement-incremental-rendering; oldR11/F003 Frame semantics, fullC002/S008recovery+interactionviewport/overlay/caretcontracts. ReadAGENTS11.1/13.2/14 actual SDK1.2syntax. AcceptedCfinalee84e7ac,137indexfa9af11a. Finalindependent138testSHA/index/ownsourceBASEprovidedondispatch; currentlynotready. OriginalC26testsandA/Bfrozen allmustremain.

Implement actuallocalcomposite/render andcaretwithinexistingFrame/LayoutNode/RuntimeNode/RuntimeSession/Application path. PrivateD1(old/new/subtreepaintbounds,整行damage+success-version/lifecycle), D2(selectiveonce-nodepainting/originalpubliccontexts/privatewritefilter/cachedcaret+actualopaqueocclusion), D3(backendrelation/profile/failurebaseline fences+finalchecks/package). Oneauthor/privatecommitsallowed, onefullunit140review/141independentexecution/142ACaftercomplete, no per-private-stepduplicatereview. Useactualsource/contractsforfit; no secondcomponenttree/renderer/Unicode/childauthority/resolver or publicmode/hooks. PreserveCactualmeasure/arrange reduction/dirtyversions/caches andM1temporaryisolation. Targetlogicalsuccessvsdeviceoutputcommit separate; partialwrite/resize/desyncmustnevertrustdamageorreuseunsafe baseline. B exactfrozenrows+fullprofilecomparison fallbackpreserved.

Do not fakeworkcounters or merely filteroutput. Unaffectedrows shared/unchanged, affectedrows restoreinitialcanvasandREPLAYallintersectingnodes/layersinactualsceneorder—notonlydirtynode. Old/newbounds/shadows/hiddenremoved/scroll/anchor/nestedmodalclosure correct. PublicCanvascontextallocation/origin/clip/defaultstyle unchangedbydamage; node atmostonedraw pertargetevenmultiplebands. Cachedcaretscanchangevisibility/controlwithzerogriddiff; actualopaqueStyledSpace/shadow occlusion sourceownership, transparentholesnotblock, focus/layout/layersaffectrequest validity. AllactualCellwrites/allocationstatsscopeM003 retained; Rowdirectories/stringsnotheapbytes. ExternalreturnedFramesfullymutable/unowned, no lastingprivategenerationfilterleak. Same publicfullrender remainscompleteoraclenoM2cachewrites/subscriptionpublication.

No tests changes orotherauthors'reasoning/reports; fixedtestcode+rawfacts only. Add sourceeachentityownlowercasefile; purehelperscohesive. Retireoldfull-targetpaintonlywhereappropriatedurablelocalpathnowhandles; retain documentedcorrectfallback actualunprovenrelations (no contenthash/addressguess). No inventednewfeatures beyondD. Roothandlesanycontractambiguity/newcounterexamplethroughindependenttestauthor. No subagents/main/SDK/globalconfig/cachecopies/nativecleanup.

SDKforeachbuild/runtime source /workspace/work/validation/sdk/cangjie/envsetup.sh; CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env; CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip. Ownignoredofficialcachecfgroot+consumerallowed repository.cache.path=/workspace/work/viewport-tests/cache registryhttps://pkg.cangjie-lang.cn/registry; no18973relay. EXPLICITexecworkdirEACHcommand. ONEOWNsharedtarget+unique-o, neverextraELFcopies; sameCJPMbundlemayclearbin soorderfinalbundlebeforefinalin-placeELFretention. Normalplainbundledefaulttests/lintmandatory/no suppression. No SDK/seed/dependencytargetcopies.

Root gives budget; >=150MiBbeforeheavycompile unless specificchangedbudgetapproved, warn<30stopbefore12, no arbitrarycleanup. Doactualcodewithconciseplan.md, sustainedprivateD1-D3; tasksizealone notstall. Scopedmeaningfulchecks finalindependent138publicconsumer+affectedC26/A/B/Frame/composition+existingprivateglyph/output_recovery/realTTY percontract; selectminimumsufficientvalidproof under11.1, no blindsamebytefullsuite/oldGUIrepeat. Changedbackendrequiresactualaffectednativeharnessresults; useunchangedfixtures notnewhooks/mode. Root141latercoversindependentactualapplicableTTYmatrix; producerdevelopmentchecksnotAC.

Versionrawfailedattempts retained/lossgzlargewithoriginalSHA/bytes; indexONLYfixedsource/config/deps/actualELF/CJP/raw (never .a/.cjo/.o). Finalfactualreport<=25lines/commit immediatelywhenfixed, sourceindex/rootproof, noauthorreasoningto140. No endtoendperformance/fullM2/LinuxcompletionbeforeE+finalmatrix023024. ModelTerra/high formultifileCangjiecomposition/ownershipintegration.



## Independent TASK142 acceptance — not admitted yet
Root will provide fixed D139 source, TASK138+rootvisibility indexes, TASK140 review and TASK141 execution indexes. No builds/source edits/subagents; verify requirement-to-raw/source/artifact bindings and both functional and work proof, do not use product-author reasoning/self-assessment. Decide full UnitD under original031/022 scope: same-epoch complete M1 Cells/literals, independent caret/geometry, damage/once-per-node replay/public context, opaque ownership, lifecycle and hidden-root recovery, full reference isolation, shared row mutability and lineage/profile/partialwrite/resize/baseline fences. Index exact files actually checked, distinguish precise reused proof under11.1. No fabricated full heap/CPU/performance/package release acceptance; E metrics and final host matrix023024 remain mandatory. Report PASS_UNIT_D or concrete blockers plus full checkable requirement table/index, compact return.

## Fixed known inputs —141 still pending
Final product f48ca45608247f52a6876ad5c27b4ca36867f406 includes fixed138test0ab, root16b9, independentcaretREDtestdf679 (cherry805), scopedfix; noforceM1 mode. Current factualindex producer/index-r1.json SHA227dd077c9dff3e10aab8875280aa8098a6cf2a8e7eeb33da25a400a1d83a83a root354bindingsverified, CJP1110d0ffbb626a8bda6f3daa67daf0198688aa0b59cd795f1a2da2e0f27dee0a. Full140initial index61708682032ba5a66b2bb641daf5db2d3be8f68362da1ed60b5d68cace30e7b9 requestchangesoneP1 D140001; R1indexd36cec40cf929587ba777ae21838f9ccd756c28bdd49dad77ef9db8457fd0cda/report4dc628eb737adcc1cf63110b47b9e36ebe0467ec0358b1cd376919c0b9c23290 PASS/PASS/addressed/no newblocker. Produceractual17/0 direct+unpacked, Frame7/0baseline+cow, defaultbundle/lint0. Previousnative5+45 produceronlye124; independent141f48nowactually17/0,5/0,45/0,full338/0 sofinalfactsindexwillbindnewsource. XTermhost10statePNG+normalF10exit0 actual; VTEfirstattempt10statePNG butF10blocked/timedout, failedattemptpreserved, isolatedhostshortcutconfigrerun pending. NoacceptancetillactualnewVTE/141sealedindex.
PrivateInt64ownerrows/transferscratch and allvisibletraversal cost are deferred Emeasurement obligations, notCellslot totalheapimprovement; acceptanceDcannotclose031/022/fullLinux. EarlierC26producerproofscopedprehiddenroot/e124 only, initialrawsource/historyversionmaps explicit; don'treauditallold1797fileswhensignedfixedreview/source/packagebindingvalid11.1, checkneededfunctional/scopedreuse +allfixedindex/artifactkeybindings. Noauthorreasoning/reports exceptindependentreview/executionfactualreports.
Localruntimehistoryrefs intentionally logicalafterlosslessgzip migrations: validation/d-caret-fix-headroom-20261114/index.json8f060 foroldDtestc00/4a, reviewed-e124-runtime-witnesses-20261114/index.json8ba9 forinitial3ELFs; exactpayload+exclusive restore receipts. e124immutableindex(actualSHAending90d)source/CJP/test/lock exactbytes via producer e124-*-location.json/Git. CurrentR1ELFsphysicalno migration. Archivepublisherpreponly notacceptanceauthority, main6bbstillCproduct+tests/methoddocs; DnotmergeduntilyourPASS. Rootmergepreviewexactsource/testtree in merge-preview.json handlesone knownregistryconflict with exactcandidateblob, no alteredbehavior.

Pathaliases in this brief: producer=/workspace/work/incremental-composition-implementation;140review=/workspace/work/incremental-composition-review;141execution=/workspace/work/incremental-composition-execution;validation=/workspace/work/validation. Priorfixedtestindices /workspace/work/incremental-composition-tests/index.json042e3789, /workspace/work/composition-root-visibility-tests/index.json04bf90e9, /workspace/work/composition-review-counterexamples/index.json10bdab56. ExactSHAvalues in producer/index-r1.json and140indices, do not infer from prefixes.

## TASK142 now ADMITTED fixed141
Independentexecution141 /workspace/work/incremental-composition-execution/index.json SHA159189b07c8348e1289f7ed23e284e95d375f0ba7bf069bc041055d09ae842eb, factualreport13c509935ee479b807b54c63b84b5ffbcfc8abc95b6fba593dc48b56ab35d246. Owncleanf48, public17/0, native5/0+45/0+FULL338/0 actualcurrentf48. Bothfinalhosts XTerm398/xfce4terminal1.1.4VTE0.80.1 final-r3 all11checkpointsequence successful,10originalstatePNG each, actualDECRQMvisible,80x24→100x30→80x24,inner/outer/hostexit0+termiosrestore. VTEisolatedShortcutsNoMenukey=TRUE exactbinary-supported, faileddefaultF10attemptretained; XTermmetadatarace/firsterrorattemptsalso retained. Rootindex/reportSHAs +271fixedsource/config/ELF/externalproofbindings +20finalPNG hashes verified; rootvisuallyviewedactualXTermmodalresized+VTErestoredNotes. Executor7828completeindexedfileshash/bytes audit0mismatch recorded, no repeatthousandsunlessneeded11.1. Readindependentfactualreport/index/raw, neverproductauthorreasoning.
PerformfinalUnitDrequirementtable/evidencepassorblockersnow, no builds/sourceedits/subagents. Preserveoriginal140failure+R1fixscope; verifyactualCell/caretwork/stats/traversal/ownerlineage/failurecoverageandpackage/reusedprooflimits. NoAC022/031cost/fullLinuxacceptanceyet. Sourcecodeintegrationcandidate only afteryourPASS; root exactmergepreview/testsresolutionnotproductchange. Outputreport.md,index.json inownacceptanceparent, factualreturn<=10lines.
