#!/usr/bin/env python3
"""Capture fixed host-cases.md actions using the existing TASK066 X11/TTY plumbing."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess as S
import sys
import time

host, binary, destination, display = sys.argv[1:5]
root = Path('/workspace/work/auto-final-execution/repo/tests/terminals')
bundle = Path('/workspace/work/cross-terminal-recon')
out = Path(destination).resolve()
out.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env.update(DISPLAY=display, TASK066_OUTER_RAW=str(out/'outer-tty.txt'),
           TASK066_INNER_RAW=str(out/'inner-tty.raw'), TASK066_INNER_STATE=str(out/'inner-tty.txt'),
           TASK066_FIXTURE=str(Path(binary).resolve()), TASK066_INNER_RUNNER=str(root/'inner-recorder.sh'),
           TASK141_INNER_INPUT=str(out/'inner-input.raw'))
env.pop('COLORTERM', None)
outer=(root/'outer-recorder.sh').read_text()
needle='--log-out "$TASK066_INNER_RAW"'
assert outer.count(needle)==1
wrapper=out/'outer-recorder.sh'
wrapper.write_text(outer.replace(needle,'--log-in "$TASK141_INNER_INPUT" '+needle))
wrapper.chmod(0o700)

def call(args, **kwargs):
    return S.run(args, check=True, text=True, capture_output=True, env=env, **kwargs).stdout

def wait_for(f, label, seconds=20):
    deadline = time.monotonic()+seconds
    while time.monotonic() < deadline:
        value = f()
        if value:
            return value
        time.sleep(.05)
    raise RuntimeError('timeout: '+label)

def raw_length():
    p = out/'inner-tty.raw'
    return p.stat().st_size if p.exists() else 0

def tty():
    p = out/'inner-tty.txt'
    if p.exists():
        m = re.search(r'^tty=(.+)$', p.read_text(), re.M)
        if m: return m.group(1)

def dims():
    return tuple(map(int, call(['stty','-F',tty(),'size']).split()))

def window():
    tree = call(['xwininfo','-root','-tree'])
    (out/'window-tree.txt').write_text(tree)
    for line in tree.splitlines():
        if 'TASK141 showcase' in line:
            return int(line.split()[0],16)

x11 = C.CDLL('libX11.so.6'); xtst = C.CDLL('libXtst.so.6')
x11.XOpenDisplay.argtypes=[C.c_char_p]; x11.XOpenDisplay.restype=C.c_void_p
x11.XCloseDisplay.argtypes=[C.c_void_p]
x11.XStringToKeysym.argtypes=[C.c_char_p]; x11.XStringToKeysym.restype=C.c_ulong
x11.XKeysymToKeycode.argtypes=[C.c_void_p,C.c_ulong]; x11.XKeysymToKeycode.restype=C.c_uint
x11.XSetInputFocus.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_ulong]
x11.XSync.argtypes=[C.c_void_p,C.c_int]
x11.XResizeWindow.argtypes=[C.c_void_p,C.c_ulong,C.c_uint,C.c_uint]
xtst.XTestFakeKeyEvent.argtypes=[C.c_void_p,C.c_uint,C.c_int,C.c_ulong]
xd = None; xp = None; hp = None
actions=[]; captures=[]; last_offset=0
try:
    xp = S.Popen(['Xorg',display,'-config',str(bundle/'probes/xorg-dummy.conf'),'-nolisten','tcp','-noreset',
                  '-logfile',str(out/'xorg.log')],stdout=(out/'xorg.stdout').open('wb'),stderr=S.STDOUT,env=env)
    wait_for(lambda: S.run(['xdpyinfo'],env=env,stdout=S.DEVNULL,stderr=S.DEVNULL).returncode==0,'Xorg')
    if host=='xterm':
        executable=str(bundle/'hosts/xterm/usr/bin/xterm')
        command=[executable,'-geometry','80x24+20+20','-fa','Monospace','-fs','12','-T','TASK141 showcase',
                 '-e','/bin/sh',str(wrapper)]
    elif host=='vte':
        executable='/usr/bin/xfce4-terminal'
        command=['dbus-run-session','--',executable,'--disable-server','--geometry=80x24+20+20',
                 '--title=TASK141 showcase','--command=/bin/sh '+str(wrapper)]
        env.update(XDG_CACHE_HOME=str(out/'xdg-cache'),XDG_CONFIG_HOME=str(out/'xdg-config'))
        (out/'xdg-cache').mkdir(); (out/'xdg-config').mkdir()
        settings=out/'xdg-config/xfce4/terminal/terminalrc'
        settings.parent.mkdir(parents=True)
        settings.write_text('[Configuration]\nShortcutsNoMenukey=TRUE\n')
    else: raise ValueError(host)
    (out/'host-version.txt').write_text(call([executable,'-version'] if host=='xterm' else [executable,'--version']))
    hp = S.Popen(command,env=env,stdout=(out/'host.stdout').open('wb'),stderr=(out/'host.stderr').open('wb'))
    wid = wait_for(window,'actual terminal window')
    wait_for(tty,'inner TTY')
    assert dims()==(24,80), ('initial host size',dims())
    xd=x11.XOpenDisplay(display.encode()); assert xd

    def key(name, wait_output=True):
        start=raw_length()
        x11.XSetInputFocus(xd,wid,1,0); x11.XSync(xd,0)
        modifier = name in ('Z','Q','N','M','P')
        code=x11.XKeysymToKeycode(xd,x11.XStringToKeysym(name.encode()))
        shift=x11.XKeysymToKeycode(xd,x11.XStringToKeysym(b'Shift_L'))
        assert code and (not modifier or shift), name
        if modifier: xtst.XTestFakeKeyEvent(xd,shift,1,0)
        xtst.XTestFakeKeyEvent(xd,code,1,0); xtst.XTestFakeKeyEvent(xd,code,0,0)
        if modifier: xtst.XTestFakeKeyEvent(xd,shift,0,0)
        x11.XSync(xd,0)
        actions.append({'utc':time.time_ns(),'key':name,'raw_bytes_before':raw_length()})
        if wait_output: wait_for(lambda: raw_length()>start,'output after key '+name)

    def geometry():
        data=call(['xwininfo','-id',hex(wid),'-all'])
        (out/'window-latest.txt').write_text(data)
        return tuple(int(re.search(r'^  '+n+r': (\d+)',data,re.M).group(1)) for n in ('Width','Height'))

    def resize(rows,cols):
        before=dims(); width,height=geometry()
        for attempt in range(12):
            if dims()==(rows,cols): break
            current=dims()
            width += (cols-current[1])*max(1,width//current[1])
            height += (rows-current[0])*max(1,height//current[0])
            x11.XResizeWindow(xd,wid,width,height); x11.XSync(xd,0)
            wait_for(lambda: dims()!=current,'host PTY resize')
            width,height=geometry()
        assert dims()==(rows,cols), ('resize',rows,cols,dims())
        actions.append({'utc':time.time_ns(),'resize_from':before,'resize_to':dims(),'window_pixels':(width,height)})

    def capture(number,label,previous=None):
        global last_offset
        if previous is not None:
            wait_for(lambda: raw_length()>previous,'output '+label)
        image=out/f'{number:02d}-{label}.png'
        stable=0; last=None; deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            start=raw_length()
            call(['import','-window',hex(wid),str(image)])
            end=raw_length()
            state=(hashlib.sha256(image.read_bytes()).hexdigest(),end)
            stable=stable+1 if start==end and state==last else 0
            if stable>=2: break
            last=state
            time.sleep(.05)
        else: raise RuntimeError('unstable host capture '+label)
        current=raw_length()
        raw=(out/'inner-tty.raw').read_bytes()[last_offset:current]
        (out/f'{number:02d}-{label}.raw').write_bytes(raw)
        captures.append({'case':number,'label':label,'png':image.name,'png_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),
                         'raw_interval':f'{number:02d}-{label}.raw','raw_bytes':len(raw),'raw_start':last_offset,
                         'raw_end':current,'dimensions':dims(),'utc':time.time_ns()})
        last_offset=current

    wait_for(lambda: b'Gallery' in (out/'inner-tty.raw').read_bytes() if (out/'inner-tty.raw').exists() else False,'startup scene')
    capture(1,'startup')
    key('End',False); key('Z'); capture(2,'find-queryz')
    key('F5'); capture(3,'find-modal')
    key('F9'); key('Q'); capture(4,'find-restored')
    [key('Tab') for _ in range(6)]; capture(5,'notes-focus')
    key('End',False); [key(k) for k in ('N','Return','M')]; capture(6,'notes-edit')
    key('F5'); capture(7,'notes-modal')
    resize(30,100); wait_for(lambda: raw_length()>last_offset,'resized output'); capture(8,'modal-resized')
    key('F9'); key('P'); capture(9,'notes-restored')
    resize(24,80); wait_for(lambda: raw_length()>last_offset,'restored-size output'); capture(10,'restored-size')
    key('F10',False); wait_for(lambda: (out/'inner-tty.txt').exists() and 'exit_status=' in (out/'inner-tty.txt').read_text(),'normal exit')
    wait_for(lambda: hp.poll() is not None,'terminal process exit')
    (out/'11-exit.raw').write_bytes((out/'inner-tty.raw').read_bytes()[last_offset:])
    (out/'actions.json').write_text(json.dumps(actions,indent=2)+'\n')
    (out/'captures.json').write_text(json.dumps(captures,indent=2)+'\n')
    (out/'host-metadata.json').write_text(json.dumps({'host':host,'host_binary':executable,'host_version':(out/'host-version.txt').read_text(),
        'fixture_binary':str(Path(binary).resolve()),'fixture_binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
        'display':display,'window':hex(wid),'TERM':re.search(r'^TERM=(.*)$',(out/'outer-tty.txt').read_text(),re.M).group(1),
        'locale':env.get('LC_ALL') or env.get('LANG'),'inner_tty':tty(),'final_dimensions':captures[-1]['dimensions'],
        'inner_state':(out/'inner-tty.txt').read_text(),'outer_state':(out/'outer-tty.txt').read_text(),
        'host_process_exit':hp.returncode,'input_raw_sha256':hashlib.sha256((out/'inner-input.raw').read_bytes()).hexdigest(),
        'operator_wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest()},indent=2)+'\n')
finally:
    if xd: x11.XCloseDisplay(xd)
    for p in (hp,xp):
        if p and p.poll() is None:
            p.terminate()
            try: p.wait(timeout=5)
            except S.TimeoutExpired: p.kill(); p.wait()
