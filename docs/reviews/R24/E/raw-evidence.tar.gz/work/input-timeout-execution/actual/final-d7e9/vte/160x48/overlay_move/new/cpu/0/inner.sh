#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_move/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_move/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-c36c28b33be94ec1bf64589d413508cc /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_move/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario overlay_move --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-c36c28b33be94ec1bf64589d413508cc --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_move/new/cpu/0/samples.csv
