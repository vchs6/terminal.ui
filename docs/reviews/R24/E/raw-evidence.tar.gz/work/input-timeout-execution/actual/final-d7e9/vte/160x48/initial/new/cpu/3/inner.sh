#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/3/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/3/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-bf8a3ea37f1d4e7fb7980d76053b94b2 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/3/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario initial --width 160 --height 48 --seed 143 --warmup 1 --updates 2 --repetition 3 --run-id tty-bf8a3ea37f1d4e7fb7980d76053b94b2 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/3/samples.csv
