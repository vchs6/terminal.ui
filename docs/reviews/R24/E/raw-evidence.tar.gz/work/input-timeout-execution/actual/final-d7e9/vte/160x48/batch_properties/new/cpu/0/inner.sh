#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/batch_properties/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/batch_properties/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-51e2518e8c4448db842e6fc0e02e9c58 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/batch_properties/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario batch_properties --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-51e2518e8c4448db842e6fc0e02e9c58 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/batch_properties/new/cpu/0/samples.csv
