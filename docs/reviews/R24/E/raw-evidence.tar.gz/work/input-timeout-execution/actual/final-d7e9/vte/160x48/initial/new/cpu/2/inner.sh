#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/2/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/2/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-15e186ed2cc14d8aa94d547fc489cf1a /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/2/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario initial --width 160 --height 48 --seed 143 --warmup 1 --updates 2 --repetition 2 --run-id tty-15e186ed2cc14d8aa94d547fc489cf1a --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/2/samples.csv
