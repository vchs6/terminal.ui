#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/4/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/4/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-de1a20d7edee49e08e062f58e4a67260 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/4/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario idle --width 160 --height 48 --seed 143 --warmup 1 --updates 1 --repetition 4 --run-id tty-de1a20d7edee49e08e062f58e4a67260 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/4/samples.csv
