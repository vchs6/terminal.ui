#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/4/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/4/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-1b77539be5ad459a8651a4b0928526af /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/4/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario initial --width 160 --height 48 --seed 143 --warmup 1 --updates 2 --repetition 4 --run-id tty-1b77539be5ad459a8651a4b0928526af --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/initial/new/cpu/4/samples.csv
