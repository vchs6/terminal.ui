#!/bin/sh
exec script --quiet --flush --return --log-out /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/terminal.raw --command '/bin/sh /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/inner.sh'
