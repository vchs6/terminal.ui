#!/bin/sh
exec script --quiet --flush --return --log-out /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/old/output/0/terminal.raw --command '/bin/sh /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/old/output/0/inner.sh'
