#!/bin/sh
exec script --quiet --flush --return --log-out /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/1/terminal.raw --command '/bin/sh /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/1/inner.sh'
