#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/old/output/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/old/output/0/inner-state.txt
exec /usr/bin/strace -ff -ttt -yy -v -e abbrev=execve,execveat -s 128 -e trace=write,writev,poll,clone,clone3,fork,vfork,execve,execveat,exit,exit_group -o /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/old/output/0/native /workspace/work/rendering-benchmark-implementation/consumers/old/target/release/bin/old-r1-compat --mode tty --scenario readonly_focus_caret --width 160 --height 48 --seed 143 --warmup 3 --updates 3 --repetition 0 --run-id tty-94dd7671472d4a9ba847c7c0db75dd79 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/old/output/0/samples.csv
