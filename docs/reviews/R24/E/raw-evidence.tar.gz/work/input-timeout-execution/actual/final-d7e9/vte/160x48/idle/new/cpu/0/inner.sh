#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-70611cb154244547a5acb6b9c3cdca77 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario idle --width 160 --height 48 --seed 143 --warmup 1 --updates 1 --repetition 0 --run-id tty-70611cb154244547a5acb6b9c3cdca77 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/0/samples.csv
