#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-7e95043978d9477a8c6f75d46db94461 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario readonly_focus_caret --width 160 --height 48 --seed 143 --warmup 3 --updates 3 --repetition 0 --run-id tty-7e95043978d9477a8c6f75d46db94461 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/readonly_focus_caret/new/cpu/0/samples.csv
