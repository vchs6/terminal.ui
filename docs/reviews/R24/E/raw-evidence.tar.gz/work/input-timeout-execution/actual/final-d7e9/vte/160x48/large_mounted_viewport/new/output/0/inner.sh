#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_mounted_viewport/new/output/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_mounted_viewport/new/output/0/inner-state.txt
exec /usr/bin/strace -ff -ttt -yy -v -e abbrev=execve,execveat -s 128 -e trace=write,writev,poll,clone,clone3,fork,vfork,execve,execveat,exit,exit_group -o /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_mounted_viewport/new/output/0/native /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario large_mounted_viewport --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-d422b8f8ed384d66adddbb3140674b3d --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_mounted_viewport/new/output/0/samples.csv
