#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_multistep/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_multistep/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-745a7d274ab64c69bd8e652a490357c4 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_multistep/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario scroll_multistep --width 160 --height 48 --seed 143 --warmup 3 --updates 3 --repetition 0 --run-id tty-745a7d274ab64c69bd8e652a490357c4 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_multistep/new/cpu/0/samples.csv
