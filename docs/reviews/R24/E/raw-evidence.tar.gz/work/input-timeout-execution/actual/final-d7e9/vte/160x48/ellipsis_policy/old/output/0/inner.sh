#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/ellipsis_policy/old/output/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/ellipsis_policy/old/output/0/inner-state.txt
exec /usr/bin/strace -ff -ttt -yy -v -e abbrev=execve,execveat -s 128 -e trace=write,writev,poll,clone,clone3,fork,vfork,execve,execveat,exit,exit_group -o /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/ellipsis_policy/old/output/0/native /workspace/work/rendering-benchmark-implementation/consumers/old/target/release/bin/old-r1-compat --mode tty --scenario ellipsis_policy --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-7a8e551347e14704a236b78932f2fe4c --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/ellipsis_policy/old/output/0/samples.csv
