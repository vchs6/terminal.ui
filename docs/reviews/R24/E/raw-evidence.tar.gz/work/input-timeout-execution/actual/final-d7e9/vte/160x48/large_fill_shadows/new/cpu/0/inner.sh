#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_fill_shadows/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_fill_shadows/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-69ea5c35f5e2471cb06355ecc25184d0 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_fill_shadows/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario large_fill_shadows --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-69ea5c35f5e2471cb06355ecc25184d0 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/large_fill_shadows/new/cpu/0/samples.csv
