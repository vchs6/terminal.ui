#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_step/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_step/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-b6c50d291e9140b5aabbfbb0d20ffe0f /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_step/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario scroll_step --width 160 --height 48 --seed 143 --warmup 4 --updates 4 --repetition 0 --run-id tty-b6c50d291e9140b5aabbfbb0d20ffe0f --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/scroll_step/new/cpu/0/samples.csv
