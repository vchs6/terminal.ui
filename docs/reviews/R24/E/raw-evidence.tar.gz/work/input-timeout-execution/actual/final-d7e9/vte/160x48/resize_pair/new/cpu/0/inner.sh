#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/resize_pair/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/resize_pair/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-d92898968b1a4b77be1adeb955b0dbbe /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/resize_pair/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario resize_pair --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-d92898968b1a4b77be1adeb955b0dbbe --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/resize_pair/new/cpu/0/samples.csv
