#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_nested_close/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_nested_close/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-c36dc13b78a9433b9a973591085370cd /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_nested_close/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario overlay_nested_close --width 160 --height 48 --seed 143 --warmup 3 --updates 3 --repetition 0 --run-id tty-c36dc13b78a9433b9a973591085370cd --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/overlay_nested_close/new/cpu/0/samples.csv
