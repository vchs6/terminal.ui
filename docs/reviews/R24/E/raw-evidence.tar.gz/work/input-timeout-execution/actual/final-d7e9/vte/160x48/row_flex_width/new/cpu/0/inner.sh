#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-9dd40b2c84e645e48ea3f7dd4663b753 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario row_flex_width --width 160 --height 48 --seed 143 --warmup 2 --updates 2 --repetition 0 --run-id tty-9dd40b2c84e645e48ea3f7dd4663b753 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/row_flex_width/new/cpu/0/samples.csv
