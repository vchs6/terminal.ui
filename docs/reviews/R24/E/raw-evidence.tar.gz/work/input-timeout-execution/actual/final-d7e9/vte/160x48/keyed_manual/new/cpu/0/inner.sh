#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/new/cpu/0/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/new/cpu/0/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-259f726f91854033bd732fea04992832 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/new/cpu/0/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario keyed_manual --width 160 --height 48 --seed 143 --warmup 3 --updates 3 --repetition 0 --run-id tty-259f726f91854033bd732fea04992832 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/keyed_manual/new/cpu/0/samples.csv
