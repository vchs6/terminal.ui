#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/2/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/2/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-e5012e143add45688d3ac18803a4a768 /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/2/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario idle --width 160 --height 48 --seed 143 --warmup 1 --updates 1 --repetition 2 --run-id tty-e5012e143add45688d3ac18803a4a768 --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/2/samples.csv
