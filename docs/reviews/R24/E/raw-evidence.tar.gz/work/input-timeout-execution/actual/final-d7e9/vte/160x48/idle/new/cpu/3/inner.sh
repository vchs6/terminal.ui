#!/bin/sh
set -eu
printf "tty=%s\n" "$(tty)" > /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/3/inner-state.txt
stty size >> /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/3/inner-state.txt
exec /workspace/work/rendering-benchmark-tests/source/tests/rendering_benchmark/target/process_cost tty-91094f3c93f04439b74fab3d3fb95e0a /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/3/process.csv /workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat --mode tty --scenario idle --width 160 --height 48 --seed 143 --warmup 1 --updates 1 --repetition 3 --run-id tty-91094f3c93f04439b74fab3d3fb95e0a --csv /workspace/work/input-timeout-execution/actual/final-d7e9/vte/160x48/idle/new/cpu/3/samples.csv
