# Unit B implementation plan

B1: Replace flat Cell storage with private row storage; freeze rows when sharing complete snapshots, detach before every write, retain transfer repair for partial copies and account for actual allocations and writes. Verify the frozen seven correctness tests, allocation oracle and affected Frame/layout regressions.

B2: Add a terminal comparison skip only for identical frozen rows under matching rendering profiles and known shared lineage. Preserve all existing output recovery fences; inspect temporary-frame owner release, then run the mandatory bundle and lint and capture fixed source and raw evidence.
