import gzip
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/workspace/work')
OUT = ROOT / 'frame-cow-acceptance'
CANDIDATE = '275149c274df41d38ffc950f104b31185dea19a7'
BASE = '4f7e853f821c334318e2038d4e20ab26e72c16c8'
MAIN = '0f83f73d0268b30b429f3f7482f4c9d1031b5006'
B = '9908551d206922d0083711abbc70738c60da9215'
A = '34240845e4bf393cc5d83475a2c9860a8de10f0e'
REPO = ROOT / 'frame-cow-implementation/source'
EXPECTED = {
    'tests': 'c9538b0eea0d6cae5e1c9ee5e4c491ae1254481cd5c35f255abf6f41c37b145f',
    'review': '7227fc2a0542e1fd4d7c6232ecc7b5cf0afb95aa0fc582a13b8c875deca531b2',
    'execution': 'def84e323b1bd40c59b5f54b5965282a4311e00bf5758e92bb5f349613fd89c1',
    'implementation': '2d1602314fd6eb7452048448ba39019246d93d73ba49d7edadb42ecd7af66c88',
}
failures = []
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def verify(record):
    path = Path(record.get('path', record.get('artifact', '')))
    try:
        data = path.read_bytes()
        ok = sha(data) == record['sha256'] and len(data) == record.get('bytes', len(data))
    except FileNotFoundError:
        ok = False
    if not ok:
        failures.append(str(path))
    return ok

indices = {}
for name, expected in EXPECTED.items():
    path = ROOT / f'frame-cow-{name}/index.json'
    assert sha(path.read_bytes()) == expected, name
    indices[name] = json.loads(path.read_text())

for name, keys in [('execution', ['raw', 'configs', 'artifacts']),
                   ('implementation', ['raw', 'configs', 'artifacts', 'source']),
                   ('review', ['evidence']), ('tests', ['test_files', 'artifacts'])]:
    records = [r for key in keys for r in indices[name][key]]
    # Producer prose and self-assessment are deliberately never read.
    records = [r for r in records if not any(x in r.get('path', r.get('artifact', '')) for x in ['/report.md', '/q1'])]
    checks.append({'group': name, 'records': len(records), 'verified': sum(verify(r) for r in records)})

witness_index = ROOT / 'validation/ended-more-runtime-witnesses-20261114/index.json'
assert sha(witness_index.read_bytes()) == '7dac4803bfde36b1dacaf9e1c26b625b0860767e1425ae1bcfa627fdefb66510'
witnesses = json.loads(witness_index.with_name('progress.json').read_text())
witness = next(r for r in witnesses if 'frame-cow-tests/' in r['logical_original_path'])
compressed = Path(witness['witness']).read_bytes()
assert sha(compressed) == witness['witness_sha256']
original = gzip.decompress(compressed)
assert sha(original) == indices['tests']['binary']['sha256'] == witness['original_sha256']
assert len(original) == indices['tests']['binary']['bytes']
assert original[:4] == b'\x7fELF'

assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert git('diff', BASE, MAIN, '--', 'src', 'native', 'build.cj', 'cjpm.toml') == b''
assert git('diff', B, CANDIDATE, '--', 'tests') == b''
delta = git('diff', '--name-only', BASE, CANDIDATE, '--', 'src').decode().splitlines()
assert delta == ['src/frame.cj', 'src/frame_row.cj', 'src/layout.cj', 'src/terminal_render_profile.cj']
audit = json.loads((ROOT / 'frame-cow-execution/raw/reuse-audit.json').read_text())
materialized = {'implementation': 0, 'execution': 0}
for entry in audit['files']:
    rel = entry['path']
    frozen = git('show', f'{CANDIDATE}:{rel}')
    assert sha(frozen) == entry['git_sha256'], rel
    for role in materialized:
        path = ROOT / f'frame-cow-{role}/source' / rel
        if path.exists():
            assert path.read_bytes() == frozen, str(path)
            materialized[role] += 1
        elif role == 'implementation' or entry.get('own_materialized'):
            failures.append(str(path))

old = json.loads((ROOT / 'frame-cow-tests/old-tests-manifest.json').read_text())
for entry in old:
    assert verify(entry)
    rel = entry['path'].split('/source/', 1)[1]
    assert git('show', f'{A}:{rel}') == git('show', f'{CANDIDATE}:{rel}'), rel
for entry in indices['tests']['test_files']:
    rel = entry['path'].split('/source/', 1)[1]
    assert sha(git('show', f'{B}:{rel}')) == entry['sha256'], rel

cjp = next(r for r in indices['implementation']['artifacts'] if r['path'].endswith('.cjp'))
with tarfile.open(cjp['path']) as archive:
    for entry in audit['cjp_all_product_native_build']:
        data = archive.extractfile('cjtui-0.0.0/' + entry['path']).read()
        assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
        assert data == git('show', f"{CANDIDATE}:{entry['path']}")
for role in ['implementation', 'execution']:
    for entry in indices[role]['artifacts']:
        if not entry['path'].endswith('.cjp'):
            with open(entry['path'], 'rb') as f:
                assert f.read(4) == b'\x7fELF', entry['path']

result = {
    'candidate': CANDIDATE, 'accepted_A': BASE, 'frozen_B': B, 'frozen_A_tests': A,
    'input_sha256': EXPECTED, 'hash_checks': checks, 'failures': failures,
    'product_delta': delta, 'A_product_exact_main': True,
    'B_tests_exact': True, 'old_A_files_exact': len(old),
    'candidate_git_and_materialized_files': materialized,
    'candidate_cjp_product_native_build_files': len(audit['cjp_all_product_native_build']),
    'current_ELFs_verified': 8, 'B128_initial_ELF_lossless_witness': witness,
    'methods': ['SHA256 and byte length', 'git show exact blobs', 'git diff frozen commits',
                'read-only CJP tar members', 'gzip decompression in memory'],
    'scope': 'Current Unit B bindings; accepted A status reused without historical archive scans. No builds or tests run.'
}
(OUT / 'raw').mkdir(exist_ok=True)
(OUT / 'raw/bindings.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['B128_initial_ELF_lossless_witness', 'methods']}, indent=2))
assert not failures, failures
