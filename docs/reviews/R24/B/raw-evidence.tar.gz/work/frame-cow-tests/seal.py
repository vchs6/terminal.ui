from pathlib import Path
import hashlib,json,subprocess,datetime,os
base=Path('/workspace/work/frame-cow-tests'); repo=base/'source'
def git(*args): return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for data in iter(lambda:f.read(1048576),b''): h.update(data)
 return h.hexdigest()
def item(p):
 p=Path(p); return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
commit=git('rev-parse','HEAD'); parent=git('rev-parse','HEAD^')
newfiles=git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines()
assert len(newfiles)==10 and all(p.startswith('tests/incremental_layout/frame_cow/') for p in newfiles)
assert git('diff','--name-only',parent,'--','src','native','build.cj','cjpm.toml')==''
assert (base/'raw/final-baseline.exit').read_text().strip()=='0'
assert (base/'raw/final-cow.exit').read_text().strip()=='1'
assert (base/'raw/accepted-source-diff.exit').read_text().strip()=='0'
assert (base/'raw/old-tests-diff.exit').read_text().strip()=='0'
oldfiles=git('ls-tree','-r','--name-only','34240845e4bf393cc5d83475a2c9860a8de10f0e','--','tests/incremental_layout').splitlines()
for name in oldfiles:
 expected=subprocess.check_output(['git','show',f'34240845e4bf393cc5d83475a2c9860a8de10f0e:{name}'],cwd=repo)
 assert (repo/name).read_bytes()==expected,name
productfiles=git('ls-tree','-r','--name-only',parent,'--','src','native','build.cj','cjpm.toml').splitlines()
(base/'source-manifest.json').write_text(json.dumps([item(repo/p) for p in productfiles],indent=2)+'\n')
(base/'old-tests-manifest.json').write_text(json.dumps([item(repo/p) for p in oldfiles],indent=2)+'\n')
consumer=repo/'tests/incremental_layout/frame_cow'
report=f'''TASK128 independent public Frame COW test delivery; classification execution, approved M002/M003 and B128 contract.
Test-only commit {commit}; parent accepted-source {parent}.
10 new files only, 7 cases; every old Unit A test file matches fixed342 byte-for-byte; no product/main/shared config edits.
Actual SDK/CJPM1.2.0 normal consumer build exit0; baseline direct exit0, 7/7 cases GREEN.
COW direct exit1: only unchanged full-snapshot Cell allocation assertion RED; actual deltas48/48, required0/0.
Actual changed-generation slots72 and full-reference slots24; observations are not synthetic dimensions/heap bytes.
Alias/write entrances/Unicode/F003/zeroaxis/fullANSI and caller allocation ownership all GREEN.
Both actual direct runs used 16GiB address-space cap; no timing/performance pass threshold.
Old9 execution reused A126 index c9eaf0d77b4c0e3613caaf7581f603394b786c023c2ee3ce3ff7cb36f8dd0a66 via AGENTS11.1.
Accepted4f vs local0f src/native/build/manifest diff0; old342 consumer diff0; exact manifests indexed.
Backend arbitrary-old/private-profile coverage stays mandatory TASK130 sourceQA plus TASK131 existing output_recovery publicApplication/native-fault execution; see new README.
No private hooks, row identity/address/hash proof, generated expected pictures, second Frame/Unicode, or product switch.
Tooling note: unnecessary oldbaseline attempts failed missing config/registry DNS; logs preserved; authorized ignored configs fixed them, final oldbaseline build exit0, not rerun.
The oldbaseline build used this role's consumer-owned target-dir and alternate binary; no shared target/config was modified.
Only untracked generated locks remain; no .a/.cjo/intermediate pins in index, SDK/deps/cache unchanged.
Skills actually read: cloud TDD + writing-good-tests and verification; fixed local Cangjie coding SKILL plus batched documented query and actualSDK compile.
Source/test/SDK/deps/config/raw statuses and exact commands indexed; no B product implementation, independent acceptance, fullM2 or Linux claim.
'''
(base/'report.md').write_text(report)
inputs=[base/'brief.md',Path('/workspace/work/terminal.ui/AGENTS.md'),Path('/workspace/work/terminal.ui/openspec/changes/implement-incremental-rendering/tasks.md'),Path('/workspace/work/terminal.ui/openspec/changes/implement-incremental-rendering/design.md'),Path('/workspace/work/incremental-layout-execution/index.json'),Path('/workspace/work/incremental-layout-acceptance/index.json'),Path('/workspace/work/CangjieSkills/.agents/skills/cangjie-coding/SKILL.md'),Path('/workspace/work/validation/sdk/cangjie/envsetup.sh'),Path('/workspace/work/validation/sdk/cangjie/bin/cjc'),Path('/workspace/work/validation/sdk/cangjie/tools/bin/cjpm'),Path('/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip'),repo/'cangjie-repo.toml',consumer/'cangjie-repo.toml',consumer/'cjpm.lock']
index={'schema':1,'role':'TASK128 independent Unit B public tests','sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'execution; approved requirements frozen; no product implementation','source_commit':parent,'test_commit':commit,'test_files':[item(repo/p) for p in newfiles],'build':{'cwd':str(consumer),'command':'cjpm build','exit':0},'runs':[{'cwd':str(consumer),'command':'ulimit -v 16777216; target/release/bin/main '+m,'exit':e,'cases':7,'failures':f} for m,e,f in [('baseline',0,0),('cow',1,1)]],'environment':{'SDK':'1.2.0','STDX':'/workspace/work/linux-build-recon/stdx-env','UCD':'/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip','cache':'/workspace/work/viewport-tests/cache','registry':'https://pkg.cangjie-lang.cn/registry','setup':'source /workspace/work/validation/sdk/cangjie/envsetup.sh; export CANGJIE_STDX_PATH=/workspace/work/linux-build-recon/stdx-env; export CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip'},'measured_slots':{'cached_snapshot_second':48,'cached_snapshot_third':48,'changed_generation':72,'full_reference':24},'cow_oracle':'unchanged complete snapshots allocate zero new Cell slots; no physical-sharing hook','inputs':[item(p) for p in inputs],'artifacts':[item(p) for p in sorted((base/'raw').iterdir())]+[item(base/p) for p in ['source-manifest.json','old-tests-manifest.json','report.md','seal.py']],'binary':item(consumer/'target/release/bin/main'),'old_cases_reuse':{'count':9,'files_byte_identical':len(oldfiles),'execution_index_sha256':'c9eaf0d77b4c0e3613caaf7581f603394b786c023c2ee3ce3ff7cb36f8dd0a66','authority':'AGENTS11.1 and root direction; accepted127 PASS_UNIT_A'},'skills':['cloud c6/test-driven-development','cloud c6/test-driven-development/writing-good-tests.md','cloud c6/verification-before-completion','local CangjieSkills277f2e1234ca5217496966887243c679653887a8 cangjie-coding; batched search_docs; SDK actual compile'],'mandatory_later_backend':'TASK130 arbitrary-old/profile/lineage/commit sourceQA; TASK131 tests/output_recovery public Application/native fault normal/supplement/fatal cuts plus affected R11/F003/output','limits':'test author development observations only; B129 implementation and independent130/131/132 still open; no C/D/E/fullM2/Linux closure','immutability':'index and evidence chmod0444; amendment requires indexed addendum; binary remains source raw, no intermediates pinned'}
(base/'index.json').write_text(json.dumps(index,ensure_ascii=False,separators=(',',':'))+'\n')
for p in list((base/'raw').iterdir())+[base/n for n in ['index.json','source-manifest.json','old-tests-manifest.json','report.md','seal.py']]: p.chmod(0o444)
print(commit); print(digest(base/'index.json')); print(f'old byte-identical files: {len(oldfiles)}; report lines: {len(report.splitlines())}')
