Losslessly migrated exactly six accepted Unit A ELF artifact pins into deterministic gzip witnesses (mtime0, no filename header). Original bytes: 114,582,528; gzip bytes: 33,115,986. Every witness was fully decompressed and SHA256/length checked against both the indexed original and the original file before unlink. Originals were then unlinked individually using nonfollowing parent descriptors. All witnesses were reverified at completion.

Allocated recovery: 81,473,536 bytes (77.70 MiB). Net free recovery after receipts: 80,601,088 bytes. Immediate free at completion: 87,138,304 bytes (83.10 MiB).

All 2241 other files in the two Unit A producer/execution workspaces remained exact, including both immutable original indices, CJP, source, raw logs, native inputs and configuration. Source and main HEAD/tree/status/config/refs snapshots remained unchanged. SDK/global cache/other worktrees were untouched.

progress.json records each original absolute logical path, original SHA/bytes/mode/uid/gid/mtime, compressed witness SHA/bytes, original index and current physical state (original absent, witness present). Original index aliases remain historical logical artifact references resolved through these mappings; original indices/reports were not rewritten. Original inode/ctime are historical and are not restoration promises. Process proof found no exe/fd holders, excluding only six previously authorized unrelated container services.

Restoration requires room for a decompressed original. Run:

```sh
python3 /workspace/work/validation/accepted-unit-a-elf-witnesses-20261114/restore.py /absolute/original/path
```

The script verifies the witness, decompresses to an exclusive temporary file, verifies exact original bytes, restores mode/uid/gid/mtime, and publishes using an atomic exclusive hard link. It refuses an existing destination and never overwrites a file. The witness remains intact.
