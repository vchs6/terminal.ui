Losslessly migrated exactly three authorized ended ELF runtimes: fixed B128 true-COW-RED main2aab..., acceptedAC021 minimal bf7da646..., and acceptedAC021 composition69e94b7a.... Both AC021 expected hashes/byte lengths agreed across frozen initial/retry4/GUI indices and the indexed raw/build/binaries.sha256 manifest before conversion. No candidates skipped.

Preserved 57,351,336 original bytes in 16,578,173 gzip bytes. Each deterministic gzip witness (mtime0, no filename) passed full decompression SHA/length comparison against indexed original and current source before per-file unlink. All witnesses passed a second full check at completion. Allocated recovery: 40,771,584 bytes (38.88 MiB); net free recovery after receipts 40,325,120 bytes; completion free 92,971,008 bytes (88.66 MiB).

All 1233 nonmigrated files in the two source/evidence workspaces remained exact, including original immutable indices, raw logs, source/config/locks/native/CJP. Source states and current main HEAD/tree/config/refs stayed unchanged. B129 worktree/new executables and SDK/global cache were untouched. Fresh exe/fd checks showed no holders, excluding exactly the six previously authorized unrelated runtime services;622 zombies skipped.

progress.json maps each old absolute logical artifact path to a verified witness with original SHA/bytes/mode/uid/gid/mtime and current physical state (original absent, witness present). Frozen indices/reports remain unchanged and resolve through this mapping. AC021 relative aliases use the role directory as their base. Original inode/ctime are historical only.

Restore safely, with enough room for one decompressed original:

```sh
python3 /workspace/work/validation/ended-more-runtime-witnesses-20261114/restore.py /absolute/original/path
```

The helper verifies witness/original SHA+bytes, restores mode/uid/gid/mtime, refuses an existing destination, and uses an exclusive temporary file plus atomic nonoverwriting publication. Witnesses remain intact.
