Losslessly migrated exactly four authorized ended runtime ELF files into deterministic gzip witnesses: theme-showcase accepted executable, historical true-RED123 baseline, B128 extra unit-a-baseline attempt, and producer-local generated std.testrunner copy. All four existed, were regular unshared ELF files, and were not in use; no skips.

Original bytes: 70,176,416; gzip bytes: 20,430,495. Each witness was fully decompressed and checked against original SHA/length before its original pathname was unlinked; all four were reverified at completion. Original theme hash matched accepted768d index3887..., old123 hash was resolved exactly from source-and-artifact-hashes.json (0b5a...). Extra baseline/runner current hashes were established in the preflight inventory.

Allocated recovery: 49,737,728 bytes (47.43 MiB); net after receipts 48,545,792 bytes. Completion free: 101,765,120 bytes (97.05 MiB), slightly below100MiB aim; authorized set exhausted.

All 3334 nonmigrated workspace files remained exact, including immutable original indices, source/raw/native/CJP/config/locks and B128 main2aab.... Four worktree source states and main HEAD/tree/config/refs remained unchanged. SDK originals/global caches/active B worktree were untouched. The six documented unrelated runtime process exclusions and otherwise clear task exe/fd proof are recorded separately.

progress.json explicitly maps each old absolute logical path to its lossless witness and original SHA/bytes/mode/uid/gid/mtime/current absent physical state. Old original indices/reports remain immutable and resolve through this representation mapping; original inode/ctime are historical only. The two unindexed extra runtimes are explicitly labeled as such.

Restoration:

```sh
python3 /workspace/work/validation/ended-runtime-witnesses-20261114/restore.py /absolute/original/path
```

The helper refuses any existing destination, verifies compressed and decompressed SHA/length, restores original mode/uid/gid/mtime, and publishes through an exclusive atomic hard link. It requires room for the original and retains the witness.
