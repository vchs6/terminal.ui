# TASK130 independent source review

## Global Constraints

- 原TASK-031/022为完整验收责任归属；123–142实现031各单元，143–147实现022并供031成本验收。实际工程层级依原WP002/WP005，角色工作为独立L3，不把原L3强行嵌另一套L3树。主仓接入时031/022转为本tasks唯一状态引用，不能保留两份勾选权威。
- 单元A123–127已独立接受；128测试已固定、129实施中，其余仍planned；有上游合同不等于上游产品已通过。正式产品124前必须冻结全部功能M1源码/制品及下表最终SHA；禁止提前用c3d743d有限功能作性能基线。
- A→B→C→D→E顺序集成。测试可按冻结合同准备，但产品只消费前单元验收固定提交；共享Component/Layout/Frame禁止多个产品作者同时编辑。
- 每实体一个小写下划线.cj文件，最小可见性，原public调用兼容，新增RuntimeStats三项仅只读；无私有测试hook、无强制M1/M2模式开关。
- 测试作者Sol/high、产品Terra/high或适合仓颉任务的Sol/high、审核/验收Astra/high、执行Sol/medium；记录指定配置，无法核验serving时不冒充实测。
- 角色只交接合同、固定源码/测试SHA、公开命令和原始证据，不交产品作者自评。验收按原AC及实际工作量/CPU/分配/输出，不以测试数量代替。
- 不publish、不改共享SDK/seed/cache、正式基准不依赖探针或开发目录；正常CJPM和普通bundle消费者不可skip。


### B / 128–132（父031，REQ004.1/.3/.8，R11/F003）

文件：128扩同测试项目Frame公共消费者（不改旧断言）；129修改src/frame.cj及必要私有frame_row等单实体文件、终端比较接口内部实现。Cell/Style公开只读值不改；不新增第二Frame类/Unicode。

输入127固定产物和旧Frame完整语义。输出同Frame不可变行共享、实际分配槽计数、任意比较正确fallback。

- [ ] 128固定源/副本双向改、自composite、半簇、透明hole、StyledSpace、负偏移、改宽/高、预算与零面积极值场景；计量观察完整snapshot共享及第一次/重复写不同作用域。
- [ ] 128记录基线功能GREEN与真实“copy逐Cell分配仍存在”工作证据，冻结测试；不为内部存储类型造反射hook。
- [ ] 129将所有实际Cell存储分配统一计槽；所有写入口含clearAt/伙伴写按行脱离；full copy共享、subrect等允许正确慢路径。
- [ ] 129终端比较仅在冻结行身份/profile及精确版本关系适用时排除行；任意old Frame/外部修改/截断lineage回退完整正确比较。
- [ ] 130审每写入口/源别名/共享不可变/零面积不建巨量目录，以及damage不能覆盖后端失同步。
- [ ] 131独立执行128与受影响R11/F003/文件/后端消费者；132按原件确认正确性及计槽口径、性能热路径分配下降，仍不关031。


Binding design: /workspace/work/terminal.ui/openspec/changes/implement-incremental-rendering/design.md sections7/8/10 and14 M002/M003/M011, with final rulings priority. Frozen Frame transparency: /workspace/work/terminal.ui/openspec/changes/implement-frame-composition/design.md F003. Other authoritative current specs: implement-incremental-rendering/specs. Read AGENTS/BATTLE_PROTOCOL/ENGINEERING_TASK_DECOMPOSITION as relevant.

Review fixed full Unit B product diff, not only final subcommit. Spec compliance AND quality verdicts required. No product-author report or self-assessment is an input. No tests/builds: execution131 separate. Check all Frame writing entry points against row sharing, source/copy mutable independence, zero area/budget, actual counter attribution, exact backend proof/profile fallback and failure fences. Check exception cleanup and ownership scope. Existing accepted Unit A source4f7e853f and main0f83f73d product bytes equal. Fixed B128tests9908551d; existing9tests unchanged34240845. Report findings with exact file/line and contract, distinguishing blocking from observations. No subagents, no source/tests edits. Write report.md/findings.json/index.json in this directory, raw fixed-source checks only. Return <=12lines. Candidate SHA/review-package path will arrive on dispatch.
