cjpm check 
