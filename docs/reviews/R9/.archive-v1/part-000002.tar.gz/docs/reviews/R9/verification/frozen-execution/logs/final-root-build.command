cjpm build 
