import pathlib,json,tarfile,hashlib,gzip,subprocess
B=pathlib.Path('/workspace/work/review-archive-acceptance');R=B/'checkout';sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(R/'docs/reviews/archive-v1/audit/evidence.tar.gz') as t: data={x.name:t.extractfile(x).read() for x in t}
byhash={}
for p,b in data.items():byhash.setdefault(sha(b),[]).append(p)
proof=[];indexes=[p for p in data if p.startswith('review-archive-execution/') and p.endswith('/index.json')]
for idx in indexes:
 j=json.loads(data[idx]);source=j.get('sourceHead');
 for a in j.get('artifacts',[]):
  p=a['path'];h=a['sha256'];logical=p.removeprefix('/workspace/work/');rel=p.removeprefix('/workspace/work/terminal.ui/');b=data.get(logical);via=logical
  if b is None or sha(b)!=h:
   q=R/rel
   if q.is_file() and sha(q.read_bytes())==h:b=q.read_bytes();via='fixed-checkout/'+rel
   elif rel.startswith('scripts/') and source:
    b=subprocess.check_output(['git','-C',str(R),'show',source+':'+rel]);assert sha(b)==h
    candidates=[n for n in byhash[h] if n.startswith('source-snapshots/')];assert candidates;via=candidates[0]+' (Git '+source+' exact bytes)'
   else:
    q=R/'docs/reviews/archive-v1/catalog-history'/(h+'.json')
    if q.exists():b=q.read_bytes();via='catalog-history/'+q.name
    else:assert h in byhash,(idx,p,h);via=byhash[h][0];b=data[via]
  assert sha(b)==h and ('bytes' not in a or len(b)==a['bytes']),(idx,p)
  proof.append({'index':idx,'sourceHead':source,'path':p,'sha256':h,'resolution':via})
(B/'raw/stage-bindings.json').write_text(json.dumps({'state':'PASS','indexes':len(indexes),'bindings':len(proof),'historicalSourceBindings':sum('source-snapshots/' in x['resolution'] for x in proof),'historicalCatalogBindings':sum('catalog-history/' in x['resolution'] for x in proof),'records':proof},indent=2)+'\n');print(len(indexes),len(proof),'stage bindings passed')
