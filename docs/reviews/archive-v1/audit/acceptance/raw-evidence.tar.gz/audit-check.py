import pathlib,subprocess,json,gzip,hashlib,tarfile,stat,os,collections
BASE=pathlib.Path('/workspace/work/review-archive-acceptance'); ROOT=BASE/'checkout'; FROZEN=pathlib.Path('/workspace/work/review-archive-migration'); OLD='f0b6b3f9c32a0de1050ee2b1c7bbab4834ab734c'; HEAD='29b9283316ed853a96d98a94cfbbf934bb4b05d8'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,x): (BASE/'raw'/name).write_text(json.dumps(x,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args])
def checked(path,h):
 b=path.read_bytes();assert sha(b)==h,(str(path),sha(b),h);return b
cat=json.loads((ROOT/'docs/reviews/archive-v1/catalog.json').read_bytes())
# Audit package is verified by its complete member set, content, and real Git snapshots.
audit=ROOT/'docs/reviews/archive-v1/audit';m=json.loads(gzip.decompress((audit/'manifest.json.gz').read_bytes()));checked(audit/m['archive']['path'],m['archive']['sha256']);expected={x['member']:x for x in m['members']};auditbytes={}
with tarfile.open(audit/'evidence.tar.gz','r:gz') as tar:
 for t in tar:
  assert t.isfile() and t.name not in auditbytes and t.name in expected,t.name
  x=expected[t.name];b=tar.extractfile(t).read();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and t.mode==x['mode'],t.name;auditbytes[t.name]=b
assert set(auditbytes)==set(expected) and len(auditbytes)==1696
snapshots=[]
for p,b in auditbytes.items():
 if p.startswith('source-snapshots/'):
  _,commit,source=p.split('/',2);assert git('show',commit+':'+source)==b,p;snapshots.append({'member':p,'sha256':sha(b)})
  if commit.startswith('9286956d'):assert (ROOT/source).read_bytes()==b,p
for p in (ROOT/'docs/reviews/archive-v1/catalog-history').glob('*.json'):assert sha(p.read_bytes())==p.stem,p
# Validate sealed execution bindings using immutable audit bytes, canonical clone assets,
# or explicit historical source/catalog snapshots when a path was intentionally reused.
bindings=[]
for name,want in [('review-archive-execution/full-v1/index.json','9f4fb8534242844bedaabdc2adb35d690005b6122e171d13102e7899d8ba5a32'),('review-archive-execution/checkout-fixed-v1/index.json','41567a5f9b94a231019325fcad726d34f839b89aa1a7999d9be1331ba43ae0a5'),('review-archive-source-review/round3/index.json','490b95848c175e29dd447554531e3a263560d422257378268ba1750ae24eaee2')]:
 b=pathlib.Path('/workspace/work',name).read_bytes();assert sha(b)==want and auditbytes[name]==b,name;j=json.loads(b)
 for a in j['artifacts']:
  p=a['path'];logical=p.removeprefix('/workspace/work/');data=auditbytes.get(logical);via='audit member'
  if data is None or sha(data)!=a['sha256']:
   rel=p.removeprefix('/workspace/work/terminal.ui/');q=ROOT/rel
   if q.is_file() and sha(q.read_bytes())==a['sha256']: data=q.read_bytes();via='fixed checkout'
   else:
    matches=[(k,v) for k,v in auditbytes.items() if k.startswith('source-snapshots/') and sha(v)==a['sha256']]
    if matches: via=matches[0][0];data=matches[0][1]
    else:
     q=ROOT/'docs/reviews/archive-v1/catalog-history'/str(a['sha256']+'.json')
     assert q.is_file(),(name,p,a['sha256']);data=q.read_bytes();via='catalog history'
  assert sha(data)==a['sha256'] and ('bytes' not in a or len(data)==a['bytes']),(name,p)
  bindings.append({'index':name,'path':p,'sha256':a['sha256'],'resolution':via})
checks=[]
for pub,orig in [('archive-contract.mjs','tests/archive-contract.mjs'),('fixtures.mjs','tests/fixtures.mjs'),('operator-contract-v2.mjs','operator-contract-v2.mjs'),('checkout-contract.mjs','checkout-contract.mjs')]:
 p=ROOT/'tests/review_archive'/pub;b=p.read_bytes();source='review-archive-migration/'+orig;assert b==auditbytes[source]==(FROZEN/orig).read_bytes();checks.append({'published':str(p.relative_to(ROOT)),'independent':source,'sha256':sha(b)})
restored=0
for g in cat['groups']:
 name='review-archive-execution/full-v1/raw/'+g+'/independent-after-remove.json'
 if name in auditbytes:restored+=json.loads(auditbytes[name])['restored']
 else:
  assert g=='R11'; pilot=json.loads(auditbytes['review-archive-execution/pilot/removal-v1/raw/independent-result.json']);assert pilot['restored444VerifiedOneAtATime'] and len(pilot['restored'])==444;restored+=len(pilot['restored'])
assert restored==32956,restored
save('sealed-bindings.json',bindings)
save('audit-comparison.json',{'state':'PASS','members':len(auditbytes),'sourceSnapshots':snapshots,'sealedIndexBindings':len(bindings),'fullMigrationIndexBindings':sum(x['index'].endswith('full-v1/index.json') for x in bindings),'publishedTests':checks,'independentFullRestorationReused':restored,'futureZeroInlineLimitation':'Recorded nonblocking; all current 26 groups have inline originals.'})
print('audit PASS',len(auditbytes),len(bindings),restored,flush=True)
