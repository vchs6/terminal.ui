import pathlib,subprocess,json,gzip,hashlib,tarfile,stat,os,collections
BASE=pathlib.Path('/workspace/work/review-archive-acceptance'); ROOT=BASE/'checkout'; FROZEN=pathlib.Path('/workspace/work/review-archive-migration'); OLD='f0b6b3f9c32a0de1050ee2b1c7bbab4834ab734c'; HEAD='29b9283316ed853a96d98a94cfbbf934bb4b05d8'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,x): (BASE/'raw'/name).write_text(json.dumps(x,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args])
def checked(path,h):
 b=path.read_bytes();assert sha(b)==h,(str(path),sha(b),h);return b
inventory=json.loads(checked(FROZEN/'inventory.json','cc02fcda5a28d18746bdc2694ed9f102aea01889bbc56fddf4c057a931a8cfc5'))
keep=json.loads(checked(FROZEN/'keep.json','4f37b13e7d92265e7562b8276b8fd7a7986b64b44cf2aa679ab910cbbac33fc6'))
cat=json.loads(checked(ROOT/'docs/reviews/archive-v1/catalog.json','99d0fbbfb8ecc2710ff0e5eff2ec61b040209982251cbca82759839dc00f5de9'))
frozen={}; members={};groups=[];archived={}
for group,ent in inventory['groups'].items():
 for line in gzip.decompress(checked(FROZEN/ent['manifest'],ent['manifestSha256'])).splitlines():
  x=json.loads(line);assert x['path'] not in frozen;frozen[x['path']]=x
for group,ent in cat['groups'].items():
 rows=[json.loads(l) for l in gzip.decompress(checked(ROOT/ent['manifest']['path'],ent['manifest']['sha256'])).splitlines()]
 for x in rows:
  p=x['path'];assert p not in members;members[p]=x;f=frozen[p]
  assert x['type']=='file' and x['member']==p and x['sha256']==f['sha256'] and x['size']==f['size'] and x['mode']==int(f['mode'],8)&0o7777,p
  assert not f['keep'] or x['inline'],p
 for shard in ent['shards']:
  checked(ROOT/shard['path'],shard['sha256'])
  with tarfile.open(ROOT/shard['path'],'r:gz') as tar:
   for t in tar:
    assert t.isfile() and t.name not in archived,t.name
    x=members[t.name];b=tar.extractfile(t).read();assert x['shard']==shard['path'] and t.mode==x['mode'] and len(b)==x['size'] and sha(b)==x['sha256'],t.name
    archived[t.name]={'sha256':sha(b),'size':len(b),'mode':t.mode}
 groups.append({'group':group,'originals':len(rows),'inline':sum(x['inline'] for x in rows),'removed':sum(not x['inline'] for x in rows)})
assert len(groups)==26 and all(x['inline']>=1 for x in groups)
assert set(members)==set(archived)==set(frozen)-{'docs/reviews/README.md'}
# Read the historical Git object bytes independently, without trusting archive content.
tree={}
for rec in git('ls-tree','-rz',OLD,'--','docs/reviews').split(b'\0'):
 if not rec:continue
 meta,p=rec.split(b'\t',1);mode,typ,oid=meta.decode().split();tree[p.decode()]={'mode':mode,'type':typ,'oid':oid}
assert set(tree)==set(frozen) and len(tree)==36756
proc=subprocess.Popen(['git','-C',str(ROOT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
proof=[];original_bytes=0;inline_bytes=0;inline=0;modecounts=collections.Counter()
for p,x in sorted(frozen.items()):
 t=tree[p]; assert t['type']=='blob' and t['mode'] in ['100644','100755'],p
 proc.stdin.write((t['oid']+'\n').encode());proc.stdin.flush();h=proc.stdout.readline().decode().split();b=proc.stdout.read(int(h[2]));assert proc.stdout.read(1)==b'\n'
 assert len(b)==x['size'] and sha(b)==x['sha256'],p
 assert bool(int(t['mode'],8)&0o100)==bool(int(x['mode'],8)&0o100),p
 present=members[p]['inline'] if p in members else True
 if present:
  s=(ROOT/p).lstat();assert stat.S_ISREG(s.st_mode) and (ROOT/p).read_bytes()==b,p
  expected=0o755 if int(t['mode'],8)&0o100 else 0o644
  assert stat.S_IMODE(s.st_mode)==expected,p
  inline+=1;inline_bytes+=len(b);modecounts[oct(stat.S_IMODE(s.st_mode))]+=1
 else: assert not (ROOT/p).exists(),p
 proof.append({'path':p,'gitOid':t['oid'],'gitMode':t['mode'],'historicalMode':x['mode'],'sha256':sha(b),'bytes':len(b),'inline':present,'archived':p in archived})
 original_bytes+=len(b)
proc.stdin.close();assert proc.wait()==0
assert original_bytes==453165327 and inline==3800 and inline_bytes==107293030
with gzip.GzipFile(filename=str(BASE/'raw/original-byte-proof.jsonl.gz'),mode='wb',mtime=0) as out:
 for x in proof:out.write((json.dumps(x,separators=(',',':'))+'\n').encode())
current=set(git('ls-tree','-rz','--name-only',HEAD,'--','docs/reviews').decode().rstrip('\0').split('\0'))
expectedremoved={p for p,x in members.items() if not x['inline']};assert set(tree)-current==expectedremoved and len(expectedremoved)==32956
for p in keep['keep']:assert p in current,p
for p in keep['keepDirectories']:assert (ROOT/p).is_dir() and any((ROOT/p).rglob('*')),p
for p in tree:
 if p.endswith(('.md','.png','.sha','.sha256','.sha512')) or (p.endswith(('.json','.jsonl')) and ('index' in pathlib.Path(p).name or 'manifest' in pathlib.Path(p).name)):assert p in current,p
assert 'docs/reviews/R16/execution/raw/host-xorg-dummy.conf' in current
assert subprocess.run(['git','-C',str(ROOT),'merge-base','--is-ancestor',OLD,HEAD]).returncode==0
extras=sorted(p for p,x in members.items() if x['inline'] and not frozen[p]['keep'])
assert extras==['docs/reviews/interaction/A/TASK-100/findings.json','docs/reviews/interaction/B/TASK-105/findings.json','docs/reviews/interaction/C/source-review/review-fd286174..61e4de9d.diff']
reviewbytes=sum((ROOT/p).stat().st_size for p in current)
save('original-comparison.json',{'state':'PASS','baseline':OLD,'head':HEAD,'groups':groups,'originals':len(tree),'originalBytes':original_bytes,'archivedOriginals':len(archived),'inlineOriginals':inline,'inlineOriginalBytes':inline_bytes,'removedOriginals':len(expectedremoved),'additionalKept':extras,'rootReadme':{'bytes':frozen['docs/reviews/README.md']['size'],'sha256':frozen['docs/reviews/README.md']['sha256'],'archived':False},'checkoutModes':dict(modecounts),'currentReviewFiles':len(current),'currentReviewFileBytes':reviewbytes,'effectiveNetLogicalSavingBytes':original_bytes-reviewbytes,'savingsExcludeGitObjects':True,'allFrozenKeepFilesAndDirectoriesPresent':True,'allOriginalMDPNGIndexesAndLiveR16InputPreserved':True})
print('original/archive/Git PASS',len(tree),len(archived),inline,reviewbytes,flush=True)
# Audit package is verified by its complete member set, content, and real Git snapshots.
audit=ROOT/'docs/reviews/archive-v1/audit';m=json.loads(gzip.decompress((audit/'manifest.json.gz').read_bytes()));checked(audit/m['archive']['path'],m['archive']['sha256']);expected={x['member']:x for x in m['members']};auditbytes={}
with tarfile.open(audit/'evidence.tar.gz','r:gz') as tar:
 for t in tar:
  assert t.isfile() and t.name not in auditbytes and t.name in expected,t.name
  x=expected[t.name];b=tar.extractfile(t).read();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and t.mode==x['mode'],t.name;auditbytes[t.name]=b
assert set(auditbytes)==set(expected) and len(auditbytes)==1696
snapshots=[]
for p,b in auditbytes.items():
 if p.startswith('source-snapshots/'):
  _,commit,source=p.split('/',2);assert git('show',commit+':'+source)==b,p;snapshots.append({'member':p,'sha256':sha(b)})
  if commit.startswith('9286956d'):assert (ROOT/source).read_bytes()==b,p
for p in (ROOT/'docs/reviews/archive-v1/catalog-history').glob('*.json'):assert sha(p.read_bytes())==p.stem,p
# Validate sealed execution bindings using immutable audit bytes, canonical clone assets,
# or explicit historical source/catalog snapshots when a path was intentionally reused.
bindings=[]
for name,want in [('review-archive-execution/full-v1/index.json','9f4fb8534242844bedaabdc2adb35d690005b6122e171d13102e7899d8ba5a32'),('review-archive-execution/checkout-fixed-v1/index.json','41567a5f9b94a231019325fcad726d34f839b89aa1a7999d9be1331ba43ae0a5'),('review-archive-source-review/round3/index.json','490b95848c175e29dd447554531e3a263560d422257378268ba1750ae24eaee2')]:
 b=pathlib.Path('/workspace/work',name).read_bytes();assert sha(b)==want and auditbytes[name]==b,name;j=json.loads(b)
 for a in j['artifacts']:
  p=a['path'];logical=p.removeprefix('/workspace/work/');data=auditbytes.get(logical);via='audit member'
  if data is None or sha(data)!=a['sha256']:
   rel=p.removeprefix('/workspace/work/terminal.ui/');q=ROOT/rel
   if q.is_file() and sha(q.read_bytes())==a['sha256']: data=q.read_bytes();via='fixed checkout'
   else:
    matches=[(k,v) for k,v in auditbytes.items() if k.startswith('source-snapshots/') and sha(v)==a['sha256']]
    if matches: via=matches[0][0];data=matches[0][1]
    else:
     q=ROOT/'docs/reviews/archive-v1/catalog-history'/str(a['sha256']+'.json')
     assert q.is_file(),(name,p,a['sha256']);data=q.read_bytes();via='catalog history'
  assert sha(data)==a['sha256'] and len(data)==a['bytes'],(name,p)
  bindings.append({'index':name,'path':p,'sha256':a['sha256'],'resolution':via})
checks=[]
for pub,orig in [('archive-contract.mjs','tests/archive-contract.mjs'),('fixtures.mjs','tests/fixtures.mjs'),('operator-contract-v2.mjs','operator-contract-v2.mjs'),('checkout-contract.mjs','checkout-contract.mjs')]:
 p=ROOT/'tests/review_archive'/pub;b=p.read_bytes();source='review-archive-migration/'+orig;assert b==auditbytes[source]==(FROZEN/orig).read_bytes();checks.append({'published':str(p.relative_to(ROOT)),'independent':source,'sha256':sha(b)})
restored=0
for g in cat['groups']:
 name='review-archive-execution/full-v1/raw/'+g+'/independent-after-remove.json'
 if name in auditbytes:restored+=json.loads(auditbytes[name])['restored']
 else:
  matches=[k for k in auditbytes if k.endswith('independent-after-remove.json') and ('R11' in k or 'pilot' in k)];raise AssertionError((g,matches))
assert restored==32956,restored
save('sealed-bindings.json',bindings)
save('audit-comparison.json',{'state':'PASS','members':len(auditbytes),'sourceSnapshots':snapshots,'sealedIndexBindings':len(bindings),'fullMigrationIndexBindings':sum(x['index'].endswith('full-v1/index.json') for x in bindings),'publishedTests':checks,'independentFullRestorationReused':restored,'futureZeroInlineLimitation':'Recorded nonblocking; all current 26 groups have inline originals.'})
print('audit PASS',len(auditbytes),len(bindings),restored,flush=True)
