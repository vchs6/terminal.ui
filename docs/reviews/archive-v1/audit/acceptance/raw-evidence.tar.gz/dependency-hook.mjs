import {registerHooks} from 'node:module';
registerHooks({resolve(specifier, context, nextResolve) {
  if (specifier === 'smol-toml') return {url:'file:///workspace/work/terminal.ui/node_modules/smol-toml/dist/index.js',shortCircuit:true};
  return nextResolve(specifier,context);
}});
