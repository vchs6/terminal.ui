# Lossless in-repository review evidence migration

Scope: `docs/reviews` at `terminal.ui` HEAD `f0b6b3f9c32a0de1050ee2b1c7bbab4834ab734c` (14 November 2026). Workflow classification: **execution** of the user's chosen in-repository, lossless, per-review-round compression approach. This is an implementation manifest and retention plan, not an executed migration. Preserve Git history and the newly tracked `docs/reviews/R22/021/storage/` receipts. Do not move product source, examples, tests, build files, or existing review reports. The machine-readable retention and frozen SHA baselines are `keep.json`, `inventory.json`, and `groups/*.jsonl.gz` alongside this plan.

## Measured inventory and retention

Counts below use `git ls-files -z docs/reviews` and current regular-file byte lengths, not `du` allocation. All 36,756 tracked review entries are regular files; Git and checkout contain no review symlinks. Total original bytes: **453,165,327**.

| State after migration | Files | Original bytes |
| --- | ---: | ---: |
| Remain at their original paths | 3,797 | 107,131,581 |
| Archive-only, removed from checkout only after verified packing | 32,959 | 346,033,746 |
| Total originals represented in archives | 36,756 | 453,165,327 |

The keep set is the union of all Markdown (including READMEs), every original PNG, all direct relative Markdown link targets, all `*.sha`, `*.sha256`, `*.sha512`, JSON/JSONL files with `index` or `manifest` in their basename, the 70 review files referenced by tracked files outside `docs/reviews`, all 18 executable-mode review files, the three R22 storage receipts, and the live `docs/reviews/R16/execution/raw/host-xorg-dummy.conf`. Overlap is counted once. The 70 external references were identified by scanning tracked non-review text for literal repository paths. These conservative rules leave historical seal/index files unchanged and readily accessible. An execution preflight must add any newly discovered active input to the keep set before packing it; it may only reduce the archive-only count.

The repository checker scans Markdown in the root set, `docs`, and `openspec`, then parses `]([path])` links, strips fragments, skips its listed URI forms, and checks `existsSync(resolve(dirname(source), path))`. A scan using those same path rules found **1,710 distinct local targets**, including **1,621 tracked review files** and **six review directories**, with **zero currently missing targets**. Preserve every linked file and target directory path, including when a directory would otherwise become empty. The newly tracked R22 storage README was included in this link scan. No checker change is needed. Backtick paths and JSON provenance references are historical logical references, not checker links; resolve them through the catalog below if their original files become archive-only.

The retained files are also included byte-for-byte in the round archives. This deliberately duplicates their compressed representation so each round archive is a complete original snapshot. Archive size and resulting net disk saving cannot be exact until packing and verification; 346,033,746 bytes is the measured amount of uncompressed checkout data eligible for removal, before archive bytes and filesystem overhead. Existing `.tar.gz`/`.gz` members are kept as their original compressed bytes inside the new archive; do not unpack and repack their contents or claim savings from those already compressed members. The current Git pack remains untouched; it is not a reliable prediction of new tar/gzip size.

## Archive layout and contract

Use one logical archive namespace per first-level review group (`R0`, `R1`, …, `R23`, `E`, `K`, `interaction`, `widgets`), with bounded shards as needed:

```text
docs/reviews/archive-v1/catalog.json
docs/reviews/<group>/.archive-v1/manifest.jsonl.gz
docs/reviews/<group>/.archive-v1/part-000001.tar.gz
docs/reviews/<group>/.archive-v1/part-000002.tar.gz
scripts/review-archive.mjs
```

The root `docs/reviews/README.md` stays at its original path and is not a round member. `catalog.json` maps group to manifest path, manifest SHA256, shard paths, shard SHA256, and format version. The gzip manifest has one sorted record for **every original round file**, including retained files: `{path, type:"file", mode, size, sha256, shard, member, inline}`. `path` is the original repository-relative logical path. `member` is the same path in the tar, without a leading slash or `..`; `inline` says whether the original also remains in the checkout. Record the original SHA256 of each file, not a recomputed substitute. Store no host absolute path as a tar member. Each original occurs in exactly one shard. The resolver accepts only paths under `docs/reviews`, normalizes known historical repository-root prefixes, and returns an inline path or archive/shard/member plus expected SHA256. It must not invent a match for external SDK, cache, binary, or source paths that were never in this review tree.

Implement `list`, `resolve <logical-path>`, `verify [group]`, and `restore <logical-path> <destination>` in a Node CLI using core `fs`, `crypto`, `zlib`, and `child_process` plus installed GNU tar/gzip. Restoring writes an atomic destination after SHA/size/mode verification. `verify` checks catalog and manifest SHA, all archive member paths and types, shard SHA, every member's original SHA/size/mode, and equality of every retained inline original with its archive member. Existing R22 `publication.sha256`, `index.sha256`, raw evidence manifests, archives, and frozen original reports stay byte-identical. Old direct `sha256sum -c` commands on now archive-only paths must use `resolve`/`restore` first; `verify` supplies the whole-round archive-aware check.

## Bounded execution order and safety gates

1. Use the frozen per-group SHA/mode/size records in `groups/*.jsonl.gz`; reject a changed, missing, untracked-overlapping, symlink, special, absolute, or traversal path. Re-run link closure and literal external-reference scan against the then-current tree. Review candidate scripts/configuration/input paths for active use, especially R16 X.Org and R22 storage, and retain additions. Never dereference a symlink.
2. Pilot **R11**: 515 originals, 6,706,515 bytes; 71 retained files, 457,705 bytes; 444 archive-only files, 6,248,810 bytes. Its largest original is 864,015 bytes. Check the tool and free-space prerequisites immediately before this pilot. Node 24.22.1, GNU tar 1.35, gzip 1.13 are present; free workspace space was 23,580,672 bytes after generating the frozen inventory and may change.
3. For each group, partition the frozen list into shards of at most 4 MiB original data and 500 files, except a single larger file must get its own shard. Stream tar to `gzip -n` in a temporary file; use NUL-delimited explicit member lists, no recursion, no symlink following, and relative paths only. Preflight free space for pack and scratch extraction; abort safely on insufficient space. No full 453 MB copy is made. The biggest original currently measured is 9,238,467 bytes, so a one-member shard remains bounded.
4. Extract each completed shard into a fresh scratch directory, verify path/type/mode/size/SHA against the frozen list, compare retained originals, then atomically rename and sync the pack. Write and sync the compressed manifest and catalog entries after all shards verify. Only then remove that group's **archive-only** originals, each after an immediate SHA check against its manifest. Make this step restartable: a present original is rechecked, an absent original must resolve to a verified archived member. Do not delete a retained original or any existing historical archive/index. Clean scratch only after success or safe abort.
5. Run the unchanged `scripts/check-repository.mjs`, the archive verifier for all completed groups, a second path/byte inventory, and `git status --short`. Stage only the new archive/catalog/CLI files and the verified deleted review paths for the completed group; do not stage the pre-existing root work. Keep all Git commits/history, with no rebase, rewrite, force push, external storage, or changed original hashes. Proceed from the pilot to high-saving groups before R22 so freed checkout space can hold R22's retained-file duplicate archive; stop a group if its bounded space gate cannot pass.

The pilot is complete only when every R11 original resolves to matching bytes, all 71 retained originals still match, all 444 removed logical paths restore correctly, the unchanged repository checker passes, and the Git diff contains only the intended R11 removals and new archive plumbing. Apply the same gate per later group.
