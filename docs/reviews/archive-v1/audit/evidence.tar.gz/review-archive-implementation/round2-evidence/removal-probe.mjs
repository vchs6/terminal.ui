import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const base=fs.mkdtempSync(path.join(os.tmpdir(),'review-removal-'));
const cli='/workspace/work/review-archive-implementation/source/scripts/review-archive-pack.mjs';
const keep=path.join(base,'keep.json');fs.writeFileSync(keep,'[]');
function run(command,args,cwd,expect=0) {const p=spawnSync(command,args,{cwd,encoding:'utf8'});if(expect===0) assert.equal(p.status,0,p.stderr); else assert.notEqual(p.status,0);return p;}
function setup(name) {const root=path.join(base,name),dir=path.join(root,'docs/reviews/R11/raw');fs.mkdirSync(dir,{recursive:true});for(const f of ['a.dat','b.dat','z.dat'])fs.writeFileSync(path.join(dir,f),f);run('git',['init','-q'],root);run('git',['add','.'],root);run('git',['-c','user.name=Probe','-c','user.email=probe@example.invalid','commit','-qm','fixture'],root);run('node',[cli,'--root',root,'--group','R11','--keep',keep,'pack'],root);return {root,dir};}
function remove(root,expect=0){return run('node',[cli,'--root',root,'--group','R11','--keep',keep,'remove'],root,expect);}
const changed=setup('changed');fs.writeFileSync(path.join(changed.dir,'z.dat'),'modified');remove(changed.root,1);for(const f of ['a.dat','b.dat'])assert.equal(fs.readFileSync(path.join(changed.dir,f),'utf8'),f);assert.equal(fs.readFileSync(path.join(changed.dir,'z.dat'),'utf8'),'modified');console.log('preexisting changed original blocks every deletion');
const resumed=setup('resumed');fs.unlinkSync(path.join(resumed.dir,'a.dat'));remove(resumed.root);for(const f of ['a.dat','b.dat','z.dat'])assert.equal(fs.existsSync(path.join(resumed.dir,f)),false);remove(resumed.root);console.log('absent archive-only original permits safe restart');
