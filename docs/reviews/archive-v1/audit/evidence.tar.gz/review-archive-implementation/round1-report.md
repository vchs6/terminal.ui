# Source review round 1 fixes

- Commit: 62b68e350ffa181d0f08f5fea8d1c846ca224e87 (parent d3d5b8e62a317d2acb02f2f4c88fd260fac5e0ab).
- SRC-001: catalog path components are checked for symlinks and non-directories before archive publication.
- SRC-002: retain a tracked descendant for each linked directory and record the decision before packing.
- Completed archive recovery verifies the baseline, originals, retention, manifest and shards before catalog publication; refuses unknown files.
- `node /tmp/archive-fixes-probe.mjs`: 5 cases passed: symlink, fresh-clone directory, recovery, unknown file, changed original.
- `node /workspace/work/review-archive-migration/tests/archive-contract.mjs /workspace/work/review-archive-implementation/source/scripts/review-archive.mjs`: 51 passed, 0 failed.
- Independent operator regressions and source review remain pending.
- A crash during pending-directory construction leaves an untracked pending directory that must be inspected before retry; no unknown files are removed automatically.
- Tar verification streams members rather than extracting them into scratch as the plan specifies.
- No real review data was modified.

Evidence is preserved in `round1-evidence/sha256-index.json`, including the exact probe, combined output, exit status and SHA256 values of the fixed source files.

For a specifically inspected abandoned pending directory, create a new, unique holding directory under the same repository root, move that one pending directory into it without deleting any contents, and rerun the same pack command. For example, with `ROOT`, `GROUP`, and the exact `PENDING_NAME` set to the inspected values:

```sh
mkdir "$ROOT/.review-archive-hold-UNIQUE"
mv -- "$ROOT/docs/reviews/$GROUP/$PENDING_NAME" "$ROOT/.review-archive-hold-UNIQUE/"
node scripts/review-archive-pack.mjs --root "$ROOT" --group "$GROUP" --keep KEEP.json pack
```

Choose a fresh holding name: `mkdir` fails if it already exists. Stop if either command fails; do not remove or replace the held directory. This procedure preserves the pending files and originals, and requires enough free space for the retry.
