import os,sys,stat,json,hashlib,subprocess,pathlib,shutil,time
BASE=pathlib.Path('/workspace/work/terminal.ui'); META=BASE/'.git/worktrees'; OUT=pathlib.Path('/workspace/work/validation/sparse-index-capacity-20261114'); GIT=shutil.which('git')
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(b):return hashlib.sha256(b).hexdigest()
def run(p,*args):
 r=subprocess.run([GIT,*args],cwd=p,env=ENV,capture_output=True)
 if r.returncode:raise RuntimeError(f'{p}: git {args}: {r.returncode}: {r.stderr.decode()}')
 return r.stdout

def cfg(p,key):
 r=subprocess.run([GIT,'config','--get',key],cwd=p,env=ENV,capture_output=True)
 if r.returncode not in (0,1):raise RuntimeError(r.stderr.decode())
 return r.stdout.decode().strip()
def main_state():return {'config_sha256':sha((BASE/'.git/config').read_bytes()),'head':run(BASE,'rev-parse','HEAD').decode().strip(),'core.sparseCheckout':cfg(BASE,'core.sparseCheckout'),'extensions.worktreeConfig':cfg(BASE,'extensions.worktreeConfig')}
def free():
 s=os.statvfs(BASE);return s.f_bavail*s.f_frsize
def idx(p):
 s=p.stat();return {'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'sha256':sha(p.read_bytes())}
def manifest(p,logical):
 tracked=set()
 for ent in logical.split(b'\0'):
  if not ent:continue
  prefix,name=ent.split(b'\t',1); mode,oid,stage=prefix.split()
  if stage!=b'0':raise RuntimeError('conflict index')
  tracked.add(os.fsdecode(name))
 files=[]
 for folder,dirs,names in os.walk(p,followlinks=False):
  for name in sorted(dirs+names):
   q=pathlib.Path(folder)/name; rel=str(q.relative_to(p))
   if rel=='.git':continue
   s=q.lstat(); mode=stat.S_IMODE(s.st_mode)
   if stat.S_ISREG(s.st_mode):
    with q.open('rb') as f:
     h=hashlib.file_digest(f,'sha256').hexdigest()
    files.append({'path':rel,'mode':mode,'bytes':s.st_size,'sha256':h,'tracked':rel in tracked})
   elif stat.S_ISLNK(s.st_mode):
    if rel in tracked:raise RuntimeError('tracked symlink: '+rel)
    files.append({'path':rel,'mode':mode,'symlink':os.readlink(q),'tracked':False})
   elif not stat.S_ISDIR(s.st_mode):raise RuntimeError('special checkout entry: '+rel)
 return sorted(files,key=lambda r:r['path'])
def write(name,data):
 (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
initial=main_state(); start_free=free(); write('main-before.json',{'state':initial,'free_bytes':start_free,'git':GIT,'git_version':run(BASE,'--version').decode().strip()})
assert initial['extensions.worktreeConfig']=='true'
candidates=[]
for d in META.iterdir():
 try:
  p=pathlib.Path((d/'gitdir').read_text().strip()).parent
  parts=p.relative_to('/workspace/work').parts
  if parts[-1]!='source' or not (len(parts)==2 or (parts[0]=='widgets-composite-tests' and len(parts) in (3,4))):continue
  if not p.is_dir():continue
  if cfg(p,'core.sparseCheckout')!='true' or cfg(p,'core.sparseCheckoutCone')!='true':continue
  candidates.append((d/'index',p,d))
 except (ValueError,FileNotFoundError):continue
candidates.sort(key=lambda c:-c[0].stat().st_size)
write('candidates.json',[{'path':str(p),'metadata':str(d),'index':idx(ix)} for ix,p,d in candidates])
results=[];skips=[]
try:
 for ix,p,d in candidates:
  if free()>=200*1024*1024:break
  assert main_state()==initial,'main state changed before conversion'
  assert run(p,'rev-parse','--show-toplevel').decode().strip()==str(p)
  status=run(p,'status','--porcelain=v1','--untracked-files=no','-z')
  if status:
   skips.append({'path':str(p),'reason':'tracked/index dirty','status':os.fsdecode(status)});write('skips.json',skips);continue
  head=run(p,'rev-parse','HEAD').decode().strip(); logical=run(p,'ls-files','--stage','-z')
  patterns=d/'info/sparse-checkout'; before_files=manifest(p,logical)
  before={'path':str(p),'metadata':str(d),'head':head,'status_sha256':sha(status),'patterns_sha256':sha(patterns.read_bytes()),'logical_inventory_sha256':sha(logical),'index':idx(ix),'free_bytes':free(),'worktree_config':(d/'config.worktree').read_text(),'files':before_files}
  write(d.name+'-before.json',before)
  r=subprocess.run([GIT,'sparse-checkout','reapply','--sparse-index'],cwd=p,env=ENV,capture_output=True)
  command={'returncode':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()};write(d.name+'-command.json',command)
  if r.returncode or r.stderr:raise RuntimeError(f'conversion warning/error: {p}: {command}')
  assert main_state()==initial,'main/shared config changed after conversion'
  after_logical=run(p,'ls-files','--stage','-z')
  after_files=manifest(p,after_logical)
  assert run(p,'rev-parse','HEAD').decode().strip()==head,'HEAD changed'
  assert run(p,'status','--porcelain=v1','--untracked-files=no','-z')==status,'tracked/index status changed'
  assert sha(patterns.read_bytes())==before['patterns_sha256'],'patterns changed'
  assert after_logical==logical,'logical index inventory changed'
  assert after_files==before_files,'checkout file inventory/bytes/modes changed'
  assert cfg(p,'index.sparse')=='true','index.sparse not true'
  after={'path':str(p),'head':head,'patterns_sha256':before['patterns_sha256'],'logical_inventory_sha256':sha(after_logical),'index':idx(ix),'free_bytes':free(),'worktree_config':(d/'config.worktree').read_text(),'files_manifest_sha256':sha(json.dumps(after_files,sort_keys=True).encode()),'file_count':len(after_files),'tracked_present_count':sum(x['tracked'] for x in after_files),'all_files_unchanged':True}
  write(d.name+'-after.json',after)
  results.append({'path':str(p),'head':head,'index_before':before['index'],'index_after':after['index'],'file_count':len(after_files),'all_files_unchanged':True,'free_bytes':after['free_bytes']})
  write('results.json',results)
  print(json.dumps(results[-1]),flush=True)
except BaseException as e:
 write('STOP.json',{'error':str(e),'main_state':main_state(),'free_bytes':free(),'results_count':len(results)})
 print('STOP '+str(e),flush=True);sys.exit(1)
finally:
 write('main-after.json',{'state':main_state(),'free_bytes':free()})
summary={'main_state_unchanged':main_state()==initial,'converted':len(results),'skipped':skips,'eligible_count':len(candidates),'free_before_bytes':start_free,'free_after_bytes':free(),'net_free_recovered_bytes':free()-start_free,'index_allocated_recovered_bytes':sum(x['index_before']['allocated_bytes']-x['index_after']['allocated_bytes'] for x in results),'index_logical_recovered_bytes':sum(x['index_before']['bytes']-x['index_after']['bytes'] for x in results),'all_checkout_manifests_unchanged':True}
write('summary.json',summary);print(json.dumps(summary),flush=True)
