# Independent archive migration source review
Revision: `d3d5b8e62a317d2acb02f2f4c88fd260fac5e0ab`; base: `323d6a7623e1c7c42939cf9cccd90e1fdf259248`.
Scope: six added CLI/operator files, against migration plan and repository rules; author self-assessment not read.
SPEC verdict: **FAIL** — two required safety/preservation guarantees are unmet.
QUALITY verdict: **FAIL** — catalog publication bypasses the shared safe-path policy; linked-directory retention is recorded without enforcement.
SRC-001 (major/P1), `scripts/review-archive/pack.mjs:48`: first catalog publication follows an existing archive-v1 directory symlink and writes outside the selected repository. Reject symlink ancestors before creating/publishing the catalog.
SRC-002 (major/P2), `scripts/review-archive/pack.mjs:45,57`: a linked directory with only archive-only children vanishes from a fresh checkout after migration. Retain a tracked child or introduce a tracked directory sentinel before removing its last tracked child.
Both findings were independently reproduced in disposable repositories under this review directory; see `probe-results.json` and `probes.mjs`.
Observed SRC-001: pack exited 0 and wrote the catalog through the symlink outside its root.
Observed SRC-002: pack/remove exited 0; retention listed the linked directory; it existed after unlinking but not in the committed fixture's fresh clone.
Positive source checks: exact-member/hash/size/mode verification, bounded shard partitioning, retained-file comparison, archive verification before removal, immediate per-file recheck, no overwrite at restore publication, and unchanged original index/report content by design.
Removal can resume with absent originals only after archive verification. Interrupted catalog publication remains a documented manual-recovery boundary, not an automatic recovery implementation.
No production archive/migration, main-tree edits, builds, author contact, or repeated unchanged suite runs were performed. The probes create and migrate synthetic fixture data only.
The announced 51-case development result was not independently rerun or treated as acceptance; independent execution remains separate.
Review evidence and input hashes are indexed in `index.json`.
