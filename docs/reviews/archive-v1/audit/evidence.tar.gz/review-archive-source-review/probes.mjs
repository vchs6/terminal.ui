import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const base='/workspace/work/review-archive-source-review';
const cli='/workspace/work/review-archive-implementation/source/scripts/review-archive-pack.mjs';
function run(command,args,cwd) {
  const r=spawnSync(command,args,{cwd,encoding:'utf8'});
  if(r.status!==0) throw new Error(`${command} ${args.join(' ')}: ${r.stderr}`);
  return {status:r.status,stdout:r.stdout,stderr:r.stderr};
}
function setup(name,readme) {
  const root=path.join(base,name); fs.mkdirSync(path.join(root,'docs/reviews/R11/linked'),{recursive:true});
  fs.writeFileSync(path.join(root,'docs/reviews/R11/linked/data.txt'),'original evidence\n');
  fs.writeFileSync(path.join(root,'README.md'),readme);
  run('git',['init','-q'],root);
  run('git',['add','.'],root);
  run('git',['-c','user.name=Reviewer','-c','user.email=reviewer@example.invalid','commit','-qm','fixture'],root);
  return root;
}
const keep=path.join(base,'keep.json'); fs.writeFileSync(keep,'[]\n');
const symlinkRoot=setup('catalog-symlink','# Fixture\n');
const outside=path.join(base,'catalog-outside'); fs.mkdirSync(outside);
fs.symlinkSync(outside,path.join(symlinkRoot,'docs/reviews/archive-v1'));
const symlinkPack=run(process.execPath,[cli,'--root',symlinkRoot,'--group','R11','--keep',keep,'pack'],base);
const linkedRoot=setup('linked-directory','[Evidence directory](docs/reviews/R11/linked)\n');
const linkedPack=run(process.execPath,[cli,'--root',linkedRoot,'--group','R11','--keep',keep,'pack'],base);
const linkedRemove=run(process.execPath,[cli,'--root',linkedRoot,'--group','R11','--keep',keep,'remove'],base);
run('git',['add','-A'],linkedRoot);
run('git',['-c','user.name=Reviewer','-c','user.email=reviewer@example.invalid','commit','-qm','migration'],linkedRoot);
const clone=path.join(base,'linked-fresh-checkout');run('git',['clone','-q',linkedRoot,clone],base);
const result={
  catalogSymlink:{...symlinkPack,wroteOutsideRoot:fs.existsSync(path.join(outside,'catalog.json'))},
  linkedDirectory:{pack:linkedPack,remove:linkedRemove,retention:JSON.parse(fs.readFileSync(path.join(linkedRoot,'docs/reviews/R11/.archive-v1/retention.json'))),presentAfterRemoval:fs.existsSync(path.join(linkedRoot,'docs/reviews/R11/linked')),presentInFreshCheckout:fs.existsSync(path.join(clone,'docs/reviews/R11/linked'))}
};
fs.writeFileSync(path.join(base,'probe-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
