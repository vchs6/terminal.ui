import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const base='/workspace/work/review-archive-source-review/round3';
const root=path.join(base,'empty-inline-fixture');
const clone=path.join(base,'empty-inline-clone');
const operator='/workspace/work/review-archive-implementation/source/scripts/review-archive-pack.mjs';
const cli='/workspace/work/review-archive-implementation/source/scripts/review-archive.mjs';
function run(program,args,cwd=root){const p=spawnSync(program,args,{cwd,encoding:'utf8'});return {exit:p.status,stdout:p.stdout,stderr:p.stderr};}
function ok(program,args,cwd=root){const r=run(program,args,cwd);if(r.exit!==0)throw Error(JSON.stringify(r));return r;}
fs.mkdirSync(path.join(root,'docs/reviews/R11/raw'),{recursive:true});
fs.writeFileSync(path.join(root,'docs/reviews/R11/raw/only.dat'),'literal original evidence\n');
const keep=path.join(base,'empty-keep.json');fs.writeFileSync(keep,'[]\n');
ok('git',['init','-q']);ok('git',['add','.']);ok('git',['-c','user.name=Reviewer','-c','user.email=reviewer@example.invalid','commit','-qm','original']);
const operate=(where,action)=>[operator,'--root',where,'--group','R11','--keep',keep,action];
const pack=ok(process.execPath,operate(root,'pack'));
const remove=ok(process.execPath,operate(root,'remove'));
ok('git',['add','-A']);ok('git',['-c','user.name=Reviewer','-c','user.email=reviewer@example.invalid','commit','-qm','migration']);
ok('git',['clone','-q',root,clone],base);
const verify=ok(process.execPath,[cli,'--root',clone,'verify','R11'],base);
const replay=run(process.execPath,operate(clone,'remove'),base);
const result={pack,remove,cloneVerify:verify,committedCloneReplay:replay,originalAbsent:!fs.existsSync(path.join(clone,'docs/reviews/R11/raw/only.dat')),cloneStatus:ok('git',['status','--porcelain'],clone).stdout};
fs.writeFileSync(path.join(base,'empty-group-replay-result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
