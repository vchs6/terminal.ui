import pathlib,os,stat,json,gzip,tarfile,hashlib,subprocess,datetime,traceback,sys,re
R=pathlib.Path('/workspace/work/terminal.ui');B=pathlib.Path('/workspace/work/review-archive-migration');E=pathlib.Path('/workspace/work/review-archive-execution/full-v1');HEAD='36b19d776b45c2aeafd2ad77bb4352103e87f44f';floor=8*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 return n,h.hexdigest()
def free():s=os.statvfs(R);return s.f_bavail*s.f_frsize
def save(p,v):assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def safe(p):
 for q in [*reversed(p.parents),p]:
  if q.exists() or q.is_symlink():assert not q.is_symlink(),q
  else:break

def git(*a):return subprocess.check_output(['git','-C',str(R),*a]).decode().strip()
def run(g,name,argv,expect=0):
 raw=E/'raw'/g;raw.mkdir(parents=True,exist_ok=True);prefix=raw/name;assert not prefix.with_suffix('.command.json').exists();start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for ext,data in [('stdout',p.stdout),('stderr',p.stderr),('exit',(str(p.returncode)+'\n').encode())]:pathlib.Path(str(prefix)+'.'+ext).write_bytes(data)
 save(pathlib.Path(str(prefix)+'.command.json'),{'argv':argv,'cwd':str(R),'startedUtc':start,'endedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'expectedExit':expect,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
 assert p.returncode==expect,(g,name,p.returncode,p.stderr.decode(errors='replace'));return p.stdout
inventoryData=(B/'inventory.json').read_bytes();assert sha(inventoryData)=='cc02fcda5a28d18746bdc2694ed9f102aea01889bbc56fddf4c057a931a8cfc5';inv=json.loads(inventoryData);assert sha((B/'keep.json').read_bytes())=='4f37b13e7d92265e7562b8276b8fd7a7986b64b44cf2aa679ab910cbbac33fc6';keepData=json.loads((B/'keep.json').read_text());supplied=set(keepData['keep']);toolHashes=json.loads(pathlib.Path('/workspace/work/review-archive-execution/pilot/attempt-v2/raw/preflight.json').read_text())['toolHashes']
allTracked=git('ls-files','-z').split('\0');allTracked=[p for p in allTracked if p];frozen={}
for g,x in inv['groups'].items():
 b=(B/x['manifest']).read_bytes();assert sha(b)==x['manifestSha256'];frozen[g]=[json.loads(l) for l in gzip.decompress(b).decode().splitlines()]
order=['E','K','interaction']+sorted([g for g in frozen if g not in {'root','R11','E','K','interaction','R22'}],key=lambda g:(-inv['groups'][g]['archiveOnlyBytes'],g))+['R22'];assert len(order)==25
save(E/'raw/run-plan.json',{'sourceHead':HEAD,'order':order,'frozenInventorySha256':sha(inventoryData),'toolHashes':toolHashes,'initialFreeBytes':free(),'diskFloorBytes':floor})
expectedDeleted={r['path'] for r in frozen['R11'] if not r['keep']};results=[];stage='setup';current=None

def tools():
 assert git('rev-parse','HEAD')==HEAD
 for p,h in toolHashes.items():assert digest(R/p)[1]==h

def originals(base,retained=None):
 for r in base:
  p=R/r['path'];safe(p)
  if retained is not None and r['path'] not in retained:assert not p.exists() and not p.is_symlink(),p;continue
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode==int(r['mode'],8),(str(p),'type/mode');assert digest(p)==(r['size'],r['sha256']),(str(p),'size/hash')

def retentionExpected(g,base):
 paths={r['path'] for r in base};retain={r['path'] for r in base if r['keep']};reasons={p:['frozen keep'] for p in retain};dirs={d for d in keepData['keepDirectories'] if d.startswith('docs/reviews/'+g+'/')}
 def add(p,reason):retain.add(p);reasons.setdefault(p,[]).append(reason)
 for r in base:
  p=r['path']
  if re.search(r'\.(?:md|png|sha|sha256|sha512)$',p,re.I) or re.search(r'/(?:[^/]*(?:index|manifest)[^/]*)\.jsonl?$',p,re.I) or int(r['mode'],8)&0o111 or p=='docs/reviews/R16/execution/raw/host-xorg-dummy.conf':add(p,'conservative retention rule')
 for source in allTracked:
  if source.startswith('docs/reviews/'):continue
  p=R/source;safe(p);b=p.read_bytes()
  if b'\0' in b:continue
  for m in re.findall(r'docs/reviews/[A-Za-z0-9_./+@%=-]+',b.decode(errors='replace')):
   while m and m not in paths:m=m[:-1]
   if m:add(m,'tracked external literal reference')
 markdown=[R/p for p in ['AGENTS.md','BATTLE_PROTOCOL.md','ENGINEERING_TASK_DECOMPOSITION.md','CONTRIBUTING.md','README.md']]+list((R/'docs').rglob('*.md'))+list((R/'openspec').rglob('*.md'))
 for f in markdown:
  safe(f)
  for link in re.findall(r'\]\(([^)]+)\)',f.read_text()):
   link=link.split('#')[0]
   if not link or re.match(r'^(?:https?:|app:|mailto:|<)',link) or '<' in link:continue
   target=pathlib.Path(os.path.normpath(f.parent/link));assert target.exists(),(f,link)
   if target.is_relative_to(R):
    p=str(target.relative_to(R))
    if p in paths:add(p,'Markdown link target')
    if p.startswith('docs/reviews/'+g+'/') and target.is_dir():dirs.add(p)
 for d in sorted(dirs):
  safe(R/d);assert (R/d).is_dir()
  if not any(p.startswith(d+'/') for p in retain):
   child=next((r['path'] for r in base if r['path'].startswith(d+'/')),None);assert child;add(child,'linked directory descendant')
 return retain,dirs,{p:v for p,v in reasons.items() if p not in {r['path'] for r in base if r['keep']}}

def snapshot(g,label):
 p=R/'docs/reviews/archive-v1/catalog.json';b=p.read_bytes();h=sha(b)
 for dest in [E/'raw/catalog-history'/(h+'.json'),R/'docs/reviews/archive-v1/catalog-history'/(h+'.json')]:
  safe(dest);dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():assert dest.is_file() and dest.read_bytes()==b
  else:
   with dest.open('xb') as f:f.write(b)
  assert digest(dest)[1]==h
 mapping={'group':g,'stage':label,'mutableCatalogPath':str(p),'sha256':h,'bytes':len(b),'ownedSnapshot':str(E/'raw/catalog-history'/(h+'.json')),'canonicalSnapshot':str(R/'docs/reviews/archive-v1/catalog-history'/(h+'.json'))};save(E/'raw'/g/(label+'-catalog-map.json'),mapping);return mapping

def archiveCheck(g,base,restore=False):
 cat=json.loads((R/'docs/reviews/archive-v1/catalog.json').read_text());entry=cat['groups'][g];mp=R/entry['manifest']['path'];assert digest(mp)[1]==entry['manifest']['sha256'];records=[json.loads(l) for l in gzip.decompress(mp.read_bytes()).decode().splitlines()];expected={r['path']:r for r in base};by={r['path']:r for r in records};assert len(records)==len(base) and set(by)==set(expected);seen=set();restored=0;proof=hashlib.sha256();shards=[];scratch=E/'scratch';maxScratch=0
 if restore:scratch.mkdir()
 for sh in entry['shards']:
  p=R/sh['path'];safe(p);n,h=digest(p);assert h==sh['sha256'];count=0;size=0
  with tarfile.open(p,'r:gz') as tf:
   for t in tf:
    assert t.name in expected and t.name not in seen;seen.add(t.name);r=expected[t.name];m=by[t.name];assert t.isfile() and not t.issym() and not t.islnk();assert t.mode==(int(r['mode'],8)&0o7777) and t.size==r['size'];assert m['path']==m['member']==t.name and m['sha256']==r['sha256'] and m['size']==r['size'] and m['mode']==t.mode and m['shard']==sh['path'] and isinstance(m['inline'],bool);count+=1;size+=t.size
    stream=tf.extractfile(t);hasher=hashlib.sha256();length=0;dest=scratch/'restored-original' if restore and not m['inline'] else None
    f=dest.open('xb') if dest else None
    try:
     while b:=stream.read(1024*1024):hasher.update(b);length+=len(b);f.write(b) if f else None
    finally:
     if f:f.close()
    assert length==r['size'] and hasher.hexdigest()==r['sha256'];proof.update((t.name+'\0'+r['sha256']+'\0'+str(t.mode)+'\0'+str(length)+'\n').encode())
    if dest:
     dest.chmod(t.mode);s=dest.lstat();assert stat.S_ISREG(s.st_mode) and (s.st_mode&0o7777)==t.mode and digest(dest)==(r['size'],r['sha256']);maxScratch=max(maxScratch,s.st_size);restored+=1;dest.unlink()
  assert count<=500 and (size<=4*1024*1024 or count==1),(g,'shard bounds',size,count);shards.append({'path':sh['path'],'bytes':n,'sha256':h,'members':count,'originalBytes':size})
 assert seen==set(expected)
 if restore:scratch.rmdir()
 return records,{'members':len(seen),'restored':restored,'maximumScratchFileBytes':maxScratch,'orderedByteModeProofSha256':proof.hexdigest(),'shards':shards,'manifest':{'path':entry['manifest']['path'],'bytes':mp.stat().st_size,'sha256':digest(mp)[1]}}

try:
 for g in order:
  current=g;stage='preflight';raw=E/'raw'/g;raw.mkdir();tools();assert free()>=floor;base=frozen[g];prefix='docs/reviews/'+g+'/';tracked=sorted(p for p in allTracked if p.startswith(prefix));assert tracked==sorted(r['path'] for r in base);assert not git('status','--porcelain','--untracked-files=all','--',prefix);assert not (R/prefix/'.archive-v1').exists();assert not list((R/prefix).glob('.archive-v1-pending-*'));originals(base)
  retain,dirs,extra=retentionExpected(g,base);save(raw/'preflight.json',{'originalFiles':len(base),'originalBytes':sum(r['size'] for r in base),'expectedRetained':len(retain),'extraRetentionReasons':extra,'linkedDirectories':sorted(dirs),'freeBytes':free(),'allOriginalsMatch':True});snapshot(g,'before-pack');assert free()>=floor
  stage='pack';operator=['node','scripts/review-archive-pack.mjs','--root',str(R),'--group',g,'--keep',str(B/'keep.json')];run(g,'pack',operator+['pack']);assert free()>=floor
  stage='verify-before-remove';run(g,'verify-before-remove',['node','scripts/review-archive.mjs','--root',str(R),'verify',g]);records,proof=archiveCheck(g,base);actual={r['path'] for r in records if r['inline']};assert retain==actual,(g,'retention mismatch',sorted(retain^actual));assert {r['path'] for r in base if r['keep']}<=actual;retention=json.loads((R/prefix/'.archive-v1/retention.json').read_text());assert set(retention['keep'])==actual and set(retention['linkedDirectories'])==dirs;originals(base);save(raw/'independent-before-remove.json',proof);snapshot(g,'after-pack');tools()
  stage='remove';run(g,'remove',operator+['remove']);expectedDeleted.update(r['path'] for r in records if not r['inline']);stage='verify-after-remove';run(g,'verify-after-remove',['node','scripts/review-archive.mjs','--root',str(R),'verify',g]);records,proof=archiveCheck(g,base,True);originals(base,actual);assert proof['restored']==len(base)-len(actual)
  for d in dirs:assert (R/d).is_dir() and any(p.startswith(d+'/') for p in actual)
  save(raw/'independent-after-remove.json',proof)
  stage='cli-restore';candidate=next((r for r in records if not r['inline']),records[0]);dest=E/'cli-restored-original';assert not dest.exists();cli=['node','scripts/review-archive.mjs','--root',str(R)];run(g,'resolve',cli+['resolve',candidate['path']]);run(g,'restore',cli+['restore',candidate['path'],str(dest)]);assert digest(dest)==(candidate['size'],candidate['sha256']) and (dest.stat().st_mode&0o7777)==candidate['mode'];run(g,'restore-refuse-overwrite',cli+['restore',candidate['path'],str(dest)],1);assert digest(dest)==(candidate['size'],candidate['sha256']) and (dest.stat().st_mode&0o7777)==candidate['mode'];dest.unlink()
  stage='repository-check';run(g,'repository-check',['node','scripts/check-repository.mjs']);tools();deleted=set(subprocess.check_output(['git','-C',str(R),'diff','--name-only','--diff-filter=D','-z']).decode().strip('\0').split('\0'));deleted.discard('');assert deleted==expectedDeleted,(g,'unexpected deletion');assert not git('diff','--name-only','--diff-filter=ACMRTUXB');assert not git('diff','--cached','--name-only');assert free()>=floor
  groupArchive=sum(p.stat().st_size for p in (R/prefix/'.archive-v1').iterdir());result={'group':g,'state':'PASS','originalFiles':len(base),'originalBytes':sum(r['size'] for r in base),'retainedFiles':len(actual),'retainedBytes':sum(r['size'] for r in base if r['path'] in actual),'removedFiles':len(base)-len(actual),'removedOriginalBytes':sum(r['size'] for r in base if r['path'] not in actual),'archiveShardBytes':sum(s['bytes'] for s in proof['shards']),'allGroupArchiveMetadataBytes':groupArchive,'extraRetentionReasons':extra,'freeBytes':free()};save(raw/'result.json',result);results.append(result);print(json.dumps(result),flush=True)
 save(E/'raw/completed-groups.json',results);print('ALL_GROUPS_COMPLETE',flush=True)
except BaseException as e:
 save(E/'raw/STOP.json',{'group':current,'stage':stage,'exception':repr(e),'traceback':traceback.format_exc(),'completedGroups':results,'freeBytes':free()});print('STOP '+current+' '+stage+' '+repr(e),flush=True);raise
