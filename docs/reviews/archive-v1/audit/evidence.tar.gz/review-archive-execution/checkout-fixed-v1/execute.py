import pathlib,os,json,hashlib,subprocess,datetime
E=pathlib.Path('/workspace/work/review-archive-execution/checkout-fixed-v1');S=pathlib.Path('/workspace/work/review-archive-implementation/source');R=pathlib.Path('/workspace/work/terminal.ui');B=pathlib.Path('/workspace/work/review-archive-migration');OLD=pathlib.Path('/workspace/work/review-archive-execution/checkout-mode-v1');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n')
checks={B/'tests-index.json':'5f513eebf9ee811490f843451d68a043b9e7c6dc9f013df056d5979c0b220af0',B/'operator-tests-index-v2.json':'14aa3eff9ee8cef1cd9e066f91244fd9a182180abb3159b9cdbb42ff75849710',B/'operator-contract-v2.mjs':'77b905bbfba86cf9a34771f4582df7665be61982fcda99a84a84ec68c069a06a',B/'checkout-contract.mjs':'b6fa1ba13dd3e532dd2bd816c97a13f3f2f174343557d75bfcb88aa656cc18ac',B/'checkout-tests-index.json':'5842c51622ec12e0ca4b5be1f49b27e2dcb91eca4388facd50f22b1142ffd396',OLD/'index.json':'6da425988b03fd421f2770d7f71ea0a4a8b9d11861db99906a5e978e20759257'}
cliIndex=json.loads(pathlib.Path('/workspace/work/review-archive-execution/cli-v1/index.json').read_text())
for a in cliIndex['test_artifacts']:checks[pathlib.Path(a['path'])]=a['sha256']
for p,v in checks.items():assert h(p)==v,(p,h(p),v)
oldIndex=json.loads((OLD/'index.json').read_text())
for a in oldIndex['artifacts']:assert h(pathlib.Path(a['path']))==a['sha256']
tools=[S/'scripts/review-archive.mjs',S/'scripts/review-archive-pack.mjs',*sorted((S/'scripts/review-archive').glob('*'))];paths=list(checks)+[p for p in tools if p.is_file()]+[pathlib.Path(a['path']) for a in oldIndex['artifacts']]
def snap():
 return {'sourceHead':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD']).decode().strip(),'sourceStatus':subprocess.check_output(['git','-C',str(S),'status','--porcelain']).decode(),'mainHead':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip(),'hashes':{str(p):h(p) for p in paths},'realFixtureOriginalModes':{str(p):oct(p.stat().st_mode&0o7777) for p in [OLD/'source/docs/reviews/R1/result.md',OLD/'clone/docs/reviews/R1/result.md']},'productionCatalogSha256':h(R/'docs/reviews/archive-v1/catalog.json')}
before=snap();assert before['sourceHead']=='9286956d1547f9a6ab9c42b8cc8cfc78292ceae9';write(E/'raw/before.json',before)
def run(name,argv):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for ext,b in [('stdout',p.stdout),('stderr',p.stderr),('exit',(str(p.returncode)+'\n').encode())]:(E/'raw'/(name+'.'+ext)).write_bytes(b)
 write(E/'raw'/(name+'.command.json'),{'argv':argv,'cwd':str(E),'startedUtc':start,'endedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()});print(json.dumps({'name':name,'exit':p.returncode,'stdoutTail':p.stdout.decode(errors='replace')[-1800:],'stderr':p.stderr.decode(errors='replace')}),flush=True);return p.returncode
cli=str(S/'scripts/review-archive.mjs');op=str(S/'scripts/review-archive-pack.mjs');results={}
for name,args in [('cli51',['node',str(B/'tests/archive-contract.mjs'),cli]),('operator13',['node',str(B/'operator-contract-v2.mjs'),op]),('checkout6',['node',str(B/'checkout-contract.mjs'),cli,op]),('real-r1-source',['node',cli,'--root',str(OLD/'source'),'verify','R1']),('real-r1-clone',['node',cli,'--root',str(OLD/'clone'),'verify','R1'])]:results[name]=run(name,args)
after=snap();assert before==after;write(E/'raw/after.json',{'snapshot':after,'unchanged':True});write(E/'raw/results.json',results)
