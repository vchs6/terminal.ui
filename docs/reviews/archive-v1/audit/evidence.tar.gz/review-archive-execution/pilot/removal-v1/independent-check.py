import pathlib,os,json,gzip,hashlib,stat,tarfile,subprocess
E=pathlib.Path('/workspace/work/review-archive-execution/pilot/removal-v1');R=pathlib.Path('/workspace/work/terminal.ui');B=pathlib.Path('/workspace/work/review-archive-migration');h=lambda b:hashlib.sha256(b).hexdigest();baseData=(B/'groups/R11.jsonl.gz').read_bytes();assert h(baseData)=='ac6d4cc0fa2d0fa9b16e834594d9dc738a7c717498ed8f68fc819bba552378c3';base={r['path']:r for r in [json.loads(l) for l in gzip.decompress(baseData).decode().splitlines()]};catalog=json.loads((R/'docs/reviews/archive-v1/catalog.json').read_text());assert set(catalog['groups'])=={'R11'};g=catalog['groups']['R11'];manifestPath=R/g['manifest']['path'];assert h(manifestPath.read_bytes())==g['manifest']['sha256'];records=[json.loads(l) for l in gzip.decompress(manifestPath.read_bytes()).decode().splitlines()];assert len(records)==515;byPath={r['path']:r for r in records};assert set(byPath)==set(base)
kept=[];absent=[]
for p,r in base.items():
 f=R/p
 if r['keep']:
  s=f.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode==int(r['mode'],8) and s.st_size==r['size'] and h(f.read_bytes())==r['sha256'];kept.append(p)
 else:assert not f.exists() and not f.is_symlink();absent.append(p)
assert len(kept)==71 and len(absent)==444
scratch=E/'scratch';scratch.mkdir();seen=set();restored=[];maxScratch=0
for sh in g['shards']:
 source=R/sh['path'];assert h(source.read_bytes())==sh['sha256']
 with tarfile.open(source,'r:gz') as tf:
  for t in tf:
   assert t.name in base and t.name not in seen;seen.add(t.name);r=base[t.name];m=byPath[t.name];assert t.isfile() and not t.islnk() and not t.issym();assert t.mode==(int(r['mode'],8)&0o7777) and t.size==r['size'];assert m['member']==t.name and m['shard']==sh['path'] and m['sha256']==r['sha256'] and m['size']==r['size'] and m['mode']==t.mode and m['inline']==r['keep'];data=tf.extractfile(t).read();assert h(data)==r['sha256']
   if not r['keep']:
    dest=scratch/'restored-file';assert not dest.exists();dest.write_bytes(data);dest.chmod(t.mode);s=dest.lstat();assert stat.S_ISREG(s.st_mode) and (s.st_mode&0o7777)==t.mode and s.st_size==r['size'] and h(dest.read_bytes())==r['sha256'];maxScratch=max(maxScratch,s.st_size);restored.append({'path':t.name,'mode':t.mode,'size':s.st_size,'sha256':h(dest.read_bytes())});dest.unlink()
assert seen==set(base) and len(restored)==444;scratch.rmdir()
retention=json.loads((R/'docs/reviews/R11/.archive-v1/retention.json').read_text());assert set(retention['keep'])==set(kept)
for d in retention['linkedDirectories']:assert (R/d).is_dir() and any(p.startswith(d+'/') for p in kept)
changes=subprocess.check_output(['git','-C',str(R),'status','--porcelain','-z']).decode().split('\0');changes=[c for c in changes if c];deleted=[c[3:] for c in changes if c[:2]==' D'];assert set(deleted)==set(absent);assert len(changes)==446;assert {c[3:] for c in changes if c[:2]=='??'}=={'docs/reviews/R11/.archive-v1/','docs/reviews/archive-v1/'}
pre=json.loads((E/'raw/preflight.json').read_text())
for p,v in pre['toolHashes'].items():assert h((R/p).read_bytes())==v
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()==pre['sourceHead']
result={'all515ArchivedOriginalsMatch':True,'all71RetainedOriginalsMatch':True,'exactly444OriginalPathsAbsent':True,'restored444VerifiedOneAtATime':True,'maximumScratchFileBytes':maxScratch,'restored':restored,'retainedPaths':kept,'absentPaths':absent,'linkedDirectoriesPreserved':retention['linkedDirectories'],'gitDeletedPathsExactlyCandidates':True,'toolsAndHeadUnchanged':True,'freeBytes':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize};(E/'raw/independent-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['restored','retainedPaths','absentPaths']}))
