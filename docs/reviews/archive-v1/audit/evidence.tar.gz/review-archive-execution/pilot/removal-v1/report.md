# R11 migration pilot: PASS

Executed remove once at main HEAD `36b19d776b45c2aeafd2ad77bb4352103e87f44f` using the reviewed/tested operator. Removal, CLI verification, independent baseline validation/restoration, all-path logical lookup, and unchanged repository checker each exited 0. Actual CLI restore succeeded; the overwrite control exited 1 as expected and left the restored destination unchanged. Exact argv/stdout/stderr/exit records are in raw/.

All 515 original archive members match frozen original SHA256, size and mode. Exactly 444 archive-only original paths are absent; all 71 retained originals remain unchanged (457,705 bytes). Independent Python tar parsing restored each of the 444 removed originals to one owned scratch file at a time and verified SHA/size/mode before deleting that scratch file. Maximum scratch file size: 864,015 bytes. Every original logical path resolves through the CLI's loaded mapping with original metadata, tested with both relative and historical absolute spelling. No scratch files remain.

The unchanged repository/configuration/link/task checker passed. Git contains exactly the intended 444 deletions and two new archive/catalog directories; no stage/commit/push, source/test changes, other group processing, or unrelated cleanup occurred. Tools and HEAD remain unchanged.

Archive shards total 368,164 bytes; archive plus all metadata totals 392,604 bytes. Removed originals total 6,248,810 bytes, yielding **5,856,206 bytes net logical savings** (filesystem allocation and Git object storage are separate). Free bytes after acceptance: **12509184**.

Before mutation, the original global catalog bytes were saved as catalog-snapshot.json with SHA256 `799ecedd17669c4def26cda4a4267adc2673043568db7e65dd886adcdf33a8f6`. catalog-snapshot-mapping.json explicitly maps the prior pilot's indexed global catalog path to these immutable bytes. The historical pilot index was not rewritten; future catalog growth can use this snapshot for historical verification.

R11 pilot acceptance is complete. This evidence covers R11 only; later groups require their own frozen inventory, bounded pack, verification, removal, restoration, retention and repository acceptance gates.
