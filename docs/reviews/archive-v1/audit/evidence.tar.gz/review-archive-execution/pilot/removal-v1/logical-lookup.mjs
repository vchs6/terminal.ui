import fs from 'node:fs';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
import {logical,load,groupData} from '/workspace/work/terminal.ui/scripts/review-archive/core.mjs';
const root='/workspace/work/terminal.ui', catalog=await load(root), data=await groupData(root,catalog,'R11');
const records=zlib.gunzipSync(fs.readFileSync('/workspace/work/review-archive-migration/groups/R11.jsonl.gz')).toString().trim().split('\n').map(JSON.parse);
for(const baseline of records){
 for(const name of [baseline.path,root+'/'+baseline.path]) {
  const p=logical(name,root), r=data.byPath.get(p);assert.ok(r);assert.equal(r.path,baseline.path);assert.equal(r.sha256,baseline.sha256);assert.equal(r.size,baseline.size);assert.equal(r.mode,parseInt(baseline.mode,8)&0o7777);assert.equal(r.inline,baseline.keep);assert.equal(r.member,baseline.path);assert.ok(data.shards.has(r.shard));
 }
}
console.log(JSON.stringify({logicalPaths:records.length,spellingsPerPath:2,lookupBranchesMatchCli:true,allBaselineMetadataMatches:true}));
