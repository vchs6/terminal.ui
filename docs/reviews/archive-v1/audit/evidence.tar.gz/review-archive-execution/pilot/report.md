# R11 pilot execution: blocked before pack

Preflight passed at c7c1bfd842ae431abd5585ca9eaa8e7bb6de3806 with a clean main checkout and reviewed tooling byte-equal to 62b68e350ffa181d0f08f5fea8d1c846ca224e87. All 515 originals (6,706,515 bytes) match frozen mode/size/SHA. Retention remains 71 files (457,705 bytes); 444 files (6,248,810 bytes) are potentially archivable. Current link closure and external references require no additions.

Independent sealed operator suite ran exactly once: exit 1, 13 cases, 6 passed and 7 failed. See raw/operator-contract.stdout for exact failures and raw/operator-contract.command.json for command/timing/hash metadata. stderr is empty. The operator, test, index and source HEAD stayed unchanged before/after.

Observed failure classes from test output and source inspection:

- Three tests fail in fullArchive's inline-retention assertion at line 95: the operator conservatively retains the sole descendant of a linked directory while the test declares it archive-only. This prevents those tests reaching their later archive-corruption/recovery checks.
- Two removal/linked-directory tests fail because that sole linked-directory descendant remains. The clone check is not reached.
- The changed archive-only original case reports two earlier archive-only originals absent after remove rejects the changed later file. The operator checks/unlinks sequentially; the test requires an all-deletion barrier. Archived bytes remain available, but the declared test gate fails.
- The untracked-file case expects successful pack; operator instead safely rejects with `untracked files in group`. The plan requires rejecting untracked-overlapping inputs; interpretation belongs to contract review.

These observations explain the seven failed cases; they are not approval to waive or edit the suite. No tests or product tools were changed or rerun. The suite's own finally blocks cleaned its disposable fixtures; the executor performed no cleanup.

Production R11 was never packed or removed. No archive/catalog was created, all 515 originals were rechecked unchanged after the failed suite, and main Git status remains clean. Actual archive bytes: 0. Readiness: NOT ready for removal; operator acceptance gate unresolved. No commits, staging, config changes, pushes, builds, cache cleanup or other groups were performed.
