# R11 pack-only pilot: PASS, removal held

Packed at main HEAD `36b19d776b45c2aeafd2ad77bb4352103e87f44f`; tool bytes equal independently tested/reviewed final d32f9ec08f36222e2759a44cd905ec079c7c98fc. Tool hashes and HEAD were unchanged after execution. Prior sealed failure evidence hashes remain unchanged.

Pack, CLI verify R11, and independent Python tarfile verification all exited 0 with empty stderr. Exact commands/stdout/stderr/exits are in raw/. Independent parsing checked every one of 515 tar members against frozen original baseline SHA/size/mode, uniqueness/type/path, manifest values, shard SHA, and effective retention. All 515 originals remain present and byte/mode/size-identical (6,706,515 bytes). Retained: 71 files / 457,705 bytes. Candidate removal: 444 files / 6,248,810 bytes. No new retention was needed from current link closure or external references.

Two gzip tar shards total **368,164 bytes**. All archive files including manifest, retention, transaction and catalog total **392,604 bytes**. Free workspace bytes after checks: **13828096** (above 8 MiB floor).

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| docs/reviews/R11/.archive-v1/manifest.jsonl.gz | 19110 | `1c48a3b170a3fbd13c303347dd222c88f5713665bb9ec0ca29cf2f5c8251413c` |
| docs/reviews/R11/.archive-v1/part-000001.tar.gz | 234624 | `cd051c5852e67f1af78f9751561dbf9e4f6204c1e5256b33017650d1ec8cc7f5` |
| docs/reviews/R11/.archive-v1/part-000002.tar.gz | 133540 | `5e2f061c6cf00405cdee7f6e83b36778de05588ec055d9f4456aaf495dd1a9cc` |
| docs/reviews/R11/.archive-v1/retention.json | 4126 | `fdc573ac64adc549d63f6abd6f13f81955030d7f82c487a99ea254dfadd6bc21` |
| docs/reviews/R11/.archive-v1/transaction.json | 522 | `f3979556736dbd4d37d0760c358f5e49b0e14db2d74594b3327739577b121955` |
| docs/reviews/archive-v1/catalog.json | 682 | `799ecedd17669c4def26cda4a4267adc2673043568db7e65dd886adcdf33a8f6` |

State: ready for root inspection before authorizing removal. No originals were removed. Git reports only the new R11 archive directory and archive catalog directory. No staging, commit, push, source/test edit, build, cleanup or other-group packing was performed. Repository checker/removal/restore acceptance belong to the subsequent authorized removal stage.
