import pathlib, os, stat, subprocess, hashlib, json, gzip, re, sys, tarfile
R=pathlib.Path('/workspace/work/terminal.ui'); E=pathlib.Path('/workspace/work/review-archive-execution/pilot/attempt-v2'); B=pathlib.Path('/workspace/work/review-archive-migration')
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*a): return subprocess.check_output(['git','-C',str(R),*a]).decode().strip()
def safe(p):
 p=pathlib.Path(p); assert p.is_absolute()
 for q in [*reversed(p.parents),p]:
  if q.exists() or q.is_symlink(): assert not q.is_symlink(),str(q)
def save(n,x): (E/'raw'/n).write_text(json.dumps(x,indent=2)+'\n')
base=[json.loads(s) for s in gzip.decompress((B/'groups/R11.jsonl.gz').read_bytes()).decode().splitlines()]; expected={r['path']:r for r in base}
assert sha((B/'inventory.json').read_bytes())=='cc02fcda5a28d18746bdc2694ed9f102aea01889bbc56fddf4c057a931a8cfc5'
assert sha((B/'keep.json').read_bytes())=='4f37b13e7d92265e7562b8276b8fd7a7986b64b44cf2aa679ab910cbbac33fc6'
assert sha((B/'groups/R11.jsonl.gz').read_bytes())=='ac6d4cc0fa2d0fa9b16e834594d9dc738a7c717498ed8f68fc819bba552378c3'
assert git('rev-parse','--show-toplevel')==str(R)
assert git('rev-parse','HEAD')=='36b19d776b45c2aeafd2ad77bb4352103e87f44f'
tracked=git('ls-files','-z').split('\0'); tracked=[p for p in tracked if p]; files=sorted(p for p in tracked if p.startswith('docs/reviews/R11/'))
assert files==sorted(expected)
for p,r in expected.items():
 f=R/p; safe(f); s=f.lstat(); assert stat.S_ISREG(s.st_mode); assert s.st_mode==int(r['mode'],8),(p,oct(s.st_mode),r['mode']); assert s.st_size==r['size']; assert sha(f.read_bytes())==r['sha256'],p
originals={'count':len(base),'bytes':sum(r['size'] for r in base),'frozenRetained':sum(r['keep'] for r in base),'frozenRetainedBytes':sum(r['size'] for r in base if r['keep']),'allMatch':True}
if sys.argv[1]=='pre':
 assert not git('status','--porcelain'); safe(E); safe(B)
 for p in [R/'docs/reviews/archive-v1',R/'docs/reviews/R11/.archive-v1']:
  safe(p); assert not p.exists()
 assert not list((R/'docs/reviews/R11').glob('.archive-v1-pending-*'))
 for p in (R/'docs/reviews/R11').rglob('*'):
  safe(p); assert p.is_dir() or p.is_file()
 tools={}
 for p in ['scripts/review-archive.mjs','scripts/review-archive-pack.mjs',*sorted(str(p.relative_to(R)) for p in (R/'scripts/review-archive').glob('*') if p.is_file())]:
  data=(R/p).read_bytes(); assert data==subprocess.check_output(['git','-C',str(R),'show','d32f9ec08f36222e2759a44cd905ec079c7c98fc:'+p]); tools[p]=sha(data)
 keep=set(json.loads((B/'keep.json').read_text())['keep']); refs=set(); links=set(); dirs=set(); missing=[]
 for p in tracked:
  if p.startswith('docs/reviews/'):continue
  b=(R/p).read_bytes()
  if b'\0' in b:continue
  for m in re.findall(r'docs/reviews/[A-Za-z0-9_./+@%=-]+',b.decode(errors='replace')):
   while m and m not in expected:m=m[:-1]
   if m:refs.add(m)
 markdown=[R/p for p in ['AGENTS.md','BATTLE_PROTOCOL.md','ENGINEERING_TASK_DECOMPOSITION.md','CONTRIBUTING.md','README.md']]+list((R/'docs').rglob('*.md'))+list((R/'openspec').rglob('*.md'))
 for f in markdown:
  safe(f)
  for m in re.findall(r'\]\(([^)]+)\)',f.read_text()):
   t=m.split('#')[0]
   if not t or re.match(r'^(?:https?:|app:|mailto:|<)',t) or '<' in t:continue
   target=pathlib.Path(os.path.normpath(f.parent/t))
   if not target.exists():missing.append([str(f),t]);continue
   if target.is_relative_to(R):
    p=str(target.relative_to(R))
    if p in expected:links.add(p)
    if p.startswith('docs/reviews/R11/') and target.is_dir():dirs.add(p)
 assert not missing,missing
 active=refs|links
 assert not active-keep,sorted(active-keep)
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize; assert free>=8*1024*1024
 save('preflight.json',{'sourceHead':git('rev-parse','HEAD'),'toolHashes':tools,'originals':originals,'r11BaselineGzipSha256':sha((B/'groups/R11.jsonl.gz').read_bytes()),'freeBytes':free,'externalReferences':sorted(refs),'linkedFiles':sorted(links),'linkedDirectories':sorted(dirs),'newRetentionRequired':[],'unsafePaths':[],'archiveExists':False})
 print(json.dumps({'preflight':'PASS','originals':originals,'freeBytes':free}))
else:
 cat=json.loads((R/'docs/reviews/archive-v1/catalog.json').read_text()); assert set(cat['groups'])=={'R11'}; entry=cat['groups']['R11']; manifest=[json.loads(l) for l in gzip.decompress((R/entry['manifest']['path']).read_bytes()).decode().splitlines()]; assert len(manifest)==len(base); seen=set(); results=[]
 for shard in entry['shards']:
  p=R/shard['path']; assert sha(p.read_bytes())==shard['sha256']; members=[]
  with tarfile.open(p,'r:gz') as tar:
   for t in tar:
    assert t.name in expected and t.name not in seen,t.name; seen.add(t.name); assert t.isfile() and not t.issym() and not t.islnk(); r=expected[t.name]; assert t.mode==(int(r['mode'],8)&0o7777); assert t.size==r['size']; data=tar.extractfile(t).read(); assert sha(data)==r['sha256']; members.append({'path':t.name,'mode':t.mode,'size':t.size,'sha256':sha(data)})
  results.append({'path':shard['path'],'size':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':members})
 assert seen==set(expected)
 for m in manifest:
  r=expected[m['path']]; assert m['member']==r['path']; assert m['mode']==(int(r['mode'],8)&0o7777); assert m['size']==r['size']; assert m['sha256']==r['sha256']; assert m['inline']==r['keep']; assert m['shard'] in {s['path'] for s in entry['shards']}
 retention=json.loads((R/'docs/reviews/R11/.archive-v1/retention.json').read_text()); assert set(retention['keep'])=={r['path'] for r in base if r['keep']}
 for d in retention['linkedDirectories']: assert any(p.startswith(d+'/') for p in retention['keep'])
 status=git('status','--porcelain'); assert all(l.startswith('?? ') for l in status.splitlines()),status
 total=sum(p.stat().st_size for p in (R/'docs/reviews/R11/.archive-v1').iterdir())+(R/'docs/reviews/archive-v1/catalog.json').stat().st_size
 save('independent-after-pack.json',{'originals':originals,'archiveMembers':len(seen),'retained':len(retention['keep']),'archivable':len(base)-len(retention['keep']),'retention':retention,'shards':results,'archiveBytes':sum(s['size'] for s in results),'allArchiveMetadataBytes':total,'freeBytes':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,'gitStatus':status,'sourceHead':git('rev-parse','HEAD')})
 print(json.dumps({'independentCheck':'PASS','originals':originals,'archiveMembers':len(seen),'archiveBytes':sum(s['size'] for s in results),'allArchiveMetadataBytes':total}))
