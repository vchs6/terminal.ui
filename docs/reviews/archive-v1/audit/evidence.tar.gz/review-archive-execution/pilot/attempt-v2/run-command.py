import subprocess,pathlib,json,sys,datetime,hashlib
E=pathlib.Path('/workspace/work/review-archive-execution/pilot/attempt-v2/raw'); R=pathlib.Path('/workspace/work/terminal.ui')
name=sys.argv[1]; command=sys.argv[2:]; assert name and command
assert not (E/(name+'.command.json')).exists(), 'refusing to overwrite evidence'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(command,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(E/(name+'.stdout')).write_bytes(p.stdout); (E/(name+'.stderr')).write_bytes(p.stderr); (E/(name+'.exit')).write_text(str(p.returncode)+'\n')
(E/(name+'.command.json')).write_text(json.dumps({'argv':command,'cwd':str(R),'startedUtc':started,'endedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
print(json.dumps({'name':name,'exit':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}));sys.exit(p.returncode)
