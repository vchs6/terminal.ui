# Real R1 checkout portability: FAIL

The exact production R1 retained original and archive files were copied byte-for-byte with existing 0600 modes to a disposable source Git repository, committed there, and cloned using `git clone --no-hardlinks` under explicit umask 022. The fixture catalog is a version-preserving subset of the production catalog containing only R1. Its source catalog and derived subset SHA256 are recorded in raw/input-state.json. Source/clone fixtures remain preserved; no production archive, catalog, mode or source was changed.

The unchanged CLI verifies the source fixture successfully (exit 0). The same CLI verifies the fresh clone with exit 1 and exact stderr:

```
review-archive: inline type/mode mismatch: docs/reviews/R1/result.md
```

`docs/reviews/R1/result.md` is 1,370 bytes, source mode 0600, fresh-clone mode 0644. Both copies have SHA256 `bb1652b8831730e732b1c1587e99b8c89027a38f35b61881509ef84b2c3c61f9`. Git records 100644 and preserves its non-executable flag. Every copied archive/manifest/retention/transaction file also remains byte-identical; filesystem modes likewise normalize 0600→0644. R1 has no executable original, so this bounded probe does not separately exercise 0700→0755.

The manifest's original mode remains decimal 384 (0600), while the verifier requires retained inline mode equality. Therefore normal fresh checkout permissions prevent verification despite preserved original bytes and Git executable semantics. No verifier fix, mode changes or manifest weakening was attempted. Tools, production catalog and sealed full-migration index hashes remain unchanged. Exact commands, exits, stdout and stderr, Git index modes and source/tool hashes are in raw/.

This is a newly evidenced portability failure beyond the original in-place migration acceptance; the earlier sealed migration evidence was left unchanged. Adoption requires root routing and resolution.
