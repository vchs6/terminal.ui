# Navigation redirect

This small page resolves a relative link in a byte-preserved original. It is navigation, not a copied historical receipt or a claim about its then-current status.

Continue to [the existing repository document](../../../../../../../../../../openspec/changes/implement-linux-vt-glyph-fallback/tasks.md).
