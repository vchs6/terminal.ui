package cjtui
public class Component {
    public func onMount(effect: (NodeRef) -> (() -> Unit)): Component { throw Exception("DECLARATION ONLY") }
}
public func Text(value: String): Component { throw Exception("DECLARATION ONLY") }
