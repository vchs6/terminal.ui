V3 exact-directory compiler scratch cleanup complete.
Removed 3 files; allocated reclaimed 14110720 bytes.
Free before 99176448 bytes; after 113254400 bytes; net gain 14077952 bytes.
64 MiB goal met: False; 32 MiB minimum met: False.
Only direct UID1000 regular generated ET_REL .o / LLVM .bc candidates permitted; cap 3 respected; only exact V3 directory exception.
Selected SHA256, header, stat and ownership recorded before unlink.
Fresh exact path/digest pin checks, no compiler, FD/maps/inode checks repeated immediately before unlink.
Source/main/config/CJP/current sealed indices/critical ELF metadata unchanged; original no-op and round2 index/report preserved.
No other files or directories removed; CPU resume requires root verification.
Cumulative V2+V3 reclaim: 15192064 bytes; remaining 32 MiB minimum shortfall: 18362368 bytes.
