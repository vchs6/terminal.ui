import fs from 'node:fs';
import crypto from 'node:crypto';
const base='/workspace/work/r7-independent-test';
const p=base+'/results.json';
const data=JSON.parse(fs.readFileSync(p,'utf8'));
data.fixedHandoffHashes={};
for(const f of ['run-native.sh','run-transitive.sh','generate-conformance.mjs','templates/consumer-main.cj','templates/consumer-middle.cj','templates/middle-lib.cj']) {
 data.fixedHandoffHashes[f]=crypto.createHash('sha256').update(fs.readFileSync(base+'/repo/docs/reviews/R7/evidence/native/'+f)).digest('hex');
}
data.reusableScope={runNative:'Full successful run-native stage for identical script/generator/templates/input bytes/SDK/environment. Includes shipped generator, seven tables, native archive, explicit consumer link, dependency-owned FFI link, 766 grapheme vectors and separate empty observation.',runTransitive:'Intermediate static-adapter stage succeeded with dependency-owned FFI. Adapter-owned FFI fresh link is not established; only affected path needs rerun after fixed handoff.'};
fs.writeFileSync(p,JSON.stringify(data,null,2)+'\n');
fs.appendFileSync(base+'/report.md','\n## Handoff input hashes and reuse scope\n\n'+Object.entries(data.fixedHandoffHashes).map(([f,h])=>'- `'+f+'`: `'+h+'`').join('\n')+'\n\n'+data.reusableScope.runNative+' '+data.reusableScope.runTransitive+'\n');
