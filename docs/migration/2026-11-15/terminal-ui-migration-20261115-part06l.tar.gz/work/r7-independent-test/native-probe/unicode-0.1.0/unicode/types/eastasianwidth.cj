package unicode.types

/** Unicode 标准定义了 6 种 East Asian Width 属性：
 * 
 *   W (Wide)         - 双字节宽度，主要用于东亚文本
 *   F (Full-width)   - 全角宽度，与 Wide 几乎相同
 *   A (Ambiguous)    - 不定宽度，取决于上下文和字体，其显示宽度通常在中文环境中为2，其它为1
 *   H (Half-width)   - 半角宽度
 *   Na (Narrow)      - 窄形式
 *   N (Neutral)      - 中性（默认），通常为单字节宽度
 */
public enum EastAsianWidth <: Codable<EastAsianWidth> & Equatable<EastAsianWidth> {
    | F
    | H
    | W
    | NA
    | A
    | N

    public static func getCategoryName(): String {
        "east_asian_width"
    }

    public static func getDefault(): EastAsianWidth {
        EastAsianWidth.N
    }

    public static func bitSize(): UInt8 {
        3
    }

    public operator func ==(rhs: EastAsianWidth): Bool {
        encode() == rhs.encode()
    }

    public func encode(): UInt16 {
        return match(this) {
            case N  => 0
            case F  => 1
            case H  => 2
            case W  => 3
            case NA => 4
            case A  => 5
        }        
    }

    public static func decode(value: UInt16): Option<EastAsianWidth> {
        return match(value) {
            case 0  => EastAsianWidth.N
            case 1  => EastAsianWidth.F 
            case 2  => EastAsianWidth.H
            case 3  => EastAsianWidth.W
            case 4  => EastAsianWidth.NA
            case 5  => EastAsianWidth.A
            case _  => None
        }
    }
}