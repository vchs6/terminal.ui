package editing_contract

import cjtui.*

// Catches no-selection copy consuming CtrlC, cut fallback to business delete, and synthetic paste.
func clipboardDefaults(): Unit {
    let c = TextEditController();
    var issues = 0;
    var changes = 0
    let root = TextInput(Observable<String>("abc"), controller: Some(c), onIssue: {_ => issues++},
        onChange: {_ => changes++})
    let app = Application(root);
    app.startHeadless()
    try {
        for (keyValue in [KeyEvent("insert", ctrl: true), KeyEvent("x", ctrl: true), KeyEvent("delete", shift: true)]) {
            app.dispatch(ref(root), keyValue)
        }
        check(issues == 0 && changes == 0, "empty-selection copy/cut no output issue/history")
        state(c, "abc", 0, 0, false, false, "empty shortcut no op")
        ui(app, {=> c.select(TextSelection(0, 2))})
        key(app, root, "interrupt", ctrl: true)
        check(c.isValid() && issues == 1 && changes == 0, "selected CtrlC copies without exit")
        key(app, root, "insert", ctrl: true)
        key(app, root, "x", ctrl: true)
        key(app, root, "delete", shift: true)
        check(issues == 4 && changes == 0, "unsupported shortcut once each")
        state(c, "abc", 0, 2, false, false, "unconfirmed shortcut cuts retain selection")
        let saved = c.snapshot()
        check(
            app.post(
                {
                    =>
                        c.select(TextSelection(2, 2));
                        c.select(TextSelection(0, 2))
                        check(!c.replaceSelection("", ifUnchanged: Some(saved)),
                            "posted move-away-back cancels delayed guard")
                }
            ),
            "delayed application consumption queued"
        )
        app.snapshot(4, 1)
        check(issues == 4 && changes == 0, "guard mismatch no implicit issue or change")
        let textGuard = c.snapshot()
        check(
            app.post(
                {
                    =>
                        c.replaceSelection("Z")
                        let after = c.snapshot()
                        check(!c.replaceSelection("BAD", ifUnchanged: Some(textGuard)),
                            "posted changed text cancels guard")
                        check(c.snapshot().text == "Zc" && c.snapshot().revision == after.revision,
                            "failed posted guard itself leaves local history intact")
                }
            ),
            "changed text result queued"
        )
        app.snapshot(4, 1)
        check(changes == 1 && issues == 4, "one posted real edit")
        ui(app, {=> c.select(TextSelection(0, 0))})
        key(app, root, "interrupt", ctrl: true)
        check(!c.isValid(), "unselected CtrlC follows framework interrupt exit")
    } finally {
        app.dispose()
    }
}
