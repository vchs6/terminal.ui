# TASK004 C004-DOC-001 round 1 factual fix handoff
Commit `114a730039812c1bbc8ceb2dd7d16f95755b2587`; parent `5c1d086e368e4954fc6a01fda046d7bc7cfc4f39`; only architecture.md and construction-map.json changed, two lines replaced.
Corrected AlreadyMounted to reject concurrently mounted or reserved instances; completed-unmount remount has fresh identity and never revives old refs.
Checked cited component.cj263–276, runtime_session.cj524–569/1309 and fixed tests/runtime/src/lifetime.cj38–50; existing ui-construction.md remains unchanged.
Command: python3 /workspace/work/linux-final-construction/verify_projection.py -> exit 0, PASS_DOCUMENT_PROJECTION_CHECKS.
Output:74 source bindings,128 declarations,19 scenario calls,12 unchanged reuse scopes,17 evidence bindings,35 Markdown links; functional_execution=false, final_AC004=pending.
Commands: git diff --check and git diff --cached --check -> exit0/no output; git status --short -> no output after commit.
git diff-tree --no-commit-id --name-only -r HEAD -> exactly docs/architecture.md and docs/reviews/Linux-final/construction-map.json.
Original report.md/index.json preserved; original report and verification hashes still match original index.
No source/tests/other docs/API/pending-scope changes, compiler/runtime/test/Node/GUI/probe execution, subagent, shared-config edits, main push or publication.
Root scoped re-review of C004-DOC-001 remains next; final consumer bindings/original AC004 acceptance remain pending.
