package cjtui
// Declaration-only compile isolation. Never run. Never part of a test delivery.
class GlyphRenderPolicy {
    static func unicode(): GlyphRenderPolicy { throw Exception("declaration-only") }
    static func ascii(): GlyphRenderPolicy { throw Exception("declaration-only") }
    static func mapped(bitmap: Array<UInt8>): GlyphRenderPolicy { throw Exception("declaration-only") }
}
func projectTerminalGlyph(grapheme: String, width: Int64, policy: GlyphRenderPolicy): String {
    throw Exception("declaration-only")
}
func generatedEllipsis(policy: GlyphRenderPolicy, availableColumns: Int64, ambiguousWide!: Bool = false): String {
    throw Exception("declaration-only")
}
