// DECLARATION ONLY; NOT PRODUCT; NOT EXECUTED
package cjtui
public class UIKeyEvent {
public let key:KeyEvent=KeyEvent("")
public let target:NodeRef=NodeRef()
public let currentTarget:NodeRef=NodeRef()
public func preventDefault(): Unit { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func stopPropagation(): Unit { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func consume(): Unit { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }

}
