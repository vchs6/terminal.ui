// DECLARATION ONLY; NOT PRODUCT; NOT EXECUTED
package cjtui
public class Component {
public func reference(): ?NodeRef { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func focusable(v:Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func focusable(v:()->Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func enabled(v:Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func enabled(v:()->Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func visible(v:Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func visible(v:()->Bool): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func width(v:Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func width(v:()->Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func height(v:Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func height(v:()->Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func minWidth(v:Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func minWidth(v:()->Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func minHeight(v:Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func minHeight(v:()->Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func gap(v:Int64): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func alignItems(v:Alignment): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func justifyContent(v:Alignment): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func textAlign(v:Alignment): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func foreground(v:Color): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func wrap(v:TextWrap): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func overflow(v:TextOverflow): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func styles(v:Array<StyleUse>): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func visualStates(v:VisualStates): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func setStyle<T>(key:StyleKey<T>,value:StyleValue<T>,state!:VisualState=VisualState.Normal): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func onKey(f:(UIKeyEvent)->Unit): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func onKeyCapture(f:(UIKeyEvent)->Unit): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func onMount(f:(NodeRef)->(()->Unit)): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }
public func defaultAction(f:(UIKeyEvent)->Unit,phase!:DefaultActionPhase=DefaultActionPhase.Target): Component { throw Exception("DECLARATION ONLY: NEVER EXECUTE") }

public func padding(v:Int64):Component {throw Exception("DECLARATION ONLY: NEVER EXECUTE")}
}
