package ansies.core

public interface AnsiParameterProvider {
    func parameters(): Array<String>
}

//cjlint-ignore -start !G.ITF.02 description
extend AnsiColorSpec <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        let code: Array<Byte> = match (this.color) {
            case Black          => [30]
            case Red            => [31]
            case Green          => [32]
            case Yellow         => [33]
            case Blue           => [34]
            case Magenta        => [35]
            case Cyan           => [36]
            case White          => [37]
            case BrightBlack    => [90]
            case BrightRed      => [91]
            case BrightGreen    => [92]
            case BrightYellow   => [93]
            case BrightBlue     => [94]
            case BrightMagenta  => [95]
            case BrightCyan     => [96]
            case BrightWhite    => [97]
            case Default        => [39]
            case IndexedColor(idx)   => [38, 5, idx]
            case TrueColor(r, g, b)  => [38, 2, r, g, b]
        }
        if (this.isBackground()) {
            code[0] += 10
        } 
        code.map({x => x.toString()})
    }
}

extend AnsiStyleSpec <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this.style) {
            case ITALIC           => if (this.isSet()) {  ["3"] } else { ["23"] }
            case BOLD             => if (this.isSet()) {  ["1"] } else { ["21"] }
            case DIM              => if (this.isSet()) {  ["2"] } else { ["22"] }
            case UNDERLINE        => if (this.isSet()) {  ["4"] } else { ["24"] }
            case BLINK            => if (this.isSet()) {  ["5"] } else { ["25"] }
            case REVERSE          => if (this.isSet()) {  ["7"] } else { ["27"] }
            case CONCEAL          => if (this.isSet()) {  ["8"] } else { ["28"] }
            case STRIKETHROUGH    => if (this.isSet()) {  ["9"] } else { ["29"] }
            case DELETEDLINE      => if (this.isSet()) {  ["9"] } else { ["29"] }
            case DOUBLEUNDERLINE  => if (this.isSet()) { ["21"] } else { ["24"] }
            case FRAMED           => if (this.isSet()) { ["51"] } else { ["54"] }
            case ENCIRCLED        => if (this.isSet()) { ["52"] } else { ["54"] }
            case OVERLINE         => if (this.isSet()) { ["53"] } else { ["55"] }
            case SUPERSCRIPT      => if (this.isSet()) { ["73"] } else { ["75"] }
            case SUBSCRIPT        => if (this.isSet()) { ["74"] } else { ["75"] }
        }        
    }
}

extend AnsiLineStyle <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case None       => ["0"]
            case Single     => ["1"]
            case Double     => ["2"]
            case Curly      => ["3"]
            case Dotted     => ["4"]
            case Dashed     => ["5"]
        }
    }
}

extend AnsiCleanModel <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case TOEND   => ["0"]
            case TOBEGIN => ["1"]
            case ENTIRE  => ["2"]
            case ALL     => ["3"]            
        }
    }
}

extend AnsiCursorDirection <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case Up       => ["A"]
            case Down     => ["B"]
            case Forward  => ["C"]
            case Backward => ["D"]
        }        
    }
}

extend AnsiDeviceStatusRequest <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case OperatingStatus => ["5"]
            case CursorPosition  => ["6"]
            case PrinterStatus   => ["15"]
            case UdkStatus       => ["25"]
            case KeyboardStatus  => ["26"]
            case LocatorStatus   => ["53"]
        }
    }
}

extend AnsiDecPrivateMode <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case ApplicationCursorKeys     => ["1"]
            case Column132                 => ["3"]
            case OriginMode                => ["6"]
            case AutoWrap                  => ["7"]
            case CursorBlink               => ["12"]
            case CursorVisible             => ["25"]
            case AlternateScreenSimple     => ["47"]
            case MouseTrackingX11          => ["1000"]
            case MouseTrackingButtonEvent  => ["1002"]
            case MouseTrackingAnyEvent     => ["1003"]
            case MouseSgrExtMode           => ["1006"]
            case AlternateScreenSaveCursor => ["1049"]
            case BracketedPaste            => ["2004"]
        }
    }
}

extend AnsiMode <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case KeyboardAction  => ["2"]
            case InsertReplace   => ["4"]
            case SendReceive     => ["12"]
            case LineFeedNewLine => ["20"]
        }
    }
}

extend AnsiTabClearMode <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case CurrentColumn => ["0"]
            case All           => ["3"]
        }
    }
}

extend AnsiCursorStyle <: AnsiParameterProvider {
    public func parameters(): Array<String> {
        match(this) {
            case BlinkingBlockDefault => ["0"]
            case BlinkingBlock        => ["1"]
            case SteadyBlock          => ["2"]
            case BlinkingUnderline    => ["3"]
            case SteadyUnderline      => ["4"]
            case BlinkingBar          => ["5"]
            case SteadyBar            => ["6"]
        }
    }
}

//cjlint-ignore -end description