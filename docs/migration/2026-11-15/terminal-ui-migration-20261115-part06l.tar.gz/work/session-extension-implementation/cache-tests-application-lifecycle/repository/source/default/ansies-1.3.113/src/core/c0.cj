package ansies.core

/**@file c0.cj
 * @brief C0 控制字符常量定义（NUL … US / ESC）
 * @package ansies.core
 */

///＜ C0控制序列，7b环境
public const NUL: Rune = '\u{00}'  ///< Null
public const SOH: Rune = '\u{01}'  ///< Start of Heading
public const STX: Rune = '\u{02}'  ///< Start of Text
public const ETX: Rune = '\u{03}'  ///< End of Text
public const EOT: Rune = '\u{04}'  ///< End of Transmission
public const ENQ: Rune = '\u{05}'  ///< Enquiry
public const ACK: Rune = '\u{06}'  ///< Acknowledge
public const BEL: Rune = '\u{07}'  ///< Bell
public const BS : Rune = '\u{08}'  ///< Backspace
public const HT : Rune = '\u{09}'  ///< Horizontal Tab
public const LF : Rune = '\u{0A}'  ///< Line Feed
public const VT : Rune = '\u{0B}'  ///< Vertical Tab
public const FF : Rune = '\u{0C}'  ///< Form Feed
public const CR : Rune = '\u{0D}'  ///< Carriage Return
public const SO : Rune = '\u{0E}'  ///< Shift Out
public const SI : Rune = '\u{0F}'  ///< Shift In
public const DLE: Rune = '\u{10}'  ///< Data Link Escape
public const DC1: Rune = '\u{11}'  ///< Device Control 1 (XON)
public const DC2: Rune = '\u{12}'  ///< Device Control 2
public const DC3: Rune = '\u{13}'  ///< Device Control 3 (XOFF)
public const DC4: Rune = '\u{14}'  ///< Device Control 4
public const NAK: Rune = '\u{15}'  ///< Negative Acknowledge
public const SYN: Rune = '\u{16}'  ///< Synchronous Idle
public const ETB: Rune = '\u{17}'  ///< End of Trans. Block
public const CAN: Rune = '\u{18}'  ///< Cancel
public const EM : Rune = '\u{19}'  ///< End of Medium
public const SUB: Rune = '\u{1A}'  ///< Substitute
public const ESC: Rune = '\u{1B}'  ///< Escape
//应用程序需定义IS4..IS1的具体含义
public const IS4: Rune = '\u{1C}'  ///< Information Separator Four(FS - File Separator)
public const IS3: Rune = '\u{1D}'  ///< Information Separator Four(GS - Group Separator)
public const IS2: Rune = '\u{1E}'  ///< Information Separator Four(RS - Record Separator)
public const IS1: Rune = '\u{1F}'  ///< Information Separator Four(US - Unit Separator)

///< 与IS4..IS1相同，额外支持
public const FS : Rune = '\u{1C}'  ///< File Separator
public const GS : Rune = '\u{1D}'  ///< Group Separator
public const RS : Rune = '\u{1E}'  ///< Record Separator
public const US : Rune = '\u{1F}'  ///< Unit Separator

///< 仅在8b环境中使用，替代7b环境中的SO和SI
public const LS1: Rune = '\u{0E}'  ///< Locking-shift one
public const LS0: Rune = '\u{0F}'  ///< Locking-shift zero
