package ansies.core

public enum AnsiCursorDirection {
    | Up
    | Down
    | Forward
    | Backward
}