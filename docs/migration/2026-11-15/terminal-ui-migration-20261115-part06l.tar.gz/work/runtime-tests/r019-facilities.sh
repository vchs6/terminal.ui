#!/usr/bin/env bash
set -euo pipefail
node --check tests/support/terminal_frames.mjs
node --check tests/resize-coherence/pty.mjs
node --check tests/application-lifecycle/pty.mjs
node --check tests/integration/pty.mjs
bash -n tests/resize-coherence/run.sh tests/integration/fixture/build.sh tests/run-slice.sh
gcc -std=c11 -Wall -Wextra -Werror -fsyntax-only tests/resize-coherence/native/gates.c tests/resize-coherence/native/close_wrap.c tests/support/terminal_size.c tests/integration/fixture/native/close_wrap.c
git diff --check
