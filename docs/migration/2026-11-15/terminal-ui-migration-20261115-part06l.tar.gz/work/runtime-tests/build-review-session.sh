#!/usr/bin/env bash
set -euo pipefail
gcc -std=c11 -Wall -Wextra -Werror -fPIC -O2 -c tests/runtime/session/native/close_wrap.c -o tests/runtime/session/native/close_wrap.o
ar rcs tests/runtime/session/native/libruntime_close.a tests/runtime/session/native/close_wrap.o
cd tests/runtime/session
cjpm build
