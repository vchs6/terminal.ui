package runtime_contract
import cjtui.{Frame, Style, Color, Alignment, BorderStyle, ColorMode}
class UIKeyEvent {
 let key = KeyEvent("text")
 let target = NodeRef()
 let currentTarget = NodeRef()
 let defaultPrevented = false
 func preventDefault(): Unit {}
 func stopPropagation(): Unit {}
 func consume(): Unit {}
}
