package runtime_contract
// Declaration-only syntax surface: never executed and not a product implementation.
class UICleanupException <: Exception {
    public let primary: Exception
    private let values: Array<Exception>
    public init(primary: Exception, cleanupFailures: Array<Exception>) {
        super("syntax only")
        this.primary = primary
        values = cleanupFailures
    }
    public prop cleanupFailures: Array<Exception> { get() { values } }
}
