package runtime_session
import cjtui.{Frame, Style, Color, Alignment, BorderStyle, ColorMode}
class RuntimeStats {
 let mountedNodes: Int64 = 0
 let activeBindings: Int64 = 0
 let subscriptions: Int64 = 0
 let pendingPosts: Int64 = 0
 let builds: Int64 = 0
 let measures: Int64 = 0
 let paints: Int64 = 0
 let frames: Int64 = 0
}