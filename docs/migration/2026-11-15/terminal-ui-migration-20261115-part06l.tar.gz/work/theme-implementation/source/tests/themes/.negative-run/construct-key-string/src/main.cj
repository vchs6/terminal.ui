package theme_negative
import cjtui.*
main(): Int64 {
    let _ = StyleKey<Color>("foreground")
    0
}
