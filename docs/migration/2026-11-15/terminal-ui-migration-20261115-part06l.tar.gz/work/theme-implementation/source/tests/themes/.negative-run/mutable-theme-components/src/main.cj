package theme_negative
import cjtui.*
main(): Int64 {
    let value = Theme.preset(ThemePreset.Classic)
    value.components[ThemeRole.Text] = StyleRule()
    0
}
