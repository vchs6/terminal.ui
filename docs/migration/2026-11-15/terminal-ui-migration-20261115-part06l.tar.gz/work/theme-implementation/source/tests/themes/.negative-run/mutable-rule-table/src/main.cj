package theme_negative
import cjtui.*
main(): Int64 {
    let rule = StyleRule()
    rule.values["foreground"] = Color.Red
    0
}
