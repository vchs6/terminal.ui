package cjtui.session
public enum SessionOperation { CopyLocalText | SetHostTitle | SaveHostTitle | RestoreHostTitle | SetHostImageIcon }
