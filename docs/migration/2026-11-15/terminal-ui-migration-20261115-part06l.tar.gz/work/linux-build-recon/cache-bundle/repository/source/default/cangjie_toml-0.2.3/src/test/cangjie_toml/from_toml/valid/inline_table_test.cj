package cangjie_toml.test.cangjie_toml.from_toml.valid

import std.unittest.testmacro.*

@Test
class InlineTableTest {
    @TestCase
    func arrayValues() {
        @Assert(testToml("""
                # "No newlines are allowed between the curly braces unless they are valid within
                # a value"

                a = { a = [
                ]}

                b = { a = [
                        1,
                        2,
                    ], b = [
                        3,
                        4,
                    ]}
            """, """
                {
                    "a": {"a": []},
                    "b": {
                        "a": [ 1, 2 ],
                        "b": [ 3, 4 ]
                    }
                }
        """))
    }

    @TestCase
    func array() {
        @Assert(testToml("""
                arr = [ {'a'= 1}, {'a'= 2} ]

                people = [{first_name = "Bruce", last_name = "Springsteen"},
                          {first_name = "Eric", last_name = "Clapton"},
                          {first_name = "Bob", last_name = "Seger"}]
            """, """
                {
                    "arr": [
                        { "a": 1 },
                        { "a": 2 }
                    ],
                    "people": [
                        {
                            "first_name": "Bruce",
                            "last_name":  "Springsteen"
                        },
                        {
                            "first_name": "Eric",
                            "last_name":  "Clapton"
                        },
                        {
                            "first_name": "Bob",
                            "last_name":  "Seger"
                        }
                    ]
                }
        """))
    }

    @TestCase
    func bool() {
        @Assert(testToml("""
                a = {a = true, b = false}
            """, """
                {
                    "a": {
                        "a": true,
                        "b": false
                    }
                }
        """))
    }

    @TestCase
    func empty() {
        @Assert(testToml("""
                empty1 = {}
                empty2 = { }
                empty_in_array = [ { not_empty = 1 }, {} ]
                empty_in_array2 = [{},{not_empty=1}]
                many_empty = [{},{},{}]
                nested_empty = {"empty"={}}
                with_cmt ={            }#nothing here
            """, """
                {
                    "empty1":   {},
                    "empty2":   {},
                    "with_cmt": {},
                    "empty_in_array": [
                        {
                            "not_empty": 1
                        },
                        {}
                    ],
                    "empty_in_array2": [
                        {},
                        {
                            "not_empty": 1
                        }
                    ],
                    "many_empty": [
                        {},
                        {},
                        {}
                    ],
                    "nested_empty": {
                        "empty": {}
                    }
                }
        """))
    }

    @TestCase
    func endInBool() {
        @Assert(testToml("""
                black = { python=">3.6", version=">=18.9b0", allow_prereleases=true }
            """, """
                {
                    "black": {
                        "allow_prereleases": true,
                        "python":            "\\u003e3.6",
                        "version":           "\\u003e=18.9b0"
                    }
                }
        """))
    }

    @TestCase
    func inlineTable() {
        @Assert(testToml("""
                name        = { first = "Tom", last = "Preston-Werner" }
                point       = { x = 1, y = 2 }
                simple      = { a = 1 }
                str-key     = { "a" = 1 }
                table-array = [{ "a" = 1 }, { "b" = 2 }]
            """, """
                {
                    "name": {
                        "first": "Tom",
                        "last":  "Preston-Werner"
                    },
                    "point": {
                        "x": 1,
                        "y": 2
                    },
                    "simple": {
                        "a": 1
                    },
                    "str-key": {
                        "a": 1
                    },
                    "table-array": [
                        {
                            "a": 1
                        },
                        {
                            "b": 2
                        }
                    ]
                }
        """))
    }

    @TestCase
    func keyDotted1() {
        @Assert(testToml("""
                a = {   a.b  =  1   }
                b = {   "a"."b"  =  1   }
                c = {   a   .   b  =  1   }
                d = {   'a'   .   "b"  =  1   }
                e = {a.b=1}
            """, """
                {
                    "a": {
                        "a": {
                            "b": 1
                        }
                    },
                    "b": {
                        "a": {
                            "b": 1
                        }
                    },
                    "c": {
                        "a": {
                            "b": 1
                        }
                    },
                    "d": {
                        "a": {
                            "b": 1
                        }
                    },
                    "e": {
                        "a": {
                            "b": 1
                        }
                    }
                }
        """))
    }

    @TestCase
    func keyDotted2() {
        @Assert(testToml("""
                many.dots.here.dot.dot.dot = {a.b.c = 1, a.b.d = 2}
            """, """
                {
                    "many": {
                        "dots": {
                            "here": {
                                "dot": {
                                    "dot": {
                                        "dot": {
                                            "a": {
                                                "b": {
                                                    "c": 1,
                                                    "d": 2
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        """))
    }

    @TestCase
    func keyDotted3() {
        @Assert(testToml("""
                [tbl]
                a.b.c = {d.e=1}

                [tbl.x]
                a.b.c = {d.e=1}
            """, """
                {
                    "tbl": {
                        "a": {
                            "b": {
                                "c": {
                                    "d": {
                                        "e": 1
                                    }
                                }
                            }
                        },
                        "x": {
                            "a": {
                                "b": {
                                    "c": {
                                        "d": {
                                            "e": 1
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        """))
    }

    @TestCase
    func keyDotted4() {
        @Assert(testToml("""
                [[arr]]
                t = {a.b=1}
                T = {a.b=1}

                [[arr]]
                t = {a.b=2}
                T = {a.b=2}
            """, """
                {
                    "arr": [
                        {
                            "T": {
                                "a": {
                                    "b": 1
                                }
                            },
                            "t": {
                                "a": {
                                    "b": 1
                                }
                            }
                        },
                        {
                            "T": {
                                "a": {
                                    "b": 2
                                }
                            },
                            "t": {
                                "a": {
                                    "b": 2
                                }
                            }
                        }
                    ]
                }
        """))
    }

    @TestCase
    func keyDotted5() {
        @Assert(testToml("""
                arr-1 = [{a.b = 1}]
                arr-2 = ["str", {a.b = 1}]

                arr-3 = [{a.b = 1}, {a.b = 2}]
                arr-4 = ["str", {a.b = 1}, {a.b = 2}]
            """, """
                {
                    "arr-1": [{
                        "a": {
                            "b": 1
                        }
                    }],
                    "arr-2": [
                        "str",
                        {
                            "a": {
                                "b": 1
                            }
                        }
                    ],
                    "arr-3": [
                        {
                            "a": {
                                "b": 1
                            }
                        },
                        {
                            "a": {
                                "b": 2
                            }
                        }
                    ],
                    "arr-4": [
                        "str",
                        {
                            "a": {
                                "b": 1
                            }
                        },
                        {
                            "a": {
                                "b": 2
                            }
                        }
                    ]
                }
        """))
    }

    @TestCase
    func keyDotted6() {
        @Assert(testToml("""
                top.dot.dot = [
                    {dot.dot.dot = 1},
                    {dot.dot.dot = 2},
                ]
            """, """
                {
                    "top": {
                        "dot": {
                            "dot": [
                                {
                                    "dot": {
                                        "dot": {
                                            "dot": 1
                                        }
                                    }
                                },
                                {
                                    "dot": {
                                        "dot": {
                                            "dot": 2
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
        """))
    }
    

    @TestCase
    func keyDotted7() {
        @Assert(testToml("""
arr = [
\t{a.b = [{c.d = 1}]}
]
            """, """
                {
                    "arr": [{
                        "a": {"b": [{
                            "c": {
                                "d": 1
                            }
                        }]}
                    }]
                }
        """))
    }
    

    @TestCase
    func multiline() {
        @Assert(testToml("""
tbl_multiline = { a = 1, b = \"\"\"
multiline
\"\"\", c = \"\"\"and yet
another line\"\"\", d = 4 }
            """, """
                {
                    "tbl_multiline": {
                        "a": 1,
                        "b": "multiline\n",
                        "c": "and yet\nanother line",
                        "d": 4
                    }
                }
        """))
    }

    @TestCase
    func nest() {
        @Assert(testToml("""
                tbl_tbl_empty = { tbl_0 = {} }
                tbl_tbl_val   = { tbl_1 = { one = 1 } }
                tbl_arr_tbl   = { arr_tbl = [ { one = 1 } ] }
                arr_tbl_tbl   = [ { tbl = { one = 1 } } ]

                # Array-of-array-of-table is interesting because it can only
                # be represented in inline form.
                arr_arr_tbl_empty = [ [ {} ] ]
                arr_arr_tbl_val = [ [ { one = 1 } ] ]
                arr_arr_tbls  = [ [ { one = 1 }, { two = 2 } ] ]
            """, """
                {
                    "arr_arr_tbl_empty": [[{}]],
                    "arr_arr_tbl_val":   [[{
                        "one": 1
                    }]],
                    "arr_arr_tbls":      [[
                        {
                            "one": 1
                        },
                        {
                            "two": 2
                        }
                    ]],
                    "arr_tbl_tbl":       [{
                        "tbl": {
                            "one": 1
                        }
                    }],
                    "tbl_arr_tbl":       {"arr_tbl": [{
                        "one": 1
                    }]},
                    "tbl_tbl_empty": {
                        "tbl_0": {}
                    },
                    "tbl_tbl_val": {
                        "tbl_1": {
                            "one": 1
                        }
                    }
                }
        """))
    }

    @TestCase
    func spaces() {
        @Assert(testToml("""
                # https://github.com/toml-lang/toml-test/issues/146
                clap-1 = { version = "4"  , features = ["derive", "cargo"] }

                # Contains some literal tabs!
                clap-2 = { version = "4"	   	,	  	features = [   "derive" 	  ,  	  "cargo"   ]   , nest   =   {  	  "a"   =   'x'  , 	  'b'   = [ 1.5    ,   9.0  ]  }  }
            """, """
                {
                    "clap-1": {
                        "version": "4",
                        "features": [
                            "derive",
                            "cargo"
                        ]
                    },
                    "clap-2": {
                        "version": "4",
                        "features": [
                            "derive",
                            "cargo"
                        ],
                        "nest": {
                            "a": "x",
                            "b": [
                                1.5,
                                9.0
                            ]
                        }
                    }
                }
        """))
    }

    @TestCase
    func toml110Only_newline() {
        @Assert(testToml("""
# TOML 1.1 supports newlines in inline tables and trailing commas.

trailing-comma-1 = {
	c = 1,
}
trailing-comma-2 = { c = 1, }

tbl-1 = {
	hello = "world",
	1     = 2,
	arr   = [1,
	         2,
	         3,
	        ],
	tbl = {
		 k = 1,
	}
}

tbl-2 = {
	k = \"\"\"
	Hello
	\"\"\"
}
            """, """
                {
                    "tbl-1": {
                        "1":     2,
                        "hello": "world",
                        "arr": [
                            1,
                            2,
                            3
                        ],
                        "tbl": {
                            "k": 1
                        }
                    },
                    "tbl-2": {
                        "k": "\tHello\n\t"
                    },
                    "trailing-comma-1": {
                        "c": 1
                    },
                    "trailing-comma-2": {
                        "c": 1
                    }
                }
        """, toml100: false, toml110: true))
    }
}