package cangjie_toml.test.cangjie_toml.from_toml.invalid

import std.unittest.testmacro.*

@Test
class IntegerTest {
    @TestCase
    func capitalBin() {
        @AssertThrows[ParseException](parseToml("""
            capital-bin = 0B0
        """))
    }

    @TestCase
    func capitalHex() {
        @AssertThrows[ParseException](parseToml("""
            capital-hex = 0X1
        """))
    }

    @TestCase
    func capitalOct() {
        @AssertThrows[ParseException](parseToml("""
            capital-oct = 0O0
        """))
    }

    @TestCase
    func doubleSignNex() {
        @AssertThrows[ParseException](parseToml("""
            double-sign-nex = --99
        """))
    }

    @TestCase
    func doubleSignPlus() {
        @AssertThrows[ParseException](parseToml("""
            double-sign-plus = ++99
        """))
    }

    @TestCase
    func doubleUnderscore() {
        @AssertThrows[ParseException](parseToml("""
            double-us = 1__23
        """))
    }

    @TestCase
    func incompleteBin() {
        @AssertThrows[ParseException](parseToml("""
            incomplete-bin = 0b
        """))
    }

    @TestCase
    func incompleteHex() {
        @AssertThrows[ParseException](parseToml("""
            incomplete-hex = 0x
        """))
    }

    @TestCase
    func incompleteOct() {
        @AssertThrows[ParseException](parseToml("""
            incomplete-oct = 0o
        """))
    }

    @TestCase
    func invalidBin() {
        @AssertThrows[ParseException](parseToml("""
            invalid-bin = 0b0012
        """))
    }

    @TestCase
    func invalidHex1() {
        @AssertThrows[ParseException](parseToml("""
            invalid-hex-1 = 0xaafz
        """))
    }

    @TestCase
    func invalidHex2() {
        @AssertThrows[ParseException](parseToml("""
            invalid-hex-2 = 0xgabba00f1
        """))
    }

    @TestCase
    func invalidOct() {
        @AssertThrows[ParseException](parseToml("""
            invalid-oct = 0o778
        """))
    }

    @TestCase
    func leadingUnderscoreBin() {
        @AssertThrows[ParseException](parseToml("""
            leading-us-bin = _0b1
        """))
    }

    @TestCase
    func leadingUnderscoreHex() {
        @AssertThrows[ParseException](parseToml("""
            leading-us-hex = _0x1
        """))
    }

    @TestCase
    func leadingUnderscoreOct() {
        @AssertThrows[ParseException](parseToml("""
            leading-us-oct = _0o1
        """))
    }

    @TestCase
    func leadingUnderscore() {
        @AssertThrows[ParseException](parseToml("""
            leading-us = _123
        """))
    }

    @TestCase
    func leadingZero1() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-1 = 01
        """))
    }

    @TestCase
    func leadingZero2() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-2 = 00
        """))
    }

    @TestCase
    func leadingZero3() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-3 = 0_0
        """))
    }

    @TestCase
    func leadingZeroSign1() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-sign-1 = -01
        """))
    }

    @TestCase
    func leadingZeroSign2() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-sign-2 = +01
        """))
    }

    @TestCase
    func leadingZeroSign3() {
        @AssertThrows[ParseException](parseToml("""
            leading-zero-sign-3 = +0_1
        """))
    }

    @TestCase
    func negativeBin() {
        @AssertThrows[ParseException](parseToml("""
            negative-bin = -0b11010110
        """))
    }

    @TestCase
    func negativeHex() {
        @AssertThrows[ParseException](parseToml("""
            negative-hex = -0xff
        """))
    }

    @TestCase
    func negativeOct() {
        @AssertThrows[ParseException](parseToml("""
            negative-oct = -0o755
        """))
    }

    @TestCase
    func positiveBin() {
        @AssertThrows[ParseException](parseToml("""
            positive-bin = +0b11010110
        """))
    }

    @TestCase
    func positiveHex() {
        @AssertThrows[ParseException](parseToml("""
            positive-hex = +0xff
        """))
    }

    @TestCase
    func positiveOct() {
        @AssertThrows[ParseException](parseToml("""
            positive-oct = +0o755
        """))
    }

    @TestCase
    func textAfterInteger() {
        @AssertThrows[ParseException](parseToml("""
            answer = 42 the ultimate answer?
        """))
    }

    @TestCase
    func trailingUnderscoreBin() {
        @AssertThrows[ParseException](parseToml("""
            trailing-us-bin = 0b1_
        """))
    }

    @TestCase
    func trailingUnderscoreHex() {
        @AssertThrows[ParseException](parseToml("""
            trailing-us-hex = 0x1_
        """))
    }

    @TestCase
    func trailingUnderscoreOct() {
        @AssertThrows[ParseException](parseToml("""
            trailing-us-oct = 0o1_
        """))
    }

    @TestCase
    func trailingUnderscore() {
        @AssertThrows[ParseException](parseToml("""
            trailing-us = 123_
        """))
    }

    @TestCase
    func underscoreAfterBin() {
        @AssertThrows[ParseException](parseToml("""
            us-after-bin = 0b_1
        """))
    }

    @TestCase
    func underscoreAfterHex() {
        @AssertThrows[ParseException](parseToml("""
            us-after-hex = 0x_1
        """))
    }

    @TestCase
    func underscoreAfterOct() {
        @AssertThrows[ParseException](parseToml("""
            us-after-oct = 0o_1
        """))
    }
}