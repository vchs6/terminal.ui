package cangjie_toml.test.cangjie_toml.from_toml.invalid

import std.unittest.testmacro.*

@Test
class EncodingTest {
    @TestCase
    func badCodepoint() {
        // TODO compile error
        // @AssertThrows[IllegalArgumentException](parseToml("""
        //     # Invalid codepoint U+D800 : \u{D800}
        // """))
    }

    @TestCase
    func badUtf8AtEnd() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xda]) }
        @AssertThrows[IllegalArgumentException](parseToml("""
# There is a 0xda at after the quotes, and no EOL at the end of the file.
#
# This is a bit of an edge case: This indicates there should be two bytes
# (0b1101_1010) but there is no byte to follow because it's the end of the file.
x = \"\"\"\"\"\"${badUtf8}"""))
    }

    @TestCase
    func badUtf8InComment() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xc3]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "# ${badUtf8}"
        ))
    }

    @TestCase
    func badUtf8InMultilineLiteral() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xc3]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bad = '''${badUtf8}'''"
        ))
    }

    @TestCase
    func badUtf8InMultiline() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xc3]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bad = \"\"\"${badUtf8}\"\"\""
        ))
    }

    @TestCase
    func badUtf8InStringLiteral() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xc3]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bad = '${badUtf8}'"
        ))
    }

    @TestCase
    func badUtf8InString() {
        let badUtf8 = unsafe { String.fromUtf8Unchecked([0xc3]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bad = \"${badUtf8}\""
        ))
    }

    @TestCase
    func bomNotAtStart1() {
        let bom = unsafe { String.fromUtf8Unchecked([0xff, 0xfd]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bom-not-at-start ${bom}"
        ))
    }

    @TestCase
    func bomNotAtStart2() {
        let bom = unsafe { String.fromUtf8Unchecked([0xff, 0xfd]) }
        @AssertThrows[IllegalArgumentException](parseToml(
            "bom-not-at-start= ${bom}"
        ))
    }

    @TestCase
    func utf16Bom() {
        @AssertThrows[IllegalArgumentException](parseToml(
            unsafe {
                // # UTF-16 with BOM
                String.fromUtf8Unchecked([
                    0xfe, 0xff, 0x00, 0x23, 0x00, 0x20, 0x00, 0x55, 
                    0x00, 0x54, 0x00, 0x46, 0x00, 0x2d, 0x00, 0x31, 
                    0x00, 0x36, 0x00, 0x20, 0x00, 0x77, 0x00, 0x69, 
                    0x00, 0x74, 0x00, 0x68, 0x00, 0x20, 0x00, 0x42, 
                    0x00, 0x4f, 0x00, 0x4d, 0x00, 0x0a
                ])
            }
        ))
    }

    @TestCase
    func utf16Comment() {
        @AssertThrows[LexException](parseToml(
            unsafe {
                // # UTF-16 without BOM
                String.fromUtf8Unchecked([
                    0x00, 0x23, 0x00, 0x20, 0x00, 0x55, 0x00, 0x54, 
                    0x00, 0x46, 0x00, 0x2d, 0x00, 0x31, 0x00, 0x36, 
                    0x00, 0x20, 0x00, 0x77, 0x00, 0x69, 0x00, 0x74, 
                    0x00, 0x68, 0x00, 0x6f, 0x00, 0x75, 0x00, 0x74, 
                    0x00, 0x20, 0x00, 0x42, 0x00, 0x4f, 0x00, 0x4d, 
                    0x00, 0x0a
                ])
            }
        ))
    }

    @TestCase
    func utf16Key() {
        @AssertThrows[LexException](parseToml(
            unsafe {
                // k = "v"
                String.fromUtf8Unchecked([
                    0x00, 0x6b, 0x00, 0x20, 0x00, 0x3d, 0x00, 0x20, 
                    0x00, 0x22, 0x00, 0x76, 0x00, 0x22, 0x00, 0x0a
                ])
            }
        ))
    }
}