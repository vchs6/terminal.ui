package cangjie_toml.test.cangjie_toml.from_toml.invalid

import std.unittest.testmacro.*

@Test
class SpecTest {
    @TestCase
    func inlineTable20() {
        @AssertThrows[ParseException](parseToml("""
            [product]
            type = { name = "Nail" }
            type.edible = false  # INVALID
        """))
    }

    @TestCase
    func inlineTable30() {
        @AssertThrows[ParseException](parseToml("""
            [product]
            type.name = "Nail"
            type = { edible = false }  # INVALID
        """))
    }

    @TestCase
    func keyValuePair1() {
        @AssertThrows[ParseException](parseToml("""
            key = # INVALID
        """))
    }

    @TestCase
    func keys2() {
        @AssertThrows[ParseException](parseToml("""
            = "no key name"  # INVALID
            "" = "blank"     # VALID but discouraged
            '' = 'blank'     # VALID but discouraged
        """))
    }

    @TestCase
    func string40() {
        @AssertThrows[ParseException](parseToml("""
            str4 = \"\"\"Here are two quotation marks: "". Simple enough.\"\"\"
            str5 = \"\"\"Here are three quotation marks: \"\"\".\"\"\"  # INVALID
            str5 = \"\"\"Here are three quotation marks: ""\\".\"\"\"
            str6 = \"\"\"Here are fifteen quotation marks: ""\\\"""\\\"""\\\"""\\\"""\\".\"""

            # "This," she said, "is just a pointless statement."
            str7 = \"\"\""This," she said, "is just a pointless statement."\"\"\"
        """))
    }

    @TestCase
    func string70() {
        @AssertThrows[ParseException](parseToml("""
            quot15 = '''Here are fifteen quotation marks: \"\"\"\"\"\"\"\"\"\"\"\"\"\"\"'''

            apos15 = '''Here are fifteen apostrophes: ''''''''''''''''''  # INVALID
            apos15 = "Here are fifteen apostrophes: '''''''''''''''"

            # 'That,' she said, 'is still pointless.'
            str = ''''That,' she said, 'is still pointless.''''
        """))
    }

    @TestCase
    func table90() {
        @AssertThrows[ParseException](parseToml("""
            [fruit]
            apple.color = "red"
            apple.taste.sweet = true

            [fruit.apple]  # INVALID
            # [fruit.apple.taste]  # INVALID

            [fruit.apple.texture]  # you can add sub-tables
            smooth = true
        """))
    }

    @TestCase
    func table91() {
        @AssertThrows[ParseException](parseToml("""
            [fruit]
            apple.color = "red"
            apple.taste.sweet = true

            # [fruit.apple]  # INVALID
            [fruit.apple.taste]  # INVALID

            [fruit.apple.texture]  # you can add sub-tables
            smooth = true
        """))
    }
}