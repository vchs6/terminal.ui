package bitarray.test

//cjlint-ignore -start !G.PKG.01 description
import bitarray.*
import std.collection.*
import std.unittest.*
import std.unittest.testmacro.*
//cjlint-ignore -end description
// ====================== 构造测试 ======================

@Test
class ConstructionTests {
    @TestCase func fromUInt8() {
        let ba = BitArray(0b1010_1101u8)
        @Expect(ba.size, 8)
        @Expect(ba.toString(), "10101101")
        @Expect(ba[0], true)
    }

    @TestCase func fromUInt16() {
        @Expect(BitArray(0xA5C3u16).toUInt64(), 0xA5C3u64)
    }

    @TestCase func fromUInt16Multi() {
        let ba = BitArray(0xABCDu16, 0xEF01u16)
        @Expect(ba.size, 32)
        @Expect(ba.toUInt64(), 0xABCD_EF01u64)
    }

    @TestCase func fromUInt32() {
        @Expect(BitArray(0xDEAD_BEEFu32).toUInt64(), 0xDEAD_BEEFu64)
    }

    @TestCase func fromUInt32Multi() {
        let ba = BitArray(0xDEADu32, 0xBEEFu32)
        @Expect(ba.size, 64)
    }

    @TestCase func fromUInt64() {
        @Expect(BitArray(0x0123_4567_89AB_CDEFu64).toUInt64(), 0x0123_4567_89AB_CDEFu64)
    }

    @TestCase func fromByteArray() {
        @Expect(BitArray(0xABu8, 0xCDu8).toUInt64(), 0xABCDu64)
    }

    @TestCase func fromBoolArray() {
        let ba = BitArray([true, false, true, true, false])
        @Expect(ba.size, 5)
        @Expect(ba[0], false)
        @Expect(ba[1], true)
        @Expect(ba[2], true)
    }

    @TestCase func fromBitCount() {
        let ba = BitArray(16)
        @Expect(ba.size, 16)
        @Expect(ba.toString(), "0000000000000000")
    }

    @TestCase func empty() {
        let ba = BitArray()
        @Expect(ba.size, 0)
        @Expect(ba.isEmpty(), true)
    }
}

// ====================== 字符串解析测试（Parsable） ======================

@Test
class ParseTests {
    @TestCase func parseBasic() {
        // 诊断 1: BitArray(8) 正常
        let ba = BitArray(8)
        @Expect(ba.size, 8)
        @Expect(ba.toString(), "00000000")

        // 诊断 2: 直接调用 BitArray.parse (Parsable)
        let pba = BitArray.parse("10101101")
        @Expect(pba.size, 8)
        @Expect(pba.toString(), "10101101")
        @Expect(pba[0], true)
        @Expect(pba[7], true)
    }

    @TestCase func parseWithSpaces() {
        @Expect(BitArray.parse("1010 1101 1111 0000").toString(), "1010110111110000")
        @Expect(BitArray.parse("1010 1101 1111 0000").size, 16)
    }

    @TestCase func parseSingleBit() {
        @Expect(BitArray.parse("0")[0], false)
        @Expect(BitArray.parse("1")[0], true)
    }

    @TestCase func parseInvalidChars() {
        @ExpectThrows[IllegalArgumentException](BitArray.parse("abc"))
        @ExpectThrows[IllegalArgumentException](BitArray.parse("hello"))
    }

    @TestCase func tryParse() {
        @Expect(BitArray.tryParse("1010") != Option<BitArray>.None, true)
        @Expect(BitArray.tryParse("abc") == Option<BitArray>.None, true)
    }
}

// ====================== 索引测试 ======================

@Test
class IndexTests {
    @TestCase func getBit() {
        let ba = BitArray(0b1001_0110u8)
        @Expect(ba[0], false); @Expect(ba[1], true)
        @Expect(ba[2], true);  @Expect(ba[3], false)
        @Expect(ba[4], true);  @Expect(ba[5], false)
        @Expect(ba[6], false); @Expect(ba[7], true)
    }

    @TestCase func setBit() {
        let ba = BitArray(8)
        ba[0] = true;  @Expect(ba.toString(), "00000001")
        ba[7] = true;  @Expect(ba.toString(), "10000001")
        ba[0] = false; @Expect(ba.toString(), "10000000")
    }

    @TestCase func outOfBounds() {
        let ba = BitArray(4)
        @ExpectThrows[IndexOutOfBoundsException](ba[4])
    }
}

// ====================== 位运算测试 ======================

@Test
class BitwiseOpTests {
    private func b(s: String): BitArray { BitArray.parse(s) }

    @TestCase func and() {
        let a = BitArray.parse("1100")
        let b = BitArray.parse("1010")
        let r = a & b
        @Expect(a.toString(), "1100")
        @Expect(b.toString(), "1010")
        @Expect(r.toString(), "1000")
    }
    @TestCase func or()  { @Expect((b("1100") | b("1010")).toString(), "1110") }
    @TestCase func xor() { @Expect((b("1100") ^ b("1010")).toString(), "0110") }
    @TestCase func not() { @Expect((!b("1100")).toString(), "0011") }

    @TestCase func diffLen() {
        let r = b("1100") & b("10101010")
        @Expect(r.size, 8)
        @Expect(r.toString(), "00001000")
    }

    @TestCase func identity() {
        let a = b("1111"); let z = b("0000")
        @Expect((a & a).toString(), "1111")
        @Expect((a | a).toString(), "1111")
        @Expect((a ^ a).toString(), "0000")
        @Expect((!a).toString(), "0000")
        @Expect((!z).toString(), "1111")
    }
}

// ====================== 移位测试 ======================

@Test
class ShiftTests {
    @TestCase func shiftLeft()  { @Expect((BitArray.parse("00001111") << 3).toString(), "01111000") }
    @TestCase func shiftRight() { @Expect((BitArray.parse("00001111") >> 2).toString(), "00000011") }
    @TestCase func shiftZero()  { @Expect((BitArray.parse("1010") << 0).toString(), "1010") }

    @TestCase func shiftAllOut() {
        @Expect((BitArray.parse("1010") << 4).toString(), "0000")
        @Expect((BitArray.parse("1010") >> 4).toString(), "0000")
    }
}

// ====================== 判等测试 ======================

@Test
class EqualityTests {
    @TestCase func equal()  { @Expect(BitArray.parse("1010") == BitArray.parse("1010"), true) }
    @TestCase func notEqual() { @Expect(BitArray.parse("1010") == BitArray.parse("1100"), false) }
    @TestCase func diffLen()  { @Expect(BitArray.parse("10") == BitArray.parse("1010"), false) }
    @TestCase func empty()    { @Expect(BitArray() == BitArray(), true) }
}

// ====================== Array 风格方法测试 ======================

@Test
class ArrayStyleTests {
    @TestCase func isEmpty() {
        @Expect(BitArray().isEmpty(), true)
        @Expect(BitArray(1).isEmpty(), false)
    }

    @TestCase func cloneIsIndependent() {
        let a = BitArray.parse("1011")  // bits: [1]=msb, [0]=lsb=1, [0]=1, [1]=0, [2]=1, [3]=1
        let b = a.clone()
        b[1] = !b[1]                    // 翻转 b 的 bit[1]，a 应不受影响
        @Expect(a[1] != b[1], true)
    }

    @TestCase func reverse() {
        let a = BitArray.parse("1011")
        a.reverse()
        @Expect(a.toString(), "1101")
    }

    @TestCase func reverseEmpty() {
        let a = BitArray()
        a.reverse()
        @Expect(a.toString(), "")
    }

    @TestCase func fillTrue()  { let a = BitArray(4); a.fill(true); @Expect(a.toString(), "1111") }
    @TestCase func fillFalse() { let a = BitArray(5); a.fill(false); @Expect(a.none(), true) }

    @TestCase func allAnyNone() {
        @Expect(BitArray.parse("1111").all(), true)
        @Expect(BitArray.parse("0000").all(), false)
        @Expect(BitArray.parse("0000").any(), false)
        @Expect(BitArray.parse("0001").any(), true)
        @Expect(BitArray.parse("0000").none(), true)
        @Expect(BitArray.parse("0001").none(), false)
    }

    @TestCase func count() {
        @Expect(BitArray.parse("1010").count(), 2)
        @Expect(BitArray.parse("1111").count(), 4)
        @Expect(BitArray.parse("0000").count(), 0)
    }

    @TestCase func countWhen() {
        @Expect(BitArray.parse("1011").count(value: false), 1)
    }

    @TestCase func indexOf() {
        match (BitArray.parse("0100").indexOf()) {
            case Some(i) => @Expect(i, 2)
            case _ => @Fail("expected Some")
        }
        @Expect(BitArray.parse("0000").indexOf(), Option<Int64>.None)
    }

    @TestCase func swap() {
        let a = BitArray.parse("1010")
        a.swap(0, 3)
        @Expect(a.toString(), "0011")
    }
}

// ====================== 接口实现测试 ======================

@Test
class InterfaceTests {
    @TestCase func hashable() {
        let m = HashMap<BitArray, String>()
        m[BitArray.parse("1010")] = "ten"
        @Expect(m[BitArray.parse("1010")], "ten")
    }

    @TestCase func comparable() {
        @Expect(BitArray.parse("1") < BitArray.parse("10"), true)
        @Expect(BitArray.parse("10") > BitArray.parse("01"), true)
        @Expect(BitArray.parse("1010").compare(BitArray.parse("1010")), Ordering.EQ)
    }

    @TestCase func equals() {
        @Expect(BitArray.parse("1010") == BitArray.parse("1010"), true)
        @Expect(BitArray.parse("1010") == BitArray.parse("1100"), false)
    }

    @TestCase func toBoolArray() {
        let arr = BitArray.parse("1011").toBoolArray()
        @Expect(arr.size, 4)
        @Expect(arr[0], true); @Expect(arr[3], true)
    }
}

// ====================== 工具方法测试 ======================

@Test
class UtilityTests {
    @TestCase func slice() {
        @Expect(BitArray.parse("11001010").slice(2, 6).toString(), "0010")
    }

    @TestCase func sliceOutOfRange() {
        @ExpectThrows[ArithmeticException](BitArray.parse("1010").slice(0, 10))
    }

    @TestCase func concat() {
        @Expect(BitArray.parse("1100").concat(BitArray.parse("0011")).toString(), "11000011")
    }

    @TestCase func concatEmpty() {
        @Expect(BitArray.parse("1010").concat(BitArray()).toString(), "1010")
    }

    @TestCase func toUInt64() {
        @Expect(BitArray(0xC0FFEEu32).toUInt64(), 0xC0FFEEu64)
    }

    @TestCase func toUInt64Truncate() {
        let ba = BitArray(0xDEAD_BEEF_0123_4567u64)
        let low32 = ba.slice(0, 32).toUInt64()
        @Expect(low32, 0x0123_4567u64)
    }

    @TestCase func toString() {
        @Expect(BitArray().toString(), "")
        @Expect(BitArray.parse("1").toString(), "1")
        @Expect(BitArray.parse("1010101010101010").toString(), "1010101010101010")
    }
}

// ====================== 分段视图测试 ======================

@Test
class SegmentedAccessTests {
    @TestCase func addAndGet() {
        let ba = BitArray(0x1A_00_AB_CDu32)
        let view = SegmentedBitArray(ba)
        view.addSegment(BitSegment("flags", 0, 8))
        view.addSegment(BitSegment("length", 8, 16))
        view.addSegment(BitSegment("type", 24, 4))
        view.addSegment(BitSegment("version", 28, 4))

        @Expect(view.getSegment("flags"), 0xCDu64)
        @Expect(view.getSegment("length"), 0xABu64)
        @Expect(view.getSegment("type"), 0xAu64)
        @Expect(view.getSegment("version"), 0x1u64)
    }

    @TestCase func setThroughView() {
        let ba = BitArray(0x1A_00_AB_CDu32)
        let view = SegmentedBitArray(ba)
        view.addSegment(BitSegment("flags", 0, 8))
        view.setSegment("flags", 0x42u64)
        @Expect(view.getSegment("flags"), 0x42u64)
        @Expect(ba.toUInt64() & 0xFFu64, 0x42u64)
    }

    @TestCase func overlappingSegments() {
        let ba = BitArray(0x1A_00_AB_CDu32)
        let view = SegmentedBitArray(ba)
        view.addSegment(BitSegment("whole", 0, 32))
        view.addSegment(BitSegment("high16", 16, 16))
        view.addSegment(BitSegment("low16", 0, 16))

        @Expect(view.getSegment("whole"), 0x1A00_AB_CDu64)
        @Expect(view.getSegment("high16"), 0x1A00u64)
        @Expect(view.getSegment("low16"), 0xAB_CDu64)
    }

    @TestCase func removeSegment() {
        let view = SegmentedBitArray(BitArray(0xABCDu32))
        view.addSegment(BitSegment("tmp", 0, 8))
        @Expect(view.getSegmentNames().size, 1)
        view.removeSegment("tmp")
        @Expect(view.getSegmentNames().size, 0)
        @ExpectThrows[IllegalArgumentException](view.getSegment("tmp"))
    }

    @TestCase func segmentNotFound() {
        let view = SegmentedBitArray(BitArray(8))
        @ExpectThrows[IllegalArgumentException](view.getSegment("x"))
        @ExpectThrows[IllegalArgumentException](view.setSegment("x", 0u64))
    }

    @TestCase func segmentOutOfRange() {
        let view = SegmentedBitArray(BitArray(8))
        view.addSegment(BitSegment("oversize", 0, 16))
        @ExpectThrows[IllegalArgumentException](view.getSegment("oversize"))
    }
}

// ====================== 分区模型测试 ======================

@Test
class PartitionedAccessTests {
    @TestCase func addAndGet() {
        let pba = PartitionedBitArray(BitArray(0x1A_00_AB_CDu32))
        pba.addField(BitSegment("flags", 0, 8))
        pba.addField(BitSegment("length", 8, 16))
        pba.addField(BitSegment("type", 24, 4))
        pba.addField(BitSegment("version", 28, 4))

        @Expect(pba.getField("flags"), 0xCDu64)
        @Expect(pba.getField("version"), 0x1u64)
    }

    @TestCase func overlapDetection() {
        let pba = PartitionedBitArray(BitArray(8))
        pba.addField(BitSegment("a", 0, 4))
        @ExpectThrows[IllegalArgumentException](
            pba.addField(BitSegment("b", 2, 4)))
    }

    @TestCase func setField() {
        let pba = PartitionedBitArray(BitArray(0x1A_00_AB_CDu32))
        pba.addField(BitSegment("flags", 0, 8))
        pba.setField("flags", 0x42u64)
        @Expect(pba.getField("flags"), 0x42u64)
    }

    @TestCase func fieldNotFound() {
        let pba = PartitionedBitArray(BitArray(8))
        @ExpectThrows[IllegalArgumentException](pba.getField("missing"))
    }

    @TestCase func listFieldNames() {
        let pba = PartitionedBitArray(BitArray(8))
        pba.addField(BitSegment("a", 0, 4))
        pba.addField(BitSegment("b", 4, 4))
        let names = pba.listFieldNames()
        @Expect(names.contains("a"), true)
        @Expect(names.contains("b"), true)
    }
}

// ====================== 两模型共存测试 ======================

@Test
class CoexistenceTests {
    @TestCase func segAndPartOnSameBitArray() {
        let ba = BitArray(0x1A_00_AB_CDu32)
        let view = SegmentedBitArray(ba)
        let pba = PartitionedBitArray(ba)

        pba.addField(BitSegment("f_flags", 0, 8))
        view.addSegment(BitSegment("whole", 0, 32))

        @Expect(view.getSegment("whole"), 0x1A00_AB_CDu64)
        @Expect(pba.getField("f_flags"), 0xCDu64)
    }

    @TestCase func writePartitionVisibleInView() {
        let ba = BitArray(0x1A_00_AB_CDu32)
        let view = SegmentedBitArray(ba)
        let pba = PartitionedBitArray(ba)

        pba.addField(BitSegment("f_flags", 0, 8))
        view.addSegment(BitSegment("whole", 0, 32))

        pba.setField("f_flags", 0x42u64)
        @Expect(pba.getField("f_flags"), 0x42u64)
        @Expect(view.getSegment("whole") & 0xFFu64, 0x42u64)
    }
}

// ====================== 多视图共存测试 ======================

@Test
class MultiViewTests {
    @TestCase func twoViewsSameBa() {
        let ba = BitArray(0xDEAD_BEEFu32)
        let v1 = SegmentedBitArray(ba); v1.addSegment(BitSegment("h16", 16, 16))
        let v2 = SegmentedBitArray(ba); v2.addSegment(BitSegment("l16", 0, 16))

        @Expect(v1.getSegment("h16"), 0xDEADu64)
        @Expect(v2.getSegment("l16"), 0xBEEFu64)
    }

    @TestCase func segOverrides() {
        let ba = BitArray(0xFFFF_0000u32)
        let v1 = SegmentedBitArray(ba); v1.addSegment(BitSegment("low8", 0, 8))
        let v2 = SegmentedBitArray(ba); v2.addSegment(BitSegment("mid8", 8, 8))

        v1.setSegment("low8", 0xABu64)
        @Expect(v2.getSegment("mid8"), 0x00u64)
    }
}

// ====================== 边缘情况与异常测试 ======================

@Test
class EdgeCaseTests {
    @TestCase func negCount() {
        @ExpectThrows[ArithmeticException](BitArray(-1))
    }

    @TestCase func operatorNotOnSelf() {
        let a = BitArray.parse("11110000")
        let na = !a
        @Expect(a.toString(), "11110000")
        @Expect(na.toString(), "00001111")
    }
}
