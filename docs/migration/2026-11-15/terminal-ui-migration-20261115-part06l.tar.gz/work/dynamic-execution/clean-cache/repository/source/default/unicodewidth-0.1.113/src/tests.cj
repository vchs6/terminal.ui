//cjlint-ignore -start !G.OTH.03 description

// Copyright 2012-2025 The Rust Project Developers. See the COPYRIGHT
// file at the top-level directory of this distribution and at
// http://rust-lang.org/COPYRIGHT.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//cjlint-ignore -end description

// NOTE: Ported from unicode-width/tests/tests.rs
// Integration tests for Unicode width calculation.

package unicodewidth

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect
import std.unittest.Configuration
import std.unittest.{TestSuite, TestClass}
import std.unittest.{expectEqual, KeyFromTopLevel, UnitTestCase}
import std.unittest.TestPackage

import std.fs.{exists, Path, File, OpenMode}
import std.io.StringReader
import std.convert.Parsable

//cjlint-ignore -start !G.NAM.04 description
func assert_width(s: String, nocjk: UInt8, cjk: UInt8) {
    @Expect(UInt8(s.width()), nocjk)
    @Expect(UInt8(s.widthCjk()), cjk)
}

func assert_width_char(c: Rune, nocjk: ?UInt8, cjk: ?UInt8) {
    let result = match( (c.width(), nocjk) ) {
        case (None, None) => true
        case (Some(x), Some(y)) => x == y
        case _ => false
    }
    @Expect(result, true)
    
    let resultCjk = match( (c.widthCjk(), cjk) ) {
        case (None, None) => true
        case (Some(x), Some(y)) => x == y
        case _ => false
    }
    @Expect(resultCjk, true)
}

@Test
public func test_str(): Unit {
    assert_width("ｈｅｌｌｏ", 10u8, 10u8)
    assert_width("\0\0\0\u{01}\u{01}", 5u8, 5u8)
    assert_width("", 0u8, 0u8)
    assert_width("\u{2081}\u{2082}\u{2083}\u{2084}", 4u8, 8u8)
}

@Test
public func test_emoji(): Unit {
    assert_width("👩", 2u8, 2u8)
    assert_width("🔬", 2u8, 2u8)
    assert_width("👩‍🔬", 2u8, 2u8)
}

@Test
public func test_halfwidth_katakana(): Unit {
    assert_width("ﾊﾟｸﾞ", 4u8, 4u8)
}

@Test
public func test_bad_devanagari(): Unit {
    @Expect("क".width(), 1)
    @Expect("ष".width(), 1)
    @Expect("क्ष".width(), 2)
}

@Test
public func test_char(): Unit {
    assert_width_char(r'ｈ', Some(2u8), Some(2u8))
    assert_width_char(r'\u{0}', None, None)
    assert_width_char(r'\u{01}', None, None)
    assert_width_char(r'\u{2081}', Some(1u8), Some(2u8))
}

@Test
public func test_char2(): Unit {
    assert_width_char(r'\n', None, None)
    assert_width_char(r'w', Some(1u8), Some(1u8))
    assert_width_char(r'ｈ', Some(2u8), Some(2u8))
    assert_width_char(r'\u{AD}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{1160}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{a1}', Some(1u8), Some(2u8))
    assert_width_char(r'\u{300}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{FF9E}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{FF9F}', Some(1u8), Some(1u8))
}

@Test
public func unicode_12(): Unit {
    assert_width_char(r'\u{1F971}', Some(2u8), Some(2u8))
}

@Test
public func test_default_ignorable(): Unit {
    assert_width_char(r'\u{1160}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{3164}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{FFA0}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{E0000}', Some(0u8), Some(0u8))
}

@Test
public func test_ambiguous(): Unit {
    assert_width("\u{B7}", 1u8, 2u8)
    assert_width("\u{0387}", 1u8, 2u8)
    assert_width("\u{A8}", 1u8, 1u8)
    assert_width("\u{02C9}", 1u8, 1u8)
}

@Test
public func test_jamo(): Unit {
    assert_width_char(r'\u{1100}', Some(2u8), Some(2u8))
    assert_width_char(r'\u{A97C}', Some(2u8), Some(2u8))
    assert_width_char(r'\u{115F}', Some(2u8), Some(2u8))
    assert_width_char(r'\u{1160}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{D7C6}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{11A8}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{D7FB}', Some(0u8), Some(0u8))
}

@Test
public func test_prepended_concatenation_marks(): Unit {
    for (c in [r'\u{0600}', r'\u{0601}', r'\u{0602}', r'\u{0603}', r'\u{0604}', r'\u{06DD}', r'\u{110BD}', r'\u{110CD}']) {
        assert_width_char(c, Some(1u8), Some(1u8))
    }
    for (c in [r'\u{0605}', r'\u{070F}', r'\u{0890}', r'\u{0891}', r'\u{08E2}']) {
        assert_width_char(c, Some(0u8), Some(0u8))
    }
}

@Test
public func test_gcb_prepend(): Unit {
    assert_width("ൎഉ", 1u8, 1u8)
    @Expect("\u{11A89}".width(), 0)
}

@Test
public func test_interlinear_annotation_chars(): Unit {
    assert_width_char(r'\u{FFF9}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{FFFA}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{FFFB}', Some(1u8), Some(1u8))
}

@Test
public func test_hieroglyph_format_controls(): Unit {
    assert_width_char(r'\u{13430}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{13436}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{1343C}', Some(1u8), Some(1u8))
}

@Test
public func test_marks(): Unit {
    assert_width_char(r'\u{0301}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{20DD}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{09CB}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{09BE}', Some(0u8), Some(0u8))
}

@Test
public func test_devanagari_caret(): Unit {
    assert_width_char(r'\u{A8FA}', Some(0u8), Some(0u8))
}

@Test
public func test_solidus_overlay(): Unit {
    assert_width("<\u{338}", 1u8, 2u8)
    assert_width("=\u{338}", 1u8, 2u8)
    assert_width(">\u{338}", 1u8, 2u8)
    assert_width("=\u{301}\u{338}", 1u8, 2u8)
    assert_width("=\u{338}\u{301}", 1u8, 2u8)
    assert_width("=\u{FE0F}\u{338}", 1u8, 2u8)
    assert_width("#\u{FE0F}\u{338}", 2u8, 2u8)
    assert_width("#\u{338}\u{FE0F}", 1u8, 1u8)
    assert_width("\u{06B8}\u{338}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{338}\u{FE0E}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{338}\u{FE0F}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{FE0E}\u{338}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{FE0F}\u{338}\u{0627}", 1u8, 1u8)
    assert_width("=\u{338}\u{0627}", 2u8, 3u8)
}

@Test
public func test_emoji_presentation(): Unit {
    assert_width_char(r'#', Some(1u8), Some(1u8))
    assert_width_char(r'\u{FE0F}', Some(0u8), Some(0u8))
    assert_width("#\u{FE0F}", 2u8, 2u8)
    assert_width("a#\u{FE0F}a", 4u8, 4u8)
    assert_width("#a\u{FE0F}", 2u8, 2u8)
    assert_width("a\u{FE0F}", 1u8, 1u8)
    assert_width("##\u{FE0F}a", 4u8, 4u8)
    assert_width("*\u{FE0F}", 2u8, 2u8)
    assert_width("\u{23F9}\u{FE0F}", 2u8, 2u8)
    assert_width("\u{24C2}\u{FE0F}", 2u8, 2u8)
    assert_width("\u{1F6F3}\u{FE0F}", 2u8, 2u8)
    assert_width("\u{1F700}\u{FE0F}", 1u8, 1u8)
    assert_width("#\u{301}\u{FE0F}", 1u8, 1u8)
    assert_width("#\u{200D}\u{FE0F}", 1u8, 1u8)
    assert_width("#\u{FE0E}\u{FE0F}", 1u8, 1u8)
}

@Test
public func test_text_presentation(): Unit {
    assert_width_char(r'\u{FE0E}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{2648}', Some(2u8), Some(2u8))
    assert_width("\u{2648}\u{FE0E}", 1u8, 2u8)
    assert_width("\u{2648}\u{FE0E}\u{FE0F}", 1u8, 2u8)
    assert_width("\u{2648}\u{FE0F}\u{FE0E}", 2u8, 2u8)
    assert_width("\u{1F21A}\u{FE0E}", 2u8, 2u8)
    assert_width("\u{0301}\u{FE0E}", 0u8, 0u8)
    assert_width("a\u{FE0E}", 1u8, 1u8)
    assert_width("𘀀\u{FE0E}", 2u8, 2u8)
    assert_width("\u{2648}\u{0301}\u{FE0E}", 2u8, 2u8)
    assert_width("\u{2648}\u{200D}\u{FE0E}", 2u8, 2u8)
}

@Test
public func test_control_line_break(): Unit {
    assert_width_char(r'\u{2028}', Some(1u8), Some(1u8))
    assert_width_char(r'\u{2029}', Some(1u8), Some(1u8))
    assert_width_char(r'\r', None, None)
    assert_width_char(r'\n', None, None)
    assert_width("\r", 1u8, 1u8)
    assert_width("\n", 1u8, 1u8)
    assert_width("\r\n", 1u8, 1u8)
    assert_width("\0", 1u8, 1u8)
    assert_width("1\t2\r\n3\u{85}4", 7u8, 7u8)
    assert_width("\r\u{FE0F}\n", 2u8, 2u8)
    assert_width("\r\u{200D}\n", 2u8, 2u8)
}

@Test
public func test_lisu_tones(): Unit {
    for (cp in 0xA4F8u32..=0xA4FDu32) {
        let c = Rune(cp)
        assert_width_char(c, Some(1u8), Some(1u8))
        assert_width("${c}", 1u8, 1u8)
    }
    for (c1_cp in 0xA4F8u32..=0xA4FDu32) {
        let c1 = Rune(c1_cp)
        for (c2_cp in 0xA4F8u32..=0xA4FDu32) {
            let c2 = Rune(c2_cp)
            let s = "${c1}" + "${c2}"
            if (c1_cp >= 0xA4F8u32 && c1_cp <= 0xA4FBu32 && c2_cp >= 0xA4FCu32 && c2_cp <= 0xA4FDu32) {
                assert_width(s, 1u8, 1u8)
            } else {
                assert_width(s, 2u8, 2u8)
            }
        }
    }
    assert_width("ꓪꓹ", 2u8, 2u8)
    assert_width("ꓪꓹꓼ", 2u8, 2u8)
    assert_width("ꓪꓹ\u{FE0F}ꓼ", 2u8, 2u8)
    assert_width("ꓪꓹ\u{200D}ꓼ", 2u8, 2u8)
    assert_width("ꓪꓹꓼ\u{FE0F}", 2u8, 2u8)
    assert_width("ꓪꓹ\u{0301}ꓼ", 3u8, 3u8)
    assert_width("ꓪꓹꓹ", 3u8, 3u8)
    assert_width("ꓪꓼꓼ", 3u8, 3u8)
}

@Test
public func test_hebrew_alef_lamed(): Unit {
    assert_width("\u{05D0}", 1u8, 1u8)
    assert_width("\u{05DC}", 1u8, 1u8)
    assert_width("\u{05D0}\u{05DC}", 2u8, 2u8)
    assert_width("\u{05D0}\u{200D}\u{05DC}", 1u8, 1u8)
    assert_width("\u{05D0}\u{200D}\u{200D}\u{200D}\u{200D}\u{200D}\u{200D}\u{200D}\u{05DC}", 1u8, 1u8)
    assert_width("\u{05D0}\u{05D0}\u{200D}\u{05DC}", 2u8, 2u8)
    assert_width("\u{05D0}\u{05D0}\u{200D}\u{200D}\u{200D}\u{200D}\u{200D}\u{200D}\u{05DC}", 2u8, 2u8)
    assert_width("\u{05D0}\u{FE0F}\u{200D}\u{FE0F}\u{05DC}\u{FE0F}", 1u8, 1u8)
    assert_width("\u{05D0}\u{FE0E}\u{200D}\u{FE0E}\u{05DC}\u{FE0E}", 1u8, 1u8)
}

@Test
public func test_arabic_lam_alef(): Unit {
    assert_width("\u{0644}", 1u8, 1u8)
    assert_width("\u{06B8}", 1u8, 1u8)
    assert_width("\u{0623}", 1u8, 1u8)
    assert_width("\u{0627}", 1u8, 1u8)
    assert_width("\u{0644}\u{0623}", 1u8, 1u8)
    assert_width("\u{0644}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{0623}", 1u8, 1u8)
    assert_width("\u{06B8}\u{0627}", 1u8, 1u8)
    assert_width("\u{0644}\u{065F}\u{065E}\u{0623}", 1u8, 1u8)
    assert_width("\u{0644}\u{065F}\u{065E}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{065F}\u{065E}\u{0623}", 1u8, 1u8)
    assert_width("\u{06B8}\u{065F}\u{065E}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{FE0E}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{FE0F}\u{0627}", 1u8, 1u8)
    assert_width("\u{06B8}\u{17B5}\u{0627}", 1u8, 1u8)
    assert_width("\u{0644}\u{0644}\u{0623}", 2u8, 2u8)
    assert_width("\u{0644}\u{0644}\u{0627}", 2u8, 2u8)
    assert_width("\u{06B8}\u{06B8}\u{0623}", 2u8, 2u8)
    assert_width("\u{06B8}\u{06B8}\u{0627}", 2u8, 2u8)
    assert_width("\u{0644}\u{200D}\u{0623}", 2u8, 2u8)
    assert_width("\u{0644}\u{200D}\u{0627}", 2u8, 2u8)
    assert_width("\u{06B8}\u{200D}\u{0623}", 2u8, 2u8)
    assert_width("\u{06B8}\u{200D}\u{0627}", 2u8, 2u8)
    assert_width("\u{0644}\u{1E94B}\u{0623}", 3u8, 3u8)
    assert_width("\u{0644}\u{1E94B}\u{0627}", 3u8, 3u8)
    assert_width("\u{06B8}\u{1E94B}\u{0623}", 3u8, 3u8)
    assert_width("\u{06B8}\u{1E94B}\u{0627}", 3u8, 3u8)
}

@Test
public func test_buginese_a_i_ya(): Unit {
    assert_width("\u{1A15}", 1u8, 1u8)
    assert_width("\u{1A17}", 0u8, 0u8)
    assert_width("\u{1A10}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{200D}\u{1A10}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{200D}\u{200D}\u{200D}\u{200D}\u{1A10}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{200D}\u{338}", 1u8, 1u8)
    assert_width("\u{1A15}\u{FE0E}\u{1A17}\u{200D}", 1u8, 1u8)
    assert_width("\u{1A15}\u{FE0F}\u{1A17}\u{200D}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{FE0E}\u{200D}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{FE0F}\u{200D}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{200D}\u{FE0E}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A17}\u{200D}\u{FE0F}", 1u8, 1u8)
    assert_width("\u{1A15}\u{17B5}\u{200D}\u{FE0E}\u{1A17}\u{200D}\u{FE0F}\u{200D}\u{FE0F}", 1u8, 1u8)
    assert_width("\u{1A15}\u{1A15}\u{1A17}\u{200D}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{1A15}\u{1A17}\u{200D}\u{200D}\u{200D}\u{200D}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{1A17}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{200D}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{1A17}\u{1A17}\u{200D}\u{1A10}", 2u8, 2u8)
    assert_width("\u{1A15}\u{1A17}\u{338}\u{200D}\u{1A10}", 2u8, 2u8)
}

@Test
public func test_tifinagh_biconsonants(): Unit {
    assert_width("\u{2D4F}", 1u8, 1u8)
    assert_width("\u{2D3E}", 1u8, 1u8)
    assert_width("\u{2D7F}", 1u8, 1u8)
    assert_width("\u{2D4F}\u{200D}\u{2D3E}", 1u8, 1u8)
    assert_width("\u{2D4F}\u{2D7F}\u{2D3E}", 1u8, 1u8)
    assert_width("\u{2D4F}\u{FE0F}\u{200D}\u{2D7F}\u{FE0E}\u{200D}\u{17B5}\u{2D3E}", 1u8, 1u8)
    assert_width("\u{2D4F}\u{301}\u{2D7F}\u{2D3E}", 3u8, 3u8)
    assert_width("\u{2D4F}\u{301}\u{200D}\u{2D3E}", 2u8, 2u8)
    assert_width("\u{2D4F}\u{2D3E}", 2u8, 2u8)
    assert_width("\u{2D4F}\u{2D7F}\u{2D7F}\u{2D3E}", 4u8, 4u8)
    assert_width("\u{2D7F}\u{2D3E}", 2u8, 2u8)
    assert_width("\u{2D7F}\u{2D7F}\u{2D66}", 3u8, 3u8)
    assert_width("\u{2D66}\u{2D7F}\u{2D3E}", 3u8, 3u8)
}

@Test
public func test_old_turkic_ligature(): Unit {
    assert_width("\u{10C32}", 1u8, 1u8)
    assert_width("\u{10C03}", 1u8, 1u8)
    assert_width("\u{10C32}\u{10C03}", 2u8, 2u8)
    assert_width("\u{10C32}\u{200D}\u{10C03}", 1u8, 1u8)
    assert_width("\u{10C32}\u{FE0F}\u{200D}\u{FE0E}\u{10C03}", 1u8, 1u8)
    assert_width("\u{10C32}\u{2D7F}\u{10C03}", 3u8, 3u8)
    assert_width("\u{10C32}\u{0301}\u{200D}\u{10C03}", 2u8, 2u8)
    assert_width("\u{10C03}\u{200D}\u{10C32}", 2u8, 2u8)
    assert_width("\u{200D}\u{10C32}", 1u8, 1u8)
}

@Test
public func test_khmer_qaa(): Unit {
    assert_width("\u{17A4}", 2u8, 2u8)
    assert_width("\u{17A2}\u{17A6}", 2u8, 2u8)
}

@Test
public func test_khmer_sign_beyyal(): Unit {
    assert_width("\u{17D8}", 3u8, 3u8)
    assert_width("\u{17D4}\u{179B}\u{17D4}", 3u8, 3u8)
}

@Test
public func test_emoji_modifier(): Unit {
    assert_width("\u{1F46A}", 2u8, 2u8)
    assert_width("\u{1F3FB}", 2u8, 2u8)
    assert_width("\u{1F46A}\u{1F3FB}", 2u8, 2u8)
    assert_width("\u{1F46A}\u{200D}\u{200D}\u{1F3FB}", 4u8, 4u8)
}

@Test
public func test_emoji_zwj(): Unit {
    assert_width("🧑‍🤝‍🧑", 2u8, 2u8)
    assert_width("🇮🇱🕊️🇵🇸", 6u8, 6u8)
    assert_width("🇵🇸\u{200D}🕊️\u{200D}🇮🇱", 2u8, 2u8)
    assert_width("🇮🇱\u{200D}🕊️\u{200D}\u{200D}🇵🇸", 4u8, 4u8)
    assert_width("🇵🇸\u{200D}\u{200D}🕊️\u{200D}🇮🇱", 4u8, 4u8)
    assert_width("🇦🇦\u{200D}🇦🇦", 2u8, 2u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦", 3u8, 3u8)
    assert_width("🇦🇦\u{200D}\u{200D}🇦🇦", 4u8, 4u8)
    assert_width("🇦🇦\u{200D}🇦\u{200D}🇦🇦", 5u8, 5u8)
    assert_width("🇦🇦\u{200D}🇦🇦\u{200D}🇦🇦", 2u8, 2u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦\u{200D}🇦🇦", 5u8, 5u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦🇦\u{200D}🇦🇦", 4u8, 4u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦🇦🇦\u{200D}🇦🇦", 7u8, 7u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦🇦🇦🇦\u{200D}🇦🇦", 6u8, 6u8)
    assert_width("🇦🇦\u{200D}🇦🇦🇦🇦🇦🇦🇦\u{200D}🇦🇦", 9u8, 9u8)
    assert_width("🏴󠁧󠁢󠁷󠁬󠁳󠁿", 2u8, 2u8)
    assert_width("🏴󠁧󠁢󠁥󠁮󠁧󠁿\u{200D}🏴󠁧󠁢󠁳󠁣󠁴󠁿\u{200D}🏴󠁧󠁢󠁷󠁬󠁳󠁿", 2u8, 2u8)
    assert_width("🇦👪\u{200D}🏿", 3u8, 3u8)
    assert_width("🇦🏿\u{200D}🏿", 3u8, 3u8)
    assert_width_char(r'🏴', Some(2u8), Some(2u8))
    @Expect("\u{E0031}".width(), 0)
    @Expect("\u{E0063}".width(), 0)
    @Expect("\u{E007F}".width(), 0)
    assert_width("🏴\u{200D}Ⓜ️", 2u8, 2u8)
    assert_width("🏴\u{200D}Ⓜ️", 2u8, 2u8)
    assert_width("a\u{200D}🏴󠁧󠁢󠁷󠁬󠁳󠁿", 3u8, 3u8)
    assert_width("👪\u{200D}a", 3u8, 3u8)
    assert_width("a\u{200D}a", 2u8, 2u8)
    assert_width("*\u{FE0F}", 2u8, 2u8)
    @Expect("*\u{20E3}".width(), 1)
    assert_width("*️⃣", 2u8, 2u8)
    @Expect("*\u{20E3}\u{FE0F}".width(), 1)
    assert_width("*️⃣\u{200D}👪", 2u8, 2u8)
    assert_width("*\u{20E3}\u{FE0F}\u{200D}👪", 3u8, 3u8)
    assert_width("*\u{20E3}\u{200D}👪", 3u8, 3u8)
    assert_width("*\u{FE0F}\u{200D}👪", 2u8, 2u8)
    assert_width("*️⃣\u{20E3}\u{200D}👪", 4u8, 4u8)
    assert_width("*\u{FE0F}\u{FE0F}\u{20E3}\u{200D}👪", 4u8, 4u8)
    assert_width("🇦👪\u{200D}🏿\u{200D}👪🏻\u{200D}Ⓜ️\u{200D}*\u{FE0F}\u{200D}🇦🇦\u{200D}🏴󠁧󠁢󠁷󠁬󠁳󠁿\u{200D}👪", 3u8, 3u8)
}

@Test
public func test_ambiguous_line_break(): Unit {
    assert_width("\u{24EA}", 1u8, 2u8)
    assert_width("\u{2616}", 1u8, 2u8)
    assert_width("\u{2780}", 1u8, 2u8)
}

@Test
public func test_char_iter(): Unit {
    @Expect(char_iter_width([r'a', r'b', r'🔬']), 4u64)
}

@Test
public func test_emoji_test_file(): Unit {
    if (! exists("tests"+ Path.Separator + "emoji-test.txt")) {
        return
    }
    let reader = StringReader<File>(File("tests/emoji-test.txt", OpenMode.Read))
    while (true) {
        let line = if (let Some(str) <- reader.readln()) {
            str
        } else {
            break
        }
        if (line.size == 0 || line[0] == 0x23u8) { // empty or starts with '#'
            continue
        }
        let parts = line.split(";")
        let status = parts[1].trimAscii()
        if (status.startsWith("fully-qualified") || status.startsWith("component")) {
            let cp_strs = parts[0].trimAscii().split(" ")
            let emoji: StringBuilder = StringBuilder()
            for (s in cp_strs) {
                let cp_val = Rune(UInt32.parse("0X" + s))
                emoji.append(cp_val)
            }
            assert_width(emoji.toString(), 2u8, 2u8)
        }
    }
}

@Test
public func char_str_consistent(): Unit {
    for (cp in 0x20u32..=0x10FFFFu32) {
        if (cp >= 0xD800u32 && cp <= 0xDFFFFu32) { continue }
        let c = Rune(cp)
        let cw_opt = c.width()
        let cw = if (let Some(w) <- cw_opt) { w } else { 1u8 }
        @Expect(UInt8("${c}".width()), cw)
        let cw_opt_cjk = c.widthCjk()
        let cw_cjk = if (let Some(w) <- cw_opt_cjk) { w } else { 1u8 }
        @Expect(UInt8("${c}".widthCjk()), cw_cjk)
    }
}

@Test
public func test_khmer_coeng(): Unit {
    assert_width("ល", 1, 1)
    assert_width("ង", 1, 1)
    assert_width("លង", 2, 2)
    assert_width("ល្ង", 1, 1)
    for (cp in 0u32..=0x10FFFFu32) {
        if (cp >= 0xD800u32 && cp <= 0xDFFFFu32) { continue }
        let c = Rune(cp)
        let s = "\u{17D2}" + "${c}"
        let is_coeng = (cp >= 0x1780u32 && cp <= 0x1782u32) ||
            (cp >= 0x1784u32 && cp <= 0x1787u32) ||
            (cp >= 0x1789u32 && cp <= 0x178Cu32) ||
            (cp >= 0x178Eu32 && cp <= 0x1793u32) ||
            (cp >= 0x1795u32 && cp <= 0x1798u32) ||
            (cp >= 0x179Bu32 && cp <= 0x179Du32) ||
            cp == 0x17A0u32 || cp == 0x17A2u32 || cp == 0x17A7u32 ||
            (cp >= 0x17ABu32 && cp <= 0x17ACu32) || cp == 0x17AFu32
        if (is_coeng) {
            assert_width(s, 0u8, 0u8)
        } else {
            let cw_opt = c.width()
            let expected = if (let Some(w) <- cw_opt) { w } else { 1u8 }
            let cw_cjk_opt = c.widthCjk()
            let expected_cjk = if (let Some(w) <- cw_cjk_opt) { w } else { 1u8 }
            assert_width(s, expected, expected_cjk)
        }
    }
}

@Test
public func test_vs1_vs2_vs3(): Unit {
    assert_width_char(r'\u{FE00}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{FE01}', Some(0u8), Some(0u8))
    assert_width_char(r'\u{FE02}', Some(0u8), Some(0u8))
    for (cp in 0u32..=0x10FFFFu32) {
        if (cp >= 0xD800u32 && cp <= 0xDFFFFu32) { continue }
        let c = Rune(cp)
        let is_special = cp == 0x2018u32 || cp == 0x2019u32 || cp == 0x201Cu32 || cp == 0x201Du32
        if (is_special) {
            assert_width_char(c, Some(1u8), Some(2u8))
            assert_width("${c}" + "\u{FE00}", 1u8, 1u8)
            assert_width("${c}" + "\u{FE00}\u{FE01}", 1u8, 1u8)
            assert_width("${c}" + "\u{FE01}", 2u8, 2u8)
            assert_width("${c}" + "\u{FE01}\u{FE00}", 2u8, 2u8)
            assert_width("${c}" + "\u{FE02}", 1u8, 1u8)
            assert_width("${c}" + "\u{FE02}\u{FE01}", 1u8, 1u8)
        } else {
            let cw = c.width()
            let expected = if (let Some(value) <- cw) { value } else { 1u8 }
            @Expect(UInt8(("${c}" + "\u{FE00}").width()), expected)
            let cw_cjk = c.widthCjk()
            let expected_cjk = if (let Some(value) <- cw_cjk) { value } else { 1u8 }
            @Expect(UInt8(("${c}" + "\u{FE00}").widthCjk()), expected_cjk)
            @Expect(UInt8(("${c}" + "\u{FE01}").width()), expected)
            @Expect(UInt8(("${c}" + "\u{FE01}").widthCjk()), expected_cjk)
            @Expect(UInt8(("${c}" + "\u{FE02}").width()), expected)
            @Expect(UInt8(("${c}" + "\u{FE02}").widthCjk()), expected_cjk)
        }
    }
}

//cjlint-ignore -end description