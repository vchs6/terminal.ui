package cjtui.style
public enum Dimension <: Equatable<Dimension> { | Auto | Cells(Int64)
public operator func ==(other:Dimension):Bool { throw Exception("DECLARATION ONLY") } }
