package cjtui
public class ThemeRequest {
public prop id:UInt64 {get(){throw Exception("DECLARATION ONLY")}}
public func result():?ThemeResult {throw Exception("DECLARATION ONLY")}
}
