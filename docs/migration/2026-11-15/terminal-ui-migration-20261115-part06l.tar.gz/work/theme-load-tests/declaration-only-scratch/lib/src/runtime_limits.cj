package cjtui
public class RuntimeLimits {public init(pendingPosts!:Int64=4096){}}
