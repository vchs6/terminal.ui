package cjtui
public struct Cell {public let grapheme:String="";public let style:Style=Style();public let width:Int64=1;public let continuation:Bool=false;public let isTransparent:Bool=false}
