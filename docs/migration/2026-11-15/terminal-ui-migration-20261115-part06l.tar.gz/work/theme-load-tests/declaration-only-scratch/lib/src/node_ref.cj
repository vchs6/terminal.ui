package cjtui
public class NodeRef {
public func isValid():Bool {throw Exception("DECLARATION ONLY")}
public func sameNode(other:NodeRef):Bool {throw Exception("DECLARATION ONLY")}
public func notify(change:ChangeKind):Unit {throw Exception("DECLARATION ONLY")}
}
