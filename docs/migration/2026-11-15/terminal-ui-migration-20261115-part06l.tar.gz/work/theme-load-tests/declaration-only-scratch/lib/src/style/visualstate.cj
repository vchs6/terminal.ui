package cjtui.style
public enum VisualState <: Equatable<VisualState> { | Normal | Focused | Selected | Disabled
public operator func ==(other:VisualState):Bool { throw Exception("DECLARATION ONLY") } }
