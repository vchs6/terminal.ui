package cjtui.style
public enum TextOverflow <: Equatable<TextOverflow> { | Clip | Ellipsis
public operator func ==(other:TextOverflow):Bool { throw Exception("DECLARATION ONLY") } }
