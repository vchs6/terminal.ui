import os,pathlib,json,hashlib,datetime,stat,re,subprocess,collections
base=pathlib.Path('/workspace/work/keyboard-implementation/source');author=base.parent;own=pathlib.Path('/workspace/work/keyboard-execution');out=pathlib.Path('/workspace/work/validation');stem='ended-keyboard-author-targets-20261113'
before=out/(stem+'.before.json');after=out/(stem+'.deletion.json');assert not before.exists() and not after.exists()
allowed_gaps={122:(0,'runuser'),151:(2000,'rootlesskit'),161:(2000,'exe'),186:(2000,'slirp4netns'),195:(2000,'dockerd'),214:(2000,'containerd')}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def activity():
 active=[];gaps=[];opaque=[];opens=set()
 for proc in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   status=(proc/'status').read_text();uid=int(status.split('Uid:')[1].split()[0]);comm=(proc/'comm').read_text().strip()
   if status.split('State:')[1].strip().startswith('Z'):continue
   for kind in ['cwd','exe']:
    try:
     p=pathlib.Path(os.readlink(proc/kind));active.append(dict(pid=int(proc.name),uid=uid,comm=comm,kind=kind,path=str(p)))
    except FileNotFoundError:pass
    except PermissionError:
     gap=dict(pid=int(proc.name),uid=uid,comm=comm,kind=kind);gaps.append(gap)
     if allowed_gaps.get(int(proc.name))!=(uid,comm):opaque.append(gap)
   if uid==os.getuid():
    try:
     for fd in (proc/'fd').iterdir():
      try:opens.add(os.readlink(fd))
      except FileNotFoundError:pass
    except PermissionError:opaque.append(dict(pid=int(proc.name),uid=uid,comm=comm,kind='fd'))
  except (FileNotFoundError,ProcessLookupError):pass
 return active,gaps,opaque,opens
def nearest_project(p):
 for parent in p.parents:
  if not parent.is_relative_to(base):break
  if (parent/'cjpm.toml').is_file():return parent
 raise ValueError('no actual nearest parent manifest')
def basic(p):
 assert p.is_relative_to(base) and 'target' in p.relative_to(base).parts
 assert p.suffix in {'.o','.a','.cjo','.bc'} and not any(a.is_symlink() for a in [p,*p.parents])
 assert not any(a in {'.git','raw','cache','repository','sdk','SDK','node_modules','actualbins','actualbinaries','docs'} for a in p.relative_to(base).parts)
 s=p.lstat();assert stat.S_ISREG(s.st_mode);project=nearest_project(p);assert p.is_relative_to(project/'target')
 with p.open('rb') as fd:head=fd.read(20)
 if head[:4]==b'\x7fELF':
  endian='little' if head[5]==1 else 'big';assert int.from_bytes(head[16:18],endian) not in {2,3},'ELF executable/shared object protected'
 return project,s
# Bind all2826 sealed TASK116 originals by exact absolute path; never mutate index or report.
own_index=own/'stablemanifest.json';own_data=json.loads(own_index.read_text());assert len(own_data['original_files'])==2826
own_protected={str(own/x['path']) for x in own_data['original_files']}
# Inspect artifact index paths only, never author narrative/self-assessment reports.
index_bindings={};index_sources=[]
pattern=re.compile(r'''(?:/[^\s"'<>()[\]{},;]+|(?:\./)?(?:source|tests|examples|target)/[^\s"'<>()[\]{},;]+)\.(?:o|a|cjo|bc)(?=[\s"'<>()[\]{},;]|$)''')
for root,dirs,files in os.walk(author):
 rr=pathlib.Path(root);dirs[:]=[d for d in dirs if d not in {'.git','target','cache','repository','docs','node_modules'} and not (rr/d).is_symlink()]
 for n in files:
  p=rr/n
  if not (p.suffix=='.sha256' or 'manifest' in n or 'index' in n) or 'source-proof' in n or 'report' in n:continue
  if p.is_relative_to(author/'cleanup-01'):continue # A former cleanup inventory records omissions, not live artifact bindings.
  try:text=p.read_text()
  except (OSError,UnicodeError):continue
  matches=[]
  for m in pattern.finditer(text):
   token=m.group(0)
   options=[pathlib.Path(os.path.normpath(token))] if token.startswith('/') else [pathlib.Path(os.path.normpath(str(rootp/token))) for rootp in [p.parent,author,base]]
   for q in options:
    if q.is_relative_to(base):index_bindings.setdefault(str(q),[]).append(str(p));matches.append(str(q))
  index_sources.append(dict(path=str(p),sha256=digest(p),target_intermediate_bindings=sorted(set(matches))))
active,gaps,opaque,opens=activity();assert not opaque,repr(opaque)
psfile=out/(stem+'.processes.txt');assert not psfile.exists();psfile.write_text(subprocess.check_output(['ps','-eo','pid,uid,comm,args'],text=True));psfile.chmod(0o444)
files=[];skipped=[];seen=set()
for root,dirs,names in os.walk(base):
 p=pathlib.Path(root);dirs[:]=[d for d in dirs if d not in {'.git','raw','cache','repository','docs','node_modules'} and not (p/d).is_symlink()]
 if 'target' not in p.relative_to(base).parts:continue
 for n in names:
  f=p/n
  if f.suffix not in {'.o','.a','.cjo','.bc'} or str(f) in seen:continue
  seen.add(str(f))
  try:
   project,s=basic(f)
   if str(f) in own_protected or str(f) in index_bindings:raise ValueError('indexed original protected: '+repr(index_bindings.get(str(f),['TASK116'])))
   if str(f) in opens:raise ValueError('open file protected')
   if any(pathlib.Path(a['path']).is_relative_to(project) for a in active if a['uid']==os.getuid()):raise ValueError('active agent-owned project')
   h=digest(f);t=f.stat();assert(s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_ino,t.st_size,t.st_mtime_ns)
   files.append(dict(path=str(f),project=str(project),size=s.st_size,allocated_bytes=s.st_blocks*512,inode=s.st_ino,mtime_ns=s.st_mtime_ns,sha256=h))
  except (AssertionError,ValueError,OSError) as e:skipped.append(dict(path=str(f),reason=repr(e)))
record=dict(utc=utc(),authorization='Root resource-only GO; ended author source target regular intermediates only',root=str(base),suffixes=['.o','.a','.cjo','.bc'],task116_index_sha256=digest(own_index),task116_originals_protected=2826,index_binding_sources=index_sources,visibility_gaps=gaps,active_processes=active,process_capture=str(psfile),files=sorted(files,key=lambda x:x['path']),skipped=skipped,count=len(files),allocated_bytes=sum(x['allocated_bytes'] for x in files),available_bytes_before=os.statvfs(base).f_bavail*os.statvfs(base).f_frsize)
before.write_text(json.dumps(record,indent=2)+'\n');before.chmod(0o444);print('BEFORE',record['count'],record['allocated_bytes'],digest(before),flush=True)
result=dict(utc_start=utc(),before_path=str(before),before_sha256=digest(before),deleted=[],skipped=[],visibility_gaps=[])
for x in record['files']:
 p=pathlib.Path(x['path'])
 try:
  active,gaps,opaque,opens=activity();result['visibility_gaps']=gaps
  if opaque:raise ValueError('opaque task/compiler process; skip')
  if str(p) in opens:raise ValueError('currently open file')
  if any(pathlib.Path(a['path']).is_relative_to(pathlib.Path(x['project'])) for a in active if a['uid']==os.getuid()):raise ValueError('active agent-owned project')
  project,s=basic(p);assert str(project)==x['project'];assert(s.st_ino,s.st_size,s.st_mtime_ns)==(x['inode'],x['size'],x['mtime_ns']);assert digest(p)==x['sha256']
  t=p.lstat();assert(t.st_ino,t.st_size,t.st_mtime_ns)==(s.st_ino,s.st_size,s.st_mtime_ns);p.unlink();result['deleted'].append(x)
 except (AssertionError,ValueError,OSError) as e:result['skipped'].append(dict(path=str(p),reason=repr(e)))
result.update(utc_end=utc(),deleted_count=len(result['deleted']),deleted_allocated_bytes=sum(x['allocated_bytes'] for x in result['deleted']),available_bytes=os.statvfs(base).f_bavail*os.statvfs(base).f_frsize)
assert all(not pathlib.Path(x['path']).exists() for x in result['deleted'])
# Recheck sealed own originals, including binaries, screenshots, report and immutable index.
assert digest(own_index)==record['task116_index_sha256']
for x in own_data['original_files']:assert digest(own/x['path'])==x['sha256'],x['path']
result['verified_all_TASK116_originals_unchanged']=2826
# Artifact indices themselves remain unchanged.
for x in index_sources:assert digest(pathlib.Path(x['path']))==x['sha256'],x['path']
result['verified_author_index_files_unchanged']=len(index_sources)
after.write_text(json.dumps(result,indent=2)+'\n');after.chmod(0o444)
print(json.dumps({k:result[k] for k in ['deleted_count','deleted_allocated_bytes','available_bytes','verified_all_TASK116_originals_unchanged','verified_author_index_files_unchanged']}),flush=True);print('SKIPPED',len(result['skipped']),'before preflight skipped',len(skipped),'DELETION_SHA',digest(after),flush=True)
