import pathlib,os,json,hashlib,datetime,stat,subprocess,time,collections
out=pathlib.Path('/workspace/work/keyboard-execution/prepare')
roots=[pathlib.Path('/workspace/work')/s for s in ['theme-execution','theme-load-actual','theme-glyph-tests','glyph-tests-refresh','rich-text-regression-tests','colors-resize-fixture','dynamic-execution']]
allowed_gaps={122:(0,'runuser'),151:(2000,'rootlesskit'),161:(2000,'exe'),186:(2000,'slirp4netns'),195:(2000,'dockerd'),214:(2000,'containerd')}
before=out/'reserve-cleanup-before.json';after=out/'reserve-cleanup-deletion-receipt.json';assert not before.exists() and not after.exists()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def activity():
 active=[];gaps=[];opens=set();opaque=[]
 for proc in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   status=(proc/'status').read_text();uid=int(status.split('Uid:')[1].split()[0]);comm=(proc/'comm').read_text().strip()
   if status.split('State:')[1].strip().startswith('Z'):continue
   for kind in ['cwd','exe']:
    try:
     p=pathlib.Path(os.readlink(proc/kind))
     if str(p).startswith('/workspace/work/'):
      if kind=='exe':p=p.parent
      active.append(dict(pid=int(proc.name),uid=uid,comm=comm,kind=kind,path=str(p)))
    except FileNotFoundError:pass
    except PermissionError:
     gap=dict(pid=int(proc.name),uid=uid,comm=comm,kind=kind);gaps.append(gap)
     if allowed_gaps.get(int(proc.name))!=(uid,comm):opaque.append(gap)
   if uid==os.getuid():
    try:
     for fd in (proc/'fd').iterdir():
      try:opens.add(os.readlink(fd))
      except FileNotFoundError:pass
    except PermissionError:opaque.append(dict(pid=int(proc.name),comm=comm,kind='fd'))
  except (FileNotFoundError,ProcessLookupError):pass
 return active,gaps,opens,opaque
def eligible(x,active,opens):
 p=pathlib.Path(x['path']);project=pathlib.Path(x['project']);assert any(p.is_relative_to(r) for r in roots)
 assert p.is_relative_to(project/'target') and (project/'cjpm.toml').is_file()
 assert p.suffix in {'.o','.a','.cjo','.bc'} and not any(a.is_symlink() for a in [p,*p.parents])
 assert not any(part in {'cache','repository','.git','raw','actualbins','actualbinaries','sdk','dependencies'} for part in p.parts)
 assert str(p) not in opens
 for a in active:
  q=pathlib.Path(a['path'])
  if q.is_relative_to(project):raise ValueError('active project')
  # An active ancestor project also excludes nested consumers.
  if project.is_relative_to(q) and (q/'cjpm.toml').is_file():raise ValueError('active ancestor project')
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 assert (s.st_ino,s.st_size,s.st_mtime_ns)==(x['inode'],x['size'],x['mtime_ns'])
 assert digest(p)==x['sha256']
 t=p.lstat();assert (t.st_ino,t.st_size,t.st_mtime_ns)==(s.st_ino,s.st_size,s.st_mtime_ns)
 return t
inventory=out/'resource-inventory.json';source=json.loads(inventory.read_text());candidates=[x for x in source['proposed_cleanup_receipt'] if any(pathlib.Path(x['path']).is_relative_to(r) for r in roots)]
active,gaps,opens,opaque=activity();assert not opaque,repr(opaque)
psfile=out/('reserve-process-command-uid-'+str(time.time_ns())+'.txt');psfile.write_text(subprocess.check_output(['ps','-eo','pid,uid,comm,args'],text=True));psfile.chmod(0o444)
receipt=dict(utc=utc(),authorization='Root resource-only GO, exactly seven listed ended-unit roots; no product execution',roots=list(map(str,roots)),source_inventory_sha256=digest(inventory),active=active,visibility_gaps=gaps,process_capture=str(psfile),files=[],skipped=[])
for x in candidates:
 try:eligible(x,active,opens);receipt['files'].append(x)
 except (AssertionError,ValueError,OSError) as e:receipt['skipped'].append(dict(path=x['path'],reason=repr(e)))
receipt.update(count=len(receipt['files']),allocated_bytes=sum(x['allocated_bytes'] for x in receipt['files']))
before.write_text(json.dumps(receipt,indent=2)+'\n');before.chmod(0o444)
print('Immutable before receipt',len(receipt['files']),receipt['allocated_bytes'],digest(before),flush=True)
result=dict(utc_start=utc(),before_sha256=digest(before),deleted=[],skipped=[],visibility_gaps=[])
# Recheck all candidate metadata and hash using fresh process/open-file snapshot in bounded sub-batches.
for index,x in enumerate(receipt['files']):
 try:
  if index%50==0:active,gaps,opens,opaque=activity();result['visibility_gaps']=gaps
  if opaque:raise ValueError('opaque task/compiler activity: '+repr(opaque))
  eligible(x,active,opens)
  # Fresh cwd/exe snapshot before unlink; descriptor evidence above is refreshed each50 files.
  now,gg,oo,op=activity()
  if op:raise ValueError('new opaque task/compiler activity')
  p=pathlib.Path(x['path']);project=pathlib.Path(x['project'])
  if str(p) in oo or any(pathlib.Path(a['path']).is_relative_to(project) for a in now):raise ValueError('new active/open consumer')
  t=p.lstat();assert (t.st_ino,t.st_size,t.st_mtime_ns)==(x['inode'],x['size'],x['mtime_ns'])
  p.unlink();result['deleted'].append(x)
 except (AssertionError,ValueError,OSError) as e:result['skipped'].append(dict(path=x['path'],reason=repr(e)))
result.update(utc_end=utc(),deleted_count=len(result['deleted']),deleted_allocated_bytes=sum(x['allocated_bytes'] for x in result['deleted']),free_bytes=os.statvfs(out).f_bavail*os.statvfs(out).f_frsize)
after.write_text(json.dumps(result,indent=2)+'\n');after.chmod(0o444)
print(json.dumps({k:result[k] for k in ['deleted_count','deleted_allocated_bytes','free_bytes']}),flush=True);print('skipped',len(result['skipped']),'receipt_sha256',digest(after),flush=True)
