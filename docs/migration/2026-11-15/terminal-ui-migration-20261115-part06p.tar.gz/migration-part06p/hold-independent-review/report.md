# 06o 暂扣项独立复核

65 项全部有结论。64 项可按 queue.json 固定指纹纳入迁移，共 15915 字节。1 项由 Git 覆盖，继续暂扣 0 项。

| 原因 | 项数 | 判定依据 |
|---|---:|---|
| invalid_utf8 | 62 | 逐个将原件与两段测试生成语句静态重建的字节串全量比较。50 个为 29 字节，12 个为 32 字节。两组都刻意构造非法 UTF-8。 |
| credential_or_environment_pattern | 2 | 两份 Python 清理工具各有一条授权字段。语法树显示值是一句限定已结束工作范围的英文说明，写入带时间、清单和文件列表的审计记录。未发现认证材料。 |
| catalog_metadata_changed | 1 | README 当前工作区字节与 HEAD blob 完全一致，索引 stage 0 命中同一 blob，文件状态干净。原目录快照和当前元数据分别保存在 covered 数组。 |

## 测试生成依据

| 样本 | 生成语句 | 样本 SHA-256 |
|---|---|---|
| 29 字节 × 50 | /workspace/work/theme-implementation/source/tests/theme-loading/generate_inputs.py 第 39 行 | f20440af3c8bd834abd3b3f216416432d3a01450321285051aaa333443f30920 |
| 32 字节 × 12 | /workspace/work/theme-tests/source/tests/themes/generate_inputs.py 第 15 行 | fc3792e68ade0caaed571ee3bf5dda5463348a29418f76dbb6421000e3431a9c |

29 字节样本在 TOML 的名称字段内嵌入一个非法字节。32 字节样本在公共有效前缀后添加包含两个非法字节的注释。两处生成代码均按字面量和字符串编码静态求值。

## 两份清理工具

- reserve-cleanup.py 第 55 行把范围说明写入清理回执。第 14 行是进程目录遍历语句。
- cleanup-ended-keyboard-author-targets-20261113.py 第 85 行同样记录范围说明。第 62–63 行使用名为 token 的局部变量保存正则捕获的路径，再交给路径标准化函数处理。

只读取固定队列列出的原件、两份测试生成器和指定 README 的 Git 记录。未执行候选脚本或生成器，也未读取脚本引用的运行时进程或环境数据。可纳入的 64 项与原队列的源路径、归档路径、大小、SHA-256、权限和纳秒修改时间均一致。

## Git 覆盖

仓库内路径为 docs/migration/2026-11-15/README.md。核对时 HEAD 为 ff40e4fb5be5e2751ab4d93adb1a8630edd9178f，blob 为 30cd9b7ce2afe62b643330125627edeb04eda40c。清单记录的是此次核对时点，该文件不进入 payload_files。
