"""Restore one original by id, without overwriting an existing path."""
import gzip,hashlib,json,os,sys
from pathlib import Path
base=Path(__file__).resolve().parent
row=next(r for r in json.load(open(base/'restore-map-final.json'))['rows'] if r['id']==int(sys.argv[1]))
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
assert digest(row['gzip_path'])==row['gzip_sha256']
h=hashlib.sha256();n=0
with gzip.open(row['gzip_path'],'rb') as source,open(row['path'],'xb') as dest:
 while b:=source.read(1048576):dest.write(b);h.update(b);n+=len(b)
 assert h.hexdigest()==row['sha256'] and n==row['size']
 os.fchmod(dest.fileno(),row['mode']);dest.flush();os.fsync(dest.fileno())
os.utime(row['path'],ns=(row['mtime_ns'],row['mtime_ns']))
fd=os.open(Path(row['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(row['path'])
