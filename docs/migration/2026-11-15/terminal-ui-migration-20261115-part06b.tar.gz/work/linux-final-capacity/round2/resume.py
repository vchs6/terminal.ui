import sys
sys.dont_write_bytecode=True
import importlib.util,json,os,gzip,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('prior','/workspace/work/linux-final-capacity/custody.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
BASE=Path(__file__).resolve().parent
def write(name,obj):prior.durable_json(BASE/name,obj)
def scan():
 try:return prior.proc_scan(rows)
 except AssertionError as e:
  limits=e.args[0] if e.args else None
  if not isinstance(limits,list):raise
  unknown=[x for x in limits if x.get('comm')=='python']
  if not unknown:raise
  pids=sorted({x['pid'] for x in unknown});statuses=[]
  for pid in pids:
   record={'pid':pid,'comm':'python'}
   try:record['limited_status']=[x for x in Path('/proc/'+pid+'/status').read_text().splitlines() if x.startswith(('Name:','State:','PPid:','Uid:'))]
   except FileNotFoundError:record['already_exited']=True
   statuses.append(record)
  write('transient-%d.json'%time.time_ns(),{'status':'Paused before mutation for separate-tool exit recheck','processes':statuses,'proc_limits':limits})
  print(json.dumps({'paused_transient_pids':pids}),flush=True);sys.exit(75)
inv=json.load(open(BASE/'inventory.json'));rows=inv['rows'];previous=[]
for row in rows:
 if (BASE/'receipts'/('%02d-unlinked.json'%row['id'])).exists():previous.append(json.load(open(BASE/'receipts'/('%02d-verified-before-unlink.json'%row['id']))))
assert len(rows)==21 and len(previous)>=10
assert not os.path.exists('/proc/2061544')
snapshot=scan();write('proc-resume-before-%d.json'%time.time_ns(),snapshot)
receipts=list(previous)
for row in rows[len(previous):]:
 if prior.free()>=700*1048576:break
 assert prior.free()>64*1048576
 before=prior.identity(row);scan_before=scan();archive=Path(row['gzip_path'])
 if archive.exists():
  # A prior paused attempt may have durably archived this still-present original.
  assert not (BASE/'receipts'/('%02d-verified-before-unlink.json'%row['id'])).exists()
  assert prior.sha_file(archive,gzip.open)==(row['sha256'],row['size'])
 else:
  with open(archive,'xb') as dest:
   with gzip.GzipFile(filename='',mode='wb',compresslevel=6,mtime=0,fileobj=dest) as z:
    with open(row['path'],'rb') as source:
     while b:=source.read(1048576):z.write(b)
   dest.flush();os.fsync(dest.fileno())
  fd=os.open(archive.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 assert archive.stat().st_size==row['forecast_gzip_bytes']
 assert prior.sha_file(archive,gzip.open)==(row['sha256'],row['size'])
 after=prior.identity(row);assert before.st_mtime_ns==after.st_mtime_ns==row['mtime_ns']
 scan2=scan()
 receipt={**row,'gzip_sha256':prior.sha_file(archive)[0],'gzip_bytes':archive.stat().st_size,'gzip_allocated':archive.stat().st_blocks*512,'verified_decompressed_sha256':row['sha256'],'verified_decompressed_bytes':row['size'],'proc_before':scan_before,'proc_before_unlink':scan2,'verification_time_ns':time.time_ns(),'reused_verified_pending_gzip':row['id']==11,'provenance':'Current bytes only; original logical indices unchanged; this receipt is durable restore alias before unlink.'}
 write('receipts/%02d-verified-before-unlink.json'%row['id'],receipt)
 os.unlink(row['path']);fd=os.open(Path(row['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 write('receipts/%02d-unlinked.json'%row['id'],{'path':row['path'],'absent':not os.path.lexists(row['path']),'time_ns':time.time_ns()})
 receipts.append(receipt);print('migrated',row['id'],flush=True)
write('restore-map-final.json',{'format':1,'provenance':'Current bytes only; original logical indices unchanged; previous20 and partial round2 artifacts immutable.','restore_helper':str(BASE/'restore-final.py'),'rows':receipts})
entries=[]
for r in receipts:
 assert not os.path.lexists(r['path']);assert prior.sha_file(r['gzip_path'])[0]==r['gzip_sha256']
 rr=[]
 for suffix in ['verified-before-unlink','unlinked']:
  p=BASE/'receipts'/('%02d-%s.json'%(r['id'],suffix));rr.append({'path':str(p),'sha256':prior.sha_file(p)[0]})
 entries.append({'id':r['id'],'original':r['path'],'gzip_path':r['gzip_path'],'gzip_sha256':r['gzip_sha256'],'receipts':rr})
write('receipt-index-final.json',{'restore_map':str(BASE/'restore-map-final.json'),'restore_map_sha256':prior.sha_file(BASE/'restore-map-final.json')[0],'rows':entries})
summary={'count':len(receipts),'scope_exhausted':len(receipts)==len(rows),'skipped_ancestry':inv['skipped'],'original_bytes':sum(r['size'] for r in receipts),'original_allocated':sum(r['allocated'] for r in receipts),'gzip_bytes':sum(r['gzip_bytes'] for r in receipts),'gzip_allocated':sum(r['gzip_allocated'] for r in receipts),'net_file_reclaim':sum(r['allocated']-r['gzip_allocated'] for r in receipts),'free_after':prior.free(),'receipt_index_sha256':prior.sha_file(BASE/'receipt-index-final.json')[0],'restore_map_sha256':prior.sha_file(BASE/'restore-map-final.json')[0],'partial_artifacts':'Unchanged; transient2061544 absent before resume; no blanket python allowlist.'}
write('completion-final.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='skipped_ancestry'}))
