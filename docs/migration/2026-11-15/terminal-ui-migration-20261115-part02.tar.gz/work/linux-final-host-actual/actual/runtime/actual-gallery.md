# Original actual-host captures

These are original PNGs from exit-zero fixed commands. Full host acceptance remains pending; see [progress index](progress-index.json).

xterm: showcase-fullCycle-80x24 — Gallery | Classic
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/xterm-attempt1/showcase-fullCycle-80x24/original-1794710038746817527.png) · SHA256 `6e6a2ced68e434b71c74e3025e6b534b56dc4d5c0892e2cebbef07a67a3509d0`

vte: showcase-fullCycle-80x24 — Gallery | Classic
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/vte-attempt2/showcase-fullCycle-80x24/original-1794710494706978717.png) · SHA256 `4de23e14a44332979f179207f99779689537bf721535a2a2c4a8cc706f533b69`

tmux: showcase-fullCycle-80x24 — Gallery | Classic
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/tmux-attempt2/showcase-fullCycle-80x24/original-1794710551391235837.png) · SHA256 `a46f7de7500fff4de3d7a37555641b0a078c75fb34f870c4245f82459d79cfa5`

screen: showcase-fullCycle-80x24 — Gallery | Classic
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/screen-attempt1/showcase-fullCycle-80x24/original-1794710414642489353.png) · SHA256 `6e6a2ced68e434b71c74e3025e6b534b56dc4d5c0892e2cebbef07a67a3509d0`

ssh: showcase-fullCycle-80x24 — Gallery | Classic
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/ssh-attempt3/showcase-fullCycle-80x24/original-1794710837161074222.png) · SHA256 `6e6a2ced68e434b71c74e3025e6b534b56dc4d5c0892e2cebbef07a67a3509d0`


VT R3 bootstrap: original real tty1 80×25 Tasks frame. Kernel mapping ACK timed out afterward; no native exit/restoration acceptance is claimed.
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/vt-bootstrap-r3/vt-run/original-1794712992176355436.png) · SHA256 `06e9c152d289eaf5fdfe0ce2491550f4eb5ffb1a20dea2d472bbc3425bb951b7`


PASTE002 interaction cases: complete fixed case command exit0 on each variable host; final Linux acceptance remains pending.

xterm: multiline paste is editor data
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/xterm-attempt2/composition-interactions-80x24/original-1794715730618747492.png) · SHA256 `528fc72e23e356aadf4653ae9f63de083812cceb5096035e899ac845f093a40f`

vte: multiline paste is editor data
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/vte-attempt4/composition-interactions-80x24/original-1794715780786337060.png) · SHA256 `99488f901c8513b62d3609ac172812e6000b1d4792b3029f9b5c23dcf065c687`

tmux: multiline paste is editor data
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/tmux-attempt3/composition-interactions-80x24/original-1794715821409761258.png) · SHA256 `5421d1f690aa889d40ff6df48e40324c726146cca843ef830b9e6d76b54f9937`

screen: multiline paste is editor data
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/screen-attempt3/composition-interactions-80x24/original-1794715872445057476.png) · SHA256 `528fc72e23e356aadf4653ae9f63de083812cceb5096035e899ac845f093a40f`

ssh: multiline paste is editor data
[Original PNG](/workspace/work/linux-final-host-actual/actual/runtime/ssh-attempt5/composition-interactions-80x24/original-1794715952924259580.png) · SHA256 `528fc72e23e356aadf4653ae9f63de083812cceb5096035e899ac845f093a40f`

