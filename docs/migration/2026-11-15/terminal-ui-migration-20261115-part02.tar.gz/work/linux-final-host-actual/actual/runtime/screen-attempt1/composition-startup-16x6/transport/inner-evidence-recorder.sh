#!/bin/sh
set -eu
: "${TASK066_INNER_STATE:?}" "${TASK066_FIXTURE:?}"
record() { printf '%s_size=%s\n%s_termios=%s\n' "$1" "$(stty size)" "$1" "$(stty -g)" >> "$TASK066_INNER_STATE"; }
: > "$TASK066_INNER_STATE"
record ready
printf 'tty=%s\n' "$(tty)" >> "$TASK066_INNER_STATE"
trap 'record exit; exit 130' HUP INT TERM
python3 "$C008_HOST_PROBE" "$C008_OUT/cursor-before.json"
date -u +%FT%TZ > "$C008_OUT/app-start.utc"
set +e
"$TASK066_FIXTURE" < /dev/tty &
app_pid=$!
printf '%s\n' "$app_pid" > "$C008_OUT/app.pid"
python3 "$C008_PID_RECORDER" "$app_pid" "$C008_OUT/app-identity.json"
wait "$app_pid"
status=$?
set -e
record exit
date -u +%FT%TZ > "$C008_OUT/app-exit.utc"
printf '%s\n' "$status" > "$C008_OUT/app.exit"
python3 "$C008_HOST_PROBE" "$C008_OUT/cursor-after.json"
printf 'exit_status=%s\n' "$status" >> "$TASK066_INNER_STATE"
exit "$status"
