from pathlib import Path
import base64,hashlib,json,os,re,shutil,signal,subprocess,threading,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';D=A/'vt-control-diagnostic-once';D.mkdir();base=R/'private/vt-guest-r3';root=R/'private/vt-guest-control-diag';O=Path('/workspace/work/linux-final-host-execution/operator');cap=256*1024;h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env={k:os.environ[k] for k in ['PATH','USER','LOGNAME'] if k in os.environ};env.update(C008_ROOT_ACTUAL_GO='1',C008_VT_NEW_GUEST_ROOT=str(root),VT_INITRD=str(D/'diagnostic.cpio.gz'))
subprocess.run(['python3',str(A/'guard.py'),str(D/'host-guard.json'),str(A/'admission-vt-r3.json')],check=True)
old=[dict(path=str(p),sha256=h(p)) for p in base.rglob('*') if p.is_file() and not p.is_symlink()];old.extend(dict(path=str(p),sha256=h(p)) for p in [A/'vt-preparation-r3/final-public-r3.cpio.gz',A/'vt-preparation-r3/vt-product-supervisor',A/'vt-preparation-r3/closure-r3.json'])
forecast=(A/'vt-preparation-r3/final-public-r3.cpio.gz').stat().st_size+4*1048576;free=shutil.disk_usage(R).free;assert free-forecast>64*1048576
supervisor_argv=['/usr/bin/strace','-ttt','-yy','-s','64','-e','trace=open,openat,fcntl,ioctl,poll,ppoll,read,close','-o','/dev/ttyS2','/vt-product-supervisor']
(D/'allocation-and-overlay-plan.json').write_text(json.dumps(dict(free_before=free,new_allocation_forecast=forecast,old_files=old,supervisor_diagnostic_argv=supervisor_argv,supervisor_follow_children=False,supervisor_write_syscalls=False,array_abbreviation='default; no -v',string_limit=64,sink_cap_bytes=cap,init_overlay_only=True,source_app_or_operator_edits=False),indent=2)+'\n')
root.mkdir()
for p in sorted(base.rglob('*')):
 relative=p.relative_to(base);dst=root/relative
 if relative.as_posix() in ['init','operator-runtime-closure.json']:continue
 if p.is_symlink():dst.symlink_to(os.readlink(p))
 elif p.is_dir():dst.mkdir(exist_ok=True)
 elif p.is_file():os.link(p,dst)
original=(base/'init').read_text();anchor="exec /vt-product-supervisor ";assert original.count(anchor)==1
replacement='exec '+' '.join(supervisor_argv[:-1])+' /vt-product-supervisor '
(root/'init').write_text(original.replace(anchor,replacement));(root/'init').chmod(0o755)
(root/'operator-runtime-closure.json').write_text(json.dumps(dict(kind='DIAGNOSTIC_ONLY_INIT_SUPERVISOR_TRACE_OVERLAY',base=str(base),original_init_sha256=h(base/'init'),diagnostic_init_sha256=h(root/'init'),supervisor_elf_sha256=h(root/'vt-product-supervisor'),inner_app_trace_flags='exact admitted R3 native ELF unchanged',independent_trace_export='/dev/ttyS2 -> dedicated QEMU pipe -> capped host transcript'),indent=2)+'\n')
assert shutil.disk_usage(R).free-(A/'vt-preparation-r3/final-public-r3.cpio.gz').stat().st_size-2*1048576>64*1048576
p=subprocess.run(['python3',str(O/'pack-vt-guest.py')],env=env,capture_output=True);(D/'pack.stdout').write_bytes(p.stdout);(D/'pack.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
run=D/'vt-run';run.mkdir();prefix=run/'supervisor-trace';os.mkfifo(str(prefix)+'.in',0o600);os.mkfifo(str(prefix)+'.out',0o600);fdin=os.open(str(prefix)+'.in',os.O_RDWR|os.O_NONBLOCK);fdout=os.open(str(prefix)+'.out',os.O_RDONLY|os.O_NONBLOCK)
sink=D/'supervisor-syscalls.raw';stop=threading.Event();overflow=threading.Event();sinkstate=dict(bytes_written=0,observed_overflow_bytes=0,cap_reached=False,reader_error=None)
def receive():
 try:
  with sink.open('xb') as f:
   while not stop.is_set():
    try:b=os.read(fdout,4096)
    except BlockingIOError:b=b''
    if not b:time.sleep(.002);continue
    remaining=cap-sinkstate['bytes_written'];f.write(b[:remaining]);f.flush();sinkstate['bytes_written']+=min(len(b),remaining)
    if len(b)>=remaining:sinkstate['cap_reached']=True;sinkstate['observed_overflow_bytes']+=max(0,len(b)-remaining);overflow.set();break
 except BaseException as e:sinkstate['reader_error']=repr(e);overflow.set()
thread=threading.Thread(target=receive);thread.start()
HOST=Path('/workspace/work/linux-console-hosts');qemu=HOST/'hosts/debian/usr/bin/qemu-system-x86_64';cmd=[str(qemu),'-accel','tcg','-cpu','max','-machine','pc','-m','512','-smp','1','-no-reboot','-nic','none','-L',str(HOST/'hosts/debian/usr/share/qemu'),'-bios',str(HOST/'hosts/debian/usr/share/seabios/bios-256k.bin'),'-device','VGA,romfile='+str(HOST/'hosts/debian/usr/share/seabios/vgabios-stdvga.bin'),'-vga','none','-display','none','-serial','file:'+str(run/'vt-serial.log'),'-chardev','socket,id=probe,path='+str(run/'control.sock')+',server=on,wait=off','-serial','chardev:probe','-chardev','pipe,id=supervisor_diag,path='+str(prefix),'-serial','chardev:supervisor_diag','-qmp','unix:'+str(run/'vt-qmp.sock')+',server=on,wait=off','-kernel',str(HOST/'packages/linux'),'-initrd',env['VT_INITRD'],'-append','console=tty0 console=ttyS0,115200 rdinit=/init nomodeset vga=normal loglevel=4 scene=composition'];env['LD_LIBRARY_PATH']=str(HOST/'hosts/debian/usr/lib/x86_64-linux-gnu')
child=subprocess.Popen(cmd,env=env,stdout=(D/'qemu.stdout').open('wb'),stderr=(D/'qemu.stderr').open('wb'),start_new_session=True);record=dict(kind='ONE_BOUNDED_DIAGNOSTIC_NOT_COMMON_CASE',start_ns=time.time_ns(),qemu_pid=child.pid,qemu_argv=cmd,supervisor_argv=supervisor_argv,records=[],frame_bound_seconds=15,ack_bound_seconds=30,requested_map_ascii_hex=b'm1b5b32317e\n'.hex(),cap_bytes=cap,app_elf_sha256=h(root/'apps/composition'),supervisor_elf_sha256=h(root/'vt-product-supervisor'),initrd_sha256=h(env['VT_INITRD']),old_bytes_preserved=None,native_exit_proved=False,error=None)
def bridge(request,label):
 helpercmd=['python3',str(O/'vt-transport.py'),json.dumps(dict(request,dir=str(D)))];p=subprocess.Popen(helpercmd,env=env,stdout=(D/(label+'.stdout')).open('wb'),stderr=(D/(label+'.stderr')).open('wb'),start_new_session=True);end=time.monotonic()+40
 while p.poll() is None:
  if overflow.is_set() or time.monotonic()>end or shutil.disk_usage(R).free<12*1048576:
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3);raise RuntimeError('diagnostic cap/reader/outer bounded guard; no acceptance')
  time.sleep(.01)
 record['records'].append(dict(label=label,request=request,argv=helpercmd,helper_pid=p.pid,exit=p.returncode,ended_ns=time.time_ns()));assert p.returncode==0,(label,(D/(label+'.stderr')).read_text());return json.loads((D/(label+'.stdout')).read_text())
try:
 bridge({'op':'identify'},'identify');deadline=time.monotonic()+15;index=0
 while True:
  result=bridge({'op':'wire'},'initial-wire-'+str(index));index+=1
  if b'Tasks' in base64.b64decode(result['wireBase64']):record['initial_frame_within_15s']=True;break
  assert time.monotonic()<deadline,'unchanged 15s initial-frame bound';time.sleep(.1)
 bridge({'op':'capture'},'initial-capture');bridge({'op':'input','hex':'1b5b32317e'},'single-map-attempt')
 record['map_ack_seen']=True
 child.wait(timeout=40);record['native_exit_candidate']=bridge({'op':'wire'},'final-wire')
except BaseException as e:record['error']=repr(e)
finally:
 if child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 time.sleep(.1);stop.set();thread.join(timeout=2);os.close(fdin);os.close(fdout)
 record.update(end_ns=time.time_ns(),qemu_exit=child.returncode,sink=sinkstate,truncated_or_cap=sinkstate['cap_reached'] or sinkstate['reader_error'] is not None or (sink.exists() and bool(sink.read_bytes()) and not sink.read_bytes().endswith(b'\n')),final_acceptance=False,free_bytes=shutil.disk_usage(R).free)
 for row in old:assert h(row['path'])==row['sha256'],row['path']
 record['old_bytes_preserved']=True;(D/'diagnostic-record.json').write_text(json.dumps(record,indent=2)+'\n')
 files=[p for p in D.rglob('*') if p.is_file() and p.name!='diagnostic-index.json'];(D/'diagnostic-index.json').write_text(json.dumps(dict(status='DIAGNOSTIC_PREFIX_FAILURE' if record['error'] or record['truncated_or_cap'] else 'DIAGNOSTIC_ATTEMPT_NOT_ACCEPTANCE',record=str(D/'diagnostic-record.json'),files=[dict(path=str(p),bytes=p.stat().st_size,mode=oct(p.stat().st_mode&0o777),sha256=h(p)) for p in files],final_acceptance=False),indent=2)+'\n');print(json.dumps(dict(index=str(D/'diagnostic-index.json'),sha256=h(D/'diagnostic-index.json'),record=record),indent=2),flush=True)
