from pathlib import Path
import json,hashlib,sys,shutil,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ad=json.loads((R/'actual-admission.json').read_text());checked=[];expected_transport_count=31
if len(sys.argv)>2:
 supplement=json.loads(Path(sys.argv[2]).read_text());expected_transport_count=supplement.get('expected_transport_count',31);ad['admitted_artifacts'].update(supplement['admitted_artifacts']);ad['transport_full_source_manifest']=supplement['transport_full_source_manifest']
for p,s in ad['admitted_artifacts'].items():assert h(p)==s,p;checked.append(dict(path=p,sha256=s))
x=json.loads(Path(ad['transport_full_source_manifest']).read_text())
for row in x['source']:
 for p in [row['path'],row['snapshot']]:assert h(p)==row['sha256'],p;checked.append(dict(path=p,sha256=row['sha256']))
assert len(x['source'])==expected_transport_count
index=json.loads(Path('/workspace/work/linux-final-host-test-contract/index.json').read_text())
for row in index['files']:
 if row['role'] in ['fixed-source-input','test-contract-output','fixed-transport-interface']:
  p=Path('/workspace/work/linux-final-host-test-contract')/row['path'];assert h(p)==row['sha256'],str(p);checked.append(dict(path=str(p),sha256=row['sha256']))
proof=json.loads((A/'package-source-proof.json').read_text());assert h(proof['archive'])==proof['sha256'];checked.append(dict(path=proof['archive'],sha256=proof['sha256']))
for row in proof['members']:
 p=R/'source'/row['member'];assert h(p)==row['sha256'],str(p);checked.append(dict(path=str(p),sha256=row['sha256']))
for group in json.loads((A/'final-provenance.json').read_text())['scopes'].values():
 for row in group['files']:assert h(row['path'])==row['sha256'],row['path'];checked.append(dict(path=row['path'],sha256=row['sha256']))
setup=json.loads((A/'setup-receipt.json').read_text())
for pair in setup['elf_placements']:
 for row in pair['original_retained'],pair['conventional_copy']:assert h(row['path'])==row['sha256'];checked.append(dict(path=row['path'],sha256=row['sha256']))
for row in setup['external_fixed_test_fixtures']:assert h(row['path'])==row['sha256'];checked.append(dict(path=row['path'],sha256=row['sha256']))
tools=json.loads((R/'tools/acquisition-receipt.json').read_text())
for row in tools['necessary_runtime_closure']+list(tools['absolute_tool_paths'].values()):assert h(row['path'])==row['sha256'];checked.append(dict(path=row['path'],sha256=row['sha256']))
assert shutil.disk_usage(R).free>64*1048576
out=Path(sys.argv[1]);out.write_text(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),admission_sha256=h(R/'actual-admission.json'),checked=checked,free_bytes=shutil.disk_usage(R).free,status='PINNED'),indent=2)+'\n');print(len(checked),'pins verified')
