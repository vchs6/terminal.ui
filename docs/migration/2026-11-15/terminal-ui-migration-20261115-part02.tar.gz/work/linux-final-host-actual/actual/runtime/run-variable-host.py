from pathlib import Path
import hashlib,json,os,shutil,signal,socket,subprocess,sys,time,shlex
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';P=R/'source/cjtui-0.0.0';O=Path('/workspace/work/linux-final-host-execution/operator');host=sys.argv[1];attempt=1
while (A/(host+'-attempt'+str(attempt))).exists():attempt+=1
H=A/(host+'-attempt'+str(attempt));H.mkdir();private=R/'private'/H.name;private.mkdir();(private/'runtime').mkdir(mode=0o700)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
subprocess.run(['python3',str(A/'guard.py'),str(H/'host-guard.json')],check=True)
env={k:os.environ[k] for k in ['PATH','USER','LOGNAME','SHELL'] if k in os.environ};env.update(HOME=str(private),XDG_CONFIG_HOME=str(private/'config'),XDG_CACHE_HOME=str(private/'cache'),XDG_RUNTIME_DIR=str(private/'runtime'),LANG='C.UTF-8',LC_ALL='C.UTF-8',C008_ROOT_ACTUAL_GO='1',C008_147_ADMISSION='/workspace/work/rendering-benchmark-acceptance/index.json',C008_PROVENANCE=str(R/'actual/final-provenance.json'),C008_SOURCE=str(P),C008_HOST_KIND=host,C008_HOST_ID='C008 independent '+host,C008_DISPLAY_OWNED='1',C008_XTERM='/workspace/work/cross-terminal-recon/hosts/xterm/usr/bin/xterm',C008_XFCE='/usr/bin/xfce4-terminal',C008_TMUX='/workspace/work/linux-console-hosts/hosts/debian/usr/bin/tmux',C008_SCREEN='/workspace/work/linux-console-hosts/hosts/debian/usr/bin/screen',C008_SSH='/usr/bin/ssh',C008_CLIPBOARD_OWNER=str(R/'tools/xclip-0.13-4/usr/bin/xclip'),C008_NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node',C008_INFOCMP='/usr/bin/infocmp',C008_TPUT='/usr/bin/tput',C008_LOCALE='/usr/bin/locale',C008_STTY='/usr/bin/stty',LD_LIBRARY_PATH='/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative:/workspace/work/validation/sdk/cangjie/tools/lib')
# Choose only an unused owned display; never attach to a user's display.
number=248
while Path(f'/tmp/.X11-unix/X{number}').exists() or Path(f'/tmp/.X{number}-lock').exists():number+=1
assert number<280;env['DISPLAY']=':'+str(number)
xcmd=['/usr/bin/Xorg',env['DISPLAY'],'-config','/workspace/work/cross-terminal-recon/probes/xorg-dummy.conf','-nolisten','tcp','-noreset','-logfile',str(H/'xorg.log')]
(H/'xorg-command.json').write_text(json.dumps(xcmd)+'\n');xp=subprocess.Popen(xcmd,env=env,stdout=(H/'xorg.stdout').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
results=[];server=None
try:
 deadline=time.monotonic()+15
 while time.monotonic()<deadline:
  q=subprocess.run(['xdpyinfo'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  if q.returncode==0:break
  assert xp.poll() is None,'owned Xorg failed';time.sleep(.1)
 else:raise RuntimeError('owned Xorg readiness timeout')
 if host=='vte':
  terminal=private/'config/xfce4/terminal';terminal.mkdir(parents=True)
  (terminal/'terminalrc').write_text('[Configuration]\nShortcutsNoMenukey=TRUE\nMiscMenubarDefault=FALSE\nMiscToolbarDefault=FALSE\nMiscAlwaysShowTabs=FALSE\nScrollingBar=TERMINAL_SCROLLBAR_NONE\n')
  (terminal/'accels.scm').write_text('(gtk_accel_path "<Actions>/terminal-window/contents" "")\n')
 if host=='tmux':
  cfg=private/'tmux.conf';cfg.write_text('set -g status off\n# Owned fixed app PTY geometry; ROOT direction after first raw23x80 finding\n');env.update(C008_TMUX_SOCKET=str(private/'tmux.sock'),C008_TMUX_CONFIG=str(cfg))
 if host=='screen':
  cfg=private/'screenrc';cfg.write_text('startup_message off\nescape ^Tt\n# Own prefix moved from CtrlA per supplied official screen.1; forward public editor CtrlA unchanged\n');d=private/'screen-sockets';d.mkdir(mode=0o700);env.update(C008_SCREEN_CONFIG=str(cfg),C008_SCREEN_SESSION='c008-owned',SCREENDIR=str(d))
 # SSH setup is supplied in separate owned setup step before this host run.
 if host=='ssh':env.update(json.loads((R/'private/ssh-environment.json').read_text()))
 (H/'host-config.json').write_text(json.dumps(dict(environment={k:v for k,v in env.items() if k!='PATH'},config_files=[dict(path=str(f),sha256=h(f)) for f in private.rglob('*') if f.is_file()]),indent=2)+'\n')
 # Real same-kind/config host bootstrap, no fabricated TERM or COLORTERM.
 boot=H/'bootstrap';env.update(C008_BOOTSTRAP_DIR=str(boot),C008_LAUNCHER=str(A/'bootstrap-launcher.sh'),C008_GEOMETRY='80x24')
 if host=='ssh':env['C008_BINARY']=str(A/'bootstrap-launcher.sh');env['C008_OUT']=str(H/'bootstrap-transport')
 cmd=['bash',str(O/'launch-host.sh'),host];p=subprocess.run(cmd,env=env,cwd=P,capture_output=True,timeout=40);(H/'bootstrap.stdout').write_bytes(p.stdout);(H/'bootstrap.stderr').write_bytes(p.stderr);assert p.returncode==0,('bootstrap host exit',p.returncode,p.stderr.decode())
 expected=boot/'profile/profile-envelope.json';assert expected.is_file(),str(expected);env.update(C008_EXPECTED_PROFILE=str(expected),C008_LAUNCHER=str(A/'public-launcher.sh'))
 
 if host=='vte':
  preflight=H/'preflight-16x6';pe=env.copy();pe.update(C008_LAUNCHER=str(A/'bootstrap-launcher.sh'),C008_BOOTSTRAP_DIR=str(preflight),C008_GEOMETRY='16x6')
  q=subprocess.run(['bash',str(O/'launch-host.sh'),host],env=pe,cwd=P,capture_output=True,timeout=40);(H/'preflight16.stdout').write_bytes(q.stdout);(H/'preflight16.stderr').write_bytes(q.stderr)
  assert q.returncode==0 and (preflight/'profile/actual-stdout-size.stdout').read_text().strip()=='6 16','actual VTE 16x6 viewport preflight'
 bootstrapfacts=json.loads((boot/'profile/facts.json').read_text());keys=['term','colorterm','terminfoKnown','colors','RGB','Tc','ncv','attributeStrings','failureReason','nativeVt','mapKnown']
 assert (boot/'profile/actual-stdout-size.stdout').read_text().strip()=='24 80','owned bootstrap requested app PTY size must match before full-grid cases'
 cases=[('composition','startup',80,24),('composition','startup',40,12),('composition','startup',16,6),('composition','interactions',80,24),('showcase','startup',80,24),('showcase','startup',40,12),('showcase','startup',16,6),('showcase','fullCycle',80,24),('showcase','retainedState',80,24),('showcase','fileReload',80,24),('showcase','absentFile',80,24),('modal','previewSwitch',80,24),('modal','popupSwitch',80,24)]
 excluded=set(os.environ.get('C008_CASE_EXCLUDE','').split(','));(H/'blocked-case-selection.json').write_text(json.dumps(dict(excluded=sorted(excluded-{''}),reason='Known affected scope pending root/role resolution; no same-source failing retries'),indent=2)+'\n')
 for group,name,w,height in cases:
  if group+'/'+name in excluded:continue
  included=os.environ.get('C008_CASE_INCLUDE')
  if included and group+'/'+name not in included.split(','):continue
  label=f'{group}-{name}-{w}x{height}'
  label_included=os.environ.get('C008_CASE_LABEL_INCLUDE')
  if label_included and label not in label_included.split(','):continue
  out=H/label;log=H/(label+'.stdout');err=H/(label+'.stderr');cmd=['bash',str(O/'run-admitted-binding.sh'),group,name,str(out),str(w),str(height)]
  start=time.time_ns();before=shutil.disk_usage(R).free;minimum=before;captures=set();profile_errors=[]
  child=subprocess.Popen(cmd,env=env,cwd=P,stdout=log.open('wb'),stderr=err.open('wb'),start_new_session=True);deadline=time.monotonic()+180
  while child.poll() is None:
   free=shutil.disk_usage(R).free;minimum=min(minimum,free)
   if free<30*1048576 and not profile_errors:profile_errors.append('runtime capacity warning below30MiB')
   if free<12*1048576 or time.monotonic()>deadline:
    os.killpg(child.pid,signal.SIGTERM);profile_errors.append('operator bounded timeout/capacity stop');break
   if out.exists():
    for identity in out.rglob('app-identity.json'):
     if str(identity) in captures:continue
     captures.add(str(identity));pid=json.loads(identity.read_text())['pid'];cap=identity.parent.parent/'actual-app-profile'
     profilecmd=['python3',str(A/'capture-profile.py'),str(cap),str(pid),str(identity)]
     if host=='ssh':
      remoteenv={k:env[k] for k in ['C008_ROOT_ACTUAL_GO','C008_HOST_KIND','C008_HOST_ID','C008_INFOCMP','C008_TPUT','C008_LOCALE','C008_STTY']}
      remote=['env',*[k+'='+v for k,v in remoteenv.items()],'/usr/bin/python3',str(A/'capture-profile.py'),str(cap),str(pid),str(identity)]
      profilecmd=[env['C008_SSH'],'-F','/dev/null','-T','-p',env['C008_SSH_PORT'],'-i',env['C008_SSH_OWNED_KEY'],'-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+env['C008_SSH_OWNED_KNOWN_HOSTS'],env['C008_SSH_USER']+'@127.0.0.1',shlex.join(remote)]
     q=subprocess.run(profilecmd,env=env,capture_output=True);(cap.parent/'profile-capture.stdout').write_bytes(q.stdout);(cap.parent/'profile-capture.stderr').write_bytes(q.stderr)
     if q.returncode:profile_errors.append('actual app profile capture failed: '+q.stderr.decode()[-500:])
     else:
      observed=json.loads((cap/'profile/facts.json').read_text());diff={k:[bootstrapfacts[k],observed[k]] for k in keys if bootstrapfacts[k]!=observed[k]}
      (cap/'bootstrap-continuity.json').write_text(json.dumps(dict(matches=not diff,differences=diff,bootstrap=str(expected),appIdentity=str(identity)),indent=2)+'\n')
      if diff:profile_errors.append('actual app environment/device profile differs from genuine same-host bootstrap')
   time.sleep(.05)
  try:exitcode=child.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);exitcode=child.wait()
  record=dict(case=label,argv=cmd,start_ns=start,end_ns=time.time_ns(),exit_code=exitcode,free_before=before,min_free=minimum,free_after=shutil.disk_usage(R).free,actual_app_profiles=len(captures),profile_errors=profile_errors,stdout=str(log),stderr=str(err),evidence=str(out));results.append(record);(H/'case-records.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(record),flush=True)
  # First case is a real full startup pilot; stop this host if fundamental delivery/geometry fails.
  if len(results)==1 and exitcode!=0:
   (H/'blocked-after-pilot.txt').write_text('First actual case failed; stop remaining same-host batch pending concrete diagnosis.\n');break
  # Preserve failures; continue independent cases, never retry the same command.
finally:
 try:subprocess.run(['python3',str(O/'cleanup-resources.py')],env=env,capture_output=True,timeout=8)
 except Exception:pass
 if xp.poll() is None:
  os.killpg(xp.pid,signal.SIGTERM)
  try:xp.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(xp.pid,signal.SIGKILL);xp.wait()
 (H/'host-finalization.json').write_text(json.dumps(dict(xorg_pid=xp.pid,xorg_exit=xp.returncode,results=len(results),utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),indent=2)+'\n')
