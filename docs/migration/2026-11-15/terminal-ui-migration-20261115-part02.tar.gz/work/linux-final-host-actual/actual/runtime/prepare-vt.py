from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';V=A/'vt-preparation';V.mkdir();O=Path('/workspace/work/linux-final-host-execution/operator');P=R/'source/cjtui-0.0.0';base=Path('/workspace/work/linux-vt-product-probe/guest-root');env=os.environ.copy();env.update(C008_ROOT_ACTUAL_GO='1',C008_VT_OPERATOR_BUILD=str(V/'native-source'),C008_147_ADMISSION='/workspace/work/rendering-benchmark-acceptance/index.json',LD_LIBRARY_PATH='/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative:/workspace/work/validation/sdk/cangjie/tools/lib')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();commands=[]
def run(label,argv):
 p=subprocess.run(argv,env=env,capture_output=True);(V/(label+'.stdout')).write_bytes(p.stdout);(V/(label+'.stderr')).write_bytes(p.stderr);commands.append(dict(label=label,argv=argv,exit=p.returncode));assert p.returncode==0,(label,p.stderr.decode());return p.stdout
assert shutil.disk_usage(R).free>64*1048576
run('derive',['python3',str(O/'derive-vt-supervisor.py')]);fixed=json.loads(Path('/workspace/work/linux-final-host-execution/fix-round2/index.json').read_text())
for row in fixed['native_derived']:
 own=V/'native-source'/Path(row['path']).name
 # provenance carries source output path independent; derived C/header must exactly match.
 if own.suffix in ['.c','.h']:assert h(own)==row['sha256']
binary=V/'vt-product-supervisor';run('compile',['gcc','-std=c11','-Wall','-Wextra','-Werror','-O2','-static',str(V/'native-source/vt-product-supervisor.c'),'-o',str(binary)])
files=[];destinations=set();closure=[]
def add(src,dst,reason):
 src=Path(src).resolve()
 if dst in destinations:return
 destinations.add(dst);files.append(dict(source=str(src),destination=dst,reason=reason,bytes=src.stat().st_size,sha256=h(src)))
for rel,dst in [('examples/composition/target/release/bin/main','/apps/composition'),('examples/theme_showcase/target/release/bin/main','/apps/showcase')]:add(P/rel,dst,'accepted ordinary final public ELF; no rebuild')
for src,dst in [(base/'init','/init'),(binary,'/vt-product-supervisor'),(base/'bin/busybox','/bin/busybox'),(base/'dlmopen-check','/dlmopen-check'),(Path('/usr/bin/strace'),'/usr/bin/strace'),(Path('/usr/bin/infocmp'),'/usr/bin/infocmp'),(Path('/usr/bin/tput'),'/usr/bin/tput'),(Path('/usr/bin/locale'),'/usr/bin/locale')]:add(src,dst,'required original boot/supervision or actual raw facts tool')
# Resolve complete transitive DT_NEEDED closure from actual admitted ELFs/tools.
for row in list(files):
 src=row['source'];p=subprocess.run(['ldd',src],env=env,capture_output=True);text=p.stdout.decode();closure.append(dict(source=src,argv=['ldd',src],exit=p.returncode,stdout=text,stderr=p.stderr.decode()))
 if 'not a dynamic executable' in text or 'not a dynamic executable' in p.stderr.decode():continue
 assert p.returncode==0 and 'not found' not in text,(src,text,p.stderr.decode())
 for line in text.splitlines():
  import re
  m=re.search(r'(\S+) => (/\S+)',line)
  if m:add(m[2],'/lib/x86_64-linux-gnu/'+m[1],'actual transitive ELF dependency of '+src)
  else:
   m=re.match(r'\s*(/\S+)',line)
   if m:add(m[1],'/lib64/ld-linux-x86-64.so.2','actual ELF interpreter')
# Public native loader explicitly uses ncurses, independently of app DT_NEEDED.
add('/lib/x86_64-linux-gnu/libtinfo.so.6','/lib/x86_64-linux-gnu/libtinfo.so.6','native capability dlmopen ncurses dependency')
add('/usr/share/terminfo/l/linux','/usr/share/terminfo/l/linux','actual kernel VT terminfo entry')
for f in Path('/usr/lib/locale/C.utf8').rglob('*'):
 if f.is_file():add(f,'/usr/lib/locale/C.utf8/'+str(f.relative_to('/usr/lib/locale/C.utf8')),'actual C.UTF-8 prerequisite for locale charmap and application')
closurepath=V/'elf-closure-evidence.json';closurepath.write_text(json.dumps(closure,indent=2)+'\n')
symlinks=[dict(destination='/bin/'+name,target='busybox') for name in ['sh','mount','setsid','poweroff','sleep','cat','base64','tar','mkdir','stty','echo','uname']]+[dict(destination='/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2',target='../../lib64/ld-linux-x86-64.so.2')]
size=sum(f['bytes'] for f in files);free=shutil.disk_usage(R).free;assert free-size-32*1048576>64*1048576,('closure allocation exceeds admitted guard',size,free)
manifest=V/'closure.json';manifest.write_text(json.dumps(dict(status='ROOT_ADMITTED_NECESSARY_RUNTIME_CLOSURE',admission147=env['C008_147_ADMISSION'],admission=str(R/'actual-admission.json'),files=files,symlinks=symlinks,elfClosureEvidence=dict(path=str(closurepath),sha256=h(closurepath)),exact_payload_bytes=size,capacity_free_before=free,estimated_compressed_upper_bound=32*1048576),indent=2)+'\n')
print(json.dumps(dict(stage='exact closure estimated before materialization',bytes=size,free_bytes=free)),flush=True)
env.update(C008_VT_CLOSURE_MANIFEST=str(manifest),C008_VT_NEW_GUEST_ROOT=str(R/'private/vt-guest'),VT_INITRD=str(V/'final-public.cpio.gz'))
run('materialize',['python3',str(O/'prepare-vt-guest.py')]);run('pack',['python3',str(O/'pack-vt-guest.py')]);(V/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(V/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('C008_','VT_'))},indent=2)+'\n')
print(json.dumps(dict(stage='guest closure ready',guest_payload_bytes=size,initrd_bytes=Path(env['VT_INITRD']).stat().st_size,free_bytes=shutil.disk_usage(R).free,native_elf_sha256=h(binary),initrd_sha256=h(env['VT_INITRD'])),indent=2),flush=True)
