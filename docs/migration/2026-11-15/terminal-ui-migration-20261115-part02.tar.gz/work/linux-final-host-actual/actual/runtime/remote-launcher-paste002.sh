#!/bin/bash
set -euo pipefail
export C008_BINARY=$1 C008_OUT=$2 C008_GEOMETRY=$3
export C008_ROOT_ACTUAL_GO=1
export C008_147_ADMISSION=/workspace/work/rendering-benchmark-acceptance/index.json
export C008_PROVENANCE=/workspace/work/linux-final-host-actual/actual/final-provenance.json
export C008_SOURCE=/workspace/work/linux-final-host-actual/source/cjtui-0.0.0
export C008_HOST_KIND=ssh C008_HOST_ID='C008 independent ssh'
export C008_INFOCMP=/usr/bin/infocmp C008_TPUT=/usr/bin/tput C008_LOCALE=/usr/bin/locale C008_STTY=/usr/bin/stty
export LD_LIBRARY_PATH=/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative:/workspace/work/validation/sdk/cangjie/tools/lib
export LANG=C.UTF-8 LC_ALL=C.UTF-8
if [[ $C008_BINARY == /workspace/work/linux-final-host-actual/actual/runtime/bootstrap-launcher.sh ]]; then
 export C008_BOOTSTRAP_DIR=$(dirname "$C008_OUT")/bootstrap
 exec "$C008_BINARY"
fi
python3 /workspace/work/linux-final-host-actual/actual/runtime/capture-paste-mode-baseline.py "$C008_OUT-mode-baseline.json"
exec bash /workspace/work/linux-final-host-execution/operator/record-public.sh
