from pathlib import Path
import json,hashlib,time,shutil
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();roots={'xterm':'xterm-attempt2','vte':'vte-attempt4','tmux':'tmux-attempt3','screen':'screen-attempt3','ssh':'ssh-attempt5'};rows=[]
for host,name in roots.items():
 H=A/name;S=H/'composition-interactions-80x24';records=json.loads((H/'case-records.json').read_text());assert len(records)==1 and records[0]['exit_code']==0 and records[0]['declaration_preparer_exit']==0 and not records[0]['profile_errors']
 result=json.loads((S/'result.json').read_text());assert result['directExit']==0 and result['status']=='ACTUAL_ATTEMPT' and result['cleanup']['reaped'] and not result['cleanup']['forced']
 packetfolders=[p for p in S.glob('paste002-*') if p.is_dir() and p.name!='paste002-originals'];assert len(packetfolders)==1
 folder=packetfolders[0];prepared=json.loads((folder/'prepared.json').read_text());verified=json.loads((folder/'verified.json').read_text());assert verified['status']=='EXACT_RECEIVED_PACKET_MATCH' and verified['finalAcceptance'] is False
 raw=Path(verified['capture']['rawPath']).read_bytes();assert h(verified['capture']['rawPath'])==verified['rawSha256'];assert raw[verified['packetStart']:verified['packetEnd']].hex()==verified['receivedPacketHex']==verified['expectedPacketHex']
 for item in prepared['evidence']:assert h(item['path'])==h(item['snapshot'])==item['sha256']
 final=json.loads((S/'paste002-finalization.json').read_text());assert final['producersComplete'] and len(final['proofs'])==2
 for item in final['proofs']:
  source=Path(item['source']).read_bytes();snapshot=Path(item['sourceSnapshot']).read_bytes();assert len(source)==item['finalSourceBytes'] and h(item['source'])==item['finalSourceSha256'];assert source.startswith(snapshot) and len(snapshot)==item['sourcePrefixBytes'] and h(item['sourceSnapshot'])==item['sourcePrefixSha256']
 ownfinal=json.loads((H/'paste002-facts/final-source-prefix-proof.json').read_text());assert len(ownfinal)==2
 for item in ownfinal:
  source=Path(item['original']).read_bytes();prefix=Path(item['prefix']).read_bytes();assert source.startswith(prefix) and h(item['original'])==item['finalSha256'] and h(item['prefix'])==item['sha256']
 life=json.loads((S/'lifecycle-evidence.json').read_text());assert life['beforeTermios']==life['afterTermios'] and life['directExit']==0 and life['directSignal'] is None and not life['syntheticReplyInjected']
 for item in json.loads((S/'lifecycle-finalization.json').read_text())['originals']:
  assert h(item['original'])==h(item['path'])==item['sha256']
 captures=json.loads((S/'captures.json').read_text());images=[]
 for cap in captures:
  if cap.get('required'):assert cap['status']=='CAPTURED';assert h(S/cap['png'])==cap['sha256'];images.append(dict(path=str(S/cap['png']),sha256=cap['sha256'],checkpoint=cap['checkpoint']))
 declaration=prepared['declaration'];rows.append(dict(host=host,case='composition/interactions',direct_exit=0,record=records[0],policy_id=verified['policyId'],mode_basis=declaration['modes']['basis'],declaration_path=str(H/'paste002-declaration.json'),declaration_sha256=h(H/'paste002-declaration.json'),prepared=str(folder/'prepared.json'),verified=str(folder/'verified.json'),fixed_verifier_sha256=prepared['policySha256'],common_source_hex=verified['sourceHex'],complete_packet_hex=verified['receivedPacketHex'],packet_offsets={k:verified[k] for k in ['beforeOffset','afterOffset','packetStart','packetEnd']},raw_capture_sha256=verified['rawSha256'],source_finalization=str(S/'paste002-finalization.json'),own_mode_route_prefix_finalization=str(H/'paste002-facts/final-source-prefix-proof.json'),required_original_pngs=images,ordinary_product_source='d7e9d1445f98021a798d223de97b97b45239de93',final_acceptance=False))
source=json.loads(Path('/workspace/work/linux-final-host-execution/paste-install/installation.json').read_text());assert len(source['source'])==34
for item in source['source']:assert h(item['path'])==h(item['snapshot'])==item['sha256']
for item in json.loads((R/'actual/package-source-proof.json').read_text())['members']:assert h(R/'source'/item['member'])==item['sha256']
files=[]
for name in roots.values():
 H=A/name
 for p in H.rglob('*'):
  if p.is_file():files.append(dict(path=str(p),bytes=p.stat().st_size,sha256=h(p)))
owned=[A/n for n in ['run-paste002-host.py','prepare-paste-declaration.py','capture-paste-mode-baseline.py','public-launcher-paste002.sh','remote-launcher-paste002.sh']]
x=dict(status='FIVE_VARIABLE_PASTE002_FIXED_CASE_COMMANDS_EXIT_ZERO_EVIDENCE_SEALED_NOT_FINAL_LINUX_ACCEPTANCE',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),rows=rows,helper_installation=dict(path='/workspace/work/linux-final-host-execution/paste-install/installation.json',sha256=h('/workspace/work/linux-final-host-execution/paste-install/installation.json')),helper_source_count=34,binder_index=dict(path='/workspace/work/linux-final-host-test-contract/index.json',sha256=h('/workspace/work/linux-final-host-test-contract/index.json')),owned_factual_instrumentation=[dict(path=str(p),sha256=h(p)) for p in owned],files=files,old_crlf_attempts='retained as true failures; not relabeled or replay-upgraded',unaffected_variable_commands='prior60 reused; no reruns for this stage',ordinary_application_rebuilds=0,all333_package_source_members_unchanged=True,independent_acceptance=False,free_bytes=shutil.disk_usage(R).free)
(A/'paste002-five-host-index.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(dict(path=str(A/'paste002-five-host-index.json'),sha256=h(A/'paste002-five-host-index.json'),hosts=[r['host'] for r in rows],required_pngs=sum(len(r['required_original_pngs']) for r in rows),free_bytes=x['free_bytes']),indent=2))
