#!/bin/sh
exec "/workspace/work/linux-final-host-actual/source/cjtui-0.0.0/examples/theme_showcase/target/release/bin/main" --theme-file "/workspace/work/linux-final-host-actual/actual/runtime/ssh-attempt3/showcase-fileReload-80x24/selected.toml"
