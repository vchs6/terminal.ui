#!/bin/bash
exec bash /workspace/work/linux-final-host-execution/operator/ssh-dimensions.sh "$@"
