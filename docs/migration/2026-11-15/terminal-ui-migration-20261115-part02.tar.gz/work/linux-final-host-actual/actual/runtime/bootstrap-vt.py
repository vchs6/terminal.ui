from pathlib import Path
import base64,hashlib,json,os,re,shutil,signal,subprocess,tarfile,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';O=Path('/workspace/work/linux-final-host-execution/operator');H=A/'vt-bootstrap';H.mkdir();run=H/'vt-run';env={k:os.environ[k] for k in ['PATH','USER','LOGNAME'] if k in os.environ};env.update(C008_ROOT_ACTUAL_GO='1',C008_147_ADMISSION='/workspace/work/rendering-benchmark-acceptance/index.json',C008_PROVENANCE=str(R/'actual/final-provenance.json'),C008_SOURCE=str(R/'source/cjtui-0.0.0'),C008_HOST_KIND='vt',VT_RUN_DIR=str(run),VT_INITRD=str(A/'vt-preparation/final-public.cpio.gz'),VT_SCENE='composition')
subprocess.run(['python3',str(A/'guard.py'),str(H/'host-guard.json')],check=True)
cmd=['bash',str(O/'launch-host.sh'),'vt'];child=subprocess.Popen(cmd,env=env,stdout=(H/'qemu.stdout').open('wb'),stderr=(H/'qemu.stderr').open('wb'),start_new_session=True)
records=[]
def bridge(request,label):
 p=subprocess.run(['python3',str(O/'vt-transport.py'),json.dumps(dict(request,dir=str(H)))],env=env,capture_output=True,timeout=40);(H/(label+'.stdout')).write_bytes(p.stdout);(H/(label+'.stderr')).write_bytes(p.stderr);records.append(dict(label=label,request=request,exit=p.returncode));assert p.returncode==0,(label,p.stderr.decode());return json.loads(p.stdout)
try:
 bridge({'op':'identify'},'identify');deadline=time.monotonic()+15
 while True:
  w=bridge({'op':'wire'},'initial-wire')
  if b'Tasks' in base64.b64decode(w['wireBase64']):break
  assert time.monotonic()<deadline,'initial app frame absent';time.sleep(.1)
 bridge({'op':'capture'},'initial-capture');bridge({'op':'input','hex':'1b5b32317e'},'ordinary-exit-key')
 child.wait(timeout=40);assert child.returncode==0
 final=bridge({'op':'wire'},'final-wire');assert final['directExit']==0 and final['keyboardRestored']
 text=(run/'vt-serial.log').read_text(errors='replace');m=re.search(r'EVIDENCE_TAR_BASE64_BEGIN\r?\n(.*?)EVIDENCE_TAR_BASE64_END',text,re.S);assert m
 archive=run/'evidence.tar';archive.write_bytes(base64.b64decode(m[1]));d=run/'evidence';d.mkdir()
 with tarfile.open(archive) as t:
  members=[m for m in t.getmembers() if m.isfile() or m.isdir()];t.extractall(d,members=members,filter='data')
 p=subprocess.run(['python3',str(O/'guest-profile-facts.py'),str(d/'guest-profile'),str(run/'vt-serial.log'),str(H/'profile')],env=env,capture_output=True);(H/'profile.stdout').write_bytes(p.stdout);(H/'profile.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
 print('VT bootstrap actual final public composition exit0, keyboard restored; genuine same-guest profile captured',flush=True)
finally:
 if child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 (H/'records.json').write_text(json.dumps(dict(argv=cmd,records=records,qemu_exit=child.returncode,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),free_bytes=shutil.disk_usage(R).free),indent=2)+'\n')
