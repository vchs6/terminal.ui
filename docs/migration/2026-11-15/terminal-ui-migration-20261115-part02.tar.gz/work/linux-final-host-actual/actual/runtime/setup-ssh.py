from pathlib import Path
import hashlib,json,os,socket,subprocess,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';D=R/'private/ssh';D.mkdir(mode=0o700);(D/'home').mkdir(mode=0o700)
for name in ['host_ed25519','client_ed25519']:subprocess.run(['/usr/bin/ssh-keygen','-q','-t','ed25519','-N','','-f',str(D/name)],check=True)
(D/'authorized_keys').write_bytes((D/'client_ed25519.pub').read_bytes());(D/'authorized_keys').chmod(0o600)
pub=(D/'host_ed25519.pub').read_text().split();(D/'known_hosts').write_text('[127.0.0.1]:22488 '+pub[0]+' '+pub[1]+'\n');(D/'known_hosts').chmod(0o600)
cfg=D/'sshd_config';cfg.write_text(f'''Port 22488
ListenAddress 127.0.0.1
HostKey {D}/host_ed25519
PidFile {D}/sshd.pid
AuthorizedKeysFile {D}/authorized_keys
AllowUsers agent
PasswordAuthentication no
KbdInteractiveAuthentication no
AuthenticationMethods publickey
PubkeyAuthentication yes
UsePAM no
PermitRootLogin no
StrictModes yes
AllowAgentForwarding no
AllowTcpForwarding no
X11Forwarding no
PermitTunnel no
PermitUserEnvironment no
PrintMotd no
PrintLastLog no
LogLevel DEBUG2
SetEnv HOME={D}/home LANG=C.UTF-8 LC_ALL=C.UTF-8
''')
launcher=A/'remote-launcher.sh';launcher.write_text('''#!/bin/bash
set -euo pipefail
export C008_BINARY=$1 C008_OUT=$2 C008_GEOMETRY=$3
export C008_ROOT_ACTUAL_GO=1
export C008_147_ADMISSION=/workspace/work/rendering-benchmark-acceptance/index.json
export C008_PROVENANCE=/workspace/work/linux-final-host-actual/actual/final-provenance.json
export C008_SOURCE=/workspace/work/linux-final-host-actual/source/cjtui-0.0.0
export C008_HOST_KIND=ssh C008_HOST_ID='C008 independent ssh'
export C008_INFOCMP=/usr/bin/infocmp C008_TPUT=/usr/bin/tput C008_LOCALE=/usr/bin/locale C008_STTY=/usr/bin/stty
export LD_LIBRARY_PATH=/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative:/workspace/work/validation/sdk/cangjie/tools/lib
export LANG=C.UTF-8 LC_ALL=C.UTF-8
if [[ $C008_BINARY == /workspace/work/linux-final-host-actual/actual/runtime/bootstrap-launcher.sh ]]; then
 export C008_BOOTSTRAP_DIR=$(dirname "$C008_OUT")/bootstrap
 exec "$C008_BINARY"
fi
exec bash /workspace/work/linux-final-host-execution/operator/record-public.sh
''');launcher.chmod(0o700)
reader=A/'ssh-reader.sh';reader.write_text('#!/bin/bash\nexec bash /workspace/work/linux-final-host-execution/operator/ssh-dimensions.sh "$@"\n');reader.chmod(0o700)
env=dict(C008_SSH_HOST='127.0.0.1',C008_SSH_PORT='22488',C008_SSH_USER='agent',C008_SSH_OWNED_KEY=str(D/'client_ed25519'),C008_SSH_OWNED_KNOWN_HOSTS=str(D/'known_hosts'),C008_REMOTE_LAUNCHER=str(launcher),C008_DIMENSIONS_READER=str(reader));(R/'private/ssh-environment.json').write_text(json.dumps(env,indent=2)+'\n')
log=A/'ssh-server';log.mkdir();p=subprocess.run(['/usr/sbin/sshd','-t','-f',str(cfg)],capture_output=True);(log/'config-check.stdout').write_bytes(p.stdout);(log/'config-check.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
s=socket.socket();s.bind(('127.0.0.1',22488));s.close()
child=subprocess.Popen(['/usr/sbin/sshd','-D','-e','-f',str(cfg)],stdout=(log/'stdout').open('wb'),stderr=(log/'server.log').open('wb'),start_new_session=True)
(log/'owned-server.json').write_text(json.dumps(dict(pid=child.pid,argv=['/usr/sbin/sshd','-D','-e','-f',str(cfg)],start_ns=time.time_ns(),config_sha256=hashlib.sha256(cfg.read_bytes()).hexdigest(),private_material='excluded; never read into public evidence',host='127.0.0.1',port=22488),indent=2)+'\n');print(child.pid)
