from pathlib import Path
import gzip,hashlib,json,os,shutil,stat,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';rows=[]
# Only completed owned case raw/frames; source, SDK, cache, ELF and original PNG excluded.
for base in sorted(A.glob('*-attempt*')):
 host=base.name
 assert (base/'host-finalization.json').exists(),base
 for p in base.rglob('*'):
  if p.is_file() and p.name in ['frames.json','stdout.raw'] and p.stat().st_size>=65536:
   s=p.stat();rows.append(dict(path=str(p),bytes=s.st_size,mode=oct(stat.S_IMODE(s.st_mode)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),gzip_path=str(p)+'.gz',host_finalization=str(base/'host-finalization.json')))
assert rows
index=A/('completed-custody-'+str(time.time_ns())+'.json');x=dict(stage='ORIGINAL_INDICES_SEALED_BEFORE_COMPRESSION',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),records=rows,scope='Ended owned host case frame/raw files only; all host-finalization files present; no active case/VM writers; PNG/source/SDK/cache/ELF excluded')
index.write_text(json.dumps(x,indent=2)+'\n');seal=hashlib.sha256(index.read_bytes()).hexdigest();freed=0
for row in rows:
 p=Path(row['path']);dst=Path(row['gzip_path']);assert not dst.exists();data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 with dst.open('xb') as f:
  with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as g:g.write(data)
 with gzip.open(dst,'rb') as f:restored=f.read()
 assert restored==data and hashlib.sha256(restored).hexdigest()==row['sha256'];assert p.read_bytes()==data
 row.update(gzip_bytes=dst.stat().st_size,gzip_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),full_decompression_verified=True);freed+=len(data)-dst.stat().st_size;p.unlink()
receipt=index.with_name(index.stem+'-restore-map.json');receipt.write_text(json.dumps(dict(original_sealed_index=str(index),original_sealed_index_sha256=seal,records=rows,restore_rule='gzip.decompress bytes to original path; chmod recorded octal mode; verify original SHA256',bytes_reclaimed=freed,free_bytes=shutil.disk_usage(R).free),indent=2)+'\n');print(str(receipt),freed,shutil.disk_usage(R).free)
