from pathlib import Path
import hashlib,json,time,shutil
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hosts={};gallery=[]
for host in ['xterm','vte','tmux','screen','ssh']:
 attempts=[];successes={}
 for base in sorted(A.glob(host+'-attempt*')):
  record=base/'case-records.json';rows=json.loads(record.read_text()) if record.exists() else []
  attempts.append(dict(path=str(base),finalization=str(base/'host-finalization.json'),cases=rows))
  for row in rows:
   if row['exit_code']==0:successes[row['case']]=row
 hosts[host]=dict(attempts=attempts,unique_exit_zero_cases=successes,multiline='HELD_ROOT_INDEPENDENT_PASTE_DISPOSITION',profile_scope='Genuine bootstrap + observed app profile equality' if host!='ssh' else 'Genuine SSH bootstrap plus direct app facts for each public ELF in targeted attempt4; all12 original remote recorder inheritance records retained; initial local namespace observer limitation explicit')
 for candidate in ['showcase-fullCycle-80x24','composition-startup-80x24','showcase-retainedState-80x24']:
  if candidate not in successes:continue
  d=Path(successes[candidate]['evidence']);cs=d/'captures.json'
  if not cs.exists():continue
  captures=json.loads(cs.read_text());cap=next((c for c in captures if c.get('status')=='CAPTURED' and c.get('required') and c.get('png')),None)
  if cap:
   p=d/cap['png'];assert h(p)==cap['sha256'];gallery.append(dict(host=host,case=candidate,checkpoint=cap['checkpoint'],png=str(p),sha256=h(p),source='original actual owned window capture; no redraw',case_direct_exit=0,independent_acceptance=False));break
custody=[dict(path=str(p),sha256=h(p)) for p in A.glob('*restore-map.json')]
x=dict(status='ACTUAL_PROGRESS_WITH_EXPLICIT_HOLDS_NOT_FINAL_ACCEPTANCE',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),hosts=hosts,vt=dict(status='HELD_ROOT_TRACE_DIAGNOSIS',evidence=str(A/'vt-bootstrap'),native_readiness=True,initial_app_frame='NOT_OBSERVED_BEFORE_OWN_BOOTSTRAP_BOUND',no_transport_source_edits=True),gallery=gallery,custody=custody,admission=dict(path=str(R/'actual-admission.json'),sha256=h(R/'actual-admission.json')),free_bytes=shutil.disk_usage(R).free,final_acceptance=False)
(A/'progress-index.json').write_text(json.dumps(x,indent=2)+'\n')
lines=['# Original actual-host captures','', 'These are original PNGs from exit-zero fixed commands. Full host acceptance remains pending; see [progress index](progress-index.json).','']
for row in gallery:
 lines.extend([f"{row['host']}: {row['case']} — {row['checkpoint']}",f"[Original PNG]({row['png']}) · SHA256 `{row['sha256']}`",''])
(A/'actual-gallery.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(index=str(A/'progress-index.json'),sha256=h(A/'progress-index.json'),unique_exit_zero={k:len(v['unique_exit_zero_cases']) for k,v in hosts.items()},gallery=str(A/'actual-gallery.md'),free_bytes=x['free_bytes']),indent=2))
