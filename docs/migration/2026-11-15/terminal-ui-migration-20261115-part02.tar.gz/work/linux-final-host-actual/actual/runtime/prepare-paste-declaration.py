from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,gzip
out=Path(sys.argv[1]);host=os.environ['C008_HOST_KIND'];H=out.parent;facts=H/'paste002-facts';facts.mkdir();deadline=time.monotonic()+15;transport=out/'transport';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 ansi=transport/'ansi.raw';inputpath=transport/'input.raw';identity=transport/'app-identity.json';baseline=Path(str(transport)+'-mode-baseline.json')
 if ansi.exists() and inputpath.exists() and identity.exists() and baseline.exists():
  a=ansi.read_bytes();b=inputpath.read_bytes()
  if b'\x1b[?2004h' in a:break
 if time.monotonic()>=deadline:raise RuntimeError('PASTE002 missing genuine pre-action mode/route inputs before fixed deadline')
 time.sleep(.005)
# Immutable original prefixes, never the multiline packet under test.
(facts/'app-output-prefix.raw').write_bytes(a);(facts/'app-input-prefix.raw').write_bytes(b)
(facts/'mode-baseline.json').write_bytes(baseline.read_bytes());(facts/'app-identity.json').write_bytes(identity.read_bytes());(facts/'inner-state-prefix.txt').write_bytes((transport/'inner-state.txt').read_bytes());(facts/'outer-state-prefix.txt').write_bytes((transport/'outer-state.txt').read_bytes())
assert b'\x1b[?2005h' not in a and b'\x1b[?2006h' not in a
name={'xterm':'C008 owned xterm','vte':'C008 owned VTE','tmux':'C008 owned tmux','screen':'C008 owned screen','ssh':'C008 owned SSH'}[host]
def run(label,args):
 p=subprocess.run(args,capture_output=True,env=os.environ);(facts/(label+'.stdout')).write_bytes(p.stdout);(facts/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(label,p.stderr.decode());return p.stdout
raw=run('xwininfo-tree',['xwininfo','-root','-tree']);matches=[line.split()[0] for line in raw.decode().splitlines() if '"'+name+'"' in line];assert len(matches)==1,matches;wid=matches[0]
pidraw=run('owner-pid',['xprop','-id',wid,'_NET_WM_PID']);m=re.search(rb'= (\d+)',pidraw);assert m,'actual owner PID property';pid=int(m[1]);owner=Path('/proc')/str(pid);exe=(owner/'exe').resolve();argv=(owner/'cmdline').read_bytes();(facts/'owner-argv.raw').write_bytes(argv)
resources=run('xresources',['xrdb','-query']);assert not resources.strip(),'new owned X server must have no inherited resource database'
configs=[Path(os.environ['HOME'])/'config/xfce4/terminal/terminalrc',Path(os.environ['HOME'])/'config/xfce4/terminal/accels.scm',Path(os.environ['HOME'])/'tmux.conf',Path(os.environ['HOME'])/'screenrc']
ownerconfig=dict(engine='VTE' if host=='vte' else 'XTerm',version='0.80.1' if host=='vte' else '398',ownerPid=pid,window=wid,exe=str(exe),elfSha256=h(exe),argvHex=argv.hex(),display=os.environ['DISPLAY'],home=os.environ['HOME'],resourceDatabaseHex=resources.hex(),config_files=[dict(path=str(p),sha256=h(p),content=p.read_text()) for p in configs if p.exists()],freshOwnedWindow=True,noUserResourceFiles=True)
if host=='vte':
 maps=(owner/'maps').read_text();(facts/'owner-maps.txt').write_text(maps);vtes=sorted(set(re.findall(r'(/\S*libvte-2\.91\.so\S*)',maps)));assert len(vtes)==1,vtes;ownerconfig['loadedVte']=dict(path=vtes[0],sha256=h(vtes[0]));run('installed-vte-version',['dpkg-query','-W','-f=${Version}','libvte-2.91-0:amd64'])
else:
 version=run('xterm-version',[str(exe),'-version']);assert b'XTerm(398)' in version
(facts/'owner-config.json').write_text(json.dumps(ownerconfig,indent=2)+'\n')
sourceRoot=Path('/workspace/work/c008-host-protocol-diagnosis/followup/upstream');official=[sourceRoot/n for n in ['vte.cc','pastify.cc','modes.py']] if host=='vte' else [Path('/workspace/work/cross-terminal-recon/hosts/xterm/usr/share/doc/xterm/ctlseqs.txt.gz')]
policy=dict(actualOwnerEngine=ownerconfig['engine'],actualOwnerVersion=ownerconfig['version'],fixedIndependentContract='/workspace/work/linux-final-host-test-contract/paste-revision/packet-contract.md',fixedIndependentContractSha256=h('/workspace/work/linux-final-host-test-contract/paste-revision/packet-contract.md'),official_sources=[dict(path=str(p),sha256=h(p)) for p in official],basis='fixed official VTE0.80.1 widget_paste/pastify and nonwritable default-reset2005/2006' if host=='vte' else 'matching supplied XTerm398 ctlseqs documented default NL-to-CR,2005 quoting and2006 literal-newline modes; fresh unmodified owned instance')
(facts/'newline-policy.json').write_text(json.dumps(policy,indent=2)+'\n');baselinefacts=json.loads(baseline.read_text());q={r['mode']:r for r in baselinefacts['queries']}
if host in ['xterm','ssh']:
 assert q[2005]['responseHex']=='1b5b3f323030353b322479' and q[2006]['responseHex']=='1b5b3f323030363b322479','actual default XTerm2005/2006 genuine reset replies required'
 basis='genuine-observation'
elif host=='vte':basis='fixed-official-source'
else:basis='verified-default-config'
mode=dict(basis=basis,bracketedPaste='set',pasteQuote='fixed-reset' if host=='vte' else 'reset',literalNewline='fixed-reset' if host=='vte' else 'reset',app2004SetOffset=a.find(b'\x1b[?2004h'),sourceOutput=str(ansi),prefix=str(facts/'app-output-prefix.raw'),prefixSha256=h(facts/'app-output-prefix.raw'),prefixBytes=len(a),actualBaselineQueries=str(facts/'mode-baseline.json'),baselineScope='Owned current session tty before app; mux replies are not claimed as outer-XTerm observations',stateBasisDetail='actual app output2004h plus genuine reset replies forwarded across actual route' if basis=='genuine-observation' else 'actual app2004h control history, fresh owned owner/default config plus pinned official fixed policy; no actual outer2005/6 query claim' if basis=='verified-default-config' else 'actual app2004h plus actual loaded VTE0.80.1 and official non-writable fixed-reset modes; unsupported query replies are not synthesized as reset')
(facts/'mode-state.json').write_text(json.dumps(mode,indent=2)+'\n');app=json.loads(identity.read_text());route=dict(kind='gui-selection',ownerPid=pid,ownerWindow=wid,host=host,hostConfig=str(H/'host-config.json'),appPid=app['pid'],appIdentity=app,actualAppTty=re.search(r'^tty=(.+)$',(transport/'inner-state.txt').read_text(),re.M)[1],actualOuterTty=re.search(r'^tty=(.+)$',(transport/'outer-state.txt').read_text(),re.M)[1],inputSource=str(inputpath),prefix=str(facts/'app-input-prefix.raw'),prefixSha256=h(facts/'app-input-prefix.raw'),prefixBytes=len(b),reviewedRecorderPath='/workspace/work/linux-final-host-execution/operator/record-public.sh',reviewedRecorderSha256=h('/workspace/work/linux-final-host-execution/operator/record-public.sh'),rawOwnerArgv=str(facts/'owner-argv.raw'),realSelectionOwnerTool=os.environ['C008_CLIPBOARD_OWNER'],realSelectionOwnerToolSha256=h(os.environ['C008_CLIPBOARD_OWNER']))
(facts/'raw-route.json').write_text(json.dumps(route,indent=2)+'\n')
refs=[dict(kind=k,path=str(facts/(k+'.json')),sha256=h(facts/(k+'.json'))) for k in ['owner-config','newline-policy','mode-state','raw-route']]
declaration=dict(schema='C008-PASTE002-v1',policyId='VTE0801_FIXED_NL_TO_CR' if host=='vte' else 'XTERM398_DEFAULT_NL_TO_CR',owner=dict(engine=ownerconfig['engine'],version=ownerconfig['version']),route=dict(kind='gui-selection',chain=[f'owned {ownerconfig["engine"]} window {wid} PID{pid} config '+str(H/'host-config.json'),host+' actual route via frozen launcher/recorder and original endpoint records',f'actual app tty {route["actualAppTty"]} PID{app["pid"]}']),modes={k:mode[k] for k in ['bracketedPaste','pasteQuote','literalNewline','basis']},declaredBeforeOffset=len(b),declaredUTC=time.strftime('%Y-%m-%dT%H:%M:%S.000Z',time.gmtime()),evidence=refs)
# Exclusive creation means a declaration can never be silently updated from the received LF packet.
(facts/'source-prefix-links.json').write_text(json.dumps([dict(original=str(ansi),prefix=str(facts/'app-output-prefix.raw'),bytes=len(a),sha256=h(facts/'app-output-prefix.raw')),dict(original=str(inputpath),prefix=str(facts/'app-input-prefix.raw'),bytes=len(b),sha256=h(facts/'app-input-prefix.raw'))],indent=2)+'\n')
temporary=facts/'declaration-ready.json';temporary.write_text(json.dumps(declaration,indent=2)+'\n');os.link(temporary,Path(os.environ['C008_PASTE002_DECLARATION']));print(os.environ['C008_PASTE002_DECLARATION'])
