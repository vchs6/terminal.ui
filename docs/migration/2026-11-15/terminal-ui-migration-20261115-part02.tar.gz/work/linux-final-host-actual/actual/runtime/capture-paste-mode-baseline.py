import os,sys,json,time,termios,tty,select,pathlib
out=pathlib.Path(sys.argv[1]);fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY);before=termios.tcgetattr(fd);rows=[]
try:
 tty.setraw(fd,termios.TCSANOW)
 for mode in [2004,2005,2006]:
  query=f'\x1b[?{mode}$p'.encode();start=time.time_ns();os.write(fd,query);raw=bytearray();deadline=time.monotonic()+.65
  while time.monotonic()<deadline:
   ready,_,_=select.select([fd],[],[],max(0,deadline-time.monotonic()))
   if ready:raw.extend(os.read(fd,256))
  rows.append(dict(mode=mode,queryHex=query.hex(),responseHex=raw.hex(),start_ns=start,end_ns=time.time_ns(),deadlineMs=650,source='genuine query on this owned host session /dev/tty before application/recorder; no injected response'))
finally:
 termios.tcsetattr(fd,termios.TCSANOW,before);after=termios.tcgetattr(fd);device=os.ttyname(fd);os.close(fd)
assert before==after
out.write_text(json.dumps(dict(stdoutDevice=device,queries=rows,beforeTermios=before,afterTermios=after,exactRestoration=True,hostKind=os.environ['C008_HOST_KIND']),indent=2,default=lambda x:dict(hex=x.hex()))+'\n')
