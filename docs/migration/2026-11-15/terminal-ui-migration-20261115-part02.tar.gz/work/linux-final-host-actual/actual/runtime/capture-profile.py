import json,os,pathlib,re,subprocess,sys,time
R=pathlib.Path('/workspace/work/linux-final-host-actual');out=pathlib.Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);pid=int(sys.argv[2]) if len(sys.argv)>2 else os.getpid();proc=pathlib.Path('/proc')/str(pid)
allowed=['TERM','COLORTERM','TERMINFO','TERMINFO_DIRS','LANG','LC_ALL','LC_CTYPE']
if len(sys.argv)>3:
 identity_expected=json.loads(pathlib.Path(sys.argv[3]).read_text());current=(proc/'stat').read_text().rsplit(')',1)[1].split()[19]
 assert identity_expected['pid']==pid and identity_expected['startTicks']==current,'owned app PID identity changed'
if len(sys.argv)>2:
 entries=(proc/'environ').read_bytes().split(b'\0');actual={k.decode():v.decode() for e in entries if b'=' in e for k,v in [e.split(b'=',1)] if k.decode() in allowed}
 device=os.readlink(proc/'fd/1');s=(proc/'fd/1').stat()
else:actual={k:os.environ[k] for k in allowed if k in os.environ};device=os.ttyname(1);s=os.fstat(1)
assert device.startswith('/dev/pts/'),device
identity=dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),pid=pid,exe=str((proc/'exe').resolve()),stdout=device,stdout_rdev=s.st_rdev,stdout_inode=s.st_ino,environment=actual,hostKind=os.environ['C008_HOST_KIND'],hostId=os.environ['C008_HOST_ID'])
identitypath=out/'actual-identity.json';identitypath.write_text(json.dumps(identity,indent=2)+'\n')
env=os.environ.copy()
for k in allowed:env.pop(k,None)
env.update(actual);env.update(C008_ACTUAL_STDOUT_DEVICE=device,C008_ACTUAL_HOST_IDENTITY_EVIDENCE=str(identitypath))
p=subprocess.run(['/usr/bin/infocmp','-1','-x','--',actual.get('TERM','')],env=env,capture_output=True);(out/'entry-resolution.stdout').write_bytes(p.stdout);(out/'entry-resolution.stderr').write_bytes(p.stderr)
m=re.search(rb'^#\s+Reconstructed via infocmp from file: (.+)$',p.stdout,re.M);assert p.returncode==0 and m,('raw entry resolution',p.returncode,p.stdout[:300],p.stderr)
env['C008_ACTUAL_TERMINFO_ENTRY']=m[1].decode()
p=subprocess.run(['python3','/workspace/work/linux-final-host-execution/operator/collect-profile-facts.py',str(out/'profile')],env=env,capture_output=True);(out/'collector.stdout').write_bytes(p.stdout);(out/'collector.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode()
print(str(out/'profile/profile-envelope.json'))
