#!/bin/bash
set -euo pipefail
exec /bin/bash /workspace/work/linux-final-host-execution/operator/record-public.sh
