from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path('/workspace/work/linux-final-host-actual');A=R/'actual/runtime';V=A/'vt-preparation-r3';V.mkdir();base=R/'private/vt-guest';root=R/'private/vt-guest-r3';O=Path('/workspace/work/linux-final-host-execution/operator');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=os.environ.copy();env.update(C008_ROOT_ACTUAL_GO='1',C008_VT_OPERATOR_BUILD=str(V/'native-source'),C008_VT_NEW_GUEST_ROOT=str(root),VT_INITRD=str(V/'final-public-r3.cpio.gz'))
oldpaths=[A/'vt-preparation/vt-product-supervisor',A/'vt-preparation/final-public.cpio.gz',A/'vt-preparation/closure.json'];old=[dict(path=str(p),sha256=h(p)) for p in oldpaths];basefiles=[dict(path=str(p),sha256=h(p),bytes=p.stat().st_size) for p in base.rglob('*') if p.is_file() and not p.is_symlink()]
free=shutil.disk_usage(R).free;forecast=2*1048576+32*1048576;assert free-forecast>64*1048576
(V/'allocation-plan.json').write_text(json.dumps(dict(free_before=free,new_payload_forecast_upper_bound=forecast,method='read-only existing admitted necessary guest base via file hardlinks; replace supervisor with fresh own regular ELF; new original-reviewed packer output. No files in old base will be written; no app/SDK/cache copies.',base_payload_bytes=sum(r['bytes'] for r in basefiles),old_artifacts=old,base_before=basefiles),indent=2)+'\n');print('R3 new allocation forecast',forecast,'free',free,flush=True)
commands=[]
def run(label,argv):
 p=subprocess.run(argv,env=env,capture_output=True);(V/(label+'.stdout')).write_bytes(p.stdout);(V/(label+'.stderr')).write_bytes(p.stderr);commands.append(dict(argv=argv,exit=p.returncode));assert p.returncode==0,(label,p.stderr.decode())
run('derive',['python3',str(O/'derive-vt-supervisor.py')]);binary=V/'vt-product-supervisor';run('compile',['gcc','-std=c11','-Wall','-Wextra','-Werror','-O2','-static',str(V/'native-source/vt-product-supervisor.c'),'-o',str(binary)])
assert not root.exists();root.mkdir()
for p in sorted(base.rglob('*')):
 relative=p.relative_to(base);dst=root/relative
 if relative.as_posix() in ['vt-product-supervisor','operator-runtime-closure.json']:continue
 if p.is_symlink():dst.symlink_to(os.readlink(p))
 elif p.is_dir():dst.mkdir(exist_ok=True)
 elif p.is_file():os.link(p,dst)
shutil.copy2(binary,root/'vt-product-supervisor')
prior=json.loads((A/'vt-preparation/closure.json').read_text());files=[]
for row in prior['files']:
 destination=row['destination'];src=binary if destination=='/vt-product-supervisor' else base/destination.lstrip('/')
 files.append(dict(source=str(src),destination=destination,reason='R3 supervisor exact reviewed generator' if destination=='/vt-product-supervisor' else 'read-only byte-identical previously admitted necessary guest file',sha256=h(src),bytes=src.stat().st_size))
manifest=dict(status='ROOT_ADMITTED_NECESSARY_RUNTIME_CLOSURE',admission=str(A/'admission-vt-r3.json'),admission147=prior['admission147'],files=files,symlinks=prior['symlinks'],elfClosureEvidence=prior['elfClosureEvidence'],base_guest_root=str(base),root=str(root),base_reuse='Unchanged file hardlinks only; no source file writes; CPIO original packer enumerates bytes independently',new_supervisor_sha256=h(binary))
(V/'closure-r3.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'operator-runtime-closure.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert shutil.disk_usage(R).free-32*1048576>64*1048576
run('pack',['python3',str(O/'pack-vt-guest.py')])
for row in old+basefiles:assert h(row['path'])==row['sha256'],row['path']
(V/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(V/'preserved-old-artifacts.json').write_text(json.dumps(dict(old=old,base_before=basefiles,verified_after=True),indent=2)+'\n')
(V/'artifact-receipt.json').write_text(json.dumps(dict(native_source_sha256=h(V/'native-source/vt-product-supervisor.c'),native_header_sha256=h(V/'native-source/vt-supervisor-transport.h'),native_elf_sha256=h(binary),native_elf_bytes=binary.stat().st_size,initrd_sha256=h(env['VT_INITRD']),initrd_bytes=Path(env['VT_INITRD']).stat().st_size,closure_sha256=h(V/'closure-r3.json'),old_bytes_preserved=True,ordinary_elf_rebuilds=0,free_after=shutil.disk_usage(R).free),indent=2)+'\n');print((V/'artifact-receipt.json').read_text(),flush=True)
