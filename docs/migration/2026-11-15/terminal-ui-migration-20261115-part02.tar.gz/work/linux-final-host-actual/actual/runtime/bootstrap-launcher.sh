#!/bin/bash
set -euo pipefail
exec python3 /workspace/work/linux-final-host-actual/actual/runtime/capture-profile.py "$C008_BOOTSTRAP_DIR"
