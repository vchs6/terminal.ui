#!/bin/bash
set -euo pipefail
python3 /workspace/work/linux-final-host-actual/actual/runtime/capture-paste-mode-baseline.py "$C008_OUT-mode-baseline.json"
exec /bin/bash /workspace/work/linux-final-host-execution/operator/record-public.sh
