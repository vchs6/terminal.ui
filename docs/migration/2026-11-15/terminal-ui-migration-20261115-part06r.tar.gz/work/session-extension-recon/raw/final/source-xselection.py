"""Small ctypes X11 selection fixture. Restricted to caller-owned DISPLAY.
No OSC52 queries and no system clipboard tools. All data is synthetic.
"""
import ctypes as c, time
L = c.CDLL('libX11.so.6'); U = c.c_ulong; I=c.c_int; P=c.c_void_p
class Req(c.Structure):
    _fields_=[('type',I),('serial',U),('send_event',I),('display',P),('owner',U),('requestor',U),('selection',U),('target',U),('property',U),('time',U)]
class Notify(c.Structure):
    _fields_=[('type',I),('serial',U),('send_event',I),('display',P),('requestor',U),('selection',U),('target',U),('property',U),('time',U)]
class Ev(c.Union):
    _fields_=[('type',I),('request',Req),('notify',Notify),('pad',c.c_long*24)]
for name, restype, args in [
 ('XOpenDisplay',P,[c.c_char_p]),('XDefaultRootWindow',U,[P]),('XCreateSimpleWindow',U,[P,U,I,I,U,U,U,U,U]),('XInternAtom',U,[P,c.c_char_p,I]),('XSetSelectionOwner',I,[P,U,U,U]),('XGetSelectionOwner',U,[P,U]),('XFlush',I,[P]),('XSync',I,[P,I]),('XPending',I,[P]),('XNextEvent',I,[P,c.POINTER(Ev)]),('XSendEvent',I,[P,U,I,c.c_long,c.POINTER(Ev)]),('XChangeProperty',I,[P,U,U,U,I,I,c.c_void_p,I]),('XConvertSelection',I,[P,U,U,U,U,U]),('XGetWindowProperty',I,[P,U,U,c.c_long,c.c_long,I,U,c.POINTER(U),c.POINTER(I),c.POINTER(U),c.POINTER(U),c.POINTER(P)]),('XFree',I,[P]),('XCloseDisplay',I,[P])]:
    f=getattr(L,name);f.restype=restype;f.argtypes=args
class Fixture:
    def __init__(self, display):
        assert display.startswith(':173'), 'private display only'
        self.d=L.XOpenDisplay(display.encode()); assert self.d
        self.w=L.XCreateSimpleWindow(self.d,L.XDefaultRootWindow(self.d),0,0,1,1,0,0,0)
        self.atoms={s:L.XInternAtom(self.d,s.encode(),0) for s in ['CLIPBOARD','UTF8_STRING','STRING','TARGETS','RECON_DATA']}
        self.seed=b''
    def seed_clipboard(self, text):
        self.seed=text.encode(); L.XSetSelectionOwner(self.d,self.atoms['CLIPBOARD'],self.w,0);L.XSync(self.d,0)
        assert self.owner()==self.w
    def owner(self): return L.XGetSelectionOwner(self.d,self.atoms['CLIPBOARD'])
    def request(self,r):
        prop=r.property or r.target; success=True
        if r.target in [self.atoms['UTF8_STRING'],self.atoms['STRING']]:
            b=c.create_string_buffer(self.seed);L.XChangeProperty(self.d,r.requestor,prop,r.target,8,0,b,len(self.seed))
        elif r.target==self.atoms['TARGETS']:
            b=(U*3)(self.atoms['TARGETS'],self.atoms['UTF8_STRING'],self.atoms['STRING']);L.XChangeProperty(self.d,r.requestor,prop,4,32,0,b,3)
        else: success=False
        n=Ev();n.notify=Notify(31,0,1,self.d,r.requestor,r.selection,r.target,prop if success else 0,r.time)
        L.XSendEvent(self.d,r.requestor,0,0,c.byref(n));L.XFlush(self.d)
    def read_clipboard(self):
        # Invoked only after this fixture has seeded the fresh private X server.
        owner=self.owner();L.XConvertSelection(self.d,self.atoms['CLIPBOARD'],self.atoms['UTF8_STRING'],self.atoms['RECON_DATA'],self.w,0);L.XFlush(self.d)
        until=time.monotonic()+3
        while time.monotonic()<until:
            if not L.XPending(self.d): time.sleep(.01); continue
            ev=Ev();L.XNextEvent(self.d,c.byref(ev))
            if ev.type==30:self.request(ev.request)
            if ev.type==31:
                if not ev.notify.property:return {'owner':owner,'error':'conversion-refused'}
                typ=U();fmt=I();n=U();remain=U();ptr=P()
                rc=L.XGetWindowProperty(self.d,self.w,self.atoms['RECON_DATA'],0,65536,1,0,c.byref(typ),c.byref(fmt),c.byref(n),c.byref(remain),c.byref(ptr))
                data=c.string_at(ptr,n.value) if ptr else b''
                if ptr:L.XFree(ptr)
                return {'owner':owner,'format':fmt.value,'property_type':typ.value,'rc':rc,'bytes_after':remain.value,'hex':data.hex(),'text':data.decode('utf-8','replace')}
        return {'owner':owner,'error':'timeout'}
    def close(self):L.XCloseDisplay(self.d)
