#!/usr/bin/env python3
"""Disposable real-terminal emission probe. Receives only local test commands."""
import fcntl, json, os, pathlib, struct, sys, termios, time
p = pathlib.Path(sys.argv[1]); index = 0
meta = {'pid': os.getpid(), 'tty': os.ttyname(1), 'term': os.getenv('TERM'), 'colorterm': os.getenv('COLORTERM'), 'tmux': os.getenv('TMUX'), 'sty': os.getenv('STY'), 'grid_rows_cols': struct.unpack('HHHH', fcntl.ioctl(1, termios.TIOCGWINSZ, b'\0'*8))[:2], 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(p/'child.json').write_text(json.dumps(meta, indent=2))
os.write(1, b'\x1b[2J\x1b[HSESSION EXTENSION RECON - disposable private display\r\n')
while True:
    src = p/f'command-{index}.json'
    if not src.exists(): time.sleep(.025); continue
    obj = json.loads(src.read_text()); raw = bytes.fromhex(obj['hex'])
    if obj.get('exit'): break
    count = os.write(1, raw)
    with (p/'emitted.bin').open('ab') as f: f.write(raw)
    os.write(1, ('\r\nphase '+str(index)+' '+obj['name']+'\r\n').encode())
    (p/f'ack-{index}.json').write_text(json.dumps({'phase':index,'name':obj['name'],'write_count':count,'requested_count':len(raw),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}))
    index += 1
(p/'exit.json').write_text(json.dumps({'exit':0}))
