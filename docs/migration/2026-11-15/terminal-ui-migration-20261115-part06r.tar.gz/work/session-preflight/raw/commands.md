All paths are relative to /workspace/work/session-preflight unless absolute.

- Input: git -C /workspace/work/terminal.ui archive fcad69da2447b4e110ba23543bfc5aeac0ae50ba | tar -x -C input
- SDK environment: source /workspace/work/validation/sdk/cangjie/envsetup.sh
- cjc --version; cjpm --version -> sdk-version.txt
- cd shape/consumer && cjpm build -> shape-build.log / .exit
- cd shape/negative-readonly && cjpm build -> negative-readonly.log / .exit (expected 1)
- cd shape/negative-constructor && cjpm build -> negative-constructor.log / .exit (expected 1)
- cd shape/array-mutation && cjpm build -> array-mutation.log / .exit
- cd codec && cjpm build -> codec-build.log / .exit
- cd codec && ./target/release/bin/main -> codec-run.log / .exit
- cd base64 && cjpm build -> base64-sdk.log / .exit (expected 1: absent dependency)
- cd input && /workspace/work/terminal.ui/node_modules/.bin/openspec validate implement-session-extensions --strict -> openspec-validate.log / .exit
- git -C /workspace/work/terminal.ui diff --exit-code acd8a1568b1007ba684a032836d8593c63ad6a10 fcad69da2447b4e110ba23543bfc5aeac0ae50ba -- src/application.cj src/runtime_session.cj src/terminal_bridge.cj native/cjtui_terminal.c -> no differences, exit 0
- Final contract review: git diff fcad69da2447b4e110ba23543bfc5aeac0ae50ba b27f16bb96b68df48f9dfeab37b2dc4569099ccd -- openspec/changes/implement-session-extensions/design.md

No shape stub was run. No formal product suite was run. Codec executable exercises public SDK APIs only. Language probe sources remain in the independent directory and are not product artifacts or formal tests.
- Final strict validation first used a change-only snapshot: exit 0 with missing-base-spec archive warning (retained as openspec-final-change-only-validate.log). Added unchanged openspec/specs and config.yaml from the same final commit. One command had a trailing slash typo (exit126, retained openspec-final-path-typo.log), corrected executable path, then final strict validation exit0 with no warning (openspec-final-validate.log). No product/SDK probe rerun.
