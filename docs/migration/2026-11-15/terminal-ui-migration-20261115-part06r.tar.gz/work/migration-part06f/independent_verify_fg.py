import os,stat,json,hashlib,gzip,zlib,tarfile,io,pathlib,datetime
ROOT='/workspace/work/'
def verify(volume):
 B=ROOT+'migration-part06'+volume+'/'
 manifest_bytes=open(B+'manifest.json','rb').read(); manifest=json.loads(manifest_bytes); delivery=json.load(open(B+'delivery.json'))
 errors=[]
 def check(c,s):
  if not c: errors.append(s)
 def hashes(f):
  h=hashlib.sha256(); n=0
  while True:
   b=f.read(1024*1024)
   if not b: break
   h.update(b); n+=len(b)
  return n,h.hexdigest()
 files=manifest['files']; check(len(files)==delivery['payload_files'],'manifest payload count'); byname={x['archive_path']:x for x in files}; check(len(byname)==len(files),'manifest duplicate names')
 source_results=[]
 for x in files:
  s=os.lstat(x['path'])
  with open(x['path'],'rb') as f: n,h=hashes(f)
  ok=stat.S_ISREG(s.st_mode) and n==x['bytes'] and h==x['sha256'] and stat.S_IMODE(s.st_mode)==x['mode']
  check(ok,'source mismatch '+x['path']); source_results.append({'path':x['archive_path'],'bytes':n,'sha256':h,'mode':stat.S_IMODE(s.st_mode),'pass':ok})
 archive=delivery['archive_path']; n=os.stat(archive).st_size; sha=hashlib.sha256(); blob=hashlib.sha1(('blob '+str(n)+'\0').encode())
 with open(archive,'rb') as f:
  while True:
   b=f.read(1024*1024)
   if not b: break
   sha.update(b); blob.update(b)
 check(n==delivery['bytes'],'archive size'); check(sha.hexdigest()==delivery['sha256'],'archive SHA256'); check(blob.hexdigest()==delivery['git_blob'],'archive git blob identity')
 expected=files+[{'path':B+'manifest.json','archive_path':'migration-part06'+volume+'/manifest.json','bytes':len(manifest_bytes),'sha256':hashlib.sha256(manifest_bytes).hexdigest(),'mode':stat.S_IMODE(os.stat(B+'manifest.json').st_mode)}]
 records={}; decompressed={}; member_results=[]; pax_count=0; seen=set(); raw_header_blocks=0
 # Compare every raw header/control byte with the exact PAX tar encoding of the corresponding source stat.
 with tarfile.open(fileobj=io.BytesIO(),mode='w',format=tarfile.PAX_FORMAT) as template, gzip.open(archive,'rb') as f:
  for x in expected:
   name=x['archive_path']; check(not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts and '\\' not in name and not any(ord(c)<32 or ord(c)==127 for c in name),'unsafe name '+name); check(name not in seen,'duplicate '+name); seen.add(name)
   ti=template.gettarinfo(x['path'],arcname=name)
   header=ti.tobuf(tarfile.PAX_FORMAT,'utf-8','surrogateescape'); actual=f.read(len(header)); check(actual==header,'raw header/control metadata mismatch '+name); raw_header_blocks+=len(header)//512
   if len(header)>512: pax_count+=1
   actual_ti=tarfile.TarInfo.frombuf(actual[-512:],'utf-8','surrogateescape')
   check(ti.isreg() and not ti.linkname,'nonregular/link '+name)
   h=hashlib.sha256(); total=0; data=bytearray(); gz=name.endswith('.gz')
   if gz: dec=zlib.decompressobj(16+zlib.MAX_WBITS); dh=hashlib.sha256(); dn=0; elfhead=b''
   remaining=x['bytes']
   while remaining:
    b=f.read(min(1024*1024,remaining))
    if not b: raise ValueError('truncated payload '+name)
    remaining-=len(b); total+=len(b); h.update(b)
    if gz:
     out=dec.decompress(b); dh.update(out); dn+=len(out); elfhead=(elfhead+out[:64])[:64]
    else: data.extend(b)
   if gz:
    out=dec.flush(); dh.update(out); dn+=len(out); check(dec.eof and not dec.unused_data and not dec.unconsumed_tail,'gzip complete single stream '+name); decompressed[name]={'bytes':dn,'sha256':dh.hexdigest(),'gzip_sha256':h.hexdigest(),'gzip_bytes':total,'ELF_header_hex':elfhead.hex()}
   else: records[name]=bytes(data)
   padding=f.read((-total)%512); check(padding==b'\0'*((-total)%512),'nonzero payload padding '+name)
   ok=total==x['bytes'] and h.hexdigest()==x['sha256'] and actual_ti.mode==x['mode']; check(ok,'archive payload mismatch '+name)
   member_results.append({'path':name,'bytes':total,'sha256':h.hexdigest(),'mode':actual_ti.mode,'pass':ok})
  tail=f.read(); check(len(tail)>=1024 and not tail.strip(b'\0'),'tar trailing content or missing terminator')
 check(len(member_results)==delivery['tar_members'],'tar regular count'); check(records.get('migration-part06'+volume+'/manifest.json')==manifest_bytes,'manifest exact bytes')
 return locals()
queue=json.load(open(ROOT+'migration-next-history-round2/queue.json')); roots={r['id']:r for r in queue['custody_roots']}
for volume,expected_count in [('g',16)]:
 m=json.load(open(ROOT+'migration-part06'+volume+'/manifest.json')); selected=[roots[rid] for rid in m['root_ids']]
 # Enforce the bounded safe metadata/root list before reading any payload.
 for x in m['files']:
  rr=[r for r in selected if x['path'].startswith(r['path']+'/')]
  if len(rr)!=1: raise ValueError('out-of-scope source path')
  r=rr[0]; rel=x['path'][len(r['path'])+1:]
  if not (rel in r['safe_metadata_relative_paths'] or x['path'] in {e['path'] for e in m['elf_payloads']}): raise ValueError('not allowed by queue: '+rel)
 v=verify(volume); errors=v['errors']; records=v['records']; gz=v['decompressed']; payload={x['archive_path']:x for x in v['files']}; expectedelf={x['path']:x for x in m['elf_payloads']}; seen=set(); rowresults=[]; indexbindings=0; excluded_index_references=[]
 def ck(ok,msg):
  if not ok: errors.append(msg)
 for root in selected:
  base=root['path'].removeprefix('/workspace/')+'/'; idxname=root['index'].removeprefix('/workspace/'); mapname=root['mapping'].removeprefix('/workspace/'); recbase=mapname.rsplit('/',1)[0]+'/'
  ck(hashlib.sha256(records[idxname]).hexdigest()==root['index_metadata_sha256'],'queue index hash '+root['id']); ck(hashlib.sha256(records[mapname]).hexdigest()==root['mapping_metadata_sha256'],'queue map hash '+root['id'])
  index=json.loads(records[idxname]); rows=json.loads(records[mapname]); ck(len(rows)==root['payload_count'],'root row count '+root['id'])
  for entry in index['files']:
   name=base+entry['path']; x=payload.get(name)
   if x is None and entry['path'] not in root['safe_metadata_relative_paths'] and name not in {p.removeprefix('/workspace/') for p in expectedelf}:
    excluded_index_references.append(name); continue
   ck(x is not None,'index target absent '+name)
   if x:
    ck(x['bytes']==entry['bytes'] and x['sha256']==entry['sha256'],'index size/hash '+name)
    if 'mode' in entry: ck(x['mode']==(int(entry['mode'],8) if isinstance(entry['mode'],str) else entry['mode']),'index mode '+name)
   indexbindings+=1
  for ordinal,r in enumerate(rows,1):
   path=r['witness']; name=path.removeprefix('/workspace/'); seen.add(name); d=gz[name]; e=expectedelf[path]
   good=d['bytes']==r['original_bytes'] and d['sha256']==r['original_sha256'] and d['gzip_bytes']==r['witness_bytes'] and d['gzip_sha256']==r['witness_sha256']; ck(good,'actual map gzip/original binding '+name)
   ck(e['root_id']==root['id'] and e['map_row']==ordinal-1 and e['logical_original']=={'path':r['logical_original_path'],'bytes':r['original_bytes'],'sha256':r['original_sha256'],'mode':r['original_mode']} and e['source_index']==r['source_index'] and e['source_index_sha256']==r['source_index_sha256'] and e['sha256']==r['witness_sha256'] and e['bytes']==r['witness_bytes'],'manifest ELF descriptor vs actual map '+name)
   ck(index['files'][e['index_files_row']]['path']==name[len(base):],'manifest index ordinal '+name)
   before=json.loads(records[recbase+str(ordinal)+'-before.json'])['original']; verified=json.loads(records[recbase+str(ordinal)+'-verified-before-unlink.json']); after=json.loads(records[recbase+str(ordinal)+'-after.json'])
   ck(after==r,'after receipt vs map '+name)
   for key,mapkey in [('path','logical_original_path'),('size','original_bytes'),('sha256','original_sha256'),('mode','original_mode'),('uid','original_uid'),('gid','original_gid'),('mtime_ns','original_mtime_ns'),('source_index','source_index'),('source_index_sha256','source_index_sha256'),('witness','witness')]: ck(before[key]==r[mapkey],'before receipt '+name+' '+key)
   for key in ['original_sha256','original_bytes','witness_sha256','witness_bytes']: ck(verified[key]==r[key],'verified receipt '+name+' '+key)
   ck(verified['decompressed_equals_original'] is True and r['physical_original_present'] is False,'historic receipt verification '+name)
   head=bytes.fromhex(d['ELF_header_hex']); ck(len(head)==64 and head[:4]==b'\x7fELF' and head[4:7]==bytes([2,1,1]) and int.from_bytes(head[18:20],'little')==62 and int.from_bytes(head[52:54],'little')==64,'ELF64 x86_64 header '+name)
   rowresults.append({'root_id':root['id'],'ordinal':ordinal,'witness':name,'original_sha256':r['original_sha256'],**d,'matches_actual_map':good})
  # Direct physical gzip scope follows the mapping directory (no unrelated recursive scan).
  physical={recbase+n for n in os.listdir('/workspace/'+recbase) if n.endswith('.gz') and os.path.isfile('/workspace/'+recbase+n)}
  ck(physical=={r['witness'].removeprefix('/workspace/') for r in rows},'physical gzip exact coverage '+root['id'])
 ck(seen==set(gz)=={p.removeprefix('/workspace/') for p in expectedelf},'manifest/archive/map ELF exact coverage'); ck(len(gz)==expected_count==m['elf_witness_count'],'expected ELF count')
 status='PASS' if not errors else 'FAIL'; total=sum(d['bytes'] for d in gz.values()); n=v['n']; B=v['B']
 result={'status':status,'scope':'Part06'+volume+' existing custody migration only; no new source/acceptance conclusions; no sixth-group or Linux completion claim.','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{'path':v['archive'],'bytes':n,'sha256':v['sha'].hexdigest(),'git_blob':v['blob'].hexdigest()},'counts':{'source_originals':len(v['files']),'regular_tar_members':len(v['member_results']),'ELF_gzip_originals':len(gz),'metadata_originals':len(v['files'])-len(gz),'pax_mtime_control_records':v['pax_count'],'original_decompressed_bytes':total,'index_file_bindings':indexbindings,'receipt_triplets':len(rowresults),'trailing_zero_bytes':len(v['tail'])},'checks':{'source_and_archive':'all size/SHA256/mode and regular type; full archive SHA256/size/Git-blob checked','tar':'exact ordered member set and manifest bytes; safe unique paths, no links/extras; zero padding/tail; all raw header/PAX bytes match source stat metadata','actual_custody_maps':'queue-bound original index/progress bytes independently read, all file references checked, manifest ELF descriptors cross-checked','ELF':'streamed single gzip CRC/EOF; original and compressed SHA/size, ELF64 x86_64 header; exact physical coverage; before/verified/after receipt identities bound','source_index_scope':'source-index path/SHA references checked across immutable map/before/manifest; referenced external source indices not opened outside allowed custody roots','metadata':'small metadata may already be Git-covered; retained for self-contained recovery and not counted as added ELF','old_indices':'unchanged; no source acceptance inferred'},'excluded_index_references':excluded_index_references,'root_ids':m['root_ids'],'sources':v['source_results'],'tar_members':v['member_results'],'restored_streams':rowresults,'errors':errors}
 open(B+'findings.json','w').write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 report=f'''# Part06{volume} independent verification\n\nResult: **{status}**, {len(errors)} findings. Verified {len(v['files'])} original files and {len(v['member_results'])} regular tar members, including exact control manifest bytes. Source and member SHA-256/size/mode match. All raw header/PAX control bytes match source-derived uid/gid/name/mode/mtime metadata. Paths are safe and unique, with no links, unexpected members or nonzero padding/tail.\n\nArchive: `{v['archive']}`\n\n- Bytes: {n}\n- SHA-256: `{v['sha'].hexdigest()}`\n- Git blob: `{v['blob'].hexdigest()}`\n- ELF gzip originals: {len(gz)}; metadata originals: {len(v['files'])-len(gz)}.\n- Original ELF bytes streamed: {total}.\n\nQueue roots {', '.join(m['root_ids'])} were enforced before reading originals. Actual original index/progress files matched queue hashes; {indexbindings} indexed file bindings and {len(rowresults)} before/verified/after receipt triplets passed. The migration ELF descriptors were independently cross-checked against those actual records. All gzip streams reached valid CRC/EOF and match original and compressed SHA-256/size. ELF64 x86_64 headers passed. Physical gzip files, actual maps and archive payloads cover the same set exactly.\n\nSource-index path/hash references agree across original maps, before receipts and migration manifest. Referenced source indices outside the bounded custody roots were not opened; this check preserves recorded provenance without asserting fresh source/compiler identity. The original index also references {len(excluded_index_references)} fallback/cache files outside the queue's explicit direct-file/ELF scope; those references remain preserved but their targets were excluded and not opened. Small already Git-covered metadata is retained for self-contained restoration and is not counted as newly added ELF. This migration does not close the sixth group or Linux acceptance.\n\nAll originals were read only; decompression was streamed in memory, with no ELF written or executed, build, VM, network or subagent. No raw environment or credential files were read. Volumes a–e were not reverified.\n'''
 if errors: report+='\n'+'\n'.join('- '+e for e in errors)+'\n'
 open(B+'report.md','w').write(report)
 print(json.dumps({'volume':volume,'status':status,'errors':errors,'counts':result['counts'],'report_bytes':os.stat(B+'report.md').st_size,'findings_bytes':os.stat(B+'findings.json').st_size}))
