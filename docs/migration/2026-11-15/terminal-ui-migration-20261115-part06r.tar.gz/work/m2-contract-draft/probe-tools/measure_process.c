#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr,"usage: measure_process PROGRAM [ARGS]\n"); return 2; }
    struct timespec start, end;
    struct rusage usage;
    clock_gettime(CLOCK_MONOTONIC, &start);
    pid_t child = fork();
    if (child < 0) { perror("fork"); return 2; }
    if (!child) { execvp(argv[1], argv+1); perror("execvp"); _exit(127); }
    int status;
    while (wait4(child,&status,0,&usage) < 0) { if (errno != EINTR) { perror("wait4"); return 2; } }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double wall = end.tv_sec-start.tv_sec + (end.tv_nsec-start.tv_nsec)/1e9;
    double user = usage.ru_utime.tv_sec + usage.ru_utime.tv_usec/1e6;
    double system = usage.ru_stime.tv_sec + usage.ru_stime.tv_usec/1e6;
    fprintf(stderr,"wall_seconds=%.9f,user_seconds=%.6f,system_seconds=%.6f,maxrss_kib=%ld,exit=%d\n",wall,user,system,usage.ru_maxrss,WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status));
    return WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);
}
