import json, os, stat, hashlib, gzip, zlib, struct, tarfile, pathlib

BASE='/workspace/work/'
queue=json.load(open(BASE+'migration-next-history-round2/queue.json'))
roots={r['id']:r for r in queue['custody_roots']}
sha=lambda b:hashlib.sha256(b).hexdigest()
cache={}
def read(p):
    assert '/vte-protocol-counterexample/' not in p and '/quarantine/' not in p
    assert 'actual/vte/160x48/vertical_panels/new/output/0' not in p
    if p not in cache:
        s=os.lstat(p);assert stat.S_ISREG(s.st_mode),p
        cache[p]=open(p,'rb').read()
    return cache[p]
def obj(p):
    b=read(p)
    return json.loads(gzip.decompress(b) if p.endswith('.gz') else b)
def each(x):
    if isinstance(x,dict):
        yield x
        for v in x.values():yield from each(v)
    elif isinstance(x,list):
        for v in x:yield from each(v)
def original_fields(e,r):
    o=e['logical_original']
    assert r['logical_original_path']==o['path']
    for k in ('bytes','sha256','mode'):assert r['original_'+k]==o[k],(k,r,o)
    for a,b in [('witness','path'),('witness_bytes','bytes'),('witness_sha256','sha256'),('source_index','source_index'),('source_index_sha256','source_index_sha256')]:assert r[a]==e[b]

for v in 'hi':
    cache.clear()
    folder=BASE+'migration-part06'+v+'/'
    m=obj(folder+'manifest.json');d=obj(folder+'delivery.json')
    errors=[];records=[];root_results=[]
    def check(label,fun):
        try: return fun()
        except Exception as ex: errors.append(label+': '+repr(ex));return None
    files=m['files'];by={f['archive_path']:f for f in files};elfs={e['path']:e for e in m['elf_payloads']}
    assert len(by)==len(files) and len(elfs)==len(m['elf_payloads'])
    for r_id in m['root_ids']:
        r=roots[r_id]
        def rootcheck():
            assert sha(read(r['index']))==r['index_metadata_sha256']
            assert sha(read(r['mapping']))==r['mapping_metadata_sha256']
            rows=obj(r['mapping']);ee=[e for e in m['elf_payloads'] if e['root_id']==r_id]
            assert len(rows)==len(ee)==r['payload_count']
            assert {x['witness'] for x in rows}=={e['path'] for e in ee}
            assert sum(e['bytes'] for e in ee)==r['gzip_bytes']
            allowed={r['path']+'/'+p for p in r['safe_metadata_relative_paths']}|{e['path'] for e in ee}
            actual={f['path'] for f in files if f['path'].startswith(r['path']+'/')}
            assert actual==allowed, {'missing':list(allowed-actual),'extra':list(actual-allowed)}
            return {'id':r_id,'queue_index_mapping_sha256':True,'physical_and_safe_metadata_coverage':True,'elf_count':len(ee)}
        rr=check('root '+r_id,rootcheck)
        if rr:root_results.append(rr)
    for f in files:
        def filecheck():
            assert f['archive_path']==f['path'].removeprefix('/workspace/')
            b=read(f['path']);s=os.lstat(f['path'])
            assert len(b)==s.st_size==f['bytes'] and sha(b)==f['sha256'] and stat.S_IMODE(s.st_mode)==f['mode']
            return True
        check('file '+f['path'],filecheck)
    for e in m['elf_payloads']:
        def elfcheck():
            r=roots[e['root_id']];row=obj(r['mapping'])[e['map_row']];original_fields(e,row)
            indexed=obj(r['index'])['files'][e['index_files_row']]
            assert r['path']+'/'+indexed['path']==e['path']
            assert indexed['bytes']==e['bytes'] and indexed['sha256']==e['sha256'] and int(indexed['mode'],8)==e['mode']
            base=r['mapping'].rsplit('/',1)[0]+'/'+str(e['map_row']+1)
            before=obj(base+'-before.json')['original'];after=obj(base+'-after.json');verified=obj(base+'-verified-before-unlink.json')
            original_fields(e,after)
            o=e['logical_original']
            for a,b in [('path','path'),('size','bytes'),('sha256','sha256'),('mode','mode')]:assert before[a]==o[b]
            assert before['witness']==e['path']
            for k in ('original_sha256','original_bytes','witness_sha256','witness_bytes'):assert verified[k]==row[k]
            assert verified['decompressed_equals_original'] is True
            sb=read(e['source_index']);assert sha(sb)==e['source_index_sha256']
            source=obj(e['source_index']);matches=[n for n in each(source) if n.get('path')==o['path'] and n.get('sha256')==o['sha256']]
            # Some historic source indexes expose the ELF digest as a named scalar instead of a file record.
            source_digest_present=o['sha256'] in json.dumps(source)
            for n in matches:
                if 'bytes'in n:assert n['bytes']==o['bytes']
                if 'mode'in n:assert (int(n['mode'],8) if isinstance(n['mode'],str) else n['mode'])==o['mode']
            b=read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
            dec=zlib.decompressobj(31);h=hashlib.sha256();n=0;crc=0;head=b''
            for j in range(0,len(b),65536):
                out=dec.decompress(b[j:j+65536]);h.update(out);n+=len(out);crc=zlib.crc32(out,crc)
                if len(head)<64:head=(head+out)[:64]
            out=dec.flush();h.update(out);n+=len(out);crc=zlib.crc32(out,crc)
            assert dec.eof and not dec.unused_data and not dec.unconsumed_tail
            assert struct.unpack('<II',b[-8:])==(crc&0xffffffff,n&0xffffffff)
            assert n==o['bytes'] and h.hexdigest()==o['sha256']
            assert head[:4]==b'\x7fELF' and head[4] in (1,2) and head[5] in (1,2) and head[6]==1
            return {'root':e['root_id'],'path':e['path'],'gzip_bytes':len(b),'original_bytes':n,'original_sha256':h.hexdigest(),'gzip_sha256':sha(b),'crc32':f'{crc&0xffffffff:08x}','eof':True,'elf_header':head[:20].hex(),'source_index_matching_records':len(matches),'source_index_contains_original_digest':source_digest_present,'receipts_index_mapping':True}
        result=check('ELF '+e['path'],elfcheck)
        if result:records.append(result)
    def archivecheck():
        p=d['archive_path'];assert p.startswith('/dev/shm/terminal-ui-migration-20261115-host/')
        s=os.lstat(p);assert stat.S_ISREG(s.st_mode) and s.st_size==d['bytes']
        h=hashlib.sha256();git=hashlib.sha1(b'blob '+str(s.st_size).encode()+b'\0')
        with open(p,'rb') as fd:
            while b:=fd.read(1048576):h.update(b);git.update(b)
        assert h.hexdigest()==d['sha256'] and git.hexdigest()==d['git_blob']
        control='migration-part06'+v+'/manifest.json';seen=set();total=0
        with tarfile.open(p,'r|gz') as t:
            for member in t:
                name=member.name
                assert name and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts and name not in seen
                assert member.isfile() and not member.linkname
                seen.add(name);total+=member.size
                expected=by.get(name)
                if name==control:
                    b=t.extractfile(member).read();cs=os.stat(folder+'manifest.json')
                    assert b==read(folder+'manifest.json') and member.size==cs.st_size
                    assert member.mode==stat.S_IMODE(cs.st_mode) and member.uid==cs.st_uid and member.gid==cs.st_gid and abs(member.mtime-cs.st_mtime)<0.000001
                else:
                    assert expected is not None,name
                    hh=hashlib.sha256();nn=0
                    fd=t.extractfile(member)
                    while b:=fd.read(1048576):hh.update(b);nn+=len(b)
                    assert nn==member.size==expected['bytes'] and hh.hexdigest()==expected['sha256'] and member.mode==expected['mode']
                    ss=os.stat(expected['path']);assert member.uid==ss.st_uid and member.gid==ss.st_gid and abs(member.mtime-ss.st_mtime)<0.000001
        assert seen==set(by)|{control}
        assert len(files)==d['payload_files'] and len(seen)==d['tar_members'] and len(records)==d['ELF_count']==m['elf_witness_count']
        # Force complete outer gzip consumption, including CRC/EOF beyond tar end blocks.
        with gzip.open(p,'rb') as fd:
            while fd.read(1048576):pass
        return {'bytes':s.st_size,'sha256':h.hexdigest(),'git_blob':git.hexdigest(),'payload_files':len(files),'tar_members':len(seen),'full_member_bytes':total,'safe_regular_unique_exact_members':True,'source_and_tar_modes_uid_gid_mtime':True,'control_manifest_exact_bytes_and_metadata':True,'outer_gzip_crc_eof':True}
    archive=check('archive',archivecheck)
    extra_gzip=[f['path'] for f in files if f['path'].endswith('.gz') and f['path'] not in elfs]
    findings={'status':'PASS' if not errors else 'FAIL','volume':'06'+v,'errors':errors,'archive':archive,'roots':root_results,'elf_witnesses':records,'metadata_gzip_payloads':extra_gzip,'historical_source_index_binding_limitations':[{'path':r['path'],'reason':'Referenced historical source index SHA matches, but that index does not contain this ELF digest; exact original binding rests on matching index/progress/before-after/verified custody receipts and measured decompressed bytes.'} for r in records if not r['source_index_contains_original_digest']],'root13_metadata_json_gzip_note':'The two old-roots-noncandidates JSON.gz metadata copies are not ELF witnesses and are not members of 06h or 06i. One source metadata gzip was parsed as JSON to cross-check source records; no content was executed.','limitations':'Historical logical originals were removed by prior custody operations; original size/hash/mode validated from index/progress/before-after/verified receipts and streamed witness decompression. No original ELF restored to disk, executed, rebuilt, or newly accepted. Existing source versions and Linux acceptance conclusions unchanged.'}
    with open(folder+'findings.json','w') as fd:json.dump(findings,fd,indent=2);fd.write('\n')
    text='# Independent migration verification 06'+v+'\n\n'+findings['status']+'; '+str(len(files))+' payload files, '+str(len(records))+' ELF witnesses.\n\n'
    text+='All listed physical source files checked with lstat, full SHA-256, size and mode. Queue root index/mapping digests, complete physical witness coverage, safe metadata scope, source indexes and before/after/verified receipts cross-checked. Every ELF gzip streamed in memory with SHA-256, decompressed SHA-256/size, CRC32, single-stream EOF and ELF header verification.\n\n'
    text+='Archive full size/SHA-256/Git blob match delivery; exact safe regular unique tar members, full payload bytes, permissions, uid/gid/mtime and exact control manifest bytes/metadata verified. Outer gzip read through CRC/EOF.\n\n'
    text+=findings['root13_metadata_json_gzip_note']+'\n\n'+findings['limitations']+'\n'
    if findings['historical_source_index_binding_limitations']:text+='\nHistorical source-index limitation: two r11 historical source indexes are matching provenance references but do not themselves enumerate the unit-a-baseline and std.testrunner ELF hashes. The matching custody receipts bind those measured witnesses; this creates no new acceptance claim.\n'
    if errors:text+='\nErrors:\n'+''.join('- '+e+'\n' for e in errors)
    with open(folder+'report.md','w') as fd:fd.write(text)
    assert os.path.getsize(folder+'report.md')+os.path.getsize(folder+'findings.json')<150000
    print(v,findings['status'],len(records),errors,flush=True)
