#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/ioctl.h>
static unsigned seq;
static int gated;
int ioctl(int fd, unsigned long req, ...) {
    va_list ap; va_start(ap,req); void *arg=va_arg(ap,void *); va_end(ap);
    int (*real_ioctl)(int,unsigned long,...)=dlsym(RTLD_NEXT,"ioctl");
    int result=real_ioctl(fd,req,arg);
    if (fd==1 && req==TIOCGWINSZ && result==0) {
        unsigned n=++seq; struct winsize *ws=arg;
        const char *dir=getenv("RESIZE_PROBE_DIR"); char path[1024];
        snprintf(path,sizeof(path),"%s/queries.log",dir); FILE *log=fopen(path,"a");
        struct timespec ts; clock_gettime(CLOCK_REALTIME,&ts);
        fprintf(log,"%ld.%09ld query=%u cols=%u rows=%u\n",ts.tv_sec,ts.tv_nsec,n,ws->ws_col,ws->ws_row); fclose(log);
        snprintf(path,sizeof(path),"%s/arm",dir);
        if (!gated && n%2==1 && access(path,F_OK)==0) {
            gated=1; snprintf(path,sizeof(path),"%s/width-read",dir); int out=open(path,O_WRONLY|O_CREAT,0600); close(out);
            snprintf(path,sizeof(path),"%s/resume",dir); struct timespec pause={0,1000000};
            while (access(path,F_OK)!=0) nanosleep(&pause,0);
        }
    }
    return result;
}
