/* Fixture selfcheck only: exercise syscall faults against the real existing
 * native writer, without substituting any cjtui session implementation. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
extern void cjt_test_arm(int, int64_t, int);
extern int cjt_buffer_add(int);
extern int cjt_buffer_write(void);
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    cjt_test_arm(atoi(argv[1]), atoll(argv[2]), 1);
    const unsigned char frame[] = "\033]52;c;Zg==\007";
    for (unsigned i = 0; i < sizeof(frame) - 1; i++) {
        if (cjt_buffer_add(frame[i]) != 0) { fputs("allocation-failed\n", stderr); return 3; }
    }
    int result = cjt_buffer_write();
    fprintf(stderr, "writer=%d\n", result);
    return result == 0 ? 0 : 4;
}
