# BitArray 二进制位数组库开发任务书

## 1. 项目目标

使用仓颉（Cangjie）语言设计并实现一个通用二进制位数组类库 `BitArray`，提供位存储、位运算、分段访问（可重叠）和分区访问（互斥）能力，为仓颉生态中的协议解析、硬件寄存器编程、位域操作等场景提供基础数据结构支持。

本项目定位参考：

- `std::bitset`（C++）：固定大小位集合
- `boost::dynamic_bitset`（C++）：动态大小位数组
- `bitvec`（Rust）：通用位向量库
- `bitfield`（Rust）：位域宏

本项目只负责：

- 二进制位存储与位运算
- 多种构造方式（整数、Bool 数组、变长参数、字符串解析）
- 命名段读写（SegmentedBitArray）
- 命名互斥字段读写（PartitionedBitArray）
- 标准接口实现（Hashable / Equatable / Comparable / Parsable）

不负责：

- 大数算术运算
- 序列化/反序列化
- 位图图像处理
- 压缩算法

设计原则：

> 位存储与位访问解耦。`BitArray` 只管理位数据，分段和分区访问通过独立的包装器类提供，不污染核心数据结构。

两个包装器之间没有继承关系，各自独立持有 `BitArray`：

```mermaid
graph TB
    BitArray["BitArray（纯位存储）"]
    SBA["SegmentedBitArray（段可重叠）"]
    PBA["PartitionedBitArray（字段互斥）"]
    BP["BitPartition（互斥校验）"]

    BitArray -->|持有| SBA
    BitArray -->|持有| PBA
    PBA -->|持有| BP
```

---

## 2. 总体架构

```mermaid
classDiagram
    class BitArray {
        -bytes: Array~UInt8~
        -bitCount: Int64
        -segments: HashMap~String, BitSegment~
        +init()
        +init(bitCount: Int64)
        +init(values: Array~UInt8~)
        +init(values: Array~UInt16~)
        +init(values: Array~UInt32~)
        +init(values: Array~UInt64~)
        +init(bits: Array~Bool~)
        +[] index: Int64: Bool
        +[] index: Int64; value!: Bool
        +&(rhs): BitArray
        +|(rhs): BitArray
        +^(rhs): BitArray
        +!(): BitArray
        +<<(shift: Int64): BitArray
        +>>(shift: Int64): BitArray
        +==(rhs): Bool
        +!=(rhs): Bool
        +clone(): BitArray
        +reverse()
        +fill(value: Bool)
        +all(): Bool
        +any(): Bool
        +none(): Bool
        +count(value!: Bool): Int64
        +indexOf(value!: Bool): Option~Int64~
        +swap(i, j)
        +slice(start, end): BitArray
        +concat(other): BitArray
        +toUInt64(): UInt64
        +toBoolArray(): Array~Bool~
        +toString(): String
    }

    class SegmentedBitArray {
        -ba: BitArray
        -segments: HashMap~String, BitSegment~
        +addSegment(seg: BitSegment)
        +getSegment(name): UInt64
        +setSegment(name, value: UInt64)
        +removeSegment(name)
        +getSegmentNames(): Array~String~
        +toString(): String
    }

    class PartitionedBitArray {
        -ba: BitArray
        -partition: BitPartition
        +addField(field: BitSegment)
        +getField(name): UInt64
        +setField(name, value: UInt64)
        +removeField(name)
        +listFieldNames(): Array~String~
        +containsField(name): Bool
        +toString(): String
    }

    class BitPartition {
        -fields: HashMap~String, BitSegment~
        +addField(field: BitSegment)
        +addField(all!: Array~BitSegment~)
        +removeField(name)
        +findField(name): Option~BitSegment~
        +getFieldNames(): Array~String~
        +contains(name): Bool
        +count: Int64
        +clear()
    }

    SegmentedBitArray --> BitArray : 持有
    PartitionedBitArray --> BitArray : 持有
    PartitionedBitArray --> BitPartition : 持有
```

---

## 3. 项目结构

```
libbitarray/
├── cjpm.toml
├── README.md
├── src/
│   ├── bitarray.cj                  # BitArray 主类 + 接口实现
│   ├── bitsegment.cj                # BitSegment 描述符结构体
│   ├── segmented_bitarray.cj        # SegmentedBitArray 包装器
│   ├── bitpartition.cj              # BitPartition 互斥校验类
│   ├── partitioned_bitarray.cj      # PartitionedBitArray 包装器
│   └── test/
│       └── bitarray_test.cj         # 71 个单元测试
├── doc/
│   ├── task.md                      # 本文件
│   ├── DESIGN.md                    # 设计文档
│   └── API.md                       # API 参考
```

---

## 4. BitArray 核心模块

### 4.1 职责

- 二进制位存储与访问
- 位运算（& | ^ ! << >> == !=）
- 多种构造入口
- 标准接口实现

### 4.2 位序约定

| 概念 | 约定 | 说明 |
|------|------|------|
| **ba[0]** | LSB（最低有效位） | 与 CPU 位运算一致 |
| **toString()** | MSB 在左 | 符合人类阅读习惯 |
| **字符串输入** | 左 = MSB，右 = LSB | 自然书写顺序 |
| **Bool 数组输入** | bits[0] = MSB | 最左元素 = 最高位 |
| **整数序列输入** | values[0] = MSB 侧 | 最左元素 = 最高值 |
| **段 offset** | 从 LSB 算起 | 与硬件寄存器规范一致 |

### 4.3 内部存储

```cangjie
private var bytes: Array<UInt8>    // 字节数组
private var bitCount: Int64        // 有效位数
```

字节数组是唯一存储方式。bit 索引到 byte 的映射：

```
byteIndex = index / 8
bitInByte = index % 8
mask = 1u8 << UInt8(bitInByte)
```

选择 `Array<UInt8>` 而非 `Array<UInt32>` 的原因：

| 因素 | Array<UInt8> | Array<UInt32> |
|------|-------------|---------------|
| 空间浪费 | ≤ 7 位 | ≤ 31 位 |
| 端序相关 | 无关 | 需处理大小端 |
| 协议对齐 | 天然一致 | 需字节重排 |

### 4.4 构造器

```
BitArray()
BitArray(bitCount: Int64)
BitArray(values: Array<UInt8>)     // 变长参数
BitArray(values: Array<UInt16>)    // 变长参数
BitArray(values: Array<UInt32>)    // 变长参数
BitArray(values: Array<UInt64>)    // 变长参数
BitArray(bits: Array<Bool>)        // 固定数组, bits[0]=MSB
```

变长参数示例：

```cangjie
BitArray(0xABu8)                    // 8 位
BitArray(0xABu8, 0xCDu8)           // 16 位, 0xAB = 高8位, 0xCD = 低8位
BitArray(0xA5C3u16)                // 16 位
BitArray(0xABCDu16, 0xEF01u16)     // 32 位, 0xABCD = 高16位
```

### 4.5 标准接口

通过 `extend BitArray` 实现（无状态扩展）：

| 接口 | 方法 | 实现 |
|------|------|------|
| Hashable | `hashCode()` | 字节数组线性哈希 `h = h * 31 + byte` |
| Equatable | `equals(other)` | 委托到 `operator ==` |
| Comparable | `compare(other)` | 先比位数，再逐位比 |
| Parsable | `parse(s) / tryParse(s)` | 空格分隔，左=MSB，反序存 |

---

## 5. Segment 分段模块

### 5.1 BitSegment 描述符

```cangjie
public struct BitSegment {
    let name: String    // 段/字段名称
    let offset: Int64   // 起始位偏移（0 = LSB）
    let width: Int64    // 位宽（1..64）
}
```

段的数据类型由 width 决定（值以 UInt64 返回，调用者自行转型）：

| width | 对应类型 |
|-------|---------|
| 1 | Bool |
| 2..8 | UInt8 |
| 9..16 | UInt16 |
| 17..32 | UInt32 |
| 33..64 | UInt64 |

### 5.2 SegmentedBitArray 包装器

段允许重叠。适用于多粒度解读同一份位数据。

```cangjie
let view = SegmentedBitArray(ba)
view.addSegment(BitSegment("whole", 0, 32))
view.addSegment(BitSegment("high16", 16, 16))    // 与 whole 重叠
view.addSegment(BitSegment("low16", 0, 16))      // 与 whole、high16 都重叠

let h = view.getSegment("high16")
view.setSegment("low8", 0xABu64)
```

---

## 6. Partition 分区模块

### 6.1 BitPartition 互斥校验

独立封装"互斥字段集"的校验逻辑。

```cangjie
public class BitPartition {
    func addField(field: BitSegment): Unit    // 自动重叠检测
    func addField(all!: Array<BitSegment>): Unit  // 批量添加，原子性
    func removeField(name: String): Unit
    func findField(name: String): Option<BitSegment>
    func getFieldNames(): Array<String>
    func contains(name: String): Bool
    prop count: Int64
    func clear(): Unit
}
```

重叠判定：

```
区间 [a.offset, a.offset + a.width) 与 [b.offset, b.offset + b.width)
不重叠 ⟺ aEnd <= b.offset || bEnd <= a.offset
```

### 6.2 PartitionedBitArray 包装器

分区是分段的特化——字段之间互斥。不继承 SegmentedBitArray，避免 `addSegment` 暴露给分区用户。独立持有 `BitArray + BitPartition`。

```cangjie
let pba = PartitionedBitArray(ba)
pba.addField(BitSegment("flags",   0, 8))
pba.addField(BitSegment("length",  8, 16))
pba.addField(BitSegment("type",    24, 4))
pba.addField(BitSegment("version", 28, 4))

let v = pba.getField("version")     // → 1
pba.setField("flags", 0x42u64)
```

### 6.3 为什么不用继承

仓颉不能隐藏父类公开方法。如果 `PartitionedBitArray <: SegmentedBitArray`：

```cangjie
let pba = PartitionedBitArray(ba)
pba.addSegment(...)      // ❌ 分区用户不应有 addSegment
pba.addField(...)        // ✅ 分区用户应该用 addField
```

改为组合后，`PartitionedBitArray` 只暴露 `addField` / `getField` / `setField`，API 纯净。

---

## 7. 两模型共存

`SegmentedBitArray` 和 `PartitionedBitArray` 可以指向同一个底层 `BitArray`，修改通过任一方进行，对方立即可见：

```cangjie
let ba = BitArray(0x1A_00_AB_CDu32)
let view = SegmentedBitArray(ba)      // 视图：允许重叠
let pba = PartitionedBitArray(ba)     // 分区：互斥

pba.addField(BitSegment("f_flags", 0, 8))
view.addSegment(BitSegment("whole", 0, 32))

pba.setField("f_flags", 0x42u64)
view.getSegment("whole") & 0xFFu64     // → 0x42（分区写入立即可见）
```

---

## 8. 字符串解析（Parsable）

### 8.1 parse 接口

```cangjie
BitArray.parse(s: String): BitArray
BitArray.tryParse(s: String): Option<BitArray>
```

### 8.2 解析规则

| 字符 | 处理 |
|------|------|
| `'0'` | 加入有效位（false） |
| `'1'` | 加入有效位（true） |
| `' '` | 分隔符，跳过 |
| 其他 | 抛 IllegalArgumentException |

### 8.3 位序映射

```
正向迭代字符串（i=0..n-1）：收集 MSB → LSB
validBits[0] = s[0] = MSB → ba[bitCount-1]
validBits[n-1] = s[n-1] = LSB → ba[0]
toString() 还原字符串 ✅
```

---

## 9. 兼容性要求

支持存储：
```
任意长度的位序列（0 ~ 2^63-1 位）
```

支持构造：
```
UInt8 / UInt16 / UInt32 / UInt64 序列（变长参数）
Array<Bool>
"01" 字符串（空格分隔）
```

---

## 10. 性能要求

| 项目 | 目标 |
|------|------|
| 单 bit 访问 | O(1) |
| 位运算（& \| ^ !） | O(n) |
| 段/字段读（< 64 位） | O(1) 实际 |
| 构造（拷贝） | O(n) |
| 克隆 | O(n) |
| 翻转、填充 | O(n) |

---

## 11. 验收标准

1. [x] 从无符号整数序列（变长参数）构造
2. [x] 从 Bool 数组构造（bits[0]=MSB）
3. [x] 从 01 字符串解析
4. [x] 位索引访问（ba[i]）
5. [x] 位运算（& | ^ ! << >>）
6. [x] 判等（== !=）
7. [x] 克隆、翻转、填充
8. [x] all / any / none / count
9. [x] slice / concat / toUInt64 / toBoolArray
10. [x] Hashable / Equatable / Comparable / Parsable 接口
11. [x] 分段访问（SegmentedBitArray，允许重叠）
12. [x] 分区访问（PartitionedBitArray，互斥校验）
13. [x] 两模型共存
14. [x] 空数组、越界等边缘情况
15. [x] 71 项单元测试全部通过

最终输出：

```
libbitarray（静态库）
├── src/        7 个源文件
├── doc/        3 个文档文件
└── test/       71 个测试用例
```
