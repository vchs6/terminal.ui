package bitarray

/**
 * BitSegment — 位段描述符
 *
 * 描述 BitArray 中一个命名的连续位段。
 * 段的数据类型由其 width 字段决定：
 *   width == 1  → Bool（单个标志位）
 *   width 2..8  → UInt8
 *   width 9..16 → UInt16
 *   width 17..32 → UInt32
 *   width 33..64 → UInt64
 *
 * 多个段可以重叠，offset 从最低有效位（LSB = 0）开始计算。
 */
public struct BitSegment {
    /** 段名称 */
    let name: String
    /** 起始位偏移（从 LSB 算起，0 = 最低位） */
    let offset: Int64
    /** 段宽度（位数，取值范围 1..64） */
    let width: Int64

    /**
     * 构造一个位段描述符。
     * @param name   段名称
     * @param offset 起始位偏移（>= 0）
     * @param width  段宽度（1..64）
     * @throws ArithmeticException 当 width 不在 1..64 范围或 offset < 0 时
     */
    public init(name: String, offset: Int64, width: Int64) {
        if (width < 1 || width > 64) {
            throw ArithmeticException("BitSegment: width must be in 1..64, but got ${width}")
        }
        if (offset < 0) {
            throw ArithmeticException("BitSegment: offset must be >= 0, but got ${offset}")
        }
        this.name = name
        this.offset = offset
        this.width = width
    }
}
