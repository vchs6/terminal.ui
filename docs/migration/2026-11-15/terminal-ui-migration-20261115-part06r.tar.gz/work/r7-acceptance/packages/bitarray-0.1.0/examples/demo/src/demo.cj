package demo

import bitarray.*
import std.collection.*
import std.convert.*

/**
 * BitArray 功能演示
 *
 * 编译运行：
 *   cd examples/demo
 *   cjpm run
 */
main() {
    println("========== BitArray 功能演示 ==========")

    // ---- 1. 构造 ----
    println("\n--- 1. 构造 ---")

    // 无符号整数变长参数
    let ba8   = BitArray(0b1010_1101u8)
    let ba16  = BitArray(0xA5C3u16)
    let ba32  = BitArray(0xDEAD_BEEFu32)
    let ba64  = BitArray(0x0123_4567_89AB_CDEFu64)
    println("UInt8(0b10101101)  = ${ba8}")
    println("UInt16(0xA5C3)     = ${ba16}")
    println("UInt32(0xDEADBEEF) = ${ba32}")
    println("UInt64(0x0123456789ABCDEF) = ${ba64}")

    // 多值构造（变长参数），从左到右为 MSB 侧到 LSB 侧
    let baMulti = BitArray(0xABu8, 0xCDu8)
    println("BitArray(0xAB, 0xCD) = ${baMulti}  → toUInt64 = 0x${baMulti.toUInt64().format("x")}")

    // Bool 数组（bits[0] = MSB）
    let baBool = BitArray([true, false, true, false, true, true, false, true])
    println("BitArray([true,false,true,false,true,true,false,true]) = ${baBool}")

    // 字符串解析（空格为分隔符）
    let baParse = BitArray.parse("1010 1101 1111 0000")
    println("BitArray.parse(\"1010 1101 1111 0000\") = ${baParse}")

    // ---- 2. 位索引与运算 ----
    println("\n--- 2. 位运算 ---")

    let a = BitArray.parse("1100")
    let b = BitArray.parse("1010")
    println("a = ${a}")
    println("b = ${b}")
    println("a & b = ${a & b}")
    println("a | b = ${a | b}")
    println("a ^ b = ${a ^ b}")
    println("!a    = ${!a}")
    println("a << 1 = ${a << 1}")
    println("a >> 1 = ${a >> 1}")

    // 索引访问
    println("\n-- 索引访问 --")
    let idx = BitArray.parse("10010110")
    print("idx = ${idx}, bits: ")
    for (i in 0..idx.size) {
        print(if (idx[i]) { "1" } else { "0" })
    }
    println()

    // ---- 3. 分段访问（SegmentedBitArray，段可重叠） ----
    println("\n--- 3. 分段访问（SegmentedBitArray） ---")

    // 模拟一个 32 位寄存器
    let reg = BitArray(0x1A_00_AB_CDu32)
    let view = SegmentedBitArray(reg)
    view.addSegment(BitSegment("whole",   0, 32))
    view.addSegment(BitSegment("flags",   0,  8))
    view.addSegment(BitSegment("length",  8, 16))
    view.addSegment(BitSegment("type",   24,  4))
    view.addSegment(BitSegment("version",28,  4))

    println("寄存器值 = ${reg}")
    println("  whole   = 0x${view.getSegment("whole").format("x")} (32位)")
    println("  flags   = 0x${view.getSegment("flags").format("x")} (8位)")
    println("  length  = ${view.getSegment("length")} (16位)")
    println("  type    = 0x${view.getSegment("type").format("x")} (4位)")
    println("  version = ${view.getSegment("version")} (4位)")

    // 修改段值
    println("\n  修改 flags = 0x42 ...")
    view.setSegment("flags", 0x42u64)
    println("  修改后寄存器值 = ${reg}")
    println("  flags 读取 = 0x${view.getSegment("flags").format("x")}")

    // ---- 4. 分区访问（PartitionedBitArray，互斥校验） ----
    println("\n--- 4. 分区访问（PartitionedBitArray） ---")

    let pba = PartitionedBitArray(BitArray(0x1A_00_AB_CDu32))
    pba.addField(BitSegment("flags",   0,  8))
    pba.addField(BitSegment("length",  8, 16))
    pba.addField(BitSegment("type",   24,  4))
    pba.addField(BitSegment("version",28,  4))

    println("分区寄存器值 = ${pba}")
    println("  flags   = 0x${pba.getField("flags").format("x")}")
    println("  length  = ${pba.getField("length")}")

    // 重叠检测
    try {
        pba.addField(BitSegment("overlap", 4, 8))
        println("  ❌ 重叠字段未检测到!")
    } catch (e: IllegalArgumentException) {
        println("  重叠检测: 与已有字段重叠 ✅")
    }

    // ---- 5. 两模型共存 ----
    println("\n--- 5. 两模型共存 ---")

    let shared = BitArray(0x1A_00_AB_CDu32)
    let sView = SegmentedBitArray(shared)
    let sPba  = PartitionedBitArray(shared)

    sPba.addField(BitSegment("f_flags", 0, 8))
    sView.addSegment(BitSegment("whole", 0, 32))

    println("初始值: whole=0x${sView.getSegment("whole").format("x")}, f_flags=0x${sPba.getField("f_flags").format("x")}")

    // 通过分区写入，通过分段读取
    sPba.setField("f_flags", 0x42u64)
    println("设 f_flags=0x42 后:")
    println("  分段读 whole  = 0x${sView.getSegment("whole").format("x")}")
    println("  分区读 f_flags = 0x${sPba.getField("f_flags").format("x")}")

    // ---- 6. 工具方法 ----
    println("\n--- 6. 工具方法 ---")

    let tool = BitArray.parse("11001010")
    println("  slice(2,6) = ${tool.slice(2, 6)}")
    println("  concat     = ${tool.concat(BitArray.parse("0011"))}")
    println("  toUInt64  = 0x${tool.toUInt64().format("x")}")
    println("  count(1)  = ${tool.count()}")
    println("  all()     = ${tool.all()}")
    println("  any()     = ${tool.any()}")
    println("  none()    = ${tool.none()}")

    // 克隆独立
    let orig = BitArray.parse("1011")
    let cloned = orig.clone()
    cloned[0] = !cloned[0]
    println("  clone 互不影响: orig=${orig}, cloned=${cloned}")

    // ---- 7. 接口 ----
    println("\n--- 7. 标准接口 ---")

    // Hashable
    let m = HashMap<BitArray, String>()
    m[BitArray.parse("1010")] = "ten"
    println("  Hashable: ${BitArray.parse("1010")} → '${m[BitArray.parse("1010")]}'")

    // Comparable
    println("  Comparable: ${BitArray.parse("1")} < ${BitArray.parse("10")} = ${BitArray.parse("1") < BitArray.parse("10")}")
    println()

    println("========== 演示结束 ==========")
}
