package ansies.core

/**@file ansi_parameter_composer.cj
 * @brief 参数组合器 — 积累任意参数提供者并合并为参数数组
 * @package ansies.core
 */

import std.collection.ArrayList

/**@class AnsiParameterComposer
 * @brief 组合多个 AnsiParameterProvider，输出合并后的参数数组
 * @details 组合结果限定在“参数”概念：不直接生成转义序列，
 *          序列封装（SGR/ED/...）由调用方根据最终字节决定。
 *          具体组合什么由调用方决定：所有加入的提供者应属于
 *          同一序列族（典型为 SGR，如 AnsiColorSpec/AnsiStyleSpec），
 *          跨族合并会导致最终字节混淆，属调用方职责。
 */
public class AnsiParameterComposer <: AnsiParameterProvider {
    private var params: ArrayList<String> = ArrayList<String>()

    /// 积累一个参数提供者（如 AnsiColorSpec / AnsiStyleSpec / 另一 AnsiParameterComposer）
    public func add<T>(p: T): AnsiParameterComposer where T <: AnsiParameterProvider {
        params.add(all: p.parameters())
        this
    }

    /// 合并后的参数数组（AnsiParameterProvider 契约）
    public func parameters(): Array<String> {
        params.toArray()
    }

    /// 是否无任何参数
    public func isEmpty(): Bool {
        params.isEmpty()
    }

    /// 清空积累的参数
    public func clear(): Unit {
        params.clear()
    }
}
