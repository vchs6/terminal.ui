package ansies.test

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.api.Response
import ansies.extensions.parseWindowSize
import ansies.extensions.parseWindowPixels
import ansies.extensions.parseWindowPosition
import ansies.extensions.parseWindowState
import ansies.extensions.parseCellSize
import ansies.extensions.parseColor

// ====================== ECMA-48 ======================

@Test
public func parseCprValid(): Unit {
    let result = Response.parseCpr("\u{1b}[12;24R")
    @Expect(result.isSome(), true)
}

@Test
public func parseCprInvalid(): Unit {
    @Expect(Response.parseCpr("not a CPR").isNone(), true)
    @Expect(Response.parseCpr("").isNone(), true)
}

@Test
public func parseDSRValid(): Unit {
    let result = Response.parseDSR("\u{1b}[0n")
    @Expect(result.isSome(), true)
}

@Test
public func parseDAValid(): Unit {
    let result = Response.parseDA("\u{1b}[?62;1;2;4;6;8;9;22c")
    @Expect(result.isSome(), true)
}

// ====================== DEC ======================

@Test
public func parseSecondaryDAValid(): Unit {
    let result = Response.parseSecondaryDA("\u{1b}[>1;10;0c")
    @Expect(result.isSome(), true)
}

// ====================== xterm ======================

@Test
public func parseWindowSizeValid(): Unit {
    let result = parseWindowSize("\u{1b}[8;24;80t")
    @Expect(result.isSome(), true)
}

@Test
public func parseWindowPixelsValid(): Unit {
    let result = parseWindowPixels("\u{1b}[4;800;600t")
    @Expect(result.isSome(), true)
}

@Test
public func parseWindowPositionValid(): Unit {
    let result = parseWindowPosition("\u{1b}[3;100;200t")
    @Expect(result.isSome(), true)
}

@Test
public func parseWindowStateValid(): Unit {
    let result = parseWindowState("\u{1b}[1;1t")
    @Expect(result.isSome(), true)
}

// ====================== iTerm2 ======================

@Test
public func parseCellSizeValid(): Unit {
    let result = parseCellSize("\u{1b}]1337;CellSize=10 20\u{1b}\\")
    @Expect(result.isSome(), true)
}

@Test
public func parseColorValid(): Unit {
    let result = parseColor("\u{1b}]1337;Color=5 65535 0 0\u{1b}\\")
    @Expect(result.isSome(), true)
}
