/* 
Copyright (c) 2024 vchuoshen6
ansies4cj is licensed under Mulan PSL v2.
You can use this software according to the terms and conditions of the Mulan PSL v2.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
See the Mulan PSL v2 for more details.
*/

/**@file response.cj
 * @brief 终端响应解析基础工具
 * @package ansies.extensions
 * @details 纯函数工具集，用于剥离终端回复的控制序列包装、拆分参数。
 * @author vchuoshen6
 * @version 0.1.0
 * @since 0.55.3
 */

package ansies.core

///< 终端回复 CSI 前缀字节
public let CSI_LEAD: String = CSI

///< 终端回复 OSC 前缀字节
public let OSC_LEAD: String = OSC

///< OSC 字符串终止符 (ST)
public let OSC_ST: String = ST

///< BEL 也可作为 OSC 终止符
public let OSC_BEL: String = BEL.toString()

/// 尝试剥离 CSI 前缀 (\033[)，成功返回内部内容，失败返回 None
public func stripCSI(raw: String): ?String {
    if (raw.startsWith(CSI_LEAD)) {
        Some(raw[2 .. raw.size])
    } else {
        None
    }
}

/// 尝试剥离 OSC 前缀 (\033]) 和终止符 (ST/BEL)
/// 支持 ST (\033\\) 或 BEL (\a) 两种终止方式
public func stripOSC(raw: String): ?String {
    if (raw.startsWith(OSC_LEAD)) {
        var body = raw[2 .. raw.size]
        // 去掉尾部 ST
        if (body.endsWith(OSC_ST)) {
            body = body[0 .. body.size - 2]
        } else if (body.endsWith(OSC_BEL)) {
            body = body[0 .. body.size - 1]
        }
        Some(body)
    } else {
        None
    }
}

/// 剥离 CSI 前缀后，按分隔符拆分参数，并移除尾部终止字符
public func parseCSIParams(raw: String, sep!: String = ";", terms!: String = "R"): ?Array<String> {
    if (let Some(s) <- stripCSI(raw)) {
        var body = s
        for (i in 0 .. terms.size) {
            if (body.endsWith(String(Rune(terms[i])))) {
                body = body[0 .. body.size - 1]
            }
        }
        Some(body.split(sep))
    } else {
        None
    }
}

/// 剥离 OSC 前缀和终止符后，按分隔符拆分，并移除尾部终止内容
public func parseOSCParams(raw: String, sep!: String = ";"): ?Array<String> {
    if (let Some(s) <- stripOSC(raw)) {
        Some(s.split(sep))
    } else {
        None
    }
}
