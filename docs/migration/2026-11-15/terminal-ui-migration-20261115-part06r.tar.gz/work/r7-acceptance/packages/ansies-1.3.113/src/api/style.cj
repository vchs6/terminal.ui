package ansies.api

import ansies.core.{SGR, AnsiStyle, AnsiStyleSpec, AnsiParameterProvider}

public class Style {
    // 生成样式设置命令
    public static func set(style: AnsiStyle): String {
        SGR(AnsiStyleSpec(style, isSet: true).parameters())
    }

    // 生成取消样式设置命令
    public static func reset(style: AnsiStyle): String {
        SGR(AnsiStyleSpec(style, isSet: false).parameters())
    }
}