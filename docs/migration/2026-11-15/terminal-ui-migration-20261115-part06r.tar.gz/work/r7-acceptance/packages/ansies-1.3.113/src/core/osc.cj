package ansies.core

/**@file osc.cj
 * @brief OSC 控制函数 — 10 个常用操作系统命令序列生成函数
 * @package ansies.core
 */

///< OSC控制序列函数集，格式：OSC command ; data ST

public let STITLE  : (args: Array<String>)-> String = { args => "${OSC}0;${String.join(args, delimiter: ";")}${ST}" }    ///<0: Set Window Title and Icon Label
public let SICON   : (args: Array<String>)-> String = { args => "${OSC}1;${String.join(args, delimiter: ";")}${ST}" }    ///<1: Set Icon Label
public let SWINTITLE: (args: Array<String>)-> String = { args => "${OSC}2;${String.join(args, delimiter: ";")}${ST}" }   ///<2: Set Window Title
public let SXPROP  : (args: Array<String>)-> String = { args => "${OSC}3;${String.join(args, delimiter: ";")}${ST}" }    ///<3: Set X Server Property
public let SPALETTE: (args: Array<String>)-> String = { args => "${OSC}4;${String.join(args, delimiter: ";")}${ST}" }    ///<4: Set/Reset ANSI Color Palette (index;color)
public let SFGCOLOR: (args: Array<String>)-> String = { args => "${OSC}10;${String.join(args, delimiter: ";")}${ST}" }   ///<10: Set Default Foreground Color
public let SBGCOLOR: (args: Array<String>)-> String = { args => "${OSC}11;${String.join(args, delimiter: ";")}${ST}" }   ///<11: Set Default Background Color
public let SCURCOL : (args: Array<String>)-> String = { args => "${OSC}12;${String.join(args, delimiter: ";")}${ST}" }   ///<12: Set Cursor Color
public let SHYPER  : (args: Array<String>)-> String = { args => "${OSC}8;${String.join(args, delimiter: ";")}${ST}" }    ///<8: Hyperlink (uri;id)
public let SCLIPBRD: (args: Array<String>)-> String = { args => "${OSC}52;${String.join(args, delimiter: ";")}${ST}" }   ///<52: Copy To Clipboard (selection;base64)
