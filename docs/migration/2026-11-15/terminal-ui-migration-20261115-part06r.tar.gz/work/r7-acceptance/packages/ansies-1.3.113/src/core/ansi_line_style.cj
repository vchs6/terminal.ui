package ansies.core

/**@file ansi_line_style.cj
 * @brief 线条风格枚举 — 下划线风格描述（ECMA-48 标准完整性保留）
 * @package ansies.core
 */

/// 线条/下划线风格枚举
/// @note 当前版本未使用，仅为 ECMA-48 标准完整性保留
public enum AnsiLineStyle <: ToString & Equatable<AnsiLineStyle> {
    | None
    | Single
    | Double
    | Curly
    | Dotted
    | Dashed

    public func toString(): String {
        match(this) {
            case None       => "None"
            case Single     => "Single"
            case Double     => "Double"
            case Curly      => "Curly"
            case Dotted     => "Dotted"
            case Dashed     => "Dashed"
        }
    }

    public operator func ==(ot: AnsiLineStyle): Bool {   //cjlint-ignore !G.OPR.01 description
        match((this, ot)) {
            case (None  , None  )  => true
            case (Single, Single)  => true
            case (Double, Double)  => true
            case (Curly , Curly )  => true
            case (Dotted, Dotted)  => true
            case (Dashed, Dashed)  => true
            case _ => false            
        }
    }
}