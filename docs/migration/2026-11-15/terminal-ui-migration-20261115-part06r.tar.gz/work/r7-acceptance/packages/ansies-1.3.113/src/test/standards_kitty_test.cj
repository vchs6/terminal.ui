package ansies.test

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.extensions.Kitty
import ansies.extensions.UnderlineStyle
import ansies.extensions.WinTerm
import ansies.extensions.ProgressState
import ansies.api.Hyperlink

// ====================== Kitty ======================

@Test
public func kittyUnderlineStyle(): Unit {
    @Expect(Kitty.underlineStyle(UnderlineStyle.Straight), "\u{1b}[4:1m")
    @Expect(Kitty.underlineStyle(UnderlineStyle.Double), "\u{1b}[4:2m")
    @Expect(Kitty.underlineStyle(UnderlineStyle.Curly), "\u{1b}[4:3m")
    @Expect(Kitty.underlineStyle(UnderlineStyle.Dotted), "\u{1b}[4:4m")
    @Expect(Kitty.underlineStyle(UnderlineStyle.Dashed), "\u{1b}[4:5m")
    @Expect(Kitty.resetUnderline(), "\u{1b}[4:0m")
}

@Test
public func kittyOverline(): Unit {
    @Expect(Kitty.overline(), "\u{1b}[53m")
    @Expect(Kitty.resetOverline(), "\u{1b}[55m")
}

@Test
public func kittyUnderlineColor(): Unit {
    @Expect(Kitty.resetUnderlineColor(), "\u{1b}[59m")
}

@Test
public func kittyUnderlineStyleEnum(): Unit {
    @Expect(UnderlineStyle.None.toEscapedCode(), 0u8)
    @Expect(UnderlineStyle.Dashed.toEscapedCode(), 5u8)
}

// ====================== Windows Terminal ======================

@Test
public func winTermProgress(): Unit {
    @Expect(WinTerm.setProgress(ProgressState.Default, 50), "\u{1b}]9;4;1;50\u{1b}\\")
}

@Test
public func winTermNotify(): Unit {
    @Expect(WinTerm.notify("hello"), "\u{1b}]9;9;hello\u{1b}\\")
}

@Test
public func winTermProgressEnum(): Unit {
    @Expect(ProgressState.Hide.toEscapedCode(), 0u8)
    @Expect(ProgressState.Default.toEscapedCode(), 1u8)
}

//cjlint-ignore -start !G.OTH.03 description
@Test
public func hyperlink(): Unit {
    let result = Hyperlink.decorate("https://example.com", dispText: "click")
    @Expect(result, "\u{1b}]8;;https://example.com\u{1b}\\click\u{1b}]8;;\u{1b}\\")
}
//cjlint-ignore -end description