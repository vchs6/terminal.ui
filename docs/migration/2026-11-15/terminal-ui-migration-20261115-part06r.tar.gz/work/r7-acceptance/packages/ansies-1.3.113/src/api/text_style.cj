package ansies.api

/**@file text_style.cj
 * @brief 样式聚合 — 基于 PartitionedBitArray 的 TextStyle 实现
 * @package ansies.utils
 */

import std.collection.ArrayList
import bitarray.{BitArray, PartitionedBitArray, BitSegment}
import ansies.core.{SGR, AnsiColor, AnsiStyle, AnsiColorSpec, AnsiStyleSpec, AnsiParameterComposer}

/*
 * 位域布局（64 bits）：
 *
 * 分区名         位偏移   宽度    类型示意
 * ─────────────────────────────────────────────
 * italic           0       1      Bool
 * bold             1       1      Bool
 * underline        2       1      Bool
 * blink            3       1      Bool
 * reverse          4       1      Bool
 * dim              5       1      Bool
 * strikethrough    6       1      Bool
 * conceal          7       1      Bool
 * double_underline 8       1      Bool
 * framed           9       1      Bool
 * encircled       10       1      Bool
 * overline        11       1      Bool
 * superscript     12       1      Bool
 * subscript       13       1      Bool
 * fgFlag          14       1      Bool //前景色是否为真彩色
 * bgFlag          15       1      Bool //背景色是否为真彩色
 * foreground      16      24      UInt32 (24bit→RGB) 或 以高字节为（0|1|2）来表示是（None | 基础色 | 索引色）
 * background      40      24      UInt32 (24bit→RGB) 或 以高字节为（0|1|2）来表示是（None | 基础色 | 索引色）
 * ─────────────────────────────────────────────
 * deleteLine 没有被分配位，使用strikethrough
 * 色区：不为真彩色时，0： None，否则，低字节内存储基础色，高字节内存储索引色
 */

private let STYLE_NAMES: Array<String> = [ //cjlint-ignore !G.VAR.02 description
    AnsiStyle.ITALIC.toString(),           
    AnsiStyle.BOLD.toString(),             
    AnsiStyle.UNDERLINE.toString(),        
    AnsiStyle.BLINK.toString(),            
    AnsiStyle.REVERSE.toString(),          
    AnsiStyle.DIM.toString(),              
    AnsiStyle.STRIKETHROUGH.toString(),    
    AnsiStyle.CONCEAL.toString(),          
    AnsiStyle.DOUBLEUNDERLINE.toString(), 
    AnsiStyle.FRAMED.toString(),           
    AnsiStyle.ENCIRCLED.toString(),        
    AnsiStyle.OVERLINE.toString(),         
    AnsiStyle.SUPERSCRIPT.toString(),      
    AnsiStyle.SUBSCRIPT.toString(),        
]

public class TextStyle <: Equatable<TextStyle> {
    private var pba: PartitionedBitArray

    private func setColor(color: Option<AnsiColor>, isBg!: Bool = false): Unit {
        let (fv, cv) = match(color) {
           case Some(c) =>
               match(c) {
                    case TrueColor(r, g, b) => (1u64, UInt64(r) << 16 | UInt64(g) << 8 | UInt64(b))
                    case IndexedColor(x)    => (0u64, 1u64 << 16 | UInt64(x))
                    case Black              => (0u64, 2u64 << 16)
                    case Red                => (0u64, 2u64 << 16 |  1u64)
                    case Green              => (0u64, 2u64 << 16 |  2u64)
                    case Yellow             => (0u64, 2u64 << 16 |  3u64)
                    case Blue               => (0u64, 2u64 << 16 |  4u64)
                    case Magenta            => (0u64, 2u64 << 16 |  5u64)
                    case Cyan               => (0u64, 2u64 << 16 |  6u64)
                    case White              => (0u64, 2u64 << 16 |  7u64)
                    case BrightBlack        => (0u64, 2u64 << 16 |  8u64)
                    case BrightRed          => (0u64, 2u64 << 16 |  9u64)
                    case BrightGreen        => (0u64, 2u64 << 16 | 10u64)
                    case BrightYellow       => (0u64, 2u64 << 16 | 11u64)
                    case BrightBlue         => (0u64, 2u64 << 16 | 12u64)
                    case BrightMagenta      => (0u64, 2u64 << 16 | 13u64)
                    case BrightCyan         => (0u64, 2u64 << 16 | 14u64)
                    case BrightWhite        => (0u64, 2u64 << 16 | 15u64)
                    case Default            => (0u64, 3u64 << 16)
               }
           case None => (0u64, 0u64)
        }
        if (isBg) {
            pba.setField("bgFlag", fv)
            pba.setField("background", cv)
        } else {
            pba.setField("fgFlag", fv)
            pba.setField("foreground", cv)
        }
    }

    // In class IllegalArgumentException
    private func getColor(isBg!: Bool = false): Option<AnsiColor> {
        let (fv, cv) = if (isBg) {
            (pba.getField("bgFlag"), pba.getField("background"))
        } else {
            (pba.getField("fgFlag"), pba.getField("foreground"))
        }
        if (fv == 1) {
            return AnsiColor.TrueColor(UInt8(cv >> 16 & 0xFF), UInt8(cv >> 8 & 0xFF), UInt8(cv & 0xFF))
        }
        if (cv == 0) {
            return None
        }
        if (cv > 0x02FFFF) {
            AnsiColor.Default
        } else if (cv > 0x01FFFF) {
            match(UInt8(cv & 0xFF)) {
                case 0  => Black
                case 1  => Red
                case 2  => Green
                case 3  => Yellow
                case 4  => Blue
                case 5  => Magenta
                case 6  => Cyan
                case 7  => White
                case 8  => BrightBlack
                case 9  => BrightRed
                case 10 => BrightGreen
                case 11 => BrightYellow
                case 12 => BrightBlue
                case 13 => BrightMagenta
                case 14 => BrightCyan
                case 15 => BrightWhite
                case _  => throw IllegalArgumentException("无效的参数，必须在区间0..=15内。")
            }
        } else{
            AnsiColor.IndexedColor(UInt8(cv & 0xFF))
        }        
    }

    // ======================== 构造 ========================
    internal init(x: UInt64) {
        pba = PartitionedBitArray(BitArray(x))
        // 注册所有分区字段
        for (i in 0 .. STYLE_NAMES.size) {
            pba.addField(BitSegment(STYLE_NAMES[i],  i,  1))
        }
        pba.addField(BitSegment("fgFlag",     14, 1))
        pba.addField(BitSegment("bgFlag",     15, 1))
        pba.addField(BitSegment("foreground", 16, 24))
        pba.addField(BitSegment("background", 40, 24))        
    }

    public init(fg!: ?AnsiColor = None, bg!: ?AnsiColor = None, styles!: Array<AnsiStyle> = []) {
        pba = PartitionedBitArray(BitArray(64))

        // 注册所有分区字段
        for (i in 0 .. STYLE_NAMES.size) {
            pba.addField(BitSegment(STYLE_NAMES[i],  i,  1))
        }
        pba.addField(BitSegment("fgFlag",     14, 1))
        pba.addField(BitSegment("bgFlag",     15, 1))
        pba.addField(BitSegment("foreground", 16, 24))
        pba.addField(BitSegment("background", 40, 24))

        // 初始化颜色
        setColor(fg)
        setColor(bg, isBg: true)
        // 初始化样式
        for (s in styles) {
            pba.setField(s.toString(), 1)
        }
    }

    // ======================== 样式属性 ========================
    // 每个样式对应一个读/写方法对，底层由分区位数组支持
    public mut prop italic: Bool {
        get() { pba.getField(AnsiStyle.ITALIC.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.ITALIC.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop bold: Bool {
        get() { pba.getField(AnsiStyle.BOLD.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.BOLD.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop deletedline: Bool {
        get() { pba.getField(AnsiStyle.STRIKETHROUGH.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.STRIKETHROUGH.toString(), if (value) { 1 } else { 0 }) }
    }


    public mut prop underLine: Bool {
        get() { pba.getField(AnsiStyle.UNDERLINE.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.UNDERLINE.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop blink: Bool {
        get() { pba.getField(AnsiStyle.BLINK.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.BLINK.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop reverse: Bool {
        get() { pba.getField(AnsiStyle.REVERSE.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.REVERSE.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop dim: Bool {
        get() { pba.getField(AnsiStyle.DIM.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.DIM.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop strikeThrough: Bool {
        get() { pba.getField(AnsiStyle.STRIKETHROUGH.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.STRIKETHROUGH.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop conceal: Bool {
        get() { pba.getField(AnsiStyle.CONCEAL.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.CONCEAL.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop DoubleUnderLine: Bool {
        get() { pba.getField(AnsiStyle.DOUBLEUNDERLINE.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.DOUBLEUNDERLINE.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop framed: Bool {
        get() { pba.getField(AnsiStyle.FRAMED.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.FRAMED.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop encircled: Bool {
        get() { pba.getField(AnsiStyle.ENCIRCLED.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.ENCIRCLED.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop overLine: Bool {
        get() { pba.getField(AnsiStyle.OVERLINE.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.OVERLINE.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop superScript: Bool {
        get() { pba.getField(AnsiStyle.SUPERSCRIPT.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.SUPERSCRIPT.toString(), if (value) { 1 } else { 0 }) }
    }

    public mut prop subScript: Bool {
        get() { pba.getField(AnsiStyle.SUBSCRIPT.toString()) == 1}
        set(value) { pba.setField(AnsiStyle.SUBSCRIPT.toString(), if (value) { 1 } else { 0 }) }
    }

    // ======================== 颜色属性 ========================
    // 颜色存储于分区字段 Flag/Value

    public mut prop foreground: Option<AnsiColor> {
        get() { getColor() }
        set(value) { setColor(value) }
    }

    public mut prop background: Option<AnsiColor> {
        get() { getColor(isBg: true) }
        set(value) { setColor(value, isBg: true) }
    }
    // ======================== 批量样式操作 ========================

    public func reset(): Unit {
        pba.underlying.fill(false)
    }

    public func isNone(): Bool {
        pba.underlying.none()
    }

    public func getStyles(): Array<AnsiStyle> {
        let result = ArrayList<AnsiStyle>()
        for (name in STYLE_NAMES) {
            if (pba.getField(name) != 0u64) {
                result.add(AnsiStyle.parse(name))
            }
        }
        result.toArray()
    }

    public func addStyle(styles: Array<AnsiStyle>): Unit {
        for (s in styles) {
            pba.setField(s.toString(), 1)
        }
    }

    public func removeStyle(styles: Array<AnsiStyle>): Unit {
        for (s in styles) {
            pba.setField(s.toString() , 0)
        }
    }

    public func clearStyles(): Unit {
        for (name in STYLE_NAMES) {
            pba.setField(name, 0)
        }
    }

    public operator func ==(ot: TextStyle): Bool {
        pba.underlying == ot.pba.underlying
    }

    // ======================== 序列化 ========================

    public func toInteger(): UInt64 {
        pba.underlying.toUInt64()
    }

    public static func fromInteger(v: UInt64): TextStyle {
        TextStyle(v)
    }

    // ======================== Escape 序列生成 ========================
    public func toEscapedString(): String {
        let composer = AnsiParameterComposer() // cjlint-ignore !G.VAR.02 description
        if (let Some(c) <- getColor()) {
            composer.add(AnsiColorSpec(c, background: false))
        }
        if (let Some(c) <- getColor(isBg: true)) {
            composer.add(AnsiColorSpec(c, background: true))
        }
        for (s in getStyles()) {
            composer.add(AnsiStyleSpec(s, isSet: true))
        }
        if (composer.isEmpty()) { "" }
        else { SGR(composer.parameters()) }
    }
}
