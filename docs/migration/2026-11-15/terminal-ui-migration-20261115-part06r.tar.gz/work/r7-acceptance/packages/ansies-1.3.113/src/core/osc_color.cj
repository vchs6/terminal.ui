package ansies.core

/**@file osc_color.cj
 * @brief OSC 颜色查询响应结果类型
 * @package ansies.core
 */

/// OSC 颜色查询响应（rgb:RRRR/GGGG/BBBB，每通道 16 位）
/// 对应协议格式：OSC 4/10/11/12 ; ... ; rgb:rrrr/gggg/bbbb ST（xterm 定义、广泛支持）
public class OscColor {
    public var r: UInt16  ///< 红色分量（0-65535）
    public var g: UInt16  ///< 绿色分量（0-65535）
    public var b: UInt16  ///< 蓝色分量（0-65535）

    public init(r: UInt16, g: UInt16, b: UInt16) {
        this.r = r
        this.g = g
        this.b = b
    }
}
