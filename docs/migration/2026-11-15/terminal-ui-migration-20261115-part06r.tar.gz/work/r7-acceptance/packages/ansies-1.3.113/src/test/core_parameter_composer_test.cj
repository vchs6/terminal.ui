package ansies.test

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.core.{AnsiParameterComposer, AnsiColor, AnsiStyle, AnsiColorSpec, AnsiStyleSpec, SGR}

// ====================== AnsiParameterComposer ======================

@Test
public func composerMergeParams(): Unit {
    let c = AnsiParameterComposer()
        .add(AnsiColorSpec(AnsiColor.Red))
        .add(AnsiColorSpec(AnsiColor.White, background: true))
        .add(AnsiStyleSpec(AnsiStyle.BOLD))
    @Expect(c.parameters(), ["31", "47", "1"])
    // 序列封装由调用方完成（参数概念之外）
    @Expect(SGR(c.parameters()), "\u{1b}[31;47;1m")
}

@Test
public func composerGenericProviders(): Unit {
    // 组合内容由调用方决定：不限于颜色/样式，任何 AnsiParameterProvider 均可加入
    let c = AnsiParameterComposer()
        .add(AnsiColorSpec(AnsiColor.IndexedColor(42u8)))
        .add(AnsiColorSpec(AnsiColor.TrueColor(0u8, 134u8, 139u8), background: true))
        .add(AnsiStyleSpec(AnsiStyle.BOLD))
    @Expect(c.parameters(), ["38", "5", "42", "48", "2", "0", "134", "139", "1"])
}

@Test
public func composerStyleReset(): Unit {
    let c = AnsiParameterComposer().add(AnsiStyleSpec(AnsiStyle.BOLD, isSet: false))
    @Expect(c.parameters(), ["21"])
}

@Test
public func composerEmpty(): Unit {
    let c = AnsiParameterComposer()
    @Expect(c.isEmpty(), true)
    @Expect(c.parameters().size, 0)
}

@Test
public func composerClear(): Unit {
    let c = AnsiParameterComposer().add(AnsiColorSpec(AnsiColor.Red))
    c.clear()
    @Expect(c.isEmpty(), true)
}

@Test
public func composerComposable(): Unit {
    let inner = AnsiParameterComposer().add(AnsiStyleSpec(AnsiStyle.BOLD))
    let outer = AnsiParameterComposer()
        .add(AnsiColorSpec(AnsiColor.Red))
        .add(inner)
    @Expect(outer.parameters(), ["31", "1"])
}
