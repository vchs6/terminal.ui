package ansies.test

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.api.{Cursor, Screen}
import ansies.core.{AnsiCursorStyle, AnsiParameterProvider}
import ansies.core.DECRQSS
import ansies.api.Response

@Test
public func decShowHideCursor(): Unit {
    @Expect(Cursor.showCursor(), "\u{1b}[?25h")
    @Expect(Cursor.hideCursor(), "\u{1b}[?25l")
}

@Test
public func decCursorKeys(): Unit {
    @Expect(Cursor.appCursorKeys(), "\u{1b}[?1h")
    @Expect(Cursor.normalCursorKeys(), "\u{1b}[?1l")
}

@Test
public func decScreenModes(): Unit {
    @Expect(Screen.alternateScreen(), "\u{1b}[?1049h")
    @Expect(Screen.mainScreen(), "\u{1b}[?1049l")
    @Expect(Screen.reverseScreen(), "\u{1b}[?5h")
    @Expect(Screen.normalScreen(), "\u{1b}[?5l")
}

@Test
public func decScrollRegion(): Unit {
    @Expect(Screen.setScrollRegion(5, 20), "\u{1b}[5;20r")
    @Expect(Screen.resetScrollRegion(), "\u{1b}[r")
}

@Test
public func decCursorStyle(): Unit {
    @Expect(Cursor.setCursorStyle(AnsiCursorStyle.BlinkingBlock), "\u{1b}[1 q")
    @Expect(Cursor.setCursorStyle(AnsiCursorStyle.SteadyUnderline), "\u{1b}[4 q")
    @Expect(Cursor.resetCursorStyle(), "\u{1b}[0 q")
}

@Test
public func decCursorStyleEnum(): Unit {
    @Expect(AnsiCursorStyle.BlinkingBlockDefault.parameters(), ["0"])
    @Expect(AnsiCursorStyle.SteadyBar.parameters(), ["6"])
}

@Test
public func decSaveRestorePosition(): Unit {
    @Expect(Cursor.savePosition(), "\u{1b}7")
    @Expect(Cursor.restorePosition(), "\u{1b}8")
}

@Test
public func decKeypadMode(): Unit {
    @Expect(Cursor.keypadApplication(), "\u{1b}=")
    @Expect(Cursor.keypadNumeric(), "\u{1b}>")
}

@Test
public func decRQSSRequest(): Unit {
    @Expect(DECRQSS("r"), "\u{1b}P$qr\u{1b}\\")
}

@Test
public func parseDECRQSSValid(): Unit {
    let result = Response.parseDECRQSS("\u{1b}P1$r5;20r\u{1b}\\")
    @Expect(result.isSome(), true)
    if (let Some(r) <- result) {
        @Expect(r.valid, true)
        @Expect(r.value, "5;20r")
    }
}

@Test
public func parseDECRQSSInvalid(): Unit {
    let result = Response.parseDECRQSS("\u{1b}P0$r\u{1b}\\")
    @Expect(result.isSome(), true)
    if (let Some(r) <- result) {
        @Expect(r.valid, false)
    }
}
