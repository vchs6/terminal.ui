package ansies.core

public enum AnsiDeviceStatusRequest {
    | OperatingStatus  // Ps=5：请求终端运行状态（响应 ESC[0n 正常 / ESC[3n 异常）
    | CursorPosition   // Ps=6：请求光标位置报告（响应 ESC[row;col R）
    | PrinterStatus    // Ps=15（DEC 扩展）：打印机状态
    | UdkStatus        // Ps=25（DEC 扩展）：可编程键状态
    | KeyboardStatus   // Ps=26（DEC 扩展）：键盘语言状态
    | LocatorStatus    // Ps=53（DEC 扩展）：定位设备状态

}