package ansies.core

public enum AnsiCursorStyle {
    | BlinkingBlockDefault  // Ps=0：终端默认样式（通常等同闪烁块状）
    | BlinkingBlock         // Ps=1
    | SteadyBlock           // Ps=2
    | BlinkingUnderline     // Ps=3
    | SteadyUnderline       // Ps=4
    | BlinkingBar           // Ps=5
    | SteadyBar             // Ps=6
}