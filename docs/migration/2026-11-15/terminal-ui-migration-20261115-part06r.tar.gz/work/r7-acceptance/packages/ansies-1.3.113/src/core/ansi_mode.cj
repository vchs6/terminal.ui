package ansies.core 

/// ECMA-48 标准模式：ESC[ Ps h（置位）/ ESC[ Ps l（复位），无前缀
public enum AnsiMode {
    | KeyboardAction   // Ps=2  KAM
    | InsertReplace    // Ps=4  IRM：插入/替换模式
    | SendReceive      // Ps=12 SRM：本地回显控制
    | LineFeedNewLine  // Ps=20 LNM：换行/新行模式
}