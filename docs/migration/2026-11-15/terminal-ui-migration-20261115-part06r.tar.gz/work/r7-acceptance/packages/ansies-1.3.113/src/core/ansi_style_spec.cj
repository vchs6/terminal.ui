package ansies.core

public struct AnsiStyleSpec {
    private let _isSet: Bool
    private let _style: AnsiStyle 

    public init(style: AnsiStyle, isSet!: Bool = true) {
        _isSet = isSet
        _style = style
    }

    public func isSet(): Bool {
        _isSet
    }

    public prop style: AnsiStyle {
        get() { _style }
    }
}