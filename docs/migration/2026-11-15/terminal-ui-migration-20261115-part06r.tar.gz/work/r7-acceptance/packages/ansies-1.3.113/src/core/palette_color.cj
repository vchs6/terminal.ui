package ansies.core

/**@file palette_color.cj
 * @brief OSC 调色板颜色查询响应结果类型
 * @package ansies.core
 */

/// OSC 调色板颜色查询响应（含索引）
/// 对应协议格式：OSC 4 ; idx ; rgb:rrrr/gggg/bbbb ST
public class PaletteColor {
    public var index: UInt16  ///< 调色板索引
    public var color: OscColor

    public init(index: UInt16, color: OscColor) {
        this.index = index
        this.color = color
    }
}
