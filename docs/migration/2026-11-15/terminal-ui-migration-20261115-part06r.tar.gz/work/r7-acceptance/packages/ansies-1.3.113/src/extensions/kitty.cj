/* 
Copyright (c) 2024 vchuoshen6
ansies4cj is licensed under Mulan PSL v2.
You can use this software according to the terms and conditions of the Mulan PSL v2.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
See the Mulan PSL v2 for more details.
*/

//cjlint-ignore -start !G.OTH.03 description
/**@file kitty.cj
 * @brief kitty 终端扩展控制序列封装
 * @package ansies.extensions
 * @details 封装 kitty 终端协议扩展的控制序列，
 *          包括 SGR 下划线风格、上划线、下划线颜色等。
 *          参考：https://sw.kovidgoyal.net/kitty/protocol-extensions/
 * @author vchuoshen6
 * @version 0.1.0
 * @date 2024.11.24
 * @copyright Copyright (C) 2024 by vchuoshen6.
 * @since 0.55.3
 */
//cjlint-ignore -end description

package ansies.extensions

import ansies.core.SGR

/**@class Kitty
 * @brief kitty 扩展的 SGR 序列封装
 * @details 这些扩展由 kitty 提出，现已被 iTerm2、WezTerm、foot 等终端广泛支持。
 *          涉及 SGR 子参数（冒号分隔）语法。
 */
public class Kitty {
    //=== 下划线风格 (Underline Style) ===//

    ///< 设置下划线风格 (CSI 4 : style m)
    public static func underlineStyle(style: UnderlineStyle): String {
        SGR(["4:${style.toEscapedCode()}"])
    }

    ///< 设置带颜色的下划线 (CSI 4 : style ; 58 : 2 : R : G : B m)
    public static func underlineStyleWithColor(style: UnderlineStyle, R: Byte, G: Byte, B: Byte): String {
        SGR(["4:${style.toEscapedCode()}", "58:2:${R.toString()}:${G.toString()}:${B.toString()}"])
    }

    ///< 重置下划线为无
    public static func resetUnderline(): String {
        SGR(["4:0"])
    }

    //=== 上划线 (Overline) ===//

    ///< 设置上划线 (CSI 53 m)
    public static func overline(): String { SGR(["53"]) }
    ///< 取消上划线 (CSI 55 m)
    public static func resetOverline(): String { SGR(["55"]) }

    //=== 下划线颜色 (Underline Color) ===//

    ///< 设置下划线颜色为真彩色 (CSI 58 : 2 : R : G : B m)
    public static func underlineColor(R: Byte, G: Byte, B: Byte): String {
        SGR(["58:2:${R.toString()}:${G.toString()}:${B.toString()}"])
    }
    ///< 设置下划线颜色为 256 色索引 (CSI 58 : 5 : idx m)
    public static func underlineColor256(idx: Byte): String {
        SGR(["58:5:${idx.toString()}"])
    }
    ///< 重置下划线颜色为默认 (CSI 59 m)
    public static func resetUnderlineColor(): String { SGR(["59"]) }
}

/**@enum UnderlineStyle
 * @brief kitty 下划线风格枚举 (SGR 4 : Ps)
 */
public enum UnderlineStyle <: ToString {
    | None
    | Straight
    | Double
    | Curly
    | Dotted
    | Dashed

    public func toEscapedCode(): Byte {
        match(this) {
            case None     => 0
            case Straight => 1
            case Double   => 2
            case Curly    => 3
            case Dotted   => 4
            case Dashed   => 5
        }
    }

    public func toString(): String {
        match(this) {
            case None     => "None"
            case Straight => "Straight"
            case Double   => "Double"
            case Curly    => "Curly"
            case Dotted   => "Dotted"
            case Dashed   => "Dashed"
        }
    }
}
