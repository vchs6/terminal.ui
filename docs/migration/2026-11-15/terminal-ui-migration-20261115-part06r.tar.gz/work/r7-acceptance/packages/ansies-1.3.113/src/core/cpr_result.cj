package ansies.core

/**@file cpr_result.cj
 * @brief CPR (Cursor Position Report) 响应结果类型
 * @package ansies.core
 */

/// CPR (Cursor Position Report) 解析结果
/// 对应协议格式：CSI Pl ; Pc R（ECMA-48 定义，所有符合标准的终端通用）
public class CprResult {
    public var row: UInt8
    public var col: UInt8

    public init(row: UInt8, col: UInt8) {
        this.row = row
        this.col = col
    }
}
