package ansies.test

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.api.Query
import ansies.api.Response

// ====================== Query（请求生成） ======================

@Test
public func queryCursorPosition(): Unit {
    @Expect(Query.cursorPosition(), "\u{1b}[6n")
}

@Test
public func queryDeviceAttributes(): Unit {
    @Expect(Query.deviceAttributes(), "\u{1b}[c")
}

@Test
public func queryDeviceStatus(): Unit {
    @Expect(Query.deviceStatus(), "\u{1b}[5n")
}

@Test
public func querySecondaryDA(): Unit {
    @Expect(Query.secondaryDeviceAttributes(), "\u{1b}[>0c")
}

@Test
public func queryDecMode(): Unit {
    @Expect(Query.decMode(["1"]), "\u{1b}[?1$p")
    @Expect(Query.decMode(["1", "3"]), "\u{1b}[?1;?3$p")
}

@Test
public func queryDecRqss(): Unit {
    @Expect(Query.decRqss("r"), "\u{1b}P$qr\u{1b}\\")
}

// ====================== OSC 颜色查询 ======================

@Test
public func queryOscColors(): Unit {
    @Expect(Query.paletteColor(5), "\u{1b}]4;5;?\u{1b}\\")
    @Expect(Query.foregroundColor(), "\u{1b}]10;?\u{1b}\\")
    @Expect(Query.backgroundColor(), "\u{1b}]11;?\u{1b}\\")
    @Expect(Query.cursorColor(), "\u{1b}]12;?\u{1b}\\")
}

@Test
public func parseOscColorValid(): Unit {
    if (let Some(c) <- Response.parseOscColor("\u{1b}]10;rgb:ffff/0000/0000\u{1b}\\")) {
        @Expect(c.r, 65535u16)
        @Expect(c.g, 0u16)
        @Expect(c.b, 0u16)
    } else {
        @Expect(false, true)
    }
}

@Test
public func parseOscColorInvalid(): Unit {
    @Expect(Response.parseOscColor("not an osc reply").isNone(), true)
    @Expect(Response.parseOscColor("\u{1b}]10;no-rgb\u{1b}\\").isNone(), true)
}

@Test
public func parseOscColorTerminalVariants(): Unit {
    // 终端特有变体不在 api 处理：短格式（8/12 位）与 #rrggbb 应返回 None，
    // 由 extensions 各终端解析器负责。
    @Expect(Response.parseOscColor("\u{1b}]10;rgb:ff/00/00\u{1b}\\").isNone(), true)
    @Expect(Response.parseOscColor("\u{1b}]10;rgb:fff/000/000\u{1b}\\").isNone(), true)
    @Expect(Response.parseOscColor("\u{1b}]10;#ff0000\u{1b}\\").isNone(), true)
}

@Test
public func parsePaletteColorValid(): Unit {
    if (let Some(p) <- Response.parsePaletteColor("\u{1b}]4;5;rgb:ffff/0000/0000\u{1b}\\")) {
        @Expect(p.index, 5u16)
        @Expect(p.color.r, 65535u16)
        @Expect(p.color.g, 0u16)
        @Expect(p.color.b, 0u16)
    } else {
        @Expect(false, true)
    }
}

@Test
public func queryOscPairing(): Unit {
    // 调色板颜色：请求 → 模拟回复 → 解析
    let q1 = Query.paletteColor(5)
    @Expect(q1, "\u{1b}]4;5;?\u{1b}\\")
    if (let Some(p) <- Response.parsePaletteColor("\u{1b}]4;5;rgb:ffff/0000/0000\u{1b}\\")) {
        @Expect(p.index, 5u16)
        @Expect(p.color.r, 65535u16)
    } else {
        @Expect(false, true)
    }

    // 前景色：请求 → 模拟回复 → 解析
    let q2 = Query.foregroundColor()
    @Expect(q2, "\u{1b}]10;?\u{1b}\\")
    if (let Some(c) <- Response.parseOscColor("\u{1b}]10;rgb:ffff/0000/0000\u{1b}\\")) {
        @Expect(c.r, 65535u16)
    } else {
        @Expect(false, true)
    }
}

// ====================== Query ↔ Response 对偶 ======================

@Test
public func queryResponsePairing(): Unit {
    // 光标位置：请求 → 模拟回复 → 解析
    let req = Query.cursorPosition()
    @Expect(req, "\u{1b}[6n")
    if (let Some(pos) <- Response.parseCpr("\u{1b}[12;24R")) {
        @Expect(pos.row, 12u8)
        @Expect(pos.col, 24u8)
    } else {
        @Expect(false, true)
    }

    // DECRQSS：请求 → 模拟回复 → 解析
    let rq = Query.decRqss("r")
    @Expect(rq, "\u{1b}P$qr\u{1b}\\")
    if (let Some(r) <- Response.parseDECRQSS("\u{1b}P1$r5;20r\u{1b}\\")) {
        @Expect(r.valid, true)
        @Expect(r.value, "5;20r")
    } else {
        @Expect(false, true)
    }
}
