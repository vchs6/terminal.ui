package ansies.core

/**@file ansi_color.cj
 * @brief 颜色类型与 SGR 颜色序列生成，支持颜色升降级
 * @package ansies.core
 */

import std.convert.{Parsable, Formattable}
import std.collection.HashMap

public enum AnsiColor <: Equatable<AnsiColor> & Parsable<AnsiColor> & ToString {
    | Black             //Black
    | Red               //Maroon
    | Green             //Green
    | Yellow            //Olive
    | Blue              //Navy
    | Magenta           //Purple
    | Cyan              //Teal
    | White             //Silver
    | BrightBlack       //Gray
    | BrightRed         //Red
    | BrightGreen       //Lime
    | BrightYellow      //Yellow
    | BrightBlue        //Blue
    | BrightMagenta     //Magenta
    | BrightCyan        //Cyan
    | BrightWhite       //White
    | Default           //Default
    | IndexedColor(/*idx*/UInt8)     //8位索引色
    | TrueColor(/*R*/UInt8, /*G*/UInt8, /*B*/UInt8)  //24位真彩色

    
    public operator func ==(ot: AnsiColor): Bool {
        match((this, ot)) {
            case (Black        , Black        )     => true
            case (Red          , Red          )     => true
            case (Green        , Green        )     => true
            case (Yellow       , Yellow       )     => true
            case (Blue         , Blue         )     => true
            case (Magenta      , Magenta      )     => true
            case (Cyan         , Cyan         )     => true
            case (White        , White        )     => true
            case (BrightBlack  , BrightBlack  )     => true
            case (BrightRed    , BrightRed    )     => true
            case (BrightGreen  , BrightGreen  )     => true
            case (BrightYellow , BrightYellow )     => true
            case (BrightBlue   , BrightBlue   )     => true
            case (BrightMagenta, BrightMagenta)     => true
            case (BrightCyan   , BrightCyan   )     => true
            case (BrightWhite  , BrightWhite  )     => true
            case (Default      , Default      )     => true
            case (IndexedColor(x), IndexedColor(y)) => x == y
            case (TrueColor(r1, g1, b1), TrueColor(r2, g2, b2))  => r1 == r2 && g1 == g2 && b1 == b2
            case _ => false
        }
    }

    public func toString(): String {
        match (this) {
            case Black          => "Black"
            case Red            => "Red"
            case Green          => "Green"
            case Yellow         => "Yellow"
            case Blue           => "Blue"
            case Magenta        => "Magenta"
            case Cyan           => "Cyan"
            case White          => "White"
            case BrightBlack    => "BrightBlack"
            case BrightRed      => "BrightRed"
            case BrightGreen    => "BrightGreen"
            case BrightYellow   => "BrightYellow"
            case BrightBlue     => "BrightBlue"
            case BrightMagenta  => "BrightMagenta"
            case BrightCyan     => "BrightCyan"
            case BrightWhite    => "BrightWhite"
            case Default        => "Default"
            case IndexedColor(x)     => "#" + x.format("02x")
            case TrueColor(r, g, b)  => "#" + r.format("02x") + g.format("02x") + b.format("02x")
        }
    }

    public static func tryParse(value: String): ?AnsiColor {
        try {
            parse(value)
        } catch(_) {
            None
        }
    }

    // in class IllegalFormatException
    public static func parse(value: String): AnsiColor {
        match (value.trimAscii().toAsciiLower()) {
            case "black"          =>  Black        
            case "red"            =>  Red          
            case "green"          =>  Green        
            case "yellow"         =>  Yellow       
            case "blue"           =>  Blue         
            case "magenta"        =>  Magenta      
            case "cyan"           =>  Cyan         
            case "white"          =>  White        
            case "brightblack"    =>  BrightBlack  
            case "brightred"      =>  BrightRed    
            case "brightgreen"    =>  BrightGreen  
            case "brightyellow"   =>  BrightYellow 
            case "brightblue"     =>  BrightBlue   
            case "brightmagenta"  =>  BrightMagenta
            case "brightcyan"     =>  BrightCyan   
            case "brightwhite"    =>  BrightWhite  
            case "default"        =>  Default
            case _                => 
                if (value.startsWith("#")) {
                    if (value.size == 3) {
                        IndexedColor(UInt8.parse("0x" + value[1 .. 3]))
                    } else if (value.size == 7) {
                        TrueColor(
                            UInt8.parse("0x" + value[1 .. 3]),
                            UInt8.parse("0x" + value[3 .. 5]),
                            UInt8.parse("0x" + value[5 .. 7])
                        )
                    } else {
                        throw IllegalFormatException("无效的颜色字符串格式！")
                    }
                } else {
                    throw IllegalFormatException("无效的颜色字符串格式！")
                }
        }
    }

    // 允许用户从自定义的调色板中创建真彩色，支持RGB和32位整数两种类型的调色板。
    public static func fromName(name: String, colors: HashMap<String, (R:Byte, G:Byte, B:Byte)>): ?AnsiColor {
        if (! colors.contains(name)) {
            None
        }
        let (r, g, b) = colors[name]
        AnsiColor.TrueColor(r, g, b)
    }
    
    public static func fromName(name: String, colors: HashMap<String, UInt32>): ?AnsiColor {
        if (! colors.contains(name)) {
            None
        }
        let value = colors[name]
        AnsiColor.TrueColor(UInt8((value >> 16) & 0xFF), UInt8((value >> 8) & 0xFF), UInt8(value & 0xFF))
    }
}