package ansies.test

import std.convert.Parsable
import std.collection.HashMap
import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect

import ansies.core.{AnsiColor, SGR, AnsiColorConverter}
import ansies.api.Color

@Test
public func colorParse(): Unit {
    @Expect(AnsiColor.parse("Black") == AnsiColor.Black, true)
    @Expect(AnsiColor.parse("RED") == AnsiColor.Red, true)
    @Expect(AnsiColor.parse("green") == AnsiColor.Green, true)
    @Expect(AnsiColor.parse("BRIGHTWHITE") == AnsiColor.BrightWhite, true)
    // #nn 两位十六进制 → 索引色
    @Expect(AnsiColor.parse("#96") == AnsiColor.IndexedColor(0x96u8), true)
    // #rrggbb 六位十六进制 → 真彩色
    @Expect(AnsiColor.parse("#ff0000") == AnsiColor.TrueColor(255u8, 0u8, 0u8), true)
    @Expect(AnsiColor.parse("#00868B") == AnsiColor.TrueColor(0u8, 134u8, 139u8), true)
}

@Test
public func colorTryParse(): Unit {
    @Expect(AnsiColor.tryParse("Blue").isSome(), true)
    @Expect(AnsiColor.tryParse("InvalidColor").isNone(), true)
    @Expect(AnsiColor.tryParse("#96").isSome(), true)
    @Expect(AnsiColor.tryParse("#ff0000").isSome(), true)
}

@Test
public func colorForegroundBackground(): Unit {
    @Expect(Color.foreground(AnsiColor.Red), "\u{1b}[31m")
    @Expect(Color.background(AnsiColor.Red), "\u{1b}[41m")
    @Expect(Color.foreground(AnsiColor.BrightGreen), "\u{1b}[92m")
    @Expect(Color.background(AnsiColor.BrightGreen), "\u{1b}[102m")
    @Expect(Color.foreground(AnsiColor.IndexedColor(42u8)), "\u{1b}[38;5;42m")
    @Expect(Color.background(AnsiColor.IndexedColor(42u8)), "\u{1b}[48;5;42m")
    @Expect(Color.foreground(AnsiColor.TrueColor(0u8, 134u8, 139u8)), "\u{1b}[38;2;0;134;139m")
    @Expect(Color.background(AnsiColor.TrueColor(0u8, 134u8, 139u8)), "\u{1b}[48;2;0;134;139m")
}

@Test
public func colorSetColor(): Unit {
    @Expect(Color.setColor(AnsiColor.Red, AnsiColor.Blue), "\u{1b}[41;34m")
}

@Test
public func colorSetDefault(): Unit {
    @Expect(Color.setDefaultForeground(), "\u{1b}[39m")
    @Expect(Color.setDefaultBackground(), "\u{1b}[49m")
}

@Test
public func colorEquality(): Unit {
    @Expect(AnsiColor.Red == AnsiColor.Red, true)
    @Expect(AnsiColor.Red == AnsiColor.Blue, false)
    @Expect(AnsiColor.IndexedColor(10u8) == AnsiColor.IndexedColor(10u8), true)
    @Expect(AnsiColor.IndexedColor(10u8) == AnsiColor.IndexedColor(20u8), false)
    @Expect(AnsiColor.TrueColor(255u8, 0u8, 0u8) == AnsiColor.TrueColor(255u8, 0u8, 0u8), true)
}

@Test
public func colorToString(): Unit {
    @Expect(AnsiColor.Red.toString(), "Red")
    @Expect(AnsiColor.IndexedColor(42u8).toString(), "#2a")
    @Expect(AnsiColor.TrueColor(0u8, 134u8, 139u8).toString(), "#00868b")
}

@Test
public func colorGetRGB(): Unit {
    let conv = AnsiColorConverter()
    match(AnsiColor.TrueColor(0u8, 134u8, 139u8)) {
        case AnsiColor.TrueColor(r, g, b) =>
            @Expect(r, 0u8)
            @Expect(g, 134u8)
            @Expect(b, 139u8)
        case _ => @Expect(false, true)
    }
    // IndexedColor(9) = BrightRed → (255,0,0)
    match(conv.toTrueColor(AnsiColor.IndexedColor(9u8))) {
        case AnsiColor.TrueColor(r2, g2, b2) =>
            @Expect(r2, 255u8)
            @Expect(g2, 0u8)
            @Expect(b2, 0u8)
        case _ => @Expect(false, true)
    }
}

@Test
public func colorToTrueColor(): Unit {
    let conv = AnsiColorConverter()
    @Expect(conv.toTrueColor(AnsiColor.TrueColor(0u8, 134u8, 139u8)) == AnsiColor.TrueColor(0u8, 134u8, 139u8), true)
    @Expect(conv.toTrueColor(AnsiColor.Red) == AnsiColor.TrueColor(128u8, 0u8, 0u8), true)
}

@Test
public func colorToBaseColor(): Unit {
    let conv = AnsiColorConverter()
    @Expect(conv.toBaseColor(AnsiColor.Red) == AnsiColor.Red, true)
    @Expect(conv.toBaseColor(AnsiColor.TrueColor(255u8, 0u8, 0u8)) == AnsiColor.BrightRed, true)
}

@Test
public func colorCreateFrom(): Unit {
    let palette = HashMap<String, UInt32>([("MYRED", 0xFF0000)])
    let c = AnsiColor.fromName("MYRED", palette)
    match(c) {
        case Some(AnsiColor.TrueColor(r, g, b)) =>
            @Expect(r, 255u8)
            @Expect(g, 0u8)
            @Expect(b, 0u8)
        case _ => @Expect(false, true)
    }
}
