# unicodedata

面向嵌入式场景的 **Unicode 属性与序列数据静态库**：将预生成的二进制表链入 `.rodata`，通过 C API 查询码点属性、规范化分解序列与组合相关信息。表数据与仓颉 toolchain 侧的生成器配套（见同仓库 `generator`）。

## 项目结构

| 路径 | 说明 |
|------|------|
| `include/unicodedata.h` | 对外 C 接口与类型 |
| `src/library.c` | 查表与 UTF-16 字节序处理 |
| `src/data.S` | GNU 汇编，`.incbin` 嵌入 `memmap/*.bin` |
| `memmap/` | **需生成**：各 `.bin` 由生成器输出（默认路径见生成器） |
| `CMakeLists.txt` | 构建静态库与安装规则 |

## 依赖与数据准备

1. **工具链**：C11 编译器；支持 **GNU 汇编（GAS）** 或 Clang 集成汇编器（`src/data.S`）。纯 MSVC 工具链不适用当前 `data.S`。
2. **二进制表**：编译前须在 `memmap/` 下放置以下文件（与 `src/data.S` 中路径一致）：
   - `DecompSequences.bin`
   - `combinsequences_first.bin`
   - `combinsequences_second.bin`
   - `Segments.bin`、`Sections.bin`、`Pages.bin`、`Properties.bin`

3. **CMake 与生成器（默认 `UNICODEDATA_AUTO_MEMMAP=ON`）**：仅当上述 **任一** `.bin` 缺失时，构建步骤才会在 `../generator` 目录执行 **`cjpm`（无其它参数）** 并随后运行生成出的可执行文件，把表写入 `memmap/`。文件已齐全时 **不会** 再编译或执行生成器。若需完全手工管理二进制表，可配置 `-DUNICODEDATA_AUTO_MEMMAP=OFF`。

同仓库的生成器可将输出目录设为 `unicodedata/memmap`（参见 `generator` 中的默认路径）。

## 构建与安装

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

生成的静态库位于构建目录下的 `lib/`（由 `CMakeLists.txt` 中 `ARCHIVE_OUTPUT_DIRECTORY` 指定）。

安装（可选）：

```bash
cmake --install build --prefix /path/to/prefix
```

会安装静态库、`unicodedata.h` 以及 CMake package（`unicodedataTargets.cmake`）。

## API 概要

- **`getCodepointProperty(UInt32 codepoint, UInt16 *data)`**  
  用三级索引在 `Segments` → `Sections` → `Pages` → `Properties` 中定位码点对应 **16 字节**属性块，写入 `data`。失败或 `data == NULL` 时返回 `0`，成功时常量返回值为 `8`（与现行实现约定）。

- **`getDecomSequences(UInt16 index)` / `getCombinSequences(UInt16 index)`**  
  返回堆上分配的 **`Utf16Array`**（字段 `pData`、`length`）。使用完毕后必须调用 **`free_utf16array`** 释放，避免泄漏。

初始化：库在加载时用 **构造函数**（MSVC 下为 `.CRT$XCU` 段）检测本机字节序，并在非小端平台上对从嵌入表读出的 UTF-16 数据做必要的交换。

## 头文件保护宏

公共头仍使用历史宏名 `RESOURCE_LIBRARY_H`，与文件名无关；若在新代码中 include，只需 `#include "unicodedata.h"`。

## 许可证

若需对外分发，请在本仓库补齐 `LICENSE` 或与上游仓颉/Unicode 数据许可策略保持一致。
