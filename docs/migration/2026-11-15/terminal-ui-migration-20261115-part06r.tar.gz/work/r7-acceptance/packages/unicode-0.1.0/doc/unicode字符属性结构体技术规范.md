Unicode 字符属性结构体技术规范 (V1.0)
------------------------------

Unicode 字符属性结构体规范基于Unicode标准（V17.0.0），平衡了内存对齐（Memory Alignment）、查找效率（Trie-friendly）以及对复杂脚本（Emoji, Arabic, Indic, Hangul）的兼容性。


## 1. 物理结构定义

Unicode 字符属性结构结构体采用固定步长布局，且所有属性值都用整数存储，名称和分类使用编号，布尔值使用1位存储。为了确保在 64 位系统下的最优对齐，内存空间大小控制在 16 字节。

```
("EAW", (0, 0xE000, 13)),   //!< ease asian width, 3b
("GC",  (0, 0x1F00, 8)),    //!< General Category, 5b
("CCC", (0, 0x00FF, 0)),    //!< canonical Combining Class, 8b
("ICB", (1, 0xC000, 14)),   //!< Indic_Conjunct_Break, 2b
("BDC", (1, 0x1F00, 8)),    //!< Bidirectional Category, 5b
("BDM", (1, 0x0080, 7)),    //!< bidi_mirrored
("IGN", (1, 0x0040, 6)),    //!< ignorable
("FCE", (1, 0x0020, 5)),    //!< full_composition exclusion
("DT",  (1, 0x001F, 0)),    //!< Decomposition Type, 5b
// emoji属性
("EMJ", (2, 0x8000, 15)),   //!< Emoji
("EEP", (2, 0x4000, 14)),   //!< Emoji_Extended_Pictographic
("EM",  (2, 0x2000, 13)),   //!< Emoji_Modifier
("EC",  (2, 0x1000, 12)),   //!< Emoji_Component
("EMB", (2, 0x0800, 11)),   //!< Emoji_Modifier_Base
("EP",  (2, 0x0400, 10)),   //!< Emoji_Presentation
//字符簇分割属性
("GCB", (2, 0x000F, 0)),    //!< Grapheme Cluster Break, 4b
// 索引段
("DSI", (3, 0xFFFF, 0)),    //!< Decomposition Sequence Index, 16b
("CSI", (4, 0xFFFF, 0)),    //!< casefold sequence Index, 16b
("USI", (5, 0xFFFF, 0)),    //!< uppercase sequence Index, 16b
("LSI", (6, 0xFFFF, 0)),    //!< lowercase sequence Index, 16b
("TSI", (7, 0xFFFF, 0))     //!< titlecase sequence Index, 16b
```

## 2. 数据获取文件

| 源文件 | 提取的核心属性 | 字段映射 / 备注 |
|---|---|---|
| UnicodeData.txt | General_Category | 核心分类 (如 Lu, Nd, Mn) |
| | Bidi_Class | 双向文本类型 (L, R, AL...) |
| | Canonical_Combining_Class | 规范组合优先级 (CCC) |
| | Numeric_Value | 存储为 double 或 Option<f64> |
| | Simple_Uppercase_Mapping | 计算 uppercase_delta |
| | Simple_Lowercase_Mapping | 计算 lowercase_delta |
| | Simple_Titlecase_Mapping | 计算 titlecase_delta |
| | Bidi_Mirrored | 布尔值 (Y/N) |
| EastAsianWidth.txt | East_Asian_Width | 终端宽度计算核心 (W, F, H, Na, N, A) |
| DerivedCoreProps.txt | Alphabetic | 二元属性：字母/标识符 |
| | Default_Ignorable_Code_Point | 终端核心：不可见字符跳过逻辑 |
| | Indic_Syllabic_Category | Indic 核心：Consonant, Virama, Vowel_Dep |
| emoji-data.txt | Emoji | 二元属性：基础 Emoji 标识 |
| | Emoji | 一元属性：是否为Emoji字符 |
| | Emoji_Presentation | 二元属性：文本 vs 彩色样式 |
| | Emoji_Component | 一元属性 |
| | Emoji_Modifier | 一元属性 |
| | Emoji_Modifier_Base | 一元属性：肤色修饰符逻辑 |
| | Extended_Pictographic | 一元属性：防止复杂 Emoji 断行（终端核心） |
| GraphemeBreakProperty.txt | Grapheme Cluster Break| 字符簇划分属性
| | Hangul_Syllable_Type | Hangul 核心：L, V, T, LV, LVT |
| DerivedNormalizationProps.txt | full_composition exclusion | 是否在组合排除表中
| CaseFolding.txt | Case Floding 序列


## 3. 字符显示宽度计算模式
   * 如果 General_Category 是 Mn, Me, Cf，宽度强制为 0。
      * 如果 East_Asian_Width 是 W 或 F，宽度为 2。
      * 特殊：U+0000 到 U+001F (C0 Controls) 宽度通常处理为转义符或 0。
   2. 数据持久化:
   推荐使用 6-8-7 三级 Trie 树 存储该结构体。为利于终端渲染，将 East_Asian_Width 放在结构体最前面的地址。

## 4. 数据更新策略

* 跟随 Unicode Standard进行更新。
* 关注 emoji-data.txt，确保新的笑脸符号不会因为 width 错误导致光标错位。
