package unicode.types

public enum NormalizationForm <: Hashable & Equatable<NormalizationForm> {
    | NFD       //规范分解
    | NFC       //规范分解 + 规范组合
    | NFKD      //兼容性分解
    | NFKC      //兼容性分解 + 规范组合

    public func hashCode(): Int64 {
        match (this) {
            case NFD  => 0
            case NFC  => 1
            case NFKD => 2
            case NFKC => 3
        }
    }

    public operator func ==(rhs: NormalizationForm): Bool {
        hashCode() == rhs.hashCode()
    }
}