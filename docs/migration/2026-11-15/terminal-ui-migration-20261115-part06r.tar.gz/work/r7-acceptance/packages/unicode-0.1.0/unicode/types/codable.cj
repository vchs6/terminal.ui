package unicode.types

import std.convert.Parsable
import std.math.log2

public interface Codable<T> <: ToString & Parsable<T> {
    func encode(): UInt16  // 将值编码为一个整型数
    static func getCategoryName(): String
    static func getDefault(): T
    static func decode(code: UInt16): Option<T>  // 将一个整型数解码为一个字符串

    func toString(): String {
        PVAM[getCategoryName()].get(Int64(encode()))??""
    }

    static func bitSize(): UInt8 {// 编码的二进制位数
        UInt8(log2(Float32(PVAM[getCategoryName()].size)) + 1.0)
    }

    static func tryDecode(code: UInt16): T {
        match(decode(code)) {
            case Some(v)  => v
            case None     => getDefault()
        }
    }

    // In class IllegalArgumentException
    static func parse(value: String): T {
        match (PVAM[getCategoryName()].indexOf(value)) {
            case Some(idx) => decode(UInt16(idx)) ?? throw IllegalArgumentException("解码失败!") //cjlint-ignore !G.EXP.03
            case None => throw IllegalArgumentException("名称无效!")
        }
    }
    static func tryParse(value: String): Option<T> {
        try {
            parse(value)
        } catch (_) {
            None
        }
    }
}