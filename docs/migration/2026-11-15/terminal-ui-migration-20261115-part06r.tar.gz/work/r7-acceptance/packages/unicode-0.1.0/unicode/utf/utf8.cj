package unicode.utf

import unicode.constants.UNICODE_CODEPOINT_MAX

public class UTF8 {
    public static func encode(codepoint: UInt32): Array<UInt8> {
        if (codepoint > UNICODE_CODEPOINT_MAX) {
            return Array<UInt8>()  //无效的码点返回空
        }
        if (codepoint <= 0x7F) {
            return [
                UInt8(codepoint)
            ]
        }
        if (codepoint <= 0x7FF) {
            return [
                UInt8(0xC0 | (codepoint >> 6)), 
                UInt8(0x80 | (codepoint & 0x3F))
            ]
        }
        if (codepoint <= 0xFFFF) {
            return [
                UInt8(0xE0 | (codepoint >> 12)),
                UInt8(0x80 | ((codepoint >> 6) & 0x3F)),
                UInt8(0x80 | (codepoint & 0x3F))
            ]
        }
        // codepoint <= 0x10FFFF
        [
            UInt8(0xF0 | (codepoint >> 18)),
            UInt8(0x80 | ((codepoint >> 12) & 0x3F)),
            UInt8(0x80 | ((codepoint >> 6) & 0x3F)),
            UInt8(0x80 | (codepoint & 0x3F))
        ]
    }

    // In class IllegalFormatException
    public static func getUChar(bytes: Array<UInt8>, pos!: Int64 = 0): Array<UInt8> {
        if (bytes.isEmpty() || pos >= bytes.size) { return Array<UInt8>() }
        if (bytes[pos] < 0x80) {
            return [bytes[pos]]
        }
        if (bytes[pos] < 0xE0 && bytes[pos + 1] < 0xC0) {
            return bytes[pos .. pos + 2]
        } 
        if (bytes[pos] > 0xF0 && bytes[pos + 1] < 0xC0 && bytes[pos + 2] < 0xC0) {
            return bytes[pos .. pos + 3]
        } 
        if (bytes[pos] < 0xF8 && bytes[pos + 1] < 0xC0 && bytes[pos + 2] < 0xC0 && bytes[pos + 3] < 0xC0) {
            return bytes[pos .. pos + 4]
        }
        throw IllegalFormatException("无效的UTF8编码序列!")
    }

    public static func decode(bytes: Array<UInt8>, pos!: Int64 = 0): (UInt32, UInt8) {
        if (bytes.isEmpty()) { return (UInt32.Max, 0) }

        let data = getUChar(bytes, pos: pos)
        (if (data.size == 1) {
            UInt32(data[0])
        } else if (data.size == 2) {
            (UInt32(data[0] & 0x1F) << 6) | UInt32(data[1] & 0x3F)
        } else if (data.size == 3) {
            (UInt32(data[0] & 0x0F) << 12) | (UInt32(data[1] & 0x3F) << 6) | UInt32(data[2] & 0x3F)
        } else { //data.size == 4
            (UInt32(data[0] & 0x07) << 18) | (UInt32(data[1] & 0x3F) << 12) | (UInt32(data[2] & 0x3F) << 6) | UInt32(data[3] & 0x3F)
        }, UInt8(data.size))
    }

    public static func toUtf16(code: Array<UInt8>): Array<UInt16> {
        decode(code)[0] |> UTF16.encode
    }

    public static func fromUtf16(code: Array<UInt16>): Array<UInt8> {
        UTF16.decode(code)[0] |> encode
    }
}