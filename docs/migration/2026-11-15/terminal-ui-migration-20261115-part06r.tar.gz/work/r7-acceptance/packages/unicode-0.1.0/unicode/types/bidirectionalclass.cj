package unicode.types

public enum BidirectionalClass <: Codable<BidirectionalClass> & Equatable<BidirectionalClass> {
    | AL        //!< Arabic_Letter
    | AN        //!< Arabic_Number
    | B         //!< Paragraph_Separator
    | BN        //!< Boundary_Neutral
    | CS        //!< Common_Separator
    | EN        //!< European_Number
    | ES        //!< European_Separator
    | ET        //!< European_Terminator
    | FSI       //!< First_Strong_Isolate
    | L         //!< Left_To_Right
    | LRE       //!< Left_To_Right_Embedding
    | LRI       //!< Left_To_Right_Isolate
    | LRO       //!< Left_To_Right_Override
    | NSM       //!< Nonspacing_Mark
    | ON        //!< Other_Neutral
    | PDF       //!< Pop_Directional_Format
    | PDI       //!< Pop_Directional_Isolate
    | R         //!< Right_To_Left
    | RLE       //!< Right_To_Left_Embedding
    | RLI       //!< Right_To_Left_Isolate
    | RLO       //!< Right_To_Left_Override
    | S         //!< Segment_Separator
    | WS        //!< White_Space
    | UN        //!< Unknown, 仅为了与其它有默认值的属性保持一致

    public static func getCategoryName(): String {
        "bidirectional_class"
    }

    public static func getDefault(): BidirectionalClass {
        BidirectionalClass.UN
    }

    public static func bitSize(): UInt8 {
        5
    }

    public operator func ==(rhs: BidirectionalClass): Bool {
        encode() == rhs.encode()
    }

    public func encode(): UInt16 {
        return match(this) {
            case UN   => 0
            case L    => 1
            case LRE  => 2
            case LRO  => 3
            case R    => 4
            case AL   => 5
            case RLE  => 6
            case RLO  => 7
            case PDF  => 8
            case EN   => 9
            case ES   => 10
            case ET   => 11
            case AN   => 12
            case CS   => 13
            case NSM  => 14
            case BN   => 15
            case B    => 16
            case S    => 17
            case WS   => 18
            case ON   => 19
            case LRI  => 20
            case RLI  => 21
            case FSI  => 22
            case PDI  => 23
        }
    }

    public static func decode(value: UInt16): Option<BidirectionalClass> {
        return match(value) {
            case 0  => UN
            case 1  => L  
            case 2  => LRE
            case 3  => LRO
            case 4  => R  
            case 5  => AL 
            case 6  => RLE
            case 7  => RLO
            case 8  => PDF
            case 9  => EN 
            case 10 => ES 
            case 11 => ET 
            case 12 => AN 
            case 13 => CS 
            case 14 => NSM
            case 15 => BN 
            case 16 => B  
            case 17 => S  
            case 18 => WS 
            case 19 => ON 
            case 20 => LRI
            case 21 => RLI
            case 22 => FSI
            case 23 => PDI
            case _  => None
        }
    }
}