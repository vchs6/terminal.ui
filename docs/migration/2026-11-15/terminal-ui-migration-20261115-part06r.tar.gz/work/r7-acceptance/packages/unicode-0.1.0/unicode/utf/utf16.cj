package unicode.utf

import unicode.constants.UNICODE_CODEPOINT_MAX
import unicode.constants.UNICODE_SURROGATE_MIN
import unicode.constants.UNICODE_SURROGATE_MAX


public class UTF16 {
    public static func encode(codepoint: UInt32): Array<UInt16> {
        if (codepoint > UNICODE_CODEPOINT_MAX) {
            return Array<UInt16>()
        }
        if (codepoint < 0x10000) {
            if (UInt16(codepoint) >= UNICODE_SURROGATE_MIN && UInt16(codepoint) <= UNICODE_SURROGATE_MAX) { //代理保留区
                return Array<UInt16>()
            }
            return [UInt16(codepoint)]
        }
        // <= UNICODE_MAX 
        let v = codepoint - 0x10000
        [
            UInt16(UNICODE_SURROGATE_MIN | UInt16((v >> 10) & 0x3FF)), //高位代理
            UInt16(0xDC00 | (v & 0x3FF))                         //低位代理
        ]
    }

    // In class IllegalFormatException
    public static func getUChar(bytes: Array<UInt16>, pos!: Int64 = 0): Array<UInt16> {
        if (bytes.isEmpty()  || pos >= bytes.size) { return Array<UInt16>() }
        if (bytes[pos] >= 0xDC00 && bytes[pos] <= UNICODE_SURROGATE_MAX) { //孤立的低位代理数值
            throw IllegalFormatException("无效的UTF16编码序列!")
        }                

        if (bytes[pos] >= UNICODE_SURROGATE_MIN && bytes[pos] <= 0xDBFF) {  //首字在高位代理区中
            if ((pos + 1) == bytes.size || (bytes[pos + 1] < 0xDC00 && bytes[pos + 1] > UNICODE_SURROGATE_MAX)) {
                throw IllegalFormatException("无效的UTF16编码序列!")
            }
            return bytes[pos .. (pos + 2)]
        }

        [bytes[pos]]
    }

    public static func decode(bytes: Array<UInt16>): (UInt32, UInt8) {
        let data = getUChar(bytes)
        if (data.size == 2) {
            (0x10000_u32 + UInt32((data[0] - UNICODE_SURROGATE_MIN) << 10) + UInt32(data[1] - 0xDC00), 2)
        } else {
            (UInt32(data[0]), 1)
        }
    }

    public static func toUtf8(code: Array<UInt16>): Array<UInt8> {
        decode(code)[0] |> UTF8.encode
    }

    public static func fromUtf8(code: Array<UInt8>): Array<UInt16> {
        UTF8.decode(code)[0] |> encode
    }
}
