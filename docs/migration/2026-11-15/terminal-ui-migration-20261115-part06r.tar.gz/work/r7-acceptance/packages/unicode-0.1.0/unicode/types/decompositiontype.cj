package unicode.types

public enum DecompositionType <: Codable<DecompositionType> & Equatable<DecompositionType> {
    | UN        /**< Unknown */
    | CANONICAL /**< canonical */ 
    | FONT      /**< Font */
    | NOBREAK   /**< Nobreak */
    | INITIAL   /**< Initial */
    | MEDIAL    /**< Medial */
    | FINAL     /**< Final */
    | ISOLATED  /**< Isolated */
    | CIRCLE    /**< Circle */
    | SUPER     /**< Super */
    | SUB       /**< Sub */
    | VERTICAL  /**< Vertical */
    | WIDE      /**< Wide */
    | NARROW    /**< Narrow */
    | SMALL     /**< Small */
    | SQUARE    /**< Square */
    | FRACTION  /**< Fraction */
    | COMPAT    /**< Compat */

    public static func getCategoryName(): String {
        "decomposition_type"
    }

    public static func getDefault(): DecompositionType {
        DecompositionType.UN
    }

    public static func bitSize(): UInt8 {
        5
    }

    public operator func ==(rhs: DecompositionType) {
        encode() == rhs.encode()
    }

    public func encode(): UInt16 {
        return match(this) {
            case UN        => 0
            case CANONICAL => 1
            case FONT      => 2
            case NOBREAK   => 3
            case INITIAL   => 4
            case MEDIAL    => 5
            case FINAL     => 6
            case ISOLATED  => 7
            case CIRCLE    => 8
            case SUPER     => 9
            case SUB       => 10
            case VERTICAL  => 11
            case WIDE      => 12
            case NARROW    => 13
            case SMALL     => 14
            case SQUARE    => 15
            case FRACTION  => 16
            case COMPAT    => 17
        }
    }

    public static func decode(value: UInt16): Option<DecompositionType> {
        return match(value) {
            case 0  =>  UN
            case 1  =>  CANONICAL
            case 2  =>  FONT    
            case 3  =>  NOBREAK 
            case 4  =>  INITIAL 
            case 5  =>  MEDIAL  
            case 6  =>  FINAL   
            case 7  =>  ISOLATED
            case 8  =>  CIRCLE  
            case 9  =>  SUPER   
            case 10 =>  SUB     
            case 11 =>  VERTICAL
            case 12 =>  WIDE    
            case 13 =>  NARROW  
            case 14 =>  SMALL   
            case 15 =>  SQUARE  
            case 16 =>  FRACTION
            case 17 =>  COMPAT            
            case _  =>  None
        }
    }
}