package generator

import std.unittest.testmacro.Test
import std.unittest.testmacro.Expect
import std.unittest.TestClass
import std.unittest.Configuration
import std.unittest.TestSuite
import std.unittest.TestPackage
import std.unittest.UnitTestCase
import std.unittest.expectEqual
import std.unittest.KeyFromTopLevel

@Test
func encodeTest(): Unit {
    @Expect(encode(0x1E921_u32), [0xD83A_u16, 0xDD21_u16])
    @Expect(encode(0x00061_u32), [0x0061_u16])
}
