package unicode.constants

/* Unicode编码范围 */
public const UNICODE_CODEPOINT_MAX: UInt32 = 0X10FFFF_u32
public const UNICODE_SURROGATE_MIN: UInt16 = 0xD800_u16
public const UNICODE_SURROGATE_MAX: UInt16 = 0xDFFF_u16

