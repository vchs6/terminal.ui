package unicode.types

public enum HangulSyllableType <: Codable<HangulSyllableType> & Equatable<HangulSyllableType> {
    | L     //前声母
    | V     //中声母
    | T     //后声母
    | LV    //由前声母和中声母组成的完整音节
    | LVT   //由前声母、中声母和后声母组成的完整音节
    | NA    //非韩文字符

    public static func bitSize(): UInt8 { 3 }
    public static func getCategoryName(): String { "hangul_syllable_type" }
    public static func getDefault(): HangulSyllableType {
        HangulSyllableType.NA
    }

    public operator func !=(rhs: HangulSyllableType): Bool {
        encode() != rhs.encode()
    }

    public operator func ==(rhs: HangulSyllableType): Bool {
        encode() == rhs.encode()
    }

    public func encode(): UInt16 {
        match(this) {
            case L   => 1
            case V   => 2
            case T   => 3
            case LV  => 4
            case LVT => 5
            case NA  => 0 
        }
    }

    public static func decode(value: UInt16): Option<HangulSyllableType> {
        match(value) {
            case 1 => HangulSyllableType.L  
            case 2 => HangulSyllableType.V  
            case 3 => HangulSyllableType.T  
            case 4 => HangulSyllableType.LV 
            case 5 => HangulSyllableType.LVT
            case _ => HangulSyllableType.NA  
        }
    }
}
