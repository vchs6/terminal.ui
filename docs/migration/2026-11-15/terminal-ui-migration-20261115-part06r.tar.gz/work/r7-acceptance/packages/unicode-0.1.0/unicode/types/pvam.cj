package unicode.types

import std.collection.HashMap

import unicode.constants.BLOCK_ALIAS_SHORT

internal let PVAM: HashMap<String, Array<String>> = HashMap<String, Array<String>>([
    ("block", BLOCK_ALIAS_SHORT)
])