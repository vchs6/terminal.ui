//cjlint-ignore -start !G.OTH.03 description

// Copyright 2012-2025 The Rust Project Developers. See the COPYRIGHT
// file at the top-level directory of this distribution and at
// http://rust-lang.org/COPYRIGHT.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//cjlint-ignore -end description

// NOTE: Ported from unicode-width/src/lib.rs
// Public API for Unicode width calculation.

package unicodewidth

public interface RuneWidth {
    func width(): Option<UInt8>
    func widthCjk(): Option<UInt8>
}

//cjlint-ignore -start !G.NAM.04 description
/// Methods for determining displayed width of Unicode characters.
/// Ambiguous width characters are treated as narrow.
extend Rune <: RuneWidth {
    /// Returns the character's displayed width in columns, or `None` if the
    /// character is a control character.
    ///
    /// This function treats characters in the Ambiguous category according
    /// to Unicode Standard Annex #11 as 1 column wide. This is consistent
    /// with the recommendations for non-CJK contexts.
    public func width(): ?UInt8 {
        single_char_width(this)
    }

    /// Returns the character's displayed width in columns, or `None` if the
    /// character is a control character.
    ///
    /// This function treats characters in the Ambiguous category according
    /// to Unicode Standard Annex #11 as 2 columns wide. This is consistent
    /// with the recommendations for CJK contexts.
    public func widthCjk(): ?UInt8 {
        single_char_width_cjk(this)
    }
}

public interface StringWidth {
    func width(): UInt64
    func widthCjk(): UInt64
}

/// Methods for determining displayed width of Unicode strings.
/// Ambiguous width characters are treated as narrow.
extend String <: StringWidth {
    /// Returns the string's displayed width in columns.
    /// Ambiguous width characters are treated as narrow.
    public func width(): UInt64 {
        str_width(this.toRuneArray())
    }

    /// Returns the string's displayed width in columns.
    /// Ambiguous width characters are treated as wide.
    public func widthCjk(): UInt64 {
        str_width_cjk(this.toRuneArray())
    }
}

/// Returns the unicode width of a character iterator.
/// Ambiguous width characters are treated as narrow.
public func char_iter_width(s: Array<Rune>): UInt64 {
    str_width(s)
}

/// Returns the unicode width of a character iterator.
/// Ambiguous width characters are treated as wide.
public func char_iter_width_cjk(s: Array<Rune>): UInt64 {
    str_width_cjk(s)
}

//cjlint-ignore -end description