package test

import unicodewidth.{RuneWidth, StringWidth}

main() {
    let text = "你好, Cangjie!"
    println(text)
    println("非 CJK 宽度：${text.width()}")
    println("CJK 宽度：${text.widthCjk()}")

    let ambiguous = r'\u{00B7}'
    match (ambiguous.width()) {
        case Some(columns) => println("· 在非 CJK 模式占 ${columns} 列")
        case None => println("· 是控制字符")
    }
    match (ambiguous.widthCjk()) {
        case Some(columns) => println("· 在 CJK 模式占 ${columns} 列")
        case None => println("· 是控制字符")
    }
}
