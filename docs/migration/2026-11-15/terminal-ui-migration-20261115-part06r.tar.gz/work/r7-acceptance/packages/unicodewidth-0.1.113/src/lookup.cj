//cjlint-ignore -start !G.OTH.03 description

// Copyright 2012-2025 The Rust Project Developers. See the COPYRIGHT
// file at the top-level directory of this distribution and at
// http://rust-lang.org/COPYRIGHT.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//cjlint-ignore -end description

// NOTE: Ported from unicode-width/src/lookup.rs
// Hand-written width calculation logic and state machine.

package unicodewidth
import unicodewidth.gen.WidthInfo
import unicodewidth.gen.{lookup_width, lookup_width_cjk}
import unicodewidth.gen.{starts_emoji_presentation_seq, starts_non_ideographic_text_presentation_seq}
import unicodewidth.gen.{is_joining_group_lam, is_emoji_modifier_base, is_ligature_transparent}

//cjlint-ignore -start !G.NAM.04 description

/// Returns the UAX #11 based width of `c`, or
/// None if `c` is a control character.
/// Ambiguous width characters are treated as narrow.
public func single_char_width(c: Rune): ?UInt8 {
    single_char_width_generic(c, false)
}

/// Returns the UAX #11 based width of `c`, or
/// None if `c` is a control character.
/// Ambiguous width characters are treated as wide.
public func single_char_width_cjk(c: Rune): ?UInt8 {
    single_char_width_generic(c, true)
}

func single_char_width_generic(c: Rune, is_cjk: Bool): ?UInt8 {
    let cp = UInt32(c)
    if (cp < 0x7Fu32) {
        if (cp >= 0x20u32) {
            Some(1u8)
        } else {
            None
        }
    } else if (cp >= 0xA0u32) {
        Some(lookup_width_generic(c, is_cjk)[0])
    } else {
        None
    }
}

public func width_in_str(c: Rune, next_info: WidthInfo): (Int8, WidthInfo) {
    width_in_generic(c, next_info, false)
}

public func width_in_str_cjk(c: Rune, next_info: WidthInfo): (Int8, WidthInfo) {
    width_in_generic(c, next_info, true)
}

public func lookup_width_generic(c: Rune, is_cjk: Bool): (UInt8, WidthInfo) {
    if (is_cjk) {
        lookup_width_cjk(c)
    } else {
        lookup_width(c)
    }
}

func width_in_generic(c: Rune, next_info: WidthInfo, is_cjk: Bool): (Int8, WidthInfo) { //cjlint-ignore !G.FUN.01 description
    var st = next_info
    let cp = UInt32(c)

    if (st.is_emoji_presentation()) {
        if (starts_emoji_presentation_seq(c)) {
            let width: Int8 = if (st.is_zwj_emoji_presentation()) { 0i8 } else { 2i8 }
            return (width, WidthInfo.WIDTH_EMOJI_PRESENTATION)
        } else {
            st = st.unset_emoji_presentation()
        }
    }

    if (is_cjk &&
        (st == WidthInfo.WIDTH_COMBINING_LONG_SOLIDUS_OVERLAY || st == WidthInfo.WIDTH_SOLIDUS_OVERLAY_ALEF) &&
        (cp == 0x3Cu32 || cp == 0x3Du32 || cp == 0x3Eu32)) {
        return (2i8, WidthInfo.WIDTH_DEFAULT)
    }

    if (cp <= 0xA0u32) { //cjlint-ignore !G.FUN.01 description
        match(cp) {
            case 0xAu32 => (1i8, WidthInfo.WIDTH_LINE_FEED)
            case 0xDu32 =>
                if (st == WidthInfo.WIDTH_LINE_FEED) {
                    (0i8, WidthInfo.WIDTH_DEFAULT)
                } else {
                    (1i8, WidthInfo.WIDTH_DEFAULT)
                }
            case _ => (1i8, WidthInfo.WIDTH_DEFAULT)
        }
    } else {
        if (st != WidthInfo.WIDTH_DEFAULT) {
            if (cp == 0xFE0Fu32) {
                return (0i8, st.set_emoji_presentation())
            }

            if (is_cjk) {
                if (cp == 0xFE00u32 || cp == 0xFE02u32) {
                    return (0i8, st.set_vs1_2_3())
                }
            } else {
                if (cp == 0xFE01u32) {
                    return (0i8, st.set_vs1_2_3())
                }
                if (cp == 0xFE0Eu32) {
                    return (0i8, st.set_text_presentation())
                }
                if (st.is_text_presentation()) {
                    if (starts_non_ideographic_text_presentation_seq(c)) {
                        return (1i8, WidthInfo.WIDTH_DEFAULT)
                    } else {
                        st = st.unset_text_presentation()
                    }
                }
            }

            if (st.is_vs1_2_3()) {
                if (cp == 0x2018u32 || cp == 0x2019u32 || cp == 0x201Cu32 || cp == 0x201Du32) {
                    return (if (is_cjk) { 1i8 } else { 2i8 }, WidthInfo.WIDTH_DEFAULT)
                } else {
                    st = st.unset_vs1_2_3()
                }
            }

            if (st.is_ligature_transparent()) {
                if (cp == 0x200Du32) {
                    return (0i8, st.set_zwj_bit())
                } else if (is_ligature_transparent(c)) {
                    return (0i8, st)
                }
            }

            if (is_solidus_transparent(c) && st == WidthInfo.WIDTH_COMBINING_LONG_SOLIDUS_OVERLAY && is_cjk) {
                return (Int8(lookup_width_generic(c, is_cjk)[0]), WidthInfo.WIDTH_COMBINING_LONG_SOLIDUS_OVERLAY)
            }
            if (st == WidthInfo.WIDTH_JOINING_GROUP_ALEF && cp == 0x338u32 && is_cjk) {
                return (0i8, WidthInfo.WIDTH_SOLIDUS_OVERLAY_ALEF)
            }
            if (st == WidthInfo.WIDTH_JOINING_GROUP_ALEF && is_joining_group_lam(c)) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_SOLIDUS_OVERLAY_ALEF && is_cjk && is_joining_group_lam(c)) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (is_transparent_zero_width(c) && st == WidthInfo.WIDTH_JOINING_GROUP_ALEF) {
                return (0i8, WidthInfo.WIDTH_JOINING_GROUP_ALEF)
            }
            if (st == WidthInfo.WIDTH_ZWJ_HEBREW_LETTER_LAMED && cp == 0x5D0u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_KHMER_COENG_ELIGIBLE_LETTER && cp == 0x17D2u32) {
                return (-1i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_ZWJ_BUGINESE_LETTER_YA && cp == 0x1A17u32) {
                return (0i8, WidthInfo.WIDTH_BUGINESE_VOWEL_SIGN_I_ZWJ_LETTER_YA)
            }
            if (st == WidthInfo.WIDTH_BUGINESE_VOWEL_SIGN_I_ZWJ_LETTER_YA && cp == 0x1A15u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if ((st == WidthInfo.WIDTH_TIFINAGH_CONSONANT || st == WidthInfo.WIDTH_ZWJ_TIFINAGH_CONSONANT) && cp == 0x2D7Fu32) {
                return (1i8, WidthInfo.WIDTH_TIFINAGH_JOINER_CONSONANT)
            }
            if (st == WidthInfo.WIDTH_ZWJ_TIFINAGH_CONSONANT && (cp >= 0x2D31u32 && cp <= 0x2D65u32 || cp == 0x2D6Fu32)) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_TIFINAGH_JOINER_CONSONANT && (cp >= 0x2D31u32 && cp <= 0x2D65u32 || cp == 0x2D6Fu32)) {
                return (-1i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_LISU_TONE_LETTER_MYA_NA_JEU && cp >= 0xA4F8u32 && cp <= 0xA4FBu32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_ZWJ_OLD_TURKIC_LETTER_ORKHON_I && cp == 0x10C32u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_EMOJI_MODIFIER && is_emoji_modifier_base(c)) {
                return (0i8, WidthInfo.WIDTH_EMOJI_PRESENTATION)
            }
            if ((st == WidthInfo.WIDTH_REGIONAL_INDICATOR || st == WidthInfo.WIDTH_SEVERAL_REGIONAL_INDICATOR) &&
                cp >= 0x1F1E6u32 && cp <= 0x1F1FFu32) {
                return (1i8, WidthInfo.WIDTH_SEVERAL_REGIONAL_INDICATOR)
            }
            if ((st == WidthInfo.WIDTH_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_SEVERAL_REGIONAL_INDICATOR ||
                 st == WidthInfo.WIDTH_EVEN_REGIONAL_INDICATOR_ZWJ_PRESENTATION ||
                 st == WidthInfo.WIDTH_ODD_REGIONAL_INDICATOR_ZWJ_PRESENTATION ||
                 st == WidthInfo.WIDTH_EMOJI_MODIFIER) &&
                cp == 0x200Du32) {
                return (0i8, WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION && cp == 0x20E3u32) {
                return (0i8, WidthInfo.WIDTH_KEYCAP_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_VS16_ZWJ_EMOJI_PRESENTATION && starts_emoji_presentation_seq(c)) {
                return (0i8, WidthInfo.WIDTH_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_VS16_KEYCAP_ZWJ_EMOJI_PRESENTATION &&
                ((cp >= 0x30u32 && cp <= 0x39u32) || cp == 0x23u32 || cp == 0x2Au32)) {
                return (0i8, WidthInfo.WIDTH_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION && cp >= 0x1F1E6u32 && cp <= 0x1F1FFu32) {
                return (1i8, WidthInfo.WIDTH_REGIONAL_INDICATOR_ZWJ_PRESENTATION)
            }
            if ((st == WidthInfo.WIDTH_REGIONAL_INDICATOR_ZWJ_PRESENTATION ||
                 st == WidthInfo.WIDTH_ODD_REGIONAL_INDICATOR_ZWJ_PRESENTATION) &&
                cp >= 0x1F1E6u32 && cp <= 0x1F1FFu32) {
                return (-1i8, WidthInfo.WIDTH_EVEN_REGIONAL_INDICATOR_ZWJ_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_EVEN_REGIONAL_INDICATOR_ZWJ_PRESENTATION && 
                cp >= 0x1F1E6u32 && cp <= 0x1F1FFu32) {
                return (3i8, WidthInfo.WIDTH_ODD_REGIONAL_INDICATOR_ZWJ_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION && cp >= 0x1F3FBu32 && cp <= 0x1F3FFu32) {
                return (0i8, WidthInfo.WIDTH_EMOJI_MODIFIER)
            }
            if (st == WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION && cp == 0xE007Fu32) {
                return (0i8, WidthInfo.WIDTH_TAG_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A1_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_A1_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A2_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_A2_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A3_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_A3_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A4_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_A4_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A5_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_A5_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0061u32 && cp <= 0xE007Au32) {
                return (0i8, WidthInfo.WIDTH_TAG_A6_END_ZWJ_EMOJI_PRESENTATION)
            }
            if ((st == WidthInfo.WIDTH_TAG_END_ZWJ_EMOJI_PRESENTATION || 
                 st == WidthInfo.WIDTH_TAG_A1_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A2_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A3_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A4_END_ZWJ_EMOJI_PRESENTATION) &&
                cp >= 0xE0030u32 && cp <= 0xE0039u32) {
                return (0i8, WidthInfo.WIDTH_TAG_D1_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_D1_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0030u32 && cp <= 0xE0039u32) {
                return (0i8, WidthInfo.WIDTH_TAG_D2_END_ZWJ_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_TAG_D2_END_ZWJ_EMOJI_PRESENTATION && cp >= 0xE0030u32 && cp <= 0xE0039u32) {
                return (0i8, WidthInfo.WIDTH_TAG_D3_END_ZWJ_EMOJI_PRESENTATION)
            }
            if ((st == WidthInfo.WIDTH_TAG_A3_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A4_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A5_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_A6_END_ZWJ_EMOJI_PRESENTATION ||
                 st == WidthInfo.WIDTH_TAG_D3_END_ZWJ_EMOJI_PRESENTATION) &&
                cp == 0x1F3F4u32) {
                return (0i8, WidthInfo.WIDTH_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_ZWJ_EMOJI_PRESENTATION &&
                lookup_width_generic(c, is_cjk)[1] == WidthInfo.WIDTH_EMOJI_PRESENTATION) {
                return (0i8, WidthInfo.WIDTH_EMOJI_PRESENTATION)
            }
            if (st == WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_E && cp == 0x16D63u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_E && cp == 0x16D67u32) {
                return (0i8, WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_AI)
            }
            if (st == WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_E && cp == 0x16D68u32) {
                return (1i8, WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_E)
            }
            if (st == WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_E && cp == 0x16D69u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
            if (st == WidthInfo.WIDTH_KIRAT_RAI_VOWEL_SIGN_AI && cp == 0x16D63u32) {
                return (0i8, WidthInfo.WIDTH_DEFAULT)
            }
        }

        let ret = lookup_width_generic(c, is_cjk)
        (Int8(ret[0]), ret[1])
    }
}

/// Returns the width of a string using the scanner automaton.
/// Ambiguous width characters are treated as narrow.
public func str_width(s: Array<Rune>): UInt64 {
    var total: UInt64 = 0
    var next_info: WidthInfo = WidthInfo.WIDTH_DEFAULT //cjlint-ignore !G.VAR.02 description
    let len = s.size
    var i = len - 1
    while (i >= 0) {
        let (add, info) = width_in_str(s[i], next_info)
        total = UInt64(Int64(total) + Int64(add))
        next_info = info
        i--
    }
    total
}

/// Returns the width of a string using the scanner automaton.
/// Ambiguous width characters are treated as wide.
public func str_width_cjk(s: Array<Rune>): UInt64 {
    var total: UInt64 = 0
    var next_info: WidthInfo = WidthInfo.WIDTH_DEFAULT //cjlint-ignore !G.VAR.02 description
    let len = s.size
    var i = len - 1
    while (i >= 0) {
        let (add, info) = width_in_str_cjk(s[i], next_info)
        total = UInt64(Int64(total) + Int64(add))
        next_info = info
        i--
    }
    total
}

//cjlint-ignore -end description