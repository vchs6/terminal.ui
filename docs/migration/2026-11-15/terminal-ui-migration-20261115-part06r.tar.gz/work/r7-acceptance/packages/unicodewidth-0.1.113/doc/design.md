# 设计文档

## 概述

unicodewidth4cj 是基于 Unicode 标准 Annex #11（East Asian Width）的字符宽度计算库，从 Rust 的 [unicode-width](https://github.com/unicode-rs/unicode-width) 库移植而来。

## 数据来源

使用 Unicode 17.0.0 的以下数据表：

- EastAsianWidth.txt
- DerivedCoreProperties.txt
- UnicodeData.txt
- PropList.txt
- LineBreak.txt
- HangulSyllableType.txt
- NormalizationTest.txt
- emoji/emoji-data.txt
- emoji/emoji-variation-sequences.txt
- auxiliary/GraphemeBreakProperty.txt
- extracted/DerivedGeneralCategory.txt
- extracted/DerivedCombiningClass.txt
- extracted/DerivedJoiningGroup.txt
- extracted/DerivedJoiningType.txt

## 架构

### 包结构

```
src/
├── gen/                    # 生成代码（由 scripts/unicode.py 生成）
│   ├── tables.cj           # 三级查找表数据
│   ├── props.cj            # 属性判断函数（并集匹配）
│   ├── lookup.cj           # 查找表查询函数
│   └── width_info.cj       # WidthInfo 结构体及常量
├── lib.cj                  # 公共 API（Rune/String 扩展方法）
├── lookup.cj               # 宽度计算状态机
├── props.cj                # 属性函数
├── width_info.cj           # WidthInfo 扩展方法
├── tables_test.cj          # 生成测试数据（20000+ 条）
├── tests.cj                # 集成测试（37 个测试用例）
└── test_test.cj            # 标准化测试
```

### 三级查找表

宽度数据通过三级查找表实现高效查询：

1. **WIDTH_ROOT**（256 字节）：一级索引，取 codepoint 高 13~20 位
2. **WIDTH_MIDDLE**（1280 字节）：二级索引，取 codepoint 高 7~12 位
3. **WIDTH_LEAVES**（5952 字节）：叶子节点，每 2 位存储一个宽度值

### 状态机

宽度计算使用自右向左的状态机：

1. 从字符串末尾开始向前遍历
2. 每个字符结合前一个字符的状态信息计算宽度贡献
3. 状态信息编码了字符类型（Emoji、修饰符、零宽字符等）
4. 支持 CRLF 序列、Emoji ZWJ 序列、文字连字等多种特殊场景

### WidthInfo 位编码

WidthInfo 使用 16 位无符号整数编码状态信息：

| 位 | 含义 |
|----|------|
| 15（最高位） | Vs16 标记 |
| 14 | Vs15 标记 |
| 13 | 不透明（不受 ligature-transparent 影响） |
| 12 | Emoji presentation 标记 |
| 11 | 不受 ligature-transparent 影响 |
| 10 | ZWJ 标记 |
| 9 | Vs1/Vs3 标记 |
| 0~8 | 具体字符类型编码 |

### 特殊序列处理

- **Arabic Lam-Alef**：Lam 后跟任意数量 Transparent 字符 + Alef → 宽度 1
- **Hebrew Alef-Lamed**：Alef + ZWJ + Lamed → 宽度 1
- **Buginese <a, -i> ya**：特定序列 → 宽度 1
- **Tifinagh**：辅音 + ZWJ/连接符 + 辅音 → 宽度 1
- **Khmer Coeng**：Coeng 后跟特定字母 → 宽度 0
- **Old Turkic**：ORKHON EC + ZWJ + ORKHON I → 宽度 1
- **Lisu 声调字母**：特定组合 → 宽度 1
- **Kirat Rai**：元音符号特定序列 → 宽度 1

## 迁移方式

本库从 Rust 的 [unicode-width](https://github.com/unicode-rs/unicode-width) 移植而来。核心策略是**修改数据生成器 `scripts/unicode.py` 直接输出仓颉 `.cj` 文件**，而非先输出 Rust 再手工翻译。

### 生成器改造

原 `unicode.py` 包含 5 个发射器（emitter），分别输出 Rust 的 `tables.rs`、`props.rs`、`lookup.rs`、`width_info.rs`、`tables_test.rs`。迁移时对生成器做了以下改造：

#### 1. 输出目标变更

| 原 Rust 文件 | 仓颉文件 | 包 |
|-------------|---------|-----|
| `src/gen/tables.rs` | `src/gen/tables.cj` | `unicodewidth.gen` |
| `src/gen/props.rs` | `src/gen/props.cj` | `unicodewidth.gen` |
| `src/gen/lookup.rs` | `src/gen/lookup.cj` | `unicodewidth.gen` |
| `src/gen/width_info.rs` | `src/gen/width_info.cj` | `unicodewidth.gen` |
| `src/gen/tables_test.rs` | `src/tables_test.cj` | `unicodewidth` |

#### 2. 语法映射

| Rust | 仓颉 | 说明 |
|------|------|------|
| `pub const` / `pub(crate) static` | `public let` | 顶层常量 |
| `fn name(c: char) -> (u8, T)` | `func name(c: Rune): (UInt8, T)` | 函数定义 |
| `match c { '\u{...}' => ... }` | `match(UInt32(c)) { case 0x...u32 => ... }` | 字符匹配 |
| `'\u{XXXX}'..='\u{YYYY}'` | `cp >= 0xXXXXu32 && cp <= 0xYYYYu32` | 范围匹配（仓颉不支持 `..=` 模式） |
| `[u8; N]` | `Array<UInt8>` | 字节数组 |
| `([u8; 3], [u8; 3])` | `((UInt8, UInt8, UInt8), (UInt8, UInt8, UInt8))` | 元组数组 |
| `Align128<[u8; 256]>` | `Array<UInt8>` | 移除对齐包装器 |
| `WidthInfo::NAME` | `WidthInfo.WIDTH_NAME` | 静态常量引用 |
| `binary_search_by` | `for (pair in arr)` | 二分查找改为线性扫描 |
| `#[cfg(feature = "cjk")]` | — | 移除条件编译，始终包含 |
| `#[inline]` | — | 仓颉自动内联 |

#### 3. 包结构设计

- `src/gen/*.cj`：生成代码，`package unicodewidth.gen`，由生成器直接输出
- `src/*.cj`：手写补充代码，`package unicodewidth`，通过 `import unicodewidth.gen.*` 引用生成代码
- `src/tables_test.cj`：测试数据使用 `package unicodewidth`（与手写代码同包，避免跨包可见性问题）
- `tests/`：原始集成测试文件参考，部分已在 `src/tests.cj` 中适配

#### 4. 手写代码适配

生成器只负责输出数据表和底层查询函数。以下代码作为手写文件单独维护：

| 文件 | 来源 `.rs` | 说明 |
|------|-----------|------|
| `src/width_info.cj` | `src/width_info.rs` | `extend WidthInfo` 状态机方法 |
| `src/props.cj` | `src/props.rs` | `is_transparent_zero_width` / `is_solidus_transparent` |
| `src/lookup.cj` | `src/lookup.rs` | `width_in_generic` 状态机、`str_width` |
| `src/lib.cj` | `src/lib.rs` | 公共 API：`extend Rune`/`String` |
| `src/tests.cj` | `tests/tests.rs` | 集成测试（37 用例） |
| `src/test_test.cj` | `src/test.rs` | 标准化测试 |

#### 5. 关键适配要点

- **关键字冲突**：仓颉中 `init` 是关键字，参数/变量名需改为 `init_state` 或转义引用
- **参数可变性**：仓颉函数参数不支持 `var`/`mut` 修饰，需用局部变量 `var st = next_info` 替代
- **位运算 NOT**：仓颉使用 `!` 而非 `~` 作为按位取反运算符
- **跨包可见性**：`src/gen/` 目录强制使用 `package unicodewidth.gen`，父包通过 `import unicodewidth.gen.*` 引用
- **测试框架**：使用 `@Test` / `@Expect` 宏（`std.unittest` 自动导入），测试文件需按 `xxx_test.cj` 命名
- **字符串处理**：`\0` / `\x01` 等转义改为 `\u{0}` / `\u{1}`；`String.fromRune(c)` 改为 `"${c}"`

### 运行生成器

```bash
cd scripts && python3 unicode.py
```

生成器依赖标准库 `urllib` 从 `unicode.org` 下载数据文件，首次运行可能需要较长时间。下载后的数据会缓存到 `scripts/` 目录。

## 测试

- 标准化测试：使用 Unicode NormalizationTest.txt 中的 20000+ 条用例验证宽度一致性
- 功能测试：37 个集成测试用例覆盖所有特殊场景
- 运行方式：`cjpm test`
