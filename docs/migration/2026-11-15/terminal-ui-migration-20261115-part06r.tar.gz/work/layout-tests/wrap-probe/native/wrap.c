int cjt_close(void) { return 7; }
extern int __real_cjt_close(void);
int __wrap_cjt_close(void) { return __real_cjt_close() + 1; }
