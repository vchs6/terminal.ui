import pathlib,os,stat,json,hashlib,gzip,subprocess,sys
O=pathlib.Path('/workspace/work/validation/accepted-d-runtime-headroom-20261114');M=pathlib.Path('/workspace/work/terminal.ui');TASKS=('incremental-composition-tests','composition-root-visibility-tests');ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def read(n):return json.loads((O/n).read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():
 s=os.statvfs(M);return s.f_bavail*s.f_frsize
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
def state():
 rev='f48ca45608247f52a6876ad5c27b4ca36867f406';data=subprocess.check_output(['git','cat-file','commit',rev],cwd=M,env=ENV)
 return {'immutable_candidate':rev,'commit_bytes_sha256':hashlib.sha256(data).hexdigest(),'tree':git(M,'rev-parse',rev+'^{tree}'),'main_config_sha256':sha(M/'.git/config'),'active_source_and_main_HEAD_tree':'intentionally excluded; code/docs edits allowed'}

def record(p):
 s=p.lstat();r={'path':str(p),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
 if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
 elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
 elif stat.S_ISFIFO(s.st_mode):r.update(type='preserved_raw_fifo')
 elif stat.S_ISSOCK(s.st_mode):r.update(type='preserved_raw_socket')
 else:raise AssertionError('unexpected special '+str(p))
 return r
def inventory(exclude):
 return sorted([record(pathlib.Path(r['path'])) for r in protected_physical_pins() if r['path'] not in exclude],key=lambda r:r['path'])

def compress(src,sink):
 with gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as z,src.open('rb') as f:
  while b:=f.read(1024*1024):z.write(b)
def verify_gz(p,expected):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 assert h.hexdigest()==expected['sha256'] and n==expected['size'],'gzip verification mismatch'
class Count:
 def __init__(self):self.n=0
 def write(self,b):self.n+=len(b);return len(b)
 def flush(self):pass
SPECS=[('incremental-composition-implementation','index-r1.json','227dd077c9dff3e10aab8875280aa8098a6cf2a8e7eeb33da25a400a1d83a83a','artifacts'),('incremental-composition-execution','index.json','159189b07c8348e1289f7ed23e284e95d375f0ba7bf069bc041055d09ae842eb','executables'),('composition-review-counterexamples','index.json','10bdab56cadd84f326d92493f8fd1061a24a77c9fa7ade0bfdeb936f49067711','binary')]
def indexvalues():
 for role,name,h,key in SPECS:
  P=pathlib.Path('/workspace/work')/role;ix=P/name;assert sha(ix)==h;yield P,ix,json.loads(ix.read_text()),key

def candidate_specs():
 rows=[]
 for P,ix,v,key in indexvalues():
  rr=v[key];rr=rr if isinstance(rr,list) else [rr]
  for r in rr:
   if not r['sha256'].startswith(('f12f','f4f8','6bb1','1ec0','bb26','2fcbb8','87d4')):continue
   p=pathlib.Path(r['path']);p=p if p.is_absolute() else P/p
   rows.append({**r,'path':str(p),'bytes':r.get('bytes',p.stat().st_size if p.exists() else 0),'index':str(ix)})
 assert len(rows)==7;return rows

def protected_physical_pins():
 rows=[]
 for P,ix,v,key in indexvalues():
  rows.append({'path':str(ix),'sha256':sha(ix)})
  for r in v.get('configuration',v.get('configs',[])):
   if not isinstance(r,dict) or 'path' not in r or 'sha256' not in r:continue
   p=pathlib.Path(r['path']);p=p if p.is_absolute() else P/p
   rows.append({**r,'path':str(p)})
  for r in v.get('artifacts',[]):
   if r['path'].endswith('.cjp'):rows.append(r)
 for r in rows:
  p=pathlib.Path(r['path']);assert p.is_file() and sha(p)==r['sha256'],str(p)
  if 'bytes' in r:assert p.stat().st_size==r['bytes']
 return list({r['path']:r for r in rows}.values())
if sys.argv[1]=='prepare':
 assert not (O/'plan.json').exists()
 plan=[]
 for item in candidate_specs():
  p=pathlib.Path(item['path']);assert p.resolve()==p and not p.is_symlink();r=record(p);assert r['type']=='file' and r['nlink']==1 and r['sha256']==item['sha256'] and r['size']==item['bytes']
  with p.open('rb') as f:assert f.read(4)==b'\x7fELF'
  ix=pathlib.Path(item['index']);r.update(source_index=str(ix),source_index_sha256=sha(ix),witness=str(O/(r['sha256']+'.gz')));plan.append(r)
 assert len(plan)==7
 write('protected-physical-pins-before.json',protected_physical_pins())
 write('publication-lifecycle.json',{'prior_public_D_pinchecks':'all 8888 members root verified before migration; accepted142/root354+271+20PNG/1417828 proofs reused','migration':'postpublication lossless custody change only; original sealed indices/public archives unchanged; original paths now logical historical aliases resolved by progress.json','source_config_raw_publicarchives':'retained via whitelist-only operator; relevant configuration/index/CJP and immutable f48 Git guarded fresh; no broad raw/history reread'})
 counter=Count();compress(pathlib.Path(plan[0]['path']),counter)
 assert free()>=counter.n+1024*1024,'first gzip cannot fit with 1MiB receipt reserve'
 write('disk-gate-first.json',{'free_bytes':free(),'first_gzip_exact_bytes':counter.n,'reserve_bytes':1048576})
 write('plan.json',plan);write('preserved-before.json',inventory({r['path'] for r in plan}));write('state-before.json',state());write('progress.json',[]);write('free-before.json',{'bytes':free()})
 print(json.dumps({'prepared':7,'first_gzip_bytes':counter.n,'free_bytes':free()}),flush=True)
elif sys.argv[1]=='next':
 plan=read('plan.json');progress=read('progress.json');i=len(progress);assert i<len(plan)
 r=plan[i];src=pathlib.Path(r['path']);dest=pathlib.Path(r['witness']);assert not dest.exists()
 proc=read('process-final.json');assert not proc['busy'] and not proc['unexpected_denied']
 current=record(src);assert all(current[k]==r[k] for k in current),'original changed'
 assert state()==read('state-before.json'),'Git state changed'
 counter=Count();compress(src,counter);assert free()>=counter.n+256*1024,'gzip disk gate failed'
 beforefree=free();write(f'{i+1}-before.json',{'original':r,'free_bytes':beforefree,'gzip_expected_bytes':counter.n})
 # Exclusive create; original remains intact until compressed bytes pass full decompression proof and fsync.
 with dest.open('xb') as f:compress(src,f);f.flush();os.fsync(f.fileno())
 assert dest.stat().st_size==counter.n
 verify_gz(dest,r);assert sha(src)==r['sha256'] and src.stat().st_size==r['size']
 os.chmod(dest,0o444)
 write(f'{i+1}-verified-before-unlink.json',{'original_sha256':r['sha256'],'original_bytes':r['size'],'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'decompressed_equals_original':True})
 fd=os.open(src.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],r['size'],r['mtime_ns'])
  os.unlink(src.name,dir_fd=fd)
 finally:os.close(fd)
 result={'logical_original_path':r['path'],'physical_original_present':False,'original_sha256':r['sha256'],'original_bytes':r['size'],'original_mode':r['mode'],'original_uid':r['uid'],'original_gid':r['gid'],'original_mtime_ns':r['mtime_ns'],'witness':str(dest),'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'source_index':r['source_index'],'source_index_sha256':r['source_index_sha256'],'original_allocated_bytes':r['allocated_bytes'],'witness_allocated_bytes':dest.stat().st_blocks*512,'free_after_bytes':free(),'net_free_delta_bytes':free()-beforefree}
 progress.append(result);write('progress.json',progress);write(f'{i+1}-after.json',result);print(json.dumps(result),flush=True)
elif sys.argv[1]=='finish':
 plan=read('plan.json');progress=read('progress.json');assert len(progress)==7
 for r in plan:assert not pathlib.Path(r['path']).exists();verify_gz(pathlib.Path(r['witness']),r)
 after=inventory({r['path'] for r in plan});assert after==read('preserved-before.json'),'noncandidate files changed'
 assert state()==read('state-before.json'),'Git state changed'
 assert protected_physical_pins()==read('protected-physical-pins-before.json')
 write('protected-physical-pins-after.json',protected_physical_pins())
 write('preserved-after.json',after);write('state-after.json',state())
 summary={'state':'complete','witness_count':7,'all_original_bytes_preserved':True,'all_nonmigrated_files_unchanged':len(after),'allocated_recovered_bytes':sum(x['original_allocated_bytes']-x['witness_allocated_bytes'] for x in progress),'net_free_recovered_bytes':free()-read('free-before.json')['bytes'],'free_bytes':free(),'logical_artifact_mapping':'progress.json','restoration':'python3 restore.py ORIGINAL_PATH; refuses overwrite; verifies original bytes then applies mode/uid/gid/mtime; inode/ctime historical only'}
 write('summary.json',summary);print(json.dumps(summary),flush=True)
