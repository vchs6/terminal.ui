"""Restore a version-qualified failed-f89 artifact or its older BIN alias.
Usage: python3 restore-logical.py ORIGINAL_ARTIFACT_OR_OLD_BIN_PATH
Never overwrites any existing destination. For an old BIN alias, first restores
its retained artifacts file from this receipt's gzip, then invokes the immutable
older BIN-copy restore helper. Requires room for both decompressed copies.
"""
import pathlib,json,sys,os,hashlib,subprocess
O=pathlib.Path(__file__).resolve().parent;assert len(sys.argv)==2
requested=sys.argv[1];rows=json.loads((O/'progress.json').read_text());witnesses={r['logical_original_path']:r for r in rows}
oldroot=pathlib.Path('/workspace/work/validation/ended-134-development-intermediates-20261114');oldmap=oldroot/'duplicate-alias-map.json'
assert hashlib.sha256(oldmap.read_bytes()).hexdigest()=='502f0e7ccc9b8864d895f588bff3d489982827775289c72ba809157176354889'
aliases={r['original']:r for r in json.loads(oldmap.read_text())}
if requested in witnesses:
 subprocess.run([sys.executable,str(O/'restore.py'),requested],check=True)
else:
 assert requested in aliases,'unknown artifact or old BIN alias'
 r=aliases[requested];retained=pathlib.Path(r['retained']);assert str(retained) in witnesses
 w=witnesses[str(retained)];assert(w['original_sha256'],w['original_bytes'])==(r['original_sha256'],r['original_bytes'])
 assert not os.path.lexists(requested),'BIN already exists; refusing overwrite'
 need=r['original_bytes']+1048576
 if not os.path.lexists(retained):need+=w['original_bytes']+1048576
 st=os.statvfs(retained.parent);assert st.f_bavail*st.f_frsize>need,'not enough room for transitive restoration'
 if not os.path.lexists(retained):subprocess.run([sys.executable,str(O/'restore.py'),str(retained)],check=True)
 assert retained.is_file() and retained.resolve()==retained and retained.stat().st_size==r['original_bytes']
 with retained.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['original_sha256'],'retained path now contains another version; refusing overwrite'
 subprocess.run([sys.executable,str(oldroot/'restore-duplicate.py'),requested],check=True)
