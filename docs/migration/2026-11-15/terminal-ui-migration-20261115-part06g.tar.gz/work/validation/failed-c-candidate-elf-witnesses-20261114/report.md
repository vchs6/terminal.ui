Losslessly migrated exactly four sole ELF artifact payloads of failed source candidate f89d3726b76441e144ac501a5cba5a84549db6c8 from sealed index1813e0de8b5a3387fb6bb7a5fd9fda1c8abc4fa18274206dd32d38a003769477. CJP was excluded and remains physical. The candidate's source-QA FAIL disposition is unchanged; no acceptance or new execution result is claimed.

All 76,930,240 original bytes remain recoverable from 22,237,942 deterministic gzip bytes (mtime0, no filename). Original indexed SHA/length, regular-file metadata and no holders were verified; each witness was fully decompressed and compared to both the index and still-present sole original before unlink. All four payloads passed a second full decompression check at completion. Actual allocated recovery:54,685,696B (52.15 MiB). Free reached149,880,832B after the final unlink; completion free98,267,136B (93.71 MiB) after concurrent counterexample compilation allocated about52MB. Net free change from the prepared-state baseline was2,994,176B and includes that unrelated build.

All530 other Cproducer files stayed exact, including original index/report/source/raw/config/native/CJP, previous immutable resource receipt/alias map/helper, and source f89 commit/tree bytes. Main107ef32c HEAD/tree/config remained unchanged; unrelated worker refs were outside the guard. Source-QA proof and new counterexample/C/D workspaces were outside mutation scope and untouched. No huge witness was published.

progress.json maps each version-qualified original artifact path to its gzip SHA/bytes and original payload SHA/bytes/mode/uid/gid/mtime. Original paths are now absent; source index and previous alias receipt remain immutable historical logical references. Inode/ctime are historical only. The earlier three BIN aliases require TRANSITIVE restoration: first restore the retained artifacts file from this new gzip witness, then use the immutable old BIN-copy helper. transitive-restoration-map.json gives both exact commands and supersedes only earlier physical-presence status, not bytes or proof.

Safe convenience restoration, with enough room for one artifact or both transitive copies:

```sh
python3 /workspace/work/validation/failed-c-candidate-elf-witnesses-20261114/restore-logical.py ORIGINAL_ARTIFACT_OR_OLD_BIN_PATH
```

The helper restores the retained artifact first when needed, verifies the original-version SHA/bytes, then invokes the old exclusive BIN-copy helper. It refuses existing/different-version destinations and never overwrites later fixed artifacts. Direct artifact restoration is also available through restore.py. Witnesses remain intact; original mode/uid/gid/mtime are restored.

Fresh process proof had no exe/fd holders or unexpected denials; only six previously documented unrelated container services were excluded (644 zombies skipped). No other runtime, compiler/cache/native, source or Git history was removed or rewritten.
