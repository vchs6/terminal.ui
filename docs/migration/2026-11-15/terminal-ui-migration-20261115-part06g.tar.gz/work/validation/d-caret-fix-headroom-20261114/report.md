Completed only the approved scope:62 unindexed ended caret-counterexample compiler files (paired package .a/.cjo plus explicitly allowed consumer BIN CJO), and lossless gzip migration of exactly two earlier D test ELF pins c00cfc55/4a208bbc. No other root/runtime was touched.

Actual allocation recovery61,042,688B (58.21 MiB):32,845,824B compiler objects plus28,196,864B ELF representation savings. Free at sealing:159,559,680B (152.17 MiB), meeting150MiB.

All39,682,232 original executable bytes remain in11,482,258 deterministic gzip bytes (mtime0, no filename). Full decompression SHA/length matched immutable source-index payloads and still-present originals before unlink; both witnesses were verified again at completion. Original bytes/length also matched prior immutable scoped audit ledgers. ELF paths are now logical historical references resolved by elf-witness/progress.json; original indices/reports/source/raw remain unchanged. Metadata records mode/uid/gid/mtime; inode/ctime are historical only.

Current caret counterexample ELF87d412509c79a12e86ff67bc26f73b113bda2755950f157efafe526faa5cc2f6 remains physical/exact, along with86 scoped retained files/17 key pins/index10bdab56/source df679c58/producte1244b21. All796 other files in the two older D roles remained exact. Source Git/product objects and configuration were guarded; main HEAD/tree were intentionally excluded for permitted documentation edits. Dproducer current executables/CJP/source/compiler cache, earlier proof/gzip maps, native/SDK/cache and other trees were preserved by disjoint scope. No broad old-role audit or extra scan occurred; no test result changed. Process checks found no holders/unexpected denial; six documented unrelated services excluded (669 zombies skipped).

Restore an earlier D ELF safely with room for one original:

```sh
python3 /workspace/work/validation/d-caret-fix-headroom-20261114/elf-witness/restore.py ORIGINAL_ABSOLUTE_PATH
```

The helper verifies gzip/original SHA+bytes, refuses existing destinations, restores mode/uid/gid/mtime and atomically publishes without overwrite. Witnesses remain intact. Compiler objects are rebuildable via the recorded normal CJPM consumer with preserved source/config/lock/SDK1.2/native inputs; audit hashes are not retention pins.
