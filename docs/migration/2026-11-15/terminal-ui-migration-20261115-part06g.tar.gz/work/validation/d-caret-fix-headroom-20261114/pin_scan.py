import pathlib,os,json,re
HEX=re.compile(r'^[0-9a-f]{64}$')
def scan(role,candidates):
 role=pathlib.Path(role);wanted={str(p) for p in candidates};holds=[];checked=[]
 def resolve(path,manifest):
  p=pathlib.Path(path)
  if p.is_absolute():return [str(p)]
  return [str(base/p) for base in (role,role/'source',role/'product',manifest.parent)]
 def inspect(value,manifest):
  if isinstance(value,dict):
   if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str) and HEX.match(value['sha256']):
    for path in resolve(value['path'],manifest):
     if path in wanted:holds.append({'path':path,'sha256':value['sha256'],'manifest':str(manifest)})
   for k,v in value.items():
    if isinstance(k,str) and isinstance(v,str) and HEX.match(v):
     for path in resolve(k,manifest):
      if path in wanted:holds.append({'path':path,'sha256':v,'manifest':str(manifest)})
    inspect(v,manifest)
  elif isinstance(value,list):
   for x in value:inspect(x,manifest)
 for d,ds,fs in os.walk(role,followlinks=False):
  ds[:]=[n for n in ds if n not in ('.git','target','node_modules','cache','.agents','.codex')]
  for name in fs:
   if not name.endswith('.json'):continue
   p=pathlib.Path(d)/name
   if p.is_symlink():continue
   try:v=json.loads(p.read_text())
   except (UnicodeError,ValueError,OSError):continue
   checked.append(str(p));inspect(v,p)
 return {'role':str(role),'json_manifests_checked':len(checked),'holds':holds,'scope':'all parseable local JSON evidence/manifests outside generated targets/Git/cache; absolute and role/source/product/manifest-relative SHA bindings'}
