"""Restore one original ELF without overwriting any existing pathname.
Usage: python3 restore.py /absolute/original/path
Requires enough free storage for the decompressed original.
"""
import pathlib,json,sys,os,gzip,hashlib,tempfile
O=pathlib.Path(__file__).resolve().parent
assert len(sys.argv)==2,'pass exactly one original absolute pathname'
rows=json.loads((O/'progress.json').read_text());matches=[x for x in rows if x['logical_original_path']==sys.argv[1]];assert len(matches)==1,'unknown original pathname'
r=matches[0];dest=pathlib.Path(r['logical_original_path']);w=pathlib.Path(r['witness'])
assert dest.is_absolute() and dest.parent.resolve()==dest.parent and not os.path.lexists(dest),'destination exists or parent contains symlink'
with w.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['witness_sha256']
s=os.statvfs(dest.parent);assert s.f_bavail*s.f_frsize>r['original_bytes']+1048576,'not enough free storage'
fd,tmp=tempfile.mkstemp(prefix='.unit-a-restore-',dir=dest.parent)
try:
 h=hashlib.sha256();n=0
 with os.fdopen(fd,'wb') as out,gzip.open(w,'rb') as src:
  while b:=src.read(1048576):out.write(b);h.update(b);n+=len(b)
  out.flush();os.fsync(out.fileno())
 assert n==r['original_bytes'] and h.hexdigest()==r['original_sha256'],'decompression proof mismatch'
 st=os.stat(tmp)
 if (st.st_uid,st.st_gid)!=(r['original_uid'],r['original_gid']):os.chown(tmp,r['original_uid'],r['original_gid'])
 os.chmod(tmp,r['original_mode']);os.utime(tmp,ns=(r['original_mtime_ns'],r['original_mtime_ns']))
 # link is an atomic exclusive publish and refuses any existing destination.
 os.link(tmp,dest,follow_symlinks=False)
 print('Restored exact original bytes/mode/uid/gid/mtime:',dest)
finally:
 if os.path.lexists(tmp):os.unlink(tmp)
