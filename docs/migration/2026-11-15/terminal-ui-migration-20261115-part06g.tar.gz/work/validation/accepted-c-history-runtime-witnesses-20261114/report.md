Losslessly migrated exactly the three authorized ended runtime payloads: final T133 pre-C9e4780, counterexampleII0c6c20, and independent136 executor c1c22609. Exact SHA/length came from sealed source indices; T133 size19,513,904B was additionally resolved through the prior immutable ecaaed47 current-runtime audit binding because its original index records currentSHA without size. The olda8 preorganization runtime is explicitly unretained metadata; it was not looked up or rebuilt. Historical test dispositions are unchanged; this operation makes no new test/acceptance claim.

All 58,798,312 original bytes remain in 16,959,533 deterministic gzip bytes (mtime0, no filename). Each sole original was regular and quiescent; gzip full-decompression SHA/length matched both indexed binding and still-present original before nonfollowing unlink. All three passed a second full decompression proof at completion. Actual allocated recovery:41,844,736B (39.91 MiB). Free at sealing:164,683,776B (157.05 MiB), meeting150MiB. No other runtime/object scope was used.

All1158 other files in the three exact roles stayed unchanged, including source/raw/config/native/CJPs/reports/indices and historical version metadata. Current producer index1de4e2c1... and its three current R2 ELFs/CJP were freshly hash/size checked and remain physical. Selected source Git objects and main d519 HEAD/tree/config stayed unchanged; unrelated worker refs were not frozen. Other witnesses, old alias maps, Cpublication/version maps and unrelated worktrees were outside mutation scope. No broad old30k snapshot or workspace scan occurred.

Cpublication committed and verified physical pins before this migration. That status remains a valid historical publication-time record; original sealed C files/indices/reports were not rewritten. post-publication-storage-map.json explicitly distinguishes the three now-absent local paths backed by exact gzip payloads from the still-physical current producer runtimes/CJPs. progress.json retains original SHA/bytes/mode/uid/gid/mtime and compressed SHA/bytes; original inode/ctime are historical only.

Safe restoration, with space for one decompressed original:

```sh
python3 /workspace/work/validation/accepted-c-history-runtime-witnesses-20261114/restore.py ORIGINAL_ABSOLUTE_PATH
```

The helper verifies gzip/original SHA+bytes, refuses existing destinations, restores mode/uid/gid/mtime, and publishes atomically without overwrite. Witnesses remain intact. No huge gzip was published. Fresh process proofs found no task holders or unexpected denials, with only six documented unrelated runtime service exclusions (657 zombies skipped).
