Completed exactly two authorized operations. (A) Removed61 unindexed paired Cangjie compiler .a/.cjo files under the ended D138 incremental_composition consumer only. CJOF/ar package provenance, local pin-reference checks and fresh task exe/fd proof passed;32,735,232B actually reclaimed. Current DRED ELFc00cfc55ac4ed4fc8e369c095fb1e7e1185f2f6a432a91de319e692b3e9b2d41 remains physical and exact, as do108 fresh scoped retained files/37 current key pin paths, source20-file metadata/raw evidence/config/lock/index/native. D139 own active source and all other D roots were untouched and not guarded.

(B) Preserved exactly the three sole CproducerR2 ELF artifact entries from immutable index1de4e2c1ff2a2c5c7d6e70055bad19e7c64fcbf7d8badea6174a0a57e1d1475e as deterministic gzip witnesses (mtime0, no filename). All57,941,928 original bytes remain in16,747,216 gzip bytes. Every indexed SHA/length and regular-file metadata matched, no holders existed, and full gzip decompression equaled the original before unlink and again at completion. Reclaimed41,201,664B allocation. All565 other producer files, CJPs/sourceee/raw/index/proof/config/native and prior gzip/alias receipts remain exact. No Ccompiler objects were removed by this job.

Total actual allocation recovery73,936,896B (70.51 MiB). Fresh actual free at sealing:177,053,696B (168.85 MiB), meeting the NEW150MiB D139 build threshold; the older238a pre-Dbuild receipt is not used as current GO evidence.

Main e151 HEAD/tree/config and exact selected source0ab/ee Git objects remained unchanged; unrelated worker refs were not frozen. Cpublication had already committed and verified physical pins before migration. Its old sealed files/status maps remain valid historical publication-time records; C-post-publication-storage-map.json explicitly records these three now-absent logical aliases backed by verified gzip payloads. Earlier presence claims in receipt238a remain historical and are superseded only for current physical representation. No huge gzip was published.

Restore one exact C R2 executable safely, with space for its original:

```sh
python3 /workspace/work/validation/d-local-composition-headroom-20261114/elf-witness/restore.py ORIGINAL_ABSOLUTE_R2_BIN_PATH
```

The helper verifies gzip/original SHA+bytes, refuses existing destinations, restores mode/uid/gid/mtime and publishes atomically without overwrite. Witnesses remain intact; inode/ctime are historical only. Dcompiler representations can be rebuilt through ordinary CJPM using preserved source/config/locks/SDK1.2/native inputs. Compiler hashes are audit metadata, not retention pins. Other source/raw/native/witness/QA files were preserved by the exact disjoint operator scope, not a fresh broad archive/workspace hash. Process proofs had no holders or unexpected denials; only the six documented unrelated runtime services were excluded (660 zombies skipped). No product/test code or test results changed.
