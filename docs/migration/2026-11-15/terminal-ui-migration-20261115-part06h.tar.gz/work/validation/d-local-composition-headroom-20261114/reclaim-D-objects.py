import pathlib,json,os,stat,hashlib,subprocess,sys
from pin_scan import scan
O=pathlib.Path(__file__).parent;M=pathlib.Path('/workspace/work/terminal.ui');ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};PKGS={'cjtui','ansies','unicode','unicodewidth','cangjie_toml','bitarray'}
SPECS=[('incremental-composition-tests','index.json','042e3789e165c2e0e542b49227cc90fad539f110c4fc3790d1080c61601d8222')]
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def read(n):return json.loads((O/n).read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
def indices():
 out=[]
 for role,name,expected in SPECS:
  p=pathlib.Path('/workspace/work')/role/name;assert sha(p)==expected;out.append((p,json.loads(p.read_text())))
 return out

def keypins():
 ix,v=indices()[0];P=ix.parent;rows=[{'path':str(ix),'sha256':sha(ix),'bytes':ix.stat().st_size}]
 for key in ('binary','dependency_lock'):
  r=v[key];rows.append({**r,'path':str(P/r['path'])})
 assert v['binary']['sha256']=='c00cfc55ac4ed4fc8e369c095fb1e7e1185f2f6a432a91de319e692b3e9b2d41'
 for r in v['source_files']:rows.append({**r,'path':str(P/'source'/r['path'])})
 for r in v['evidence']:
  if isinstance(r,dict) and 'path' in r and 'sha256' in r:rows.append({**r,'path':str(P/r['path'])})
 for r in rows:
  p=pathlib.Path(r['path']);assert p.is_file() and sha(p)==r['sha256'],str(p)
  if 'bytes' in r:assert p.stat().st_size==r['bytes']
 return {r['path']:r for r in rows}

def state():
 out={'main':{'head':git(M,'rev-parse','HEAD'),'tree':git(M,'rev-parse','HEAD^{tree}'),'config_sha256':sha(M/'.git/config')}};assert out['main']['head']=='e151f204a69925edde33fe91d968942c8f9d7aa2'
 for role,_,_ in SPECS:
  S=pathlib.Path('/workspace/work')/role/'source';assert git(S,'rev-parse','--show-toplevel')==str(S)
  out[role]={'head':git(S,'rev-parse','HEAD'),'tree':git(S,'rev-parse','HEAD^{tree}'),'status':git(S,'status','--porcelain=v1','--untracked-files=all'),'diff_sha256':hashlib.sha256(git(S,'diff','--binary','HEAD').encode()).hexdigest(),'manifest_sha256':sha(S/'cjpm.toml')}
 rev='ee84e7ac7a35bb6481a17ecb91f1ec07804b672a';b=subprocess.check_output(['git','cat-file','commit',rev],cwd=M,env=ENV);out['exact_product_git']={'commit':rev,'commit_bytes_sha256':hashlib.sha256(b).hexdigest(),'tree':git(M,'rev-parse',rev+'^{tree}')};return out

def retained(exclude,pins):
 paths={pathlib.Path(p) for p in pins}
 for role,_,_ in SPECS:
  S=pathlib.Path('/workspace/work')/role/'source';R=S/'tests/incremental_composition/target/release'
  for d,ds,fs in os.walk(R,followlinks=False):
   for n in fs:paths.add(pathlib.Path(d)/n)
  for name in ('cjpm.toml','cjpm.lock','cangjie-repo.toml','build.cj','native/build.sh'):
   p=S/name
   if p.is_file():paths.add(p)
 out=[]
 for p in sorted(paths):
  if str(p) in exclude:continue
  s=p.lstat();r={'path':str(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
  if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
  elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
  else:raise AssertionError('unexpected special '+str(p))
  out.append(r)
 return out
if sys.argv[1]=='prepare':
 pins=keypins();rows=[]
 for role,_,_ in SPECS:
  P=pathlib.Path('/workspace/work')/role;R=P/'source/tests/incremental_composition/target/release';assert R.is_dir() and R.resolve()==R
  files=[];archives=[]
  for pkg in sorted(PKGS):
   d=R/pkg
   if not d.is_dir():continue
   assert d.resolve()==d and (R/'.build-logs'/pkg).is_dir()
   for p in sorted(d.iterdir()):
    if p.suffix not in ('.a','.cjo'):continue
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p
    if p.suffix=='.a':
     pair=p.with_name(p.name[3:-2]+'.cjo');assert pair.is_file() and not pair.is_symlink()
     with pair.open('rb') as f:assert f.read(8)[4:8]==b'CJOF'
     members=subprocess.check_output(['ar','t',str(p)]).decode().splitlines();assert members and all(m.startswith(pkg) and m.endswith('.o') and '/' not in m for m in members);archives.append({'path':str(p),'paired_cjo':str(pair),'members':members})
    else:
     with p.open('rb') as f:assert f.read(8)[4:8]==b'CJOF'
    files.append({'path':str(p),'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512})
  pin=scan(P,[pathlib.Path(f['path']) for f in files]);assert not pin['holds'];assert all(f['path'] not in pins for f in files)
  rows.append({'role':str(P),'release_root':str(R),'files':files,'provenance':archives,'proof_pin_scan':pin})
 exclude={f['path'] for r in rows for f in r['files']};write('candidate-plan.json',rows);write('source-main-before.json',state());write('current-key-pins-before.json',pins);write('scoped-retained-before.json',retained(exclude,pins));print(json.dumps({'candidate_files':len(exclude),'allocated_bytes':sum(f['allocated_bytes'] for r in rows for f in r['files']),'free_bytes':free()}),flush=True)
elif sys.argv[1]=='reclaim':
 rows=read('candidate-plan.json');assert state()==read('source-main-before.json') and keypins()==read('current-key-pins-before.json')
 proc=read('process-final.json');assert not proc['busy'] and not proc['unexpected_denied'];results=[]
 for i,r in enumerate(rows):
  assert not scan(r['role'],[pathlib.Path(f['path']) for f in r['files']])['holds'];before=free()
  for f in r['files']:
   p=pathlib.Path(f['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)==(f['device'],f['inode'],f['bytes'],f['mtime_ns'],f['nlink']) and sha(p)==f['sha256']
   fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
   try:
    t=os.stat(p.name,dir_fd=fd,follow_symlinks=False);assert(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino);os.unlink(p.name,dir_fd=fd)
   finally:os.close(fd)
  v={'release_root':r['release_root'],'removed_files':len(r['files']),'allocated_recovered_bytes':sum(f['allocated_bytes'] for f in r['files']),'observed_free_recovery_bytes':free()-before,'free_bytes':free()};results.append(v);write('root-'+str(i+1)+'-after.json',v);print(json.dumps(v),flush=True)
 pins=keypins();exclude={f['path'] for r in rows for f in r['files']};after=retained(exclude,pins);assert after==read('scoped-retained-before.json') and pins==read('current-key-pins-before.json') and state()==read('source-main-before.json')
 write('source-main-after.json',state());write('current-key-pins-after.json',pins);write('scoped-retained-after.json',after)
 s={'state':'complete','removed_files':len(exclude),'allocated_recovered_bytes':sum(v['allocated_recovered_bytes'] for v in results),'observed_free_recovery_at_unlink_bytes':sum(v['observed_free_recovery_bytes'] for v in results),'free_bytes':free(),'fresh_scoped_retained_files_unchanged':len(after),'current_key_pin_paths_unchanged':len(pins),'source_product_Git_and_main_e151_unchanged':True,'D_RED_ELF_physical_and_raw_source_config_native_preserved':True,'old_gzs_and_other_files_preserved_by_disjoint_scope':True,'otherDtrees_and_C_current_producer_not_mutated':True,'no_broad_role_or_workspace_filehash':True};write('summary.json',s);print(json.dumps(s),flush=True)
