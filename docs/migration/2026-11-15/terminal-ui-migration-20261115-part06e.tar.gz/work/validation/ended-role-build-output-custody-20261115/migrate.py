import pathlib,os,stat,json,hashlib,gzip,subprocess,time,sys
O=pathlib.Path(__file__).parent;W=O/'witness';W.mkdir(exist_ok=True);M=pathlib.Path('/workspace/work/terminal.ui');G=json.loads(pathlib.Path('/workspace/work/validation/e146-runtime-headroom-20261114/guards.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,d):
 p=O/n
 with p.open('w') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
ROLES=('keyboard-execution','theme-implementation','editing-implementation','runtime-execution')
ROOTS=[pathlib.Path('/workspace/work')/r/'source/tests' for r in ROLES]
CURRENT=('input-timeout-implementation','input-timeout-execution','queued-input-regression','rendering-benchmark-implementation','rendering-benchmark-tests')
HISTORY={}
for base in [pathlib.Path('/workspace/work/validation/input-fix-build-headroom-20261114'),pathlib.Path('/workspace/work/validation/input-fix-build-headroom-20261114/round1')]:
 for n in ['index.json','report.md','plan.json','progress.json','summary.json']:HISTORY[str(base/n)]=sha(base/n)
assert HISTORY['/workspace/work/validation/input-fix-build-headroom-20261114/index.json']=='93ed60afd84ff197fe4b9e5c70d58be5bd299fec7b15e1224797033c34b06cef'
assert HISTORY['/workspace/work/validation/input-fix-build-headroom-20261114/round1/index.json']=='2199f48e487478f317807071d54fc5fb070d0048eb057493ad74fbdd4541d70e'
STATE_BASE=None
def state():
 global STATE_BASE
 for name,h in HISTORY.items():assert sha(pathlib.Path(name))==h
 projects=[M]+[pathlib.Path('/workspace/work')/r/'source' for r in (*ROLES,*CURRENT)]
 gitstates={};pins={};elfstats={}
 for root in projects:
  if (root/'.git').exists():
   gitstates[str(root)]={'HEAD':git(root,'rev-parse','HEAD'),'tree':git(root,'rev-parse','HEAD^{tree}'),'tracked_status':git(root,'status','--porcelain=v1','--untracked-files=no'),'tracked_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root,env=ENV)).hexdigest()}
  for p in [root/'cjpm.toml',root/'cjpm.lock',root/'cangjie-repo.toml']:
   if p.is_file():pins[str(p)]=sha(p)
 pins[str(M/'.git/config')]=sha(M/'.git/config')
 for name in G['unchanged_source_CJP_config_pins']:
  p=pathlib.Path(name)
  if p.is_file():pins[name]=sha(p)
 for role in CURRENT:
  top=pathlib.Path('/workspace/work')/role
  for p in [*top.glob('*.json'),*top.glob('*.sha256'),*top.glob('actual/*.json')]:
   if p.is_file():pins[str(p)]=sha(p)
  if role in ('input-timeout-implementation','input-timeout-execution','queued-input-regression'):
   for p in (top/'source').glob('**/target/release/bin/*'):
    if p.is_file() and not p.is_symlink():
     z=p.stat();elfstats[str(p)]={k:getattr(z,k) for k in ['st_dev','st_ino','st_size','st_mode','st_mtime_ns','st_ctime_ns']}
 for name in G['critical_ELF_stat_snapshot']:
  p=pathlib.Path(name);z=p.stat();elfstats[name]={k:getattr(z,k) for k in ['st_dev','st_ino','st_size','st_mode','st_mtime_ns','st_ctime_ns']}
 r={'git':gitstates,'source_config_CJP_current_indices':pins,'critical_current_ELF_stats':elfstats,'old16_receipt_history':HISTORY}
 if STATE_BASE is None:STATE_BASE=r
 else:assert r==STATE_BASE,'source/current pins changed during exclusive custody window'
 return r
EXCLUDE=('rendering-benchmark','queued-input-regression','vte-protocol-counterexample','native-output-operator-fix','/validation/sdk/','/cache/','/stdx','process_cost','queued_input','diagnostic','input-timeout-implementation','input-timeout-execution')
def rec(p):
 s=p.lstat();assert any(p.is_relative_to(root) for root in ROOTS);assert p.suffix!='.so';assert not any(x in str(p) for x in EXCLUDE);assert p.resolve()==p and '/target/release/bin/' in str(p) and stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and s.st_mode&0o111
 with p.open('rb') as f:h=f.read(64)
 assert h[:4]==b'\x7fELF' and h[4] in (1,2) and h[5] in (1,2) and int.from_bytes(h[16:18],'little' if h[5]==1 else 'big') in (2,3)
 return {'path':str(p),'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'sha256':sha(p),'ELF_header_hex':h.hex()}
def process(rows):
 paths={r['path'] for r in rows};inos={(r['device'],r['inode']) for r in rows};busy=[];limits=[];seen=[]
 expected={122:'runuser',151:'rootlesskit',161:'exe',186:'slirp4netns',195:'dockerd',214:'containerd'}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   status=(p/'status').read_text();comm=(p/'comm').read_text().strip();uids=next(x for x in status.splitlines() if x.startswith('Uid:')).split()[1:]
   if '\nState:\tZ' in status:continue
   if int(p.name) in expected:
    assert comm==expected[int(p.name)]
    limits.append({'pid':int(p.name),'comm':comm,'uids':uids,'status':next(x for x in status.splitlines() if x.startswith('State:')),'limit':'prior approved unrelated container runtime supervisor; inaccessible FDs not asserted unused'});continue
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if comm in ('cjc','cjpm','clang','clang++','ld','ld.lld','lld','llc','opt','cjnative','llvm-ar'):busy.append({'pid':int(p.name),'compiler':comm})
   maps=(p/'maps').read_text()
   if any(x in maps for x in paths):busy.append({'pid':int(p.name),'reason':'candidate mapped'})
   for t in [p/'cwd',p/'root',p/'exe']+list((p/'fd').iterdir()):
    try:
     v=os.readlink(t);s=t.stat()
     if v.removesuffix(' (deleted)') in paths or (s.st_dev,s.st_ino) in inos:busy.append({'entry':str(t),'target':v})
    except FileNotFoundError:continue
    except PermissionError:raise AssertionError('unknown process visibility denied '+str(t))
   seen.append({'pid':int(p.name),'comm':comm})
  except FileNotFoundError:continue
  except PermissionError:raise AssertionError('unknown potentially relevant process visibility denied '+str(p))
 r={'busy':busy,'finite_visibility_limits':limits,'readable_live_processes':seen,'epoch':time.time(),'scope':'no candidate FD/inode/maps among readable processes; known compilers absent; explicit unrelated runtime supervisor limits, no global all-proc claim'};write('process-latest.json',r);assert not busy,r;return r

def discover():
 candidates=[];catalogs=[];bindings={}
 # Bounded existing catalogs only; optional matches never reinterpret or rewrite historical evidence.
 for role in ROLES:
  top=pathlib.Path('/workspace/work')/role
  catalogs += list(top.glob('*index*.json'))+list(top.glob('*manifest*.json'))
 V=pathlib.Path('/workspace/work/validation')
 catalogs += [p for p in [V/'ended-unit-b-consumer-intermediates-20261114/sealed-pins-after.json',V/'ended-older-role-compiler-intermediates-20261114/keyboard-execution-pin-scan.json',V/'d-validation-durable-headroom-20261114/editing-implementation-pin-scan.json',V/'round1-cache-fix-headroom-20261114/old-roots-noncandidates-after.json.gz'] if p.is_file()]
 def visit(v,src,ih):
  if isinstance(v,dict):
   name=v.get('path');h=v.get('sha256')
   if isinstance(name,str) and isinstance(h,str):
    if not name.startswith('/') and src.parent.name in ROLES:name=str(src.parent/name)
    bindings.setdefault(name,[]).append({'path':str(src),'sha256':ih,'expected_original_sha256':h,'expected_bytes':v.get('bytes',v.get('size'))})
   for x in v.values():visit(x,src,ih)
  elif isinstance(v,list):
   for x in v:visit(x,src,ih)
 for q in sorted(set(catalogs)):
  b=q.read_bytes();ih=hashlib.sha256(b).hexdigest()
  if q.suffix=='.gz':b=gzip.decompress(b)
  try:visit(json.loads(b),q,ih)
  except json.JSONDecodeError:continue
 for root in ROOTS:
  for bindir in root.glob('**/target/release/bin'):
   if bindir.resolve()!=bindir:continue
   for p in bindir.iterdir():
    z=p.lstat()
    if stat.S_ISREG(z.st_mode) and z.st_uid==1000 and z.st_mode&0o111 and p.suffix!='.so':
     with p.open('rb') as f:h=f.read(20)
     if h[:4]==b'\x7fELF' and h[5] in (1,2) and int.from_bytes(h[16:18],'little' if h[5]==1 else 'big') in (2,3):candidates.append((z.st_blocks*512,p))
 plan=[];skips=[]
 for _,p in sorted(candidates,key=lambda x:x[0],reverse=True):
  if len(plan)>=20:break
  try:
   r=rec(p);consumer=p.parents[3];manifest=consumer/'cjpm.toml';assert manifest.is_file() and manifest.resolve()==manifest
   root=next(x for x in ROOTS if p.is_relative_to(x));project=root.parent;assert (project/'.git').exists()
   sourcefiles=[manifest,*consumer.glob('*.lock'),*consumer.glob('cangjie-repo.toml'),*consumer.glob('src/*.cj')]
   matches=bindings.get(str(p),[])
   r.update(source_indices=[{'path':x['path'],'sha256':x['sha256']} for x in matches],historical_index_matches=[{**x,'actual_SHA_matches':x['expected_original_sha256']==r['sha256'],'actual_length_matches':x['expected_bytes'] in (None,r['bytes'])} for x in matches],historical_identity_claim='current bytes custody only; no inferred historical compiler-source identity or retroactive index acceptance',source_build_proof={'consumer_cwd':str(consumer),'normal_build_command':'source /workspace/work/validation/sdk/cangjie/envsetup.sh; cjpm build','project':str(project),'project_HEAD':git(project,'rev-parse','HEAD'),'source_build_inputs':{str(q):sha(q) for q in sourcefiles if q.is_file()},'ownership':'regular UID1000 executable ELF in normal compiler output location under one of four explicitly ended role test roots; adjacent CJPM manifest and Git project verified; exact bytes retained regardless of unavailable/mismatching historical tag'},witness=str(W/(r['sha256']+'.gz')));plan.append(r)
  except AssertionError as e:skips.append({'path':str(p),'reason':str(e) or 'ownership/header/source manifest guard failed'})
 write('discovery.json',{'bounded_roots':[str(x) for x in ROOTS],'candidate_count':len(candidates),'selected_count':len(plan),'skipped':skips,'existing_catalogs':[str(x) for x in sorted(set(catalogs))]})
 return plan

def verify_gz(p,r):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 assert n==r['bytes'] and h.hexdigest()==r['sha256'];return {'decompressed_sha256':h.hexdigest(),'decompressed_bytes':n}
def compress(src,p):
 with p.open('xb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as z,src.open('rb') as inp:
   while b:=inp.read(1048576):z.write(b)
  f.flush();os.fsync(f.fileno())
 os.chmod(p,0o444)
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)

def sourceguard(rows):
 for r in rows:
  for ix in r['source_indices']:assert sha(pathlib.Path(ix['path']))==ix['sha256']
  for name,h in r['source_build_proof']['source_build_inputs'].items():assert sha(pathlib.Path(name))==h,name
try:
 assert not (O/'progress.json').exists(),'no implicit repeated migration'
 before=free();write('free-before.json',{'bytes':before});write('state-before.json',state());plan=discover();write('plan.json',plan);assert plan and len(plan)<=20;sourceguard(plan);process(plan);progress=[];write('progress.json',progress)
 prior_roots=[pathlib.Path('/workspace/work/validation')/n for n in ['ended-runtime-witnesses-20261114','ended-more-runtime-witnesses-20261114','accepted-c-history-runtime-witnesses-20261114','accepted-d-runtime-headroom-20261114','accepted-unit-b-elf-witnesses-20261114','reviewed-e124-runtime-witnesses-20261114','input-fix-build-headroom-20261114/witness','input-fix-build-headroom-20261114/round1/witness']]
 for r in plan:
  if free()>=320*1048576:break
  src=pathlib.Path(r['path']);assert rec(src)=={k:v for k,v in r.items() if k not in ('source_indices','source_build_proof','witness','historical_index_matches','historical_identity_claim')};sourceguard([r]);state();pr=process([r]);dest=pathlib.Path(r['witness']);reuse=next((q for root in prior_roots if (q:=root/(r['sha256']+'.gz')).is_file()),None)
  i=len(progress)+1;write(str(i)+'-before.json',{'original':r,'free_bytes':free(),'process':pr})
  if reuse:dest=reuse
  else:
   assert free()>10*1048576,'reserve too small for witness';compress(src,dest)
  verification=verify_gz(dest,r);compressed_sha=sha(dest);compressed_bytes=dest.stat().st_size;assert compressed_bytes<r['allocated_bytes']
  assert rec(src)=={k:v for k,v in r.items() if k not in ('source_indices','source_build_proof','witness','historical_index_matches','historical_identity_claim')};sourceguard([r]);state();pr=process([r]);assert sha(dest)==compressed_sha
  record={**r,'witness':str(dest),'witness_uri':str(dest),'witness_sha256':compressed_sha,'witness_bytes':compressed_bytes,'witness_allocated_bytes':dest.stat().st_blocks*512,'witness_reused':bool(reuse),'verified_before_unlink':verification,'preunlink_process':pr}
  write(str(i)+'-verified-before-unlink.json',record)
  fd=os.open(src.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
  try:
   s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_uid,s.st_nlink)==(r['device'],r['inode'],r['bytes'],r['mtime_ns'],r['ctime_ns'],r['uid'],1)
   os.unlink(src.name,dir_fd=fd);os.fsync(fd)
  finally:os.close(fd)
  record.update(physical_original_present=False,unlinked_epoch=time.time(),free_after_bytes=free());progress.append(record);write('progress.json',progress);print(json.dumps({'migrated':len(progress),'free_bytes':free(),'path':str(src)}),flush=True)
 sourceguard(plan);write('state-after.json',state())
 for r in progress:assert not pathlib.Path(r['path']).exists();assert sha(pathlib.Path(r['witness']))==r['witness_sha256']
 after=free();summary={'state':'complete','migrated_files':len(progress),'original_bytes':sum(r['bytes'] for r in progress),'witness_bytes':sum(r['witness_bytes'] for r in progress),'allocated_reclaimed_bytes':sum(r['allocated_bytes']-(0 if r['witness_reused'] else r['witness_allocated_bytes']) for r in progress),'free_before_bytes':before,'free_after_bytes':after,'net_free_delta_bytes':after-before,'minimum230MiB_met':after>=230*1048576,'goal320MiB_met':after>=320*1048576,'minimum_shortfall_bytes':max(0,230*1048576-after),'goal_shortfall_bytes':max(0,320*1048576-after),'all_original_bytes_preserved':True,'logical_alias_map':'progress.json','original_indices_immutable':True,'root_verification_required_before_compiler':True};write('summary.json',summary)
 (O/'report.md').write_text('Lossless custody migration complete: '+str(len(progress))+' old ended test/public-consumer ELFs.\nOriginal bytes '+str(summary['original_bytes'])+'; gzip bytes '+str(summary['witness_bytes'])+'; net allocated reclaim '+str(summary['allocated_reclaimed_bytes'])+' bytes.\nFree before '+str(before)+' bytes; after '+str(after)+' bytes.\n230 MiB minimum met: '+str(summary['minimum230MiB_met'])+'; shortfall '+str(summary['minimum_shortfall_bytes'])+' bytes.\n320 MiB goal met: '+str(summary['goal320MiB_met'])+'; shortfall '+str(summary['goal_shortfall_bytes'])+' bytes; 20-file cap respected.\nEach witness fsynced and fully decompressed to exact original SHA256/length before unlink.\nFresh original SHA/header/stat/UID/source recipe/index checks and readable-process FD/maps checks preceded unlink.\nFinite unrelated runtime-supervisor visibility limits recorded; no claim of global process visibility.\nOriginal indices remain immutable logical aliases; progress.json gives exact witness maps and restore.py restores original bytes.\nSource/config/current CJP/critical benchmark ELF/provenance guards unchanged; excluded artifacts untouched.\nRoot must verify custody receipt before cold compiler starts.\n')
 files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name!='index.json'];write('index.json',{'schema':'ended-role-build-output-lossless-custody-v1','state':'complete','summary':summary,'files':files});print(json.dumps({'receipt_sha256':sha(O/'index.json'),**summary}),flush=True)
except Exception as e:
 write('failure.json',{'type':type(e).__name__,'error':str(e),'free_bytes':free()});raise
