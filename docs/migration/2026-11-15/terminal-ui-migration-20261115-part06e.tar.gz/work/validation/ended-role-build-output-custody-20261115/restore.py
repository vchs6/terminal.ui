"""Usage: python3 restore.py EXACT_ORIGINAL_PATH. Refuses overwrite; restores verified original bytes, not a rebuild."""
import pathlib,json,hashlib,gzip,os,sys
O=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit(__doc__)
rows=json.loads((O/'progress.json').read_text());r=next(x for x in rows if x['path']==sys.argv[1]);dest=pathlib.Path(r['path']);src=pathlib.Path(r['witness'])
assert dest.parent.resolve()==dest.parent and not dest.exists() and not dest.is_symlink()
with src.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['witness_sha256']
assert src.stat().st_size==r['witness_bytes'];tmp=dest.with_name(dest.name+'.custody-restore-part');h=hashlib.sha256();n=0
with tmp.open('xb') as out,gzip.open(src,'rb') as inp:
 while b:=inp.read(1048576):out.write(b);h.update(b);n+=len(b)
 out.flush();os.fsync(out.fileno())
assert n==r['bytes'] and h.hexdigest()==r['sha256'],'restore bytes mismatch: keep temporary file for investigation'
os.chmod(tmp,r['mode']);s=tmp.stat()
if (s.st_uid,s.st_gid)!=(r['uid'],r['gid']):os.chown(tmp,r['uid'],r['gid'])
os.utime(tmp,ns=(r['mtime_ns'],r['mtime_ns']));os.link(tmp,dest,follow_symlinks=False);tmp.unlink();fd=os.open(dest.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print('Restored exact original bytes: '+str(dest)+' SHA256 '+r['sha256'])
