# Bounded reversible custody of ended role compiler executables

ResourceSol/medium, no subagents. Current~100MiB; F1twoordinaryprojectsPASS, third+3affectedruntimefixtures need90–110MiB extra before64MiBguard. Sourceoldrole usage freshlymeasured: keyboard-execution/source/tests576.5MiB, theme-implementation/source/tests234.7MiB,editing-implementation/source/tests249.5MiB,runtime-execution/source/tests219.8MiB. Fullmetadata /workspace/work/validation/space-detail-20261115.txt,worktreeheadsworktrees-20261115.txt. Previous16positivepinwitnesses preserved/notrewritten.

ROOTEXPLICITBOUNDEDMIGRATIONGO: ONLYregularUID1000 ELF EXECUTABLES (not*.so) inside target/release/bin ofthesefourEXACTENDEDtestroots:
/workspace/work/keyboard-execution/source/tests
/workspace/work/theme-implementation/source/tests
/workspace/work/editing-implementation/source/tests
/workspace/work/runtime-execution/source/tests
Useboundedpathglobundertheserootsonly, notglobalfilesystem/ELFscan. Max20additionalphysicalfiles, stopfree320MiB; minneededfree230MiB, reportshortfallnocreep. Current/newcodeCJP/bench/validator/input-timeout-execution/input-timeout-implementation/queued-regression/diagnostic andSDK/cache/hosttools/AOTplugins excluded. NOsource/docs/raw/PNG/CJP/config/native.a/.cjo/.o deletions orGitworktreechanges inthisscope. Knownoldconsumer test executables withnormalcompilerlocation/adjacentmanifest+GitHEAD/recipe arepositiveownership.

NEWclarification topreviousstrictprior-pinrule: PriorindexedexpectedSHA isNOTmandatoryforTHISreversiblehousekeeping onknownendedcompileroutput; computeactualoriginalSHA/header/metadata and preserveEXACTbytes. Recordexistingindexmatcheswhereavailable; ifnone explicitly state currentbytescustodyonly/no inferredhistoricalcompiler-sourceidentity/no retroactively accepting anyoldindex. Existingmismatchedhistoricalindexnotrewritten orsilentlysatisfiedbynewSHA. ThisdoesNOTadmitunrelatedunknownuserbinaries; fourownedendedroots+ELF+normaltarget/manifestprovenance+noactivity mandatory. Anyownershipambiguityskip.

SequentialgzipONLY: hashactualoriginal/header/length/mode/stat/ownership/sourceprojectmanifest+Gitref, newwitnessfsync, decompressfullSAMEoriginalSHA/bytes BEFOREexactoriginalunlink; recheckstat/sha+holdersoncebeforeunlink. FilebyteNEVERdiscarded/rebuilt. Originalsourceindicesimmutablelogicalaliases; receiptrestoremap+helper records originalpath/bytes/hash/mode/gzipURI/compressedsha, criticalcurrentpins/source/config/CJPbeforeafter. Reuseexistingexactgzipwitnessifavailabletoavoiddoublecopy. No activecompiler/currenttargetruntime/holder underanyreadableproc; allknownownedbenchmark/tracer/GUIjobsquiescent. Recordunreadableunrelatedsupervisorfinitevisibilitylimitno falseglobalFDclaim. Standardtoolreadonly/proc escalationallowed(no sudo/auth).

No newcompiles/tests/probes/GUI/helperproductruns. Rootcurrentexecutorholdingcoldsteps; resourcehash/gzipwindowexclusive. Do NOTgrowarchivecopiesunbounded: onecandidateatime thenverify/unlink, max20. Saveindex/report<=20lines/actualfree/netreclaim/members/restore/sourceguards. Rootwillverify thenreleasecompiler; no userconfirmationneededforauthorizedreversiblearchive.
