Lossless custody migration complete: 18 old ended test/public-consumer ELFs.
Original bytes 325898280; gzip bytes 94272632; net allocated reclaim 231636992 bytes.
Free before 106016768 bytes; after 337031168 bytes.
230 MiB minimum met: True; shortfall 0 bytes.
320 MiB goal met: True; shortfall 0 bytes; 20-file cap respected.
Each witness fsynced and fully decompressed to exact original SHA256/length before unlink.
Fresh original SHA/header/stat/UID/source recipe/index checks and readable-process FD/maps checks preceded unlink.
Finite unrelated runtime-supervisor visibility limits recorded; no claim of global process visibility.
Original indices remain immutable logical aliases; progress.json gives exact witness maps and restore.py restores original bytes.
Source/config/current CJP/critical benchmark ELF/provenance guards unchanged; excluded artifacts untouched.
Root must verify custody receipt before cold compiler starts.
