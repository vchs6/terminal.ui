# 06s 暂扣项独立复核

**可纳入迁移 2,683 项，共 14,510,856 字节。继续暂扣 0 项，Git 或其他归档覆盖 0 项。** 原队列 2,683 条路径按 SHA-256 去重后对应 639 份内容，共 7,812,604 字节。每条路径均单独核验原件大小、普通文件类型、权限、纳秒修改时间及实际字节摘要。

| 原规则 | 路径数 | 不同摘要数 | 不同内容字节 |
|---|---:|---:|---:|
| credential_or_environment_pattern | 162 | 126 | 5,611,628 |
| binary_or_unexpected_control_bytes | 47 | 13 | 3,226 |
| unclassified_ansi_escape | 2,341 | 458 | 2,089,041 |
| invalid_utf8 | 133 | 42 | 108,709 |

## 终端控制和编码

- 2,309 条 ANSI 会话或延迟输出逐段匹配 CSI、会话测试的固定控制帧，或这些帧的截断前缀。含标题或剪贴板的 OSC 与 screen/tmux 的 DCS 包装均按字节同原始测试向量及生成边界输入比对。普通文本中不允许遗留未识别控制。另有 57 条键盘输入包含方向、编辑、终端状态应答或有限的控制组合，其中包括原规则归入二进制的输入。
- 128 条非法 UTF-8 会话记录归于标题、帧写入故障或延迟不完整字符测试。核对了截断位置和固定字符的多字节前缀。另有 5 条键盘路径映射到同一份两字节输入，为不完整中文字符起始字节紧接 ASCII 退出输入。
- 12 条 VTE 原生网格内容记录含 NUL 与测试场景文字。9 条构建日志和 1 条汇总日志含 NUL 填充及构建或验证诊断。去除 NUL 后检查了剩余控制和文本。未渲染或执行原始控制流。

会话参考为 editing-implementation/source/tests/session_extensions 下的 fixtures/wire.json、cases.mjs、oracle.mjs 及 src/vectors.cj。输出恢复测试的固定标题与剪贴板文本在 output-recovery-tests/source/tests/output_recovery/src/live.cj 第 35–36 行。

## 敏感规则

- 67 项是终端属性快照、启动或退出状态记录。嵌套的 env 对象只列显示、临时目录、区域设置或 GUI 测试所选字段。1 项构建 manifest 的环境字段为工具链、脚本、包管理器及路径摘要等。生成器的显式字段选择可见 composition-application-execution/tools/host-supervisor.py、glyph-execution/tools/record-host.py 和 glyph-review/source/docs/reviews/R18/vte-grid-recon/scripts/run.py 第 60 行。原队列内没有已经标记为实际环境转储的来源。
- 28 项 SSH 客户端、服务端或有效配置的命中逐一比对，均为 OpenSSH 安全密钥算法名称。密钥路径交接记录只保存文件位置。未打开所引用的密钥或认证目录。
- 29 项是依赖文件路径及摘要，22 项为包锁及验证清单，10 项为审核范围说明。另有 2 项解析器记号类别、1 项引用路径及 1 项手册占位示例。对候选另行筛查了常见服务凭据、私钥、JWT、认证头、连接口令与凭据赋值。

## 完整清单

完整 queue.json 保留全部路径和精确整数，位于 /dev/shm/terminal-ui-migration-20261115-host/part06t-hold-review/queue.json。大小 1,237,244 字节，SHA-256 为 fb9af15992bb53c1db34014647b59f11fc0bb552f3db0c56fca670123ccde27c。工作区同名文件是定位指针和汇总。RAM 记录独立于工作区指针，须在相应 RAM 目录仍存在时读取。
