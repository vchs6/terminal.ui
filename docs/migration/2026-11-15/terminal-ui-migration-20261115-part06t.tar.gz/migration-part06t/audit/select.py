
from pathlib import Path,PurePosixPath
import collections,hashlib,json,os,re,sqlite3
root=Path('/workspace/work')
ram=Path('/dev/shm/terminal-ui-migration-20261115-host/part06t-audit')
def bind(path):
 raw=path.read_bytes()
 return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},raw
census_info,census_raw=bind(ram/'metadata-census.json')
topics_info,topic_raw=bind(ram/'metadata-binary-topics.json')
census=json.loads(census_raw)
rows=json.loads(topic_raw)
roots_ppm={'cursor-capability-recon','session-lifecycle-vt-execution','linux-vt-product-probe','glyph-execution','linux-console-hosts'}
reviews={'rich-text-review','glyph-advance-review','glyph-review','input-preflight','rich-text-execution','session-extension-review','session-preflight','theme-preflight','widgets-preflight'}
root_tar={'editing-execution','interaction-execution','keyboard-execution','overlay-execution','viewport-execution','widgets-composite-execution','widgets-small-execution'}
plain_evidence={'cursor-capability-recon','glyph-execution','linux-vt-product-probe'}
cjp_roots={'glyph-implementation','keyboard-execution','layout-execution','overlay-execution','rich-text-implementation','runtime-execution','widgets-composite-implementation','widgets-composite-review'}
provenance={
 'cursor-capability-recon/report.md':['QMP','56张原PPM'],
 'session-lifecycle-vt-execution/report.md':['53 original QMP PPMs','post-test tar export compression'],
 'linux-vt-product-probe/report.md':['QMP','720×400'],
 'glyph-execution/report.md':['QMP','720×400'],
 'linux-console-hosts/report.md':['screendump','720×400'],
 'first-slice-native/report.md':['Invalid local UCD archive'],
 'first-slice-native/bad-ucd.log':['bad-ucd.zip: FAILED'],
}
document_bindings={}
for rel,needles in provenance.items():
 document_bindings[rel],raw=bind(root/rel)
 text=raw.decode('utf-8')
 assert all(s in text for s in needles),rel
ucd_build,raw=bind(root/'terminal.ui/native/build.sh')
archive_sha=re.search(rb'^ucd_sha=([0-9a-f]{64})$',raw,re.M)
assert archive_sha and b'https://www.unicode.org/Public/17.0.0/ucd/UCD.zip' in raw
known_ucd=archive_sha.group(1).decode('ascii')
data=[]
ucd_rows=[]
invalid_zip=None
for r in rows:
 path=PurePosixPath(r['path']); first=path.parts[0]; name=path.name
 kind=r['family']
 anchor=None
 if kind=='.ppm':
  if first in roots_ppm and 'raw' in path.parts:
   anchor='direct_documented_project_qmp'
  elif first in reviews and ('/docs/reviews/R11/host-readiness/raw/reuse-smoke/' in '/'+r['path'] or (path.parent.as_posix().endswith('/docs/reviews/R11/host-readiness/raw') and name in {'vt-ready.ppm','vt-input.ppm','vt-exit.ppm'})):
   anchor='documented_qmp_reuse_smoke_copy_family'
 elif kind=='.tar' and 'raw' in path.parts:
  if name=='guest-evidence.tar' and first in root_tar:
   anchor='project_kernel_vt_guest_evidence'
  elif name=='evidence.tar' and first in plain_evidence:
   anchor='project_kernel_vt_evidence'
 elif kind=='.tar.gz' and first=='session-lifecycle-vt-execution' and 'raw' in path.parts and name in {'guest-evidence.tar.gz','guest-export.tar.gz'}:
  anchor='documented_session_lifecycle_vt_guest_export'
 elif kind=='.cjp' and first in cjp_roots and name.startswith('cjtui') and '.cjtui-build' not in path.parts:
  anchor='named_project_cjtui_source_bundle'
 elif kind=='.zip' and name=='UCD-17.0.0.zip':
  ucd_rows.append(r)
 elif r['path']=='first-slice-native/bad-ucd.zip':
  invalid_zip=r
 if anchor:
  data.append({**r,'provenance':anchor})
if invalid_zip:
 data.append({**invalid_zip,'provenance':'recorded_project_invalid_ucd_input_test'})
data.sort(key=lambda r:r['path'])
assert len(data)==len({r['path'] for r in data})==318
assert sum(r['bytes'] for r in data)==265946035
assert len(ucd_rows)==40 and sum(r['bytes'] for r in ucd_rows)==364075080
assert invalid_zip and invalid_zip['bytes']==16
lookups=[r['path'] for r in data+ucd_rows]+[invalid_zip['path']]
hashes={}
metadata_labels={}
with sqlite3.connect('file:'+census['catalog']+'?mode=ro&immutable=1',uri=True) as connection:
 connection.execute('PRAGMA query_only=ON')
 query='SELECT path,kind,source_index,sha256 FROM evidence WHERE path IN ('+','.join('?' for _ in lookups)+')'
 for p,kind,index,sha in connection.execute(query,lookups):
  if not isinstance(sha,str) or not re.fullmatch('[0-9a-f]{64}',sha):
   continue
  hashes.setdefault(p,set()).add(sha)
  if p in {r['path'] for r in ucd_rows} and sha==known_ucd:
   metadata_labels.setdefault(p,[]).append({'kind':kind,'source_index':index})
for r in data:
 r['catalog_digest_claims']=sorted(hashes.get(r['path'],[]))
by_kind={}
for r in data:
 group=by_kind.setdefault(r['family'],{'files':0,'bytes':0,'max_file_bytes':0})
 group['files']+=1
 group['bytes']+=r['bytes']
 group['max_file_bytes']=max(group['max_file_bytes'],r['bytes'])
code_info,_=bind(Path(__file__))
first_invalid=invalid_zip['path']
selection={
 'schema':'terminal-ui-migration-part06t-narrow-binary-selection-v1',
 'source_census':census_info,'source_topics':topics_info,'census_script':bind(ram/'census.py')[0],'selection_script':code_info,
 'inherited_06s_selector':census['base_06s_selector'],'inherited_06r_selector':census['base_06r_selector'],
 'inherited_06r_policy_clarification':census['base_06r_clarification'],
 'path_rule':census['metadata_rule'],'allowed_catalog_categories':census['catalog_categories'],
 'selected_files':len(data),'selected_bytes':sum(r['bytes'] for r in data),'selected_by_kind':by_kind,
 'source_byte_cap':800_000_000,'decoded_gzip_byte_cap':1_073_741_824,
 'provenance_reports':document_bindings,
 'invalid_zip':{'path':first_invalid,'bytes':invalid_zip['bytes'],'static_intent_reported':True,
   'known_catalog_digest_claims':sorted(hashes.get(first_invalid,[])),
   'disposition':'tiny release candidate; historic report proves invalid-input intent. Validate current bytes without claiming identity with the historical execution.'},
 'ucd_distribution_metadata':{'release':'Unicode 17.0.0 UCD.zip','canonical_url':'https://www.unicode.org/Public/17.0.0/ucd/UCD.zip',
   'pinned_distribution_sha256':known_ucd,'project_build_source':ucd_build,'candidate_paths':len(ucd_rows),
   'candidate_directory_bytes':sum(r['bytes'] for r in ucd_rows),'candidate_common_file_size':9101877,
   'catalog_records_with_the_pinned_sha256':metadata_labels,'source_bodies_opened':0,
   'disposition':'metadata-only canonical archive and possible alias inputs; actual same-byte restoration still requires evidence for each alias path.'}}
with (ram/'metadata-selected.json').open('x',encoding='utf-8') as f:
 json.dump({'selection':selection,'rows':data},f,ensure_ascii=False,separators=(',',':'));f.write('\n')
print(json.dumps({'counts':by_kind,'ucd_existing_pinned_digest_paths':len(metadata_labels),
 'invalid_zip_existing_digest_claims':len(hashes.get(first_invalid,[])),'selection_script':code_info},ensure_ascii=False))

