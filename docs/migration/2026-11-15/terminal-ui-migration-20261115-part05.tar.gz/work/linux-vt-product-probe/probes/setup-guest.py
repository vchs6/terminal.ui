import pathlib,os,shutil,subprocess,re
b=pathlib.Path(__file__).resolve().parents[1];r=b/'guest-root'
for n in ['sh','mount','setsid','poweroff','sleep','echo','cat','stty','uname','base64','tar','mkdir']:
 p=r/'bin'/n
 if not p.exists():p.symlink_to('busybox')
for app,src in [('minimal','examples/minimal'),('colors','examples/colors'),('fixture','tests/terminals/fixture')]:
 p=b/'source'/src/'target/release/bin/main'
 if p.exists():shutil.copy2(p,r/'apps'/app)
env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/validation/sdk/cangjie/runtime/lib/linux_x86_64_cjnative'
manifest=[]
def cp(src,dest):
 target=r/str(dest).lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);manifest.append((str(src),str(dest)))
for binary in [r/'apps/minimal',pathlib.Path('/usr/bin/strace'),pathlib.Path('/lib/x86_64-linux-gnu/libtinfo.so.6')]:
 out=subprocess.check_output(['ldd',str(binary)],env=env,text=True)
 for line in out.splitlines():
  m=re.search(r'(?:=> )?(/\S+)',line)
  if m:
   p=pathlib.Path(m.group(1));dest='/lib/x86_64-linux-gnu/'+p.name if '/workspace/' in str(p) else str(p);cp(p,dest)
cp('/usr/bin/strace','/usr/bin/strace');cp('/lib/x86_64-linux-gnu/libtinfo.so.6','/lib/x86_64-linux-gnu/libtinfo.so.6');cp('/usr/share/terminfo/l/linux','/usr/share/terminfo/l/linux')
(b/'raw/guest-copy-manifest.txt').write_text('\n'.join(a+' -> '+c for a,c in manifest)+'\n')
