#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){void *h=dlmopen(LM_ID_NEWLM,"libtinfo.so.6",RTLD_NOW|RTLD_LOCAL);printf("DLMOPEN term=%s LD_LIBRARY_PATH=%s handle=%p error=%s\n",getenv("TERM"),getenv("LD_LIBRARY_PATH"),h,h?"none":dlerror());if(!h)return 1;int(*setupterm)(char*,int,int*)=dlsym(h,"setupterm");int e=0;int rc=setupterm("linux",1,&e);printf("SETUPTERM rc=%d error=%d\n",rc,e);return rc;}
