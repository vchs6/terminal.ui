# 固定 Cangjie 产品在真实 Linux VT 的独立风险验证

2026-11-10 15:51–16:05 UTC；独立工作目录 `/workspace/work/linux-vt-product-probe`。指定角色 Sol/high；实际 serving model 无可核验来源，不声称已核验。仅开发环境 smoke / 能力风险探查，不是完整 Linux 验收，不关闭 TASK-041。

## 结论

固定提交 `6a7b240bfc89bb054b11306f257ebed519a26b5f` 的公开 `examples/minimal`、`examples/colors` 和既有 `tests/terminals/fixture`，均以正常 SDK/CJPM 构建，未改产品、示例或正式测试源码。产品确实可在 QEMU 虚拟硬件上的 Linux **内核 VT `/dev/tty1`** 启动、显示基础界面、接收真实 PS/2 键盘路径输入，正常 q 和键盘 Ctrl-C 均退出 0、恢复 termios。

这解决了“当前只有 C readiness probe，Cangjie 产品还没有在真实 VT 启动”的证据缺口。**Unicode 字形显示没有通过**：当前默认 VGA 字体对中文、组合重音及 emoji 显示方块；`/dev/vcsu1` 保存相关 Unicode 码点不能作为像素显示支持。彩色/属性按实际 `linux` terminfo 降级可工作，但并不提供所有风格的原样显示。

新增只读 `GIO_UNIMAP` 调查证实：guest root 与实际 tty1 所有者 uid 1000 均能读取当前 303 项 BMP Unicode→fontpos 映射，可为后续已知缺字策略提供设备证据。该 API 没有非 BMP 表达能力，也不证明组合字形/emoji shaping。此次不实现 fallback、不读/加载/修改字体位图。

## 固定环境、源码和构建

- 独立 `git clone --no-hardlinks` 主仓后 detached checkout 上述提交。`raw/source-commit.txt`、`raw/source-status.txt` 保留状态。tracked diff 为空；仅正常 CJPM 生成的两个示例 `cjpm.lock` 未跟踪。
- SDK `/workspace/work/validation/sdk/cangjie/envsetup.sh`，实际 `cjc 1.2.0 (cjnative)`、`cjpm 1.2.0`，目标 `x86_64-unknown-linux-gnu`；见 `raw/sdk-version.txt`。
- 只读 seed `/workspace/work/validation/replay-dependencies/cache` 复制到本目录 `cache`；本地 `cangjie-repo.toml` 指向本目录 cache 和既有 registry `http://127.0.0.1:18973`，没有修改共享 cache/registry 服务。
- `CJTUI_UCD_ARCHIVE=/workspace/work/validation/replay-dependencies/UCD-17.0.0.zip`；原生依赖按固定源 `native/build.sh` 构建，未复制现成第三方构建结果替代源码编译。产品依赖为固定源清单中的 ansies 1.3.113 / unicode 0.1.0 / unicodewidth 0.1.113。
- 分别在 `source/examples/minimal`、`source/examples/colors`、`source/tests/terminals/fixture` 执行 `cjpm build`，均结束 0，日志 `raw/build-{minimal,colors,fixture}.log` 保留 `cjpm build success`。既有 fixture 的 `CJTUI_TERMINAL_VALIDATE=1` 主机逻辑检查也输出 PASS，见 `raw/fixture-host-logical-check.txt`；该检查不作为 VT 显示验收。
- 复用 readiness 环境的 QEMU **10.0.13**、官方 Debian **Linux 6.12.107+deb13-amd64**，`-accel tcg -cpu max -machine pc -m 512 -smp 1`、SeaBIOS、VGA、PS/2，`nomodeset vga=normal`，实际 **80×25**。CPU max 是本轮选择，未对默认 QEMU CPU 做指令集失败归因。
- `-display none` 仅关闭 host GUI frontend，VGA 设备仍实际存在。QMP `query-kvm` 记录 present/enabled 均 false。产品不依赖 GUI，QEMU/截图/strace/Python 只属此开发测试环境。
- guest 自有 `apps` 固定二进制、`/lib64` loader、`/lib/x86_64-linux-gnu` 全部 ldd 依赖、libtinfo 与 `linux` terminfo、静态 BusyBox；guest 没有 host bind mount/共享目录或 host SDK 路径依赖。完整 guest 文件及 hash 见 `raw/guest-file-manifest.json`，复制来源见 `raw/guest-copy-manifest.txt`。
- 不使用 sudo、host 包安装、他人的 VM 或服务；所有 VM 均是本目录新启动并已正常关机，host QEMU 退出 0。没有把 SDK 二进制放入产品 Git。

## 最终产品执行证据

三个最终场景都使用保留的 `packages/vt-initramfs-product-final.cpio.gz` 的相同字节；不是先前纯 C readiness 场景。`VT_GETSTATE=0 active=1`、`KDGKBTYPE=0 type=2` 和 `TIOCGWINSZ=0 80x25` 均来自实际 tty1 ioctl。BusyBox init 安装 devtmpfs/proc/sysfs，以 setsid 和真实控制 tty1 启动外部 supervisor；supervisor 不改产品输入模式或输出，使用 strace 旁观真实进程。

| 原始证据目录 | 未修改程序 | QMP 键盘事件 | 产品真实 read(0) 字节 | 退出 / 恢复 |
|---|---|---|---|---|
| `raw/minimal-final` | examples/minimal | Up、q | `1b 5b 41 71` | 0 / termios_equal=1 |
| `raw/fixture-color` | 原有 cross-terminal fixture | p,c,p,t,p,Up,q | `70 63 70 74 70 1b 5b 41 71` | 0 / termios_equal=1 |
| `raw/colors-color` | examples/colors | c,t,Up,Ctrl+C | `63 74 1b 5b 41 03` | 0 / termios_equal=1 |

Ctrl-C 是 QMP 同时按下 ctrl+c 的 PS/2 路径；产品 raw mode 关闭 ISIG 后读到 `03` 并自行处理取消，不是 host 给进程 kill。方向键读到字节只证明键盘输入到产品的通路；这些界面没有方向导航动作，未声称完整键盘协议验收。

三轮均有：

```text
RESTORE iflag=4500/4500 oflag=5/5 cflag=4bf/4bf lflag=8a3b/8a3b cc_equal=1 termios_equal=1
PRODUCT_EXIT=0 raw_status=0
INIT_CHILD_EXIT=0
```

`raw/final-run-summary.json` 汇总实际终端、动作、输入和恢复。各目录的 `vt-qmp.jsonl` 保留 UTC 时间和 QMP 原文、`vt-serial.log` 保留 kernel/supervisor 原文；`evidence/*.strace` 包含真实 ioctl/read/write。`stdout-raw.ansi` / `stdin-raw.bin` 从 strace 的成功 write(1)/read(0) 原始字节无损提取，保留原 trace 作权威来源。

实际画面是 QMP 原始 `ready.ppm`、`input-*.ppm`、`exit.ppm`（720×400），逐张 lossless PNG 转换。不是 ANSI→image、字体替换、重绘或生成图。每个快照的 `/dev/vcsa1` 4004 字节和 `/dev/vcsu1` 8000 字节同时保留 `.bin`；`.txt` 只是派生阅读视图。串口只运送诊断、kernel grid 和证据归档，不作为 VT 显示/键盘证据。

注：早期 `raw/minimal` 的 supervisor 用未初始化填充字节做 struct memcmp，曾打印 termios_equal=0，但所有有效 flags/cc 已相等；后续仅将测试 supervisor 的 before/after struct 零初始化，最终 minimal-final 已重新验证等于1。早期 minimal 的确切初始 initramfs 未归档，因此最终结论只取已归档最终三轮，不把早期 raw 当作相同 harness 的正式通过证据。

## 能力检测与 guest closure 的真实阻断

初始 guest 已有 ELF interpreter `/lib64/ld-linux-x86-64.so.2`，普通 Cangjie 产品可启动，但 fixture 回报 `Monochrome; colorKnown=false; terminfoKnown=false; reason=terminfo-library-unavailable`。这是保守行为的真实记录，见 `raw/fixture/evidence/capabilities-1.txt`，不能误归产品颜色故障。

只读独立 `dlmopen-check` 精确显示：

```text
DLMOPEN ... handle=(nil) error=ld-linux-x86-64.so.2: cannot open shared object file: No such file or directory
```

`libc.so.6` 的 `DT_NEEDED` 还包含 loader **basename**，libtinfo 的新 dlmopen namespace 需要按库搜索路径再次找到它。向自有 guest `/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2` 复制同字节 loader 后，`DLMOPEN error=none`，`setupterm("linux") rc=0`。未改产品和能力强制配置。保留失败环境 `packages/vt-initramfs-dlmopen-check.cpio.gz`、`raw/dlmopen-initial`，成功产品环境 `packages/vt-initramfs-product-final.cpio.gz`。

最终 fixture 实际诊断：

```text
colorMode=Basic8;colorKnown=true;terminfoKnown=true;
supportsBold=true;supportsDim=true;supportsItalic=false;supportsUnderline=true;
supportsInverse=true;supportsStrikethrough=false;ncv=18;source=terminfo;reason=
```

真实 raw SGR 使用基础 `30–37/41` 等；没有 256/真彩色序列、italic `3m` 或 strike `9m`。fixture RGB(1,128,254) 映射 cyan，红色背景保留；c 切换后前景 red，vcsa 首行属性由 `0x43` 变为 `0x44`；p 标记粗体 `0x07↔0x0f`；t 后为 `0x4c`。ncv18 约束带颜色时的 dim/underline。colors 示例在无颜色文字上可见 SGR `1/2/4/7`，可用属性是终端自身呈现而非全部字体样式承诺。Basic8 下 bright 样例按公开策略降级，暗色 black 文字在黑背景不可见；不能把文字标签名当最终像素色彩。

## 字体、Unicode 和逻辑网格风险

最终 PNG 的中文、emoji 及组合重音为默认 VGA 字体的方块。`vcsu1` 的 Unicode 视图仍包含“中/文/👩/💻/U+0301”，但 `vcsa1` 对应是 fallback glyph，像素截图也缺字。因此当前产品未实现这一路径的自动已知缺字降级；本轮不宣称 Linux VT Unicode/emoji 显示合格。

组合重音还有宽度/游标风险：fixture 第二行在 kernel vcsu grid 的 0-based 列14为 e、列15为 U+0301、列16空格、列17/18为 woman/computer，组合 mark 实际占独立 console cell；不能以框架 grapheme/width 逻辑成功推定 VT shaping/对齐一致。ZWJ 没有作为可见独立字形；没有展示合成 woman-technologist emoji。没有伪造 font 效果、替换 font 或把码点网格转画图。

只读新探针 `probes/font-map.c` 使用实际控制 tty1：

| 条件 | VT_GETSTATE / KDGKBTYPE / KDGETMODE | GIO_UNIMAP |
|---|---|---|
| guest uid/euid/gid=0；tty owner1000 mode0600 | rc0 active1 / rc0 type2 / rc0 KD_TEXT | 容量0返回 rc-1 errno12 ENOMEM、回填303；容量65535返回 rc0/count303 |
| guest uid/euid/gid=1000；同一 tty，owner1000 mode0600 | 同上，均成功 | 同上；返回表与 root 完全同字节 |

仅在该专用 font-map guest 将 `/dev/tty1` 和 `/evidence` 的 owner 设为1000建立非 root 所有者 fixture；随后 helper `setgid(1000);setuid(1000)`。没测无 tty 所有权的任意非 root 用户。没有字体设置或替换。

| 固定样本 | 当前表结果 |
|---|---|
| A U+0041、e U+0065 | fontpos65、101 |
| ─ U+2500、│ U+2502、┌ U+250C | fontpos196、179、218 |
| ╭ U+256D | absent |
| é U+00E9 | fontpos130 |
| e + U+0301 | e 存在，组合 U+0301 absent；映射不能证明组合行为 |
| 中 U+4E2D、文 U+6587、ZWJ U+200D | absent |
| ■ U+25A0 / replacement U+FFFD | 同为 fontpos254，符合截图 fallback 方块 |
| 😀 U+1F600、👩 U+1F469、💻 U+1F4BB | GIO_UNIMAP 的 unsigned-short Unicode 字段无法表达非 BMP；该 API 证据不足，不能判定非 BMP 覆盖 |

原始 `raw/font-map/vt-serial.log` 保留权限、errno、容量、303项全表；`raw/font-map/evidence/unimap-{0,1000}.bin` 是原始4字节 unipair数组，各1212字节且相同 SHA-256 `a0b62239bb3c3894e51dea560a2d4b2a2a9d04c2f4a7aee140e780cfbe28f1c8`。探针只调用 GIO_UNIMAP/VT_GETSTATE/KDGKBTYPE/KDGETMODE 读 ioctl，不调用 PIO_UNIMAP/GIO_FONT/PIO_FONT/KDFONTOP；BMP 映射可提示已知字形缺失，不能证明 glyph 像素质量、复杂簇/零宽 shaping、颜色或终端更新一致性。此为后续能力设计依据，未新增产品 API 或 fallback。

## 复现和制品

工具仅在本目录使用；既有 host 依赖来源、官方 URL、包/内核 SHA 与下载验证边界见 `/workspace/work/linux-console-hosts/report.md` 和其原始 manifest。复现产品最终配置：

```sh
cd /workspace/work/linux-vt-product-probe
VT_RUN_DIR=$PWD/raw/NEW_RUN VT_SCENE=colors \
 VT_INITRD=$PWD/packages/vt-initramfs-product-final.cpio.gz probes/start-vt.sh
# 另一终端，待新 serial log 出现 PRODUCT_STARTED：
VT_RUN_DIR=$PWD/raw/NEW_RUN VT_ACTIONS=c,t,up,ctrl-c python3 probes/control-vt.py
python3 probes/export-evidence.py raw/NEW_RUN
```

fixture 用 `VT_SCENE=fixture` 和 `VT_ACTIONS=p,c,p,t,p,up,q`，minimal 用 `VT_SCENE=minimal` 和 `VT_ACTIONS=up,q`。控制器只通过 QMP 发产品输入，第二串口只向外部 supervisor 请求读取 kernel grid。

当前 `packages/vt-initramfs.cpio.gz` 是新增 font-map probe 的归档环境，`VT_SCENE=fontmap` 可重跑只读调查。`guest-root` 对应该当前归档；历史产品最终环境请使用明确保留的 product-final archive。`probes/pack-guest.py` 按自有 guest-root 打包，不引用 host SDK。

`raw/frozen-artifacts.sha256`、`raw/probe-hashes.sha256`、`raw/guest-file-manifest.json` 和 `raw/SHA256SUMS` 索引制品。关键产品最终 initramfs SHA-256：`4791bae20edf220d60157a9441849443e5d3dfbe803f489bc338ff247aad5448`。三个二进制 hash：minimal `6556b756d2af60c0a58108e2758187a9a3cd0d9c8b89a6a9ba081f251372ad25`；colors `efcfee80c863c8ed3c712737050c8a8291aba82df6708cc9f02c586aeec3709a`；fixture `f75b9e42f8ec25df9e4f00b69cecc259d7f107d3efe23ae1efc2b52c0cb6a996`。

16:05 UTC 最终核对：三个最终产品轮的退出/恢复原文、16张 PPM/PNG RGB像素逐张完全相同、tracked product diff为空、最终initramfs hash一致，350项artifact校验全部通过；见 `raw/checksums-verification.log`。

仍需最终框架固定源后的统一应用/完整 Linux 矩阵验收、实际尺寸变化（本 VT 固定80×25）、完整键盘/焦点/恢复错误路径及字形 fallback 设计与像素复验。本轮证明可启动和有限输入/恢复/能力映射事实，不外推这些未测项。
