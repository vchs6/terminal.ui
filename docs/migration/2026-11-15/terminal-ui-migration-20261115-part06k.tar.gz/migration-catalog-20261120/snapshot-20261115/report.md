# 全局逐文件 metadata 对账

安全快照已完成：**1,077,771项 / 28,003,322,666逻辑字节**，另列148,533目录。264仓库记录（262原盘点工作树、1 bare provenance、1后建派生验证repo）；14个迁移包manifest；131份baseline历史metadata索引；baseline包含180个tar.gz。

| 类别（互斥） | 文件/节点数 | 逻辑字节 |
|---|---:|---:|
| 未找到恢复证明 | 285,209 | 20,887,199,341 |
| 首包导出HEAD + 当前Git clean | 488,792 | 3,435,511,879 |
| .git/bare元数据，需单列refs/bundle恢复边界 | 206,345 | 1,164,250,722 |
| 迁移包manifest有member；当前原件SHA待核 | 10,375 | 963,081,882 |
| 旧索引仅原路径hash引用，未闭环 | 10,261 | 934,857,392 |
| 旧索引有exact member/copy；当前原件SHA待核 | 62,422 | 353,182,240 |
| 当前clean blob与已导出a5 baseline相同 | 5,978 | 235,671,813 |
| 7固定shallow上游的tracked clean文件 | 8,389 | 29,567,397 |

所有包/旧archive SHA均来自既有metadata。**没有重新hash原件；size相同不等于SHA相同。** 历史exact locator表示索引声明可恢复member/copy；本轮没打开archive payload验证。Curated lineage与仅hash引用均不能证明原报告/原测试已迁移。Git证据绑定当前status、HEAD/index blob、首包精确refs或a5 baseline；不是全文件SHA扫描。

源体类型：1,063,711常规文件、151 symlink、13,907 FIFO、2 socket。未读symlink目标，未打开FIFO/socket。Git只恢复内容blob与Git模式，完整原mode/type保留在catalog。

`.git`的1.164GB单列，不把整个repo/objectstore说成已迁完。首包refs/bundle覆盖可达历史；未承诺unreachable objects、hooks/config/reflog或本地认证状态。原认证目录一律过滤。

仅历史hash引用仍未闭环：**10,261文件 / 934,857,392B**。另有1428个curated原路径lineage记录尚无闭环（可能与其他标签重叠）。具体样例及证据来源见summary与数据库evidence表。

未闭环curated lineage原路径示例：

- `glyph-acceptance/README.md`
- `glyph-acceptance/acceptance-matrix.json`
- `glyph-acceptance/acceptance-matrix.md`
- `glyph-acceptance/finalize.py`
- `glyph-acceptance/findings.json`
- `glyph-acceptance/pending-matrix.json`

SDK/cache本轮**0文件获得完整可重取免迁证明**。目录名、旧索引excluded声明、只有SHA均不足；仍需来源URL/版本/包hash/恢复命令/所需native闭包。七个声明固定上游有准确HEAD pins和clean tracked证据，catalog未读remote配置；重取来源locator仍需外部现成证明。

- `CangjieSkills` @ `277f2e1234ca5217496966887243c679653887a8`
- `cangjie-rules` @ `40bacab1dafc7c5710a9b14c5c5c86898feed63c`
- `r7-acceptance/upstreams/ansies` @ `dac6fe9ab1407cd533153e98b091cda0d8610713`
- `r7-acceptance/upstreams/bitarray` @ `c6c5a40a5ed2a51199cb3a8b9702c01a8da1e694`
- `r7-acceptance/upstreams/unicode` @ `a12b0d8009e3111cc3f98563026a5b2dbfaf149f`
- `r7-acceptance/upstreams/unicodewidth` @ `b3d9c8c8684f3a093a2e9d9d306ec36a3eb67cb5`
- `terminal.ui/.dev-tools/superpowers` @ `bb92a77741419a4ab5f06e711a283343f1ada0c3`

逻辑custody单列：5,490逻辑原件，0逻辑路径当前存在，5,490有当前物理gzip，128有迁移包物理member、5,362有历史exact locator（两者可重叠）；尚需map/receipt、physical SHA与包member联核。20份已交付progress/restore-map补齐128条映射，含part04、06a-i。被gzip有意替代的ELF不按丢失计。migration-package-verify/helper已标实际Git root及派生验证仓库，不充作独有原成果；首包两个已删派生暂存copy按migration-staging-cleanup receipt解释，不是源原件缺失。

优先候选队列（未读内容）：**7,801安全小报告/测试原件、31,227,880B**，每件≤200KB，均未找到exact member闭环。先做有限SHA及来源复核，再决定保留原字节；不能直接把全部候选打成无限分卷。较宽小文件队列另有36,830项（含待核旧exact locator）。

- `theme-showcase-archive/report.md` — 597B；unresolved
- `validation/e146-runtime-headroom-20261114/report.md` — 667B；unresolved
- `validation/e146-runtime-headroom-20261114/round2/report.md` — 698B；unresolved
- `validation/e146-runtime-headroom-20261114/round4/report.md` — 817B；unresolved
- `projection-execution-archive/report.md` — 841B；unresolved
- `validation/e146-runtime-headroom-20261114/round3/report.md` — 842B；unresolved
- `keyboard-tests/integration-profile-fix/report.md` — 887B；unresolved
- `validation/ended-129-bundle-intermediates-20261114/report.md` — 907B；unresolved
- `widgets-small-tests/typing-fix/report.md` — 941B；unresolved
- `widgets-small-tests/initial-theme-fix/report.md` — 968B；unresolved
- `review-archive-execution/cli-v1/report.md` — 1098B；unresolved
- `linux-final-construction-review/round1/report.md` — 1106B；unresolved

大数据全部位于host RAM：

- `catalog.sqlite3`：完整files/directories/repositories/evidence/inputs/logical_custody表；路径以/workspace/work为根。
- `unresolved.jsonl`：全部未闭环物理节点；`source-sha-obligations.jsonl`：包/旧exact locator的当前SHA义务。
- `logical-custody.jsonl`：逻辑缺失与物理gzip/member区分；`priority-original-candidates.jsonl`：本轮优先队列；`small-safe-candidates.jsonl`：宽候选。

RAM目录：`/dev/shm/terminal-ui-migration-20261115-host/global-catalog`。常规sandbox namespace看不到该RAM，读取需require_escalated。

安全/完整性检查：SQLite quick_check=ok；各互斥分类数与类型数一致；禁区路径记录0；Git错误0；scan错误0；未识别Git root 0。禁区在stat/递归前剪枝；.ssh/private/auth/credentials/.env*/.aws/.netrc/.npmrc及既定ssh-server路径等不读、不记录值。无源体内容读取、无全盘SHA、无构建/VM/网络/上传/子代理。

这份catalog收敛了逐文件metadata边界与具体待办；没有宣称整迁移验收完成，也没有用目录汇总推算剩余分卷。

旧inventory 342个顶层入口逐项对账：当前catalog无缺失入口；当前安全快照顶层入口361个（包括后建迁移审计/验证目录，排除本报告目录）。
