#!/usr/bin/env python3
import sqlite3,subprocess,json,gzip,os
ROOT='/workspace/work';MAIN=ROOT+'/terminal.ui';BASE='a5aed68544d7681a522400d2f061e5cf64532ee4';RAM='/dev/shm/terminal-ui-migration-20261115-host/global-catalog';c=sqlite3.connect(RAM+'/catalog.sqlite3');c.execute('PRAGMA journal_mode=OFF');c.execute('PRAGMA synchronous=OFF')
def git(root,*args):return subprocess.check_output(['git','-c','core.fsmonitor=false','-C',root,*args],env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','LC_ALL':'C'})
def record_original(p,idx):
 if isinstance(p,str) and p.startswith(ROOT+'/'):
  rel=p[len(ROOT)+1:]
  # Existing safe physical paths only: never introduce a restricted original path from metadata.
  if c.execute('SELECT 1 FROM files WHERE path=?',(rel,)).fetchone():c.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?)',(rel,'historical_lineage_only',idx,None,None,None,None,None,json.dumps({'original_path_lineage':'curated copy never proves original bytes'})))
def walk(d,idx,context=''):
 if isinstance(d,list):
  for r in d:walk(r,idx,context)
 elif isinstance(d,dict):
  if d.get('curated_source'):
   record_original(d.get('original_external_source',d.get('original_source')),idx)
  if 'source_copy_map' in context or 'lineage' in context:
   for k in d:
    if k.startswith(ROOT+'/'):record_original(k,idx)
  for k,v in d.items():
   if isinstance(v,(list,dict)):walk(v,idx,context+'/'+k)
for idx, in c.execute("SELECT path FROM inputs WHERE source=? AND path NOT LIKE '%.jsonl.gz'",('git:'+BASE,)).fetchall():
 raw=git(MAIN,'show',BASE+':'+idx);raw=gzip.decompress(raw) if idx.endswith('.gz') else raw
 walk(json.loads(raw),idx)
# A restore-verification derivative created after baseline inventory. Tag its actual Git root.
p='migration-package-verify/helper';rp=ROOT+'/'+p;head=git(rp,'rev-parse','HEAD').decode().strip();refs=json.load(open('/workspace/shared/downloads/terminal-ui-migration-20261115/repository-refs.json'));matches=[(r['path'],x['bundle_ref']) for r in refs if r.get('exported') for x in r['refs'] if x['sha']==head]
c.execute('UPDATE files SET git_root=? WHERE path LIKE ?',(p,p+'/%'));c.execute('UPDATE directories SET git_root=? WHERE path=? OR path LIKE ?',(p,p,p+'/%'))
changed={}
for rec in git(rp,'status','--porcelain=v1','-z','--untracked-files=no').split(b'\0'):
 if rec:changed[rec[3:].decode('utf-8','surrogateescape')]=rec[:2].decode()
tracked=0
for rec in git(rp,'ls-files','--stage','-v','-z').split(b'\0'):
 if not rec:continue
 prefix,path=rec.split(b'\t',1);tag,mode,blob,stage=prefix.decode().split();path=path.decode('utf-8','surrogateescape');rel=p+'/'+path
 if c.execute('SELECT 1 FROM files WHERE path=?',(rel,)).fetchone():
  status=changed.get(path,'clean_status');ge='derived_verification_copy_HEAD_exported_clean' if matches and tag=='H' and status=='clean_status' and stage=='0' else 'derived_verification_copy_requires_review'
  c.execute('UPDATE files SET tracked=1,git_status=?,head=?,index_blob=?,index_flags=?,git_evidence=? WHERE path=?',(status,head,blob,tag,ge,rel));tracked+=1
c.execute('INSERT OR REPLACE INTO repositories VALUES(?,?,?,?,?,?,?,?,?,?)',(p,head,'derived_verification_repository',int(bool(matches)),int(bool(matches)),matches[0][1] if matches else None,tracked,len(changed),0,None));c.commit();print(json.dumps({'derived_repository':p,'head':head,'matches_existing_first_batch_export':bool(matches),'tracked_materialized':tracked}));c.close()
