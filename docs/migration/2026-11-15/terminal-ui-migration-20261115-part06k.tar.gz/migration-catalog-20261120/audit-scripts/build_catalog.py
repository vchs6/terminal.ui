#!/usr/bin/env python3
"""Read-only project metadata reconciliation. Large outputs require dedicated host RAM."""
import os,sys,json,stat,sqlite3,subprocess,gzip,hashlib,datetime,collections,fnmatch,time
ROOT='/workspace/work'; MAIN=ROOT+'/terminal.ui'; BASE='a5aed68544d7681a522400d2f061e5cf64532ee4'
RAM='/dev/shm/terminal-ui-migration-20261115-host/global-catalog'; OUT=ROOT+'/migration-global-catalog'; FIRST='/workspace/shared/downloads/terminal-ui-migration-20261115'
FORBIDDEN=['vte-protocol-counterexample/quarantine','vte-protocol-counterexample/actual/vte/160x48/vertical_panels/new/output/0']
SENSITIVE={'.ssh','private','auth','authentication','credentials','.aws','.netrc','.npmrc','ssh-server'}
START=datetime.datetime.now(datetime.timezone.utc).isoformat(); omissions=collections.Counter(); errors=[]
def safe(p):
 if not isinstance(p,str):return False
 rel=p[len(ROOT)+1:] if p.startswith(ROOT+'/') else p
 if rel.startswith('/') or rel=='..' or '/..' in rel:return False
 if any(rel==x or rel.startswith(x+'/') for x in FORBIDDEN):return False
 for part in rel.split('/'):
  low=part.lower()
  if low in SENSITIVE or low.startswith('.env') or fnmatch.fnmatch(low,'id_*') or low.endswith(('.key','.pem')):return False
 return True
def relpath(p):
 if not isinstance(p,str):return None
 if p.startswith(ROOT+'/'):p=p[len(ROOT)+1:]
 elif p.startswith('work/'):p=p[5:]
 if not safe(p):return None
 return os.path.normpath(p)
def load(p):
 with open(p,'rb') as f:return json.load(f)
def git(repo,*args,check=True):
 p=subprocess.run(['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-C',repo,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','LC_ALL':'C'},timeout=180)
 if p.returncode and check:raise RuntimeError('git metadata command failed: '+repo+' '+str(args[:2])+': '+p.stderr.decode(errors='replace')[:250])
 return p.stdout
os.makedirs(RAM,exist_ok=True)
DB=RAM+'/catalog.sqlite3'
if os.path.exists(DB):raise RuntimeError('Refuse overwrite existing catalog')
c=sqlite3.connect(DB); c.executescript('''PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=MEMORY;
CREATE TABLE files(path TEXT PRIMARY KEY,top TEXT,type TEXT,bytes INTEGER,mode INTEGER,mtime_ns INTEGER,git_root TEXT,tracked INTEGER,git_status TEXT,head TEXT,head_blob TEXT,index_blob TEXT,index_flags TEXT,git_evidence TEXT,category TEXT);
CREATE TABLE evidence(path TEXT,kind TEXT,source_index TEXT,sha256 TEXT,bytes INTEGER,mode TEXT,member TEXT,archive TEXT,detail TEXT);
CREATE TABLE repositories(path TEXT PRIMARY KEY,head TEXT,kind TEXT,exported INTEGER,head_exported INTEGER,export_ref TEXT,tracked_count INTEGER,changes_count INTEGER,flags_count INTEGER,error TEXT);
CREATE TABLE inputs(path TEXT PRIMARY KEY,sha256 TEXT,bytes INTEGER,source TEXT);
CREATE TABLE logical_custody(path TEXT,sha256 TEXT,bytes INTEGER,mode TEXT,physical TEXT,physical_sha256 TEXT,source_index TEXT,member TEXT,detail TEXT);
CREATE TABLE directories(path TEXT PRIMARY KEY,mode INTEGER,git_root TEXT);
CREATE TABLE scan_errors(path TEXT,operation TEXT,error TEXT);
''')
def record_input(p,raw,source='physical_known_index'):
 c.execute('INSERT OR REPLACE INTO inputs VALUES(?,?,?,?)',(p,hashlib.sha256(raw).hexdigest(),len(raw),source))
def read_index(p):
 with open(p,'rb') as f:raw=f.read()
 record_input(p,raw);return json.loads(raw)
def evidence(path,kind,idx,row,member=None,archive=None,detail=None):
 p=relpath(path)
 if not p:return
 sha=row.get('sha256') or row.get('original_sha256')
 if sha and (not isinstance(sha,str) or len(sha)!=64):sha=None
 size=row.get('bytes',row.get('size',row.get('declared_bytes')))
 if not isinstance(size,int):size=None
 mode=row.get('mode')
 c.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?)',(p,kind,idx,sha,size,str(mode) if mode is not None else None,member if isinstance(member,str) else None,archive if isinstance(archive,str) else None,json.dumps(detail or {},ensure_ascii=False)))
refp=FIRST+'/repository-refs.json'; refs=read_index(refp); gitrefs=read_index(FIRST+'/git-refs.json'); verification=read_index(FIRST+'/ref-coverage-verification.json'); read_index(FIRST+'/independent-verification.json'); read_index(ROOT+'/migration-staging-cleanup-20261115.json')
# Only declared first-batch refs plus their verified baseline prerequisite prove export.
repolist={r['path']:r for r in refs if r.get('kind')!='bare_provenance_repository' and r['path'].startswith(ROOT+'/') and safe(r['path'])}
repostate={};treecache={}
for num,(rp,r) in enumerate(sorted(repolist.items())):
 try:
  head=git(rp,'rev-parse','HEAD').decode().strip(); exported=bool(r.get('exported')); match=[x for x in r.get('refs',[]) if x.get('sha')==head]; isexp=exported and bool(match) and verification.get('missing')==[]
  status=git(rp,'status','--porcelain=v1','-z','--untracked-files=no','--ignore-submodules=all'); chunks=status.split(b'\0'); changed={};i=0
  while i<len(chunks):
   s=chunks[i];i+=1
   if not s:continue
   st=s[:2].decode(); p=s[3:].decode('utf-8','surrogateescape');changed[p]=st
   if 'R' in st or 'C' in st:
    if i<len(chunks):changed[chunks[i].decode('utf-8','surrogateescape')]='rename_source';i+=1
  tracked={}; flags=0
  for rec in git(rp,'ls-files','--stage','-v','-z').split(b'\0'):
   if not rec:continue
   prefix,p=rec.split(b'\t',1);tag,mode,blob,stage=prefix.decode().split();pn=p.decode('utf-8','surrogateescape')
   if safe(rp+'/'+pn):tracked[pn]=(tag,mode,blob,int(stage))
   if tag!='H':flags+=1
  if head not in treecache:
   tree={}
   for rec in git(rp,'ls-tree','-r','-z','HEAD').split(b'\0'):
    if not rec:continue
    fields,p=rec.split(b'\t',1);mode,typ,blob=fields.decode().split();tree[p.decode('utf-8','surrogateescape')]=(mode,typ,blob)
   treecache[head]=tree
  tree=treecache[head]
  repostate[rp]={'head':head,'tracked':tracked,'changed':changed,'tree':tree,'head_exported':isexp,'exported':exported,'kind':r['kind'],'ref':match[0]['bundle_ref'] if match else None,'upstream':not exported}
  c.execute('INSERT INTO repositories VALUES(?,?,?,?,?,?,?,?,?,?)',(relpath(rp),head,r['kind'],exported,isexp,match[0]['bundle_ref'] if match else None,len(tracked),len(changed),flags,None))
 except Exception as e:
  errors.append(str(e));c.execute('INSERT INTO repositories VALUES(?,?,?,?,?,?,?,?,?,?)',(relpath(rp),None,r['kind'],bool(r.get('exported')),0,None,0,0,0,str(e)))
 if num%40==0:print('git_repositories',num+1,flush=True)
c.commit();print('git_metadata_ready',len(repostate),flush=True)
# Current package declarations are coverage evidence, never fresh source SHA equality.
manifest_paths=[('part01',FIRST+'/first-batch-files.json')]
for name in sorted(os.listdir(ROOT)):
 if name.startswith('migration-part') and os.path.isfile(ROOT+'/'+name+'/manifest.json'):manifest_paths.append((name.replace('migration-',''),ROOT+'/'+name+'/manifest.json'))
for part,p in manifest_paths:
 d=read_index(p)
 for row in d.get('files',[]):
  evidence(row.get('original_path',row.get('path')), 'package_manifest',p,row,row.get('archive_path'),part)
 for row in d.get('elf_payloads',[]):
  orig=row.get('logical_original',{}); logical=relpath(orig.get('path'));physical=relpath(row.get('path'))
  if logical and physical:
   c.execute('INSERT INTO logical_custody VALUES(?,?,?,?,?,?,?,?,?)',(logical,orig.get('sha256'),orig.get('bytes'),str(orig.get('mode')),physical,row.get('sha256'),p,'work/'+physical,json.dumps({'kind':'package_elf_custody','part':part})))
# Fixed baseline archive metadata. Blob IDs and input digests bind precisely what was read.
names=git(MAIN,'ls-tree','-r','--name-only',BASE,'docs/reviews').decode().splitlines(); archive_names=[p for p in names if p.endswith('.tar.gz')]
old_indices=[p for p in names if ('archive-index' in p and p.endswith('.json')) or ('.archive-v1/' in p and p.endswith('manifest.jsonl.gz')) or p.endswith('original-manifest.json.gz')]
knowncopy={'copies','copied_files','files','originals_copied','originals','members','candidate_packages','captures'}
lineagekeys={'original_external_source','original_source_lineage_mapping','source_copy_map'}
sourcekeys=['original_path','external_path','original_source','external_source','original_metadata','original','source','path']
def walk_rows(obj,idx,context='',archive_hint=None):
 if isinstance(obj,list):
  for x in obj:walk_rows(x,idx,context,archive_hint)
  return
 if not isinstance(obj,dict):return
 member=obj.get('member',obj.get('archive_member')); sha=obj.get('sha256'); src=None
 for key in sourcekeys:
  v=obj.get(key)
  if isinstance(v,str) and v.startswith(ROOT+'/'):src=v;break
 # Curated lineage must never bind original report path to curated report SHA.
 if obj.get('curated_source') and isinstance(obj['curated_source'],str):
  if src:evidence(src,'historical_lineage_only',idx,{},detail={'context':context})
  src=obj['curated_source']
 archive=obj.get('archive',obj.get('copy')); authority=obj.get('authority')
 if isinstance(authority,dict):
  member=member or authority.get('member');archive=archive or authority.get('index_path')
 if isinstance(src,str) and sha:
  blocked=any(x in context.lower() for x in ['exclusion','omission','external_provenance','external_reference','lineage']) or obj.get('status')=='excluded' or obj.get('omission_reason') or obj.get('copied') is False
  exact=bool(member or (isinstance(archive,str) and archive)) and not blocked
  kind='historical_exact_locator' if exact else 'historical_hash_reference'
  evidence(src,kind,idx,obj,member,archive or archive_hint,{'context':context,'status':obj.get('status'),'resolution':obj.get('resolution')})
 # Old logical gzip aliases keep absent original separate from physical compressed payload.
 if obj.get('resolution')=='lossless-gzip-alias' and src:
  phy=relpath(obj.get('physical'));logical=relpath(src)
  if phy and logical:c.execute('INSERT INTO logical_custody VALUES(?,?,?,?,?,?,?,?,?)',(logical,obj.get('original_sha256',sha),obj.get('original_bytes'),None,phy,obj.get('compressed_sha256'),idx,None,json.dumps({'kind':'historic_lossless_gzip_alias'})))
 if obj.get('logical_original_path') and obj.get('original_sha256'):
  logical=relpath(obj['logical_original_path']);phy=relpath(obj.get('witness',obj.get('gzip_path')))
  if logical:c.execute('INSERT INTO logical_custody VALUES(?,?,?,?,?,?,?,?,?)',(logical,obj['original_sha256'],obj.get('original_bytes'),str(obj.get('original_mode')),phy,obj.get('witness_sha256',obj.get('compressed_sha256')),idx,None,json.dumps({'kind':'historic_elf_custody_reference'})))
 for k,v in obj.items():
  if isinstance(v,(list,dict)):walk_rows(v,idx,context+'/'+k,archive_hint)
for n,p in enumerate(old_indices):
 raw=git(MAIN,'show',BASE+':'+p);record_input(p,raw,'git:'+BASE)
 data=gzip.decompress(raw) if p.endswith('.gz') else raw
 if p.endswith('.jsonl.gz'):
  for line in data.splitlines():
   row=json.loads(line);rp=MAIN+'/'+row.get('path','')
   evidence(rp,'historical_archive_v1_member',p,row,row.get('member'),row.get('shard'))
 else:
  d=json.loads(data)
  walk_rows(d,p,archive_hint=os.path.dirname(p)+'/raw-evidence.tar.gz' if p.endswith('original-manifest.json.gz') else None)
 if n%40==0:print('old_indices',n+1,flush=True)
c.commit();print('evidence_ready',flush=True)
# Stat only. Symlink target text and file bodies are never read. Git metadata dirs are inventoried,
# but never counted as full recovery merely because refs were exported.
rows=[];dirs=[];count=0;new_git_roots=set();topcounts=collections.Counter();st=time.monotonic()
def scan(path,owner=None):
 global count,rows,dirs
 rel=path[len(ROOT)+1:]
 if rel=='migration-global-catalog':omissions['own_report_directory']+=1;return
 if not safe(rel):omissions['forbidden_or_sensitive_entries_pruned']+=1;return
 if path in repostate:owner=path
 try:s=os.lstat(path)
 except OSError as e:c.execute('INSERT INTO scan_errors VALUES(?,?,?)',(rel,'lstat',str(e)));return
 typ='directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'special'
 if typ=='directory':
  dirs.append((rel,stat.S_IMODE(s.st_mode),relpath(owner) if owner else None))
  try:
   with os.scandir(path) as it:
    for entry in it:scan(entry.path,owner)
  except OSError as e:c.execute('INSERT INTO scan_errors VALUES(?,?,?)',(rel,'scandir',str(e)))
  if len(dirs)>=5000:c.executemany('INSERT INTO directories VALUES(?,?,?)',dirs);dirs=[]
  return
 if os.path.basename(path)=='.git' and (not owner or os.path.dirname(path)!=owner):new_git_roots.add(os.path.dirname(path))
 tracked=0;status=None;head=None;blob=None;ib=None;flags=None;ge=None
 if owner:
  rs=repostate[owner];p=path[len(owner)+1:];head=rs['head'];tr=rs['tracked'].get(p);ht=rs['tree'].get(p)
  if tr:
   tracked=1;flags=tr[0];ib=tr[2];status=rs['changed'].get(p,'clean_status')
   if ht:blob=ht[2]
   if status=='clean_status' and flags=='H' and tr[3]==0 and ht and ib==blob:
    ge='exported_HEAD_clean_status' if rs['head_exported'] else 'fixed_upstream_HEAD_clean_status' if rs['upstream'] else 'HEAD_not_proven_exported'
   else:ge='tracked_requires_review'
  else:status='untracked_ignored_not_checked'
 isgit='.git' in rel.split('/') or rel.endswith('.git') or any(rel.startswith(x+'/') for x in ['linux-final-host-actual/actual/source-admission.git'])
 category='git_metadata_refs_recovery_separate' if isgit else 'git_HEAD_exported_clean' if ge=='exported_HEAD_clean_status' else 'pinned_upstream_clean' if ge=='fixed_upstream_HEAD_clean_status' else 'unresolved'
 rows.append((rel,rel.split('/')[0],typ,s.st_size,stat.S_IMODE(s.st_mode),s.st_mtime_ns,relpath(owner) if owner else None,tracked,status,head,blob,ib,flags,ge,category));count+=1
 if len(rows)>=5000:
  c.executemany('INSERT INTO files VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',rows);rows=[]
 if count%100000==0:print('stat_files',count,'seconds',round(time.monotonic()-st),flush=True);c.commit()
with os.scandir(ROOT) as it:
 for e in it:scan(e.path)
if rows:c.executemany('INSERT INTO files VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',rows)
if dirs:c.executemany('INSERT INTO directories VALUES(?,?,?)',dirs)
c.executescript('CREATE INDEX evidence_path ON evidence(path); CREATE INDEX evidence_kind ON evidence(kind); CREATE INDEX evidence_path_kind ON evidence(path,kind); CREATE INDEX files_category ON files(category); CREATE INDEX custody_physical ON logical_custody(physical);')
# Preserve exact metadata-only status. These categories do not assert current SHA equality.
c.execute("UPDATE files SET category='package_manifest_source_SHA_pending' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='package_manifest')")
c.execute("UPDATE files SET category='historical_exact_locator_source_SHA_pending' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='historical_exact_locator')")
c.execute("UPDATE files SET category='historical_hash_reference_unresolved' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='historical_hash_reference')")
c.commit();print('classification_ready',flush=True)
# Self-contained bounded summary, complete executable metadata queues in RAM.
def dictrows(sql,args=()):
 cursor=c.execute(sql,args);return [dict(zip([x[0] for x in cursor.description],r)) for r in cursor]
summary={'schema':'safe-project-metadata-catalog-v1','started_utc':START,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':ROOT,'database':DB,'baseline_archive_commit':BASE,'current_main':git(MAIN,'rev-parse','HEAD').decode().strip(),'no_source_bodies_read':True,'no_source_content_hashes_computed':True,'scan_scope':'Current safe project entries excluding own report output, secret/auth paths, and forbidden descendants. No symlink traversal.','counts':dictrows('SELECT type,count(*) files,sum(bytes) bytes FROM files GROUP BY type'),'categories':dictrows('SELECT category,count(*) files,sum(bytes) bytes FROM files GROUP BY category ORDER BY bytes DESC'),'evidence':dictrows('SELECT kind,count(*) rows,count(DISTINCT path) distinct_paths FROM evidence GROUP BY kind'),'repositories':dictrows('SELECT kind,exported,head_exported,count(*) repositories FROM repositories GROUP BY kind,exported,head_exported'),'directories':c.execute('SELECT count(*) FROM directories').fetchone()[0],'omission_counts':dict(omissions),'scan_errors':c.execute('SELECT count(*) FROM scan_errors').fetchone()[0],'git_errors':errors,'unrecognized_git_roots':sorted(new_git_roots),'history_index_files':len(old_indices),'history_tar_gz_count':len(archive_names),'input_metadata_files':c.execute('SELECT count(*) FROM inputs').fetchone()[0],'package_manifests':[{'part':part,'path':p} for part,p in manifest_paths],'logical_custody':dictrows('SELECT count(*) rows,count(DISTINCT path) logical_paths,count(DISTINCT physical) physical_paths FROM logical_custody'),'unresolved_top':dictrows("SELECT top,count(*) files,sum(bytes) bytes FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved') GROUP BY top ORDER BY bytes DESC LIMIT 35"),'obligations':['Package/historical SHA values were read from existing manifests only; compare current physical source SHA before declaring those bytes identical. Size/mode matches are triage, never SHA proof.','Git clean status evidence requires exported HEAD, same index/HEAD blob, no reported change, normal H index flag; index trust/mtime races remain bounded Git-status semantics, not a fresh content SHA pass.','Git metadata/objectstore is separate: exported refs and baseline restore reachable history, not arbitrary unreachable objects, hooks/config/reflogs or other local Git state.','Seven declared unmodified shallow upstream checkouts are pinned by exact HEAD only. Origin/reacquisition locator remains external to this catalog; SDK/cache trees remain unresolved without per-file origin/hash/restore proof.','Historical exact locator means index supplies member/copy/archive; no archive member payload was opened or source content rehashed. Curated lineage/hash-only references never count as exact original recovery.','Logical ELF/gzip aliases are separate from materialized scan; absence of intentionally replaced original is not data loss. Verify physical custody SHA, map/receipt and delivered archive links.','Catalogue is a bounded safe snapshot; no final migration acceptance or final compressed volume count.']}
# Source-safe small queue: names/types only. No raw/event/env/generated/SDK/cache or Git metadata candidates.
queue_sql="""SELECT path,type,bytes,mode,git_root,tracked,git_status,category FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved','historical_exact_locator_source_SHA_pending') AND type='file' AND bytes<=200000 AND path NOT LIKE 'migration-%' AND path NOT LIKE '%/.git/%' AND lower(path) NOT LIKE '%/raw/%' AND lower(path) NOT LIKE '%/actual/%' AND lower(path) NOT LIKE '%/target/%' AND lower(path) NOT LIKE '%/cache/%' AND lower(path) NOT LIKE '%/sdk/%' AND lower(path) NOT LIKE '%/packages/%' AND lower(path) NOT LIKE '%/output/%' AND lower(path) NOT LIKE '%/events/%' AND (lower(path) LIKE '%.md' OR lower(path) LIKE '%.py' OR lower(path) LIKE '%.mjs' OR lower(path) LIKE '%.sh' OR lower(path) LIKE '%.cj' OR lower(path) LIKE '%.toml') ORDER BY CASE WHEN lower(path) LIKE '%/report%.md' OR lower(path) LIKE '%/findings%.md' OR lower(path) LIKE '%/review%.md' THEN 0 WHEN lower(path) LIKE '%test%' THEN 1 ELSE 2 END, bytes,path"""
queue=dictrows(queue_sql); summary['small_safe_candidate_queue']={'files':len(queue),'bytes':sum(r['bytes'] for r in queue),'first_60':queue[:60],'note':'Candidates only, no candidate contents read; SHA/classification review precedes packaging.'}
with open(RAM+'/small-safe-candidates.jsonl','w') as f:
 for row in queue:f.write(json.dumps(row,ensure_ascii=True)+'\n')
for name,sql in [('unresolved',"SELECT * FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved') ORDER BY top,path"),('source-sha-obligations',"SELECT f.*,e.kind,e.source_index,e.sha256 expected_sha256,e.bytes expected_bytes,e.mode expected_mode,e.member,e.archive FROM files f JOIN evidence e ON e.path=f.path WHERE e.kind IN ('package_manifest','historical_exact_locator') AND f.category NOT IN ('git_HEAD_exported_clean','git_baseline_blob_exported_clean','pinned_upstream_clean','git_metadata_refs_recovery_separate') ORDER BY f.path"),('logical-custody',"SELECT l.*, EXISTS(SELECT 1 FROM files f WHERE f.path=l.path) logical_present, EXISTS(SELECT 1 FROM files f WHERE f.path=l.physical) physical_present, EXISTS(SELECT 1 FROM evidence e WHERE e.path=l.physical AND e.kind='package_manifest') physical_package_manifest FROM logical_custody l ORDER BY l.path")]:
 with open(RAM+'/'+name+'.jsonl','w') as f:
  cur=c.execute(sql);keys=[x[0] for x in cur.description]
  for row in cur:f.write(json.dumps(dict(zip(keys,row)),ensure_ascii=True)+'\n')
with open(OUT+'/summary.json','w') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
c.close();print(json.dumps({'database':DB,'files':count,'summary':OUT+'/summary.json','safe_candidates':len(queue),'errors':len(errors)},ensure_ascii=False),flush=True)
