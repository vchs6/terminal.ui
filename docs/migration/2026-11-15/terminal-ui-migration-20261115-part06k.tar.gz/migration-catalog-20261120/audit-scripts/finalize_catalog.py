#!/usr/bin/env python3
"""Read-only project metadata reconciliation. Large outputs require dedicated host RAM."""
import os,sys,json,stat,sqlite3,subprocess,gzip,hashlib,datetime,collections,fnmatch,time
ROOT='/workspace/work'; MAIN=ROOT+'/terminal.ui'; BASE='a5aed68544d7681a522400d2f061e5cf64532ee4'
RAM='/dev/shm/terminal-ui-migration-20261115-host/global-catalog'; OUT=ROOT+'/migration-global-catalog'; FIRST='/workspace/shared/downloads/terminal-ui-migration-20261115'
FORBIDDEN=['vte-protocol-counterexample/quarantine','vte-protocol-counterexample/actual/vte/160x48/vertical_panels/new/output/0']
SENSITIVE={'.ssh','private','auth','authentication','credentials','.aws','.netrc','.npmrc','ssh-server'}
START=datetime.datetime.now(datetime.timezone.utc).isoformat(); omissions=collections.Counter(); errors=[]
def safe(p):
 if not isinstance(p,str):return False
 rel=p[len(ROOT)+1:] if p.startswith(ROOT+'/') else p
 if rel.startswith('/') or rel=='..' or '/..' in rel:return False
 if any(rel==x or rel.startswith(x+'/') for x in FORBIDDEN):return False
 for part in rel.split('/'):
  low=part.lower()
  if low in SENSITIVE or low.startswith('.env') or fnmatch.fnmatch(low,'id_*') or low.endswith(('.key','.pem')):return False
 return True
def relpath(p):
 if not isinstance(p,str):return None
 if p.startswith(ROOT+'/'):p=p[len(ROOT)+1:]
 elif p.startswith('work/'):p=p[5:]
 if not safe(p):return None
 return os.path.normpath(p)
def load(p):
 with open(p,'rb') as f:return json.load(f)
def git(repo,*args,check=True):
 p=subprocess.run(['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-C',repo,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','LC_ALL':'C'},timeout=180)
 if p.returncode and check:raise RuntimeError('git metadata command failed: '+repo+' '+str(args[:2])+': '+p.stderr.decode(errors='replace')[:250])
 return p.stdout

DB=RAM+'/catalog.sqlite3';c=sqlite3.connect(DB)
manifest_paths=[('part01',FIRST+'/first-batch-files.json')]+[(n.replace('migration-',''),ROOT+'/'+n+'/manifest.json') for n in sorted(os.listdir(ROOT)) if n.startswith('migration-part') and os.path.isfile(ROOT+'/'+n+'/manifest.json')]
old_indices=[r[0] for r in c.execute("SELECT path FROM inputs WHERE source=?",('git:'+BASE,))]
archive_names=[n for n in git(MAIN,'ls-tree','-r','--name-only',BASE,'docs/reviews').decode().splitlines() if n.endswith('.tar.gz')]
count=c.execute('SELECT count(*) FROM files').fetchone()[0]
errors=[r[0] for r in c.execute('SELECT error FROM repositories WHERE error IS NOT NULL')]
new_git_roots=set()
omissions={'own_report_directory':1,'forbidden_sensitive_pruning_counter':'not persisted before classification restart; pruning rules remain mandatory and verified by forbidden-path SQL'}
# Preserve exact metadata-only status. These categories do not assert current SHA equality.
c.execute("UPDATE files SET category='package_manifest_source_SHA_pending' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='package_manifest')")
c.execute("UPDATE files SET category='historical_exact_locator_source_SHA_pending' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='historical_exact_locator')")
c.execute("UPDATE files SET category='historical_hash_reference_unresolved' WHERE category='unresolved' AND EXISTS(SELECT 1 FROM evidence e WHERE e.path=files.path AND e.kind='historical_hash_reference')")
c.commit();print('classification_ready',flush=True)
# Self-contained bounded summary, complete executable metadata queues in RAM.
def dictrows(sql,args=()):
 cursor=c.execute(sql,args);return [dict(zip([x[0] for x in cursor.description],r)) for r in cursor]
summary={'schema':'safe-project-metadata-catalog-v1','started_utc':START,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':ROOT,'database':DB,'baseline_archive_commit':BASE,'current_main':git(MAIN,'rev-parse','HEAD').decode().strip(),'no_source_bodies_read':True,'no_source_content_hashes_computed':True,'scan_scope':'Current safe project entries excluding own report output, secret/auth paths, and forbidden descendants. No symlink traversal.','counts':dictrows('SELECT type,count(*) files,sum(bytes) bytes FROM files GROUP BY type'),'categories':dictrows('SELECT category,count(*) files,sum(bytes) bytes FROM files GROUP BY category ORDER BY bytes DESC'),'evidence':dictrows('SELECT kind,count(*) rows,count(DISTINCT path) distinct_paths FROM evidence GROUP BY kind'),'repositories':dictrows('SELECT kind,exported,head_exported,count(*) repositories FROM repositories GROUP BY kind,exported,head_exported'),'directories':c.execute('SELECT count(*) FROM directories').fetchone()[0],'omission_counts':dict(omissions),'scan_errors':c.execute('SELECT count(*) FROM scan_errors').fetchone()[0],'git_errors':errors,'unrecognized_git_roots':sorted(new_git_roots),'history_index_files':len(old_indices),'history_tar_gz_count':len(archive_names),'input_metadata_files':c.execute('SELECT count(*) FROM inputs').fetchone()[0],'package_manifests':[{'part':part,'path':p} for part,p in manifest_paths],'logical_custody':dictrows('SELECT count(*) rows,count(DISTINCT path) logical_paths,count(DISTINCT physical) physical_paths FROM logical_custody'),'unresolved_top':dictrows("SELECT top,count(*) files,sum(bytes) bytes FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved') GROUP BY top ORDER BY bytes DESC LIMIT 35"),'obligations':['Package/historical SHA values were read from existing manifests only; compare current physical source SHA before declaring those bytes identical. Size/mode matches are triage, never SHA proof.','Git clean status evidence requires exported HEAD, same index/HEAD blob, no reported change, normal H index flag; index trust/mtime races remain bounded Git-status semantics, not a fresh content SHA pass.','Git metadata/objectstore is separate: exported refs and baseline restore reachable history, not arbitrary unreachable objects, hooks/config/reflogs or other local Git state.','Seven declared unmodified shallow upstream checkouts are pinned by exact HEAD only. Origin/reacquisition locator remains external to this catalog; SDK/cache trees remain unresolved without per-file origin/hash/restore proof.','Historical exact locator means index supplies member/copy/archive; no archive member payload was opened or source content rehashed. Curated lineage/hash-only references never count as exact original recovery.','Logical ELF/gzip aliases are separate from materialized scan; absence of intentionally replaced original is not data loss. Verify physical custody SHA, map/receipt and delivered archive links.','Catalogue is a bounded safe snapshot; no final migration acceptance or final compressed volume count.']}
# Source-safe small queue: names/types only. No raw/event/env/generated/SDK/cache or Git metadata candidates.
queue_sql="""SELECT path,type,bytes,mode,git_root,tracked,git_status,category FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved','historical_exact_locator_source_SHA_pending') AND type='file' AND bytes<=200000 AND path NOT LIKE 'migration-%' AND path NOT LIKE '%/.git/%' AND lower(path) NOT LIKE '%/raw/%' AND lower(path) NOT LIKE '%/actual/%' AND lower(path) NOT LIKE '%/target/%' AND lower(path) NOT LIKE '%/cache/%' AND lower(path) NOT LIKE '%/sdk/%' AND lower(path) NOT LIKE '%/packages/%' AND lower(path) NOT LIKE '%/output/%' AND lower(path) NOT LIKE '%/events/%' AND (lower(path) LIKE '%.md' OR lower(path) LIKE '%.py' OR lower(path) LIKE '%.mjs' OR lower(path) LIKE '%.sh' OR lower(path) LIKE '%.cj' OR lower(path) LIKE '%.toml') ORDER BY CASE WHEN lower(path) LIKE '%/report%.md' OR lower(path) LIKE '%/findings%.md' OR lower(path) LIKE '%/review%.md' THEN 0 WHEN lower(path) LIKE '%test%' THEN 1 ELSE 2 END, bytes,path"""
queue=dictrows(queue_sql); summary['small_safe_candidate_queue']={'files':len(queue),'bytes':sum(r['bytes'] for r in queue),'first_60':queue[:60],'note':'Candidates only, no candidate contents read; SHA/classification review precedes packaging.'}
with open(RAM+'/small-safe-candidates.jsonl','w') as f:
 for row in queue:f.write(json.dumps(row,ensure_ascii=True)+'\n')
for name,sql in [('unresolved',"SELECT * FROM files WHERE category IN ('unresolved','historical_hash_reference_unresolved') ORDER BY top,path"),('source-sha-obligations',"SELECT f.*,e.kind,e.source_index,e.sha256 expected_sha256,e.bytes expected_bytes,e.mode expected_mode,e.member,e.archive FROM files f JOIN evidence e ON e.path=f.path WHERE e.kind IN ('package_manifest','historical_exact_locator') AND f.category NOT IN ('git_HEAD_exported_clean','git_baseline_blob_exported_clean','pinned_upstream_clean','git_metadata_refs_recovery_separate') ORDER BY f.path"),('logical-custody',"SELECT l.*, EXISTS(SELECT 1 FROM files f WHERE f.path=l.path) logical_present, EXISTS(SELECT 1 FROM files f WHERE f.path=l.physical) physical_present, EXISTS(SELECT 1 FROM evidence e WHERE e.path=l.physical AND e.kind='package_manifest') physical_package_manifest FROM logical_custody l ORDER BY l.path")]:
 with open(RAM+'/'+name+'.jsonl','w') as f:
  cur=c.execute(sql);keys=[x[0] for x in cur.description]
  for row in cur:f.write(json.dumps(dict(zip(keys,row)),ensure_ascii=True)+'\n')
with open(OUT+'/summary.json','w') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
c.close();print(json.dumps({'database':DB,'files':count,'summary':OUT+'/summary.json','safe_candidates':len(queue),'errors':len(errors)},ensure_ascii=False),flush=True)
