#!/usr/bin/env python3
"""Bounded metadata refinements after the initial complete safe stat scan."""
import os,json,sqlite3,stat,subprocess,hashlib,datetime
ROOT='/workspace/work';MAIN=ROOT+'/terminal.ui';BASE='a5aed68544d7681a522400d2f061e5cf64532ee4';RAM='/dev/shm/terminal-ui-migration-20261115-host/global-catalog';OUT=ROOT+'/migration-global-catalog';FIRST='/workspace/shared/downloads/terminal-ui-migration-20261115'
c=sqlite3.connect(RAM+'/catalog.sqlite3');c.execute('PRAGMA journal_mode=OFF');c.execute('PRAGMA synchronous=OFF')
def rel(p):return p[len(ROOT)+1:] if isinstance(p,str) and p.startswith(ROOT+'/') else None
def git(*args):return subprocess.check_output(['git','-c','core.fsmonitor=false','-C',MAIN,*args],env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0','LC_ALL':'C'})
# Recover exact nonregular type without reading any body or symlink target.
count=0
for path, in c.execute("SELECT path FROM files WHERE type='special'").fetchall():
 try:m=os.lstat(ROOT+'/'+path).st_mode
 except OSError:continue
 typ='fifo' if stat.S_ISFIFO(m) else 'socket' if stat.S_ISSOCK(m) else 'character_device' if stat.S_ISCHR(m) else 'block_device' if stat.S_ISBLK(m) else 'unknown_special'
 c.execute('UPDATE files SET type=? WHERE path=?',(typ,path));count+=1
# Main has advanced since the first bundle; unchanged baseline blobs still have exact exported evidence.
tree={}
for record in git('ls-tree','-r','-z',BASE).split(b'\0'):
 if not record:continue
 fields,p=record.split(b'\t',1);mode,typ,blob=fields.decode().split();tree[p.decode('utf-8','surrogateescape')]=blob
baseline_matches=0
for path,ib,hb in c.execute("SELECT path,index_blob,head_blob FROM files WHERE git_root='terminal.ui' AND tracked=1 AND git_status='clean_status' AND index_flags='H'").fetchall():
 p=path[len('terminal.ui/'):]
 if ib==hb==tree.get(p):
  c.execute("UPDATE files SET category='git_baseline_blob_exported_clean',git_evidence='baseline_a5_exported_blob_current_clean_status' WHERE path=? AND category<>'git_metadata_refs_recovery_separate'",(path,))
  c.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?)',(path,'git_exported_baseline_blob','first-batch git-refs.json:base_main',None,None,None,p,'git:'+BASE,json.dumps({'blob':ib,'baseline':BASE})));baseline_matches+=1
# Bare provenance is refs recovery, separate from its physical Git metadata.
refs=json.load(open(FIRST+'/repository-refs.json'))
for r in refs:
 if r.get('kind')=='bare_provenance_repository':
  path=rel(r['path']);head=next((x['sha'] for x in r['refs'] if x['original_ref']=='HEAD'),None)
  c.execute('INSERT OR REPLACE INTO repositories VALUES(?,?,?,?,?,?,?,?,?,?)',(path,head,r['kind'],int(bool(r.get('exported'))),int(bool(r.get('exported'))),next((x['bundle_ref'] for x in r['refs'] if x['sha']==head),None),0,0,0,None))
# Known delivered progress/restore maps supply intentionally absent original ELF -> gzip links.
map_paths=[]
for n in sorted(os.listdir(ROOT)):
 p=ROOT+'/'+n+'/manifest.json'
 if not n.startswith('migration-part') or not os.path.isfile(p):continue
 for row in json.load(open(p)).get('files',[]):
  f=row.get('path','')
  if f.endswith(('/progress.json','/restore-map.json')) and f not in map_paths:map_paths.append(f)
maprows=0
for p in map_paths:
 raw=open(p,'rb').read();c.execute('INSERT OR REPLACE INTO inputs VALUES(?,?,?,?)',(p,hashlib.sha256(raw).hexdigest(),len(raw),'physical_known_custody_map'))
 d=json.loads(raw); rows=d if isinstance(d,list) else d.get('rows',d.get('mapping',[]))
 for r in rows:
  if not isinstance(r,dict):continue
  logical=rel(r.get('logical_original_path',r.get('path')));phy=rel(r.get('gzip_path',r.get('witness')))
  if not logical or not phy:continue
  # Both paths are already represented by safe evidence or catalog metadata; never create secret/forbidden records.
  if c.execute('SELECT 1 FROM evidence WHERE path=? LIMIT 1',(phy,)).fetchone() is None:continue
  sha=r.get('original_sha256',r.get('sha256'));psha=r.get('gzip_sha256',r.get('witness_sha256'));size=r.get('original_bytes',r.get('size',r.get('bytes')));mode=r.get('original_mode',r.get('mode'))
  c.execute('INSERT INTO logical_custody VALUES(?,?,?,?,?,?,?,?,?)',(logical,sha,size,str(mode),phy,psha,p,'work/'+phy,json.dumps({'kind':'known_delivered_custody_map','intentional_original_absence':bool(r.get('original_absent') or r.get('physical_original_present') is False),'decompressed_verified_in_original_receipt':r.get('verified_decompressed_sha256')==sha or r.get('verified_before_unlink') is True})));maprows+=1
c.commit()
print(json.dumps({'precise_special_types':count,'main_baseline_blob_matches':baseline_matches,'custody_maps':len(map_paths),'custody_map_rows':maprows},ensure_ascii=False))
c.close()
