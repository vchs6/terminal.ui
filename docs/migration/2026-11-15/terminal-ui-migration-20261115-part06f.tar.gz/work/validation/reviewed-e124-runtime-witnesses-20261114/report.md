Preserved exactly the three indexed reviewed e124 runtimes before bundle can replace BIN: d139_composition_final14fe829c, d139_bundle_final5e504099 and d139_recoveryd4cbccd2. All59,009,472 original bytes remain in17,083,039 deterministic gzip bytes (mtime0, no filename). Full indexed SHA/length and metadata matched each still-present original before unlink; each gzip passed full decompression proof before unlink and again afterward. Sole original entries were unlinked only after fsync/verification and fresh no-holder proof.

Actual allocated recovery41,938,944B (40.00 MiB); completion free201,125,888B (191.81 MiB). No extra executable copies or other file removals.

Fresh guard was limited to exact three payloads and43 relevant immutable index/raw/config/CJP/mapping/native-helper paths. Index-e124 remains e7c0fd43fd28b936ee5a67f7c8e4a52dffa1eca5e7b9f7931da5ad2c00b3e90d. Relocated CJP artifacts/cjtui-e124.cjp188002B/SHA8576 remains exact through unchanged location-map SHA d4c1d813267368e5cbd9ec993d6a8d46676b969c6fccd81e600948e55aad5c03. Native terminal-size helper16368B/f726922b remains exact. Raw logs and264298B recovery manifest were hash-guarded; prior1797-binding review proof was reused, not recursively rehashed. Immutable product e124 commit/tree bytes and main configuration stayed unchanged. Current author source edits/main HEAD/tree were intentionally excluded; no source or main writes occurred. No cache/native/CJP/source authority loss or broad role scan occurred.

Original index/receipts remain historical logical path references; progress.json records exact payload/metadata and compressed hashes, and e124-storage-map.json distinguishes ELF gzip representation from the earlier CJP relocation. Mode/uid/gid/mtime are recoverable; inode/ctime are historical only. Storage migration adds no product acceptance/test execution claim.

Safe restore with space for one original:

```sh
python3 /workspace/work/validation/reviewed-e124-runtime-witnesses-20261114/restore.py ORIGINAL_ABSOLUTE_BIN_PATH
```

The helper verifies gzip/original SHA+bytes, refuses existing destinations, restores metadata and atomically publishes without overwrite. Witnesses remain intact. Process proof had no task holders/unexpected denial; only six documented unrelated service exclusions (670 zombies skipped). Bundler may proceed after root GO because original runtime bytes are now safely retained.
