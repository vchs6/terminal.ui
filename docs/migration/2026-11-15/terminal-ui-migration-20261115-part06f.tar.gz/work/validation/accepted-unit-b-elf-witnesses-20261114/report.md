Losslessly migrated exactly six ended B129 author ELF artifact pins (not CJP) from sealed index2d1602314fd6eb7452048448ba39019246d93d73ba49d7edadb42ecd7af66c88 into private deterministic gzip witnesses (mtime0, no filename). All 114,845,240 original bytes remain recoverable from 33,205,597 compressed bytes. Each witness passed full decompression SHA/length proof against the indexed original and physical original before individual nonfollowing unlink; all six were verified again at completion.

Allocated recovery: 81,653,760 bytes (77.87 MiB). Observed net free recovery from the prepared-state baseline: 78,581,760 bytes after later receipt overhead. Completion free: 203,513,856 bytes (194.09 MiB).

All 8,985 other author/publication files stayed exact, including source/native/raw/config/CJP, original immutable author index/reports, and the entire published docs/reviews/R24/B. Main97a160e1 HEAD/tree/config and exact historical source Git objects stayed unchanged; unrelated worker refs were outside the guard. The two independent131 ELFs remain physical and match sealed executor indexdef84e323b1bd40c59b5f54b5965282a4311e00bf5758e92bb5f349613fd89c1; the author CJP remains physical and exact. Active133/SDK/cache/other runtimes were untouched. No huge witness was published.

Publication-time physical pin checks remain valid historical snapshots; they are not current physical-presence claims after this migration. Original sealed indices/reports/publication were not rewritten. Current-nine-artifact-status.json explicitly records six local compressed author artifacts, two physical independent artifacts and one physical CJP. progress.json maps original absolute logical paths to witnesses and original SHA/bytes/mode/uid/gid/mtime/current absent physical state. Original inode/ctime are historical only. This representation migration changes no executable bytes or test results.

Restore without overwrite, with room for one decompressed original:

```sh
python3 /workspace/work/validation/accepted-unit-b-elf-witnesses-20261114/restore.py /absolute/original/path
```

The helper verifies witness and original SHA/length, restores mode/uid/gid/mtime, refuses existing destinations, and publishes through an exclusive temporary file and atomic nonoverwriting link. Witnesses remain intact. Fresh process proof found no exe/fd holders or unexpected task denials; only the six documented unrelated container services were excluded (632 zombies skipped).
