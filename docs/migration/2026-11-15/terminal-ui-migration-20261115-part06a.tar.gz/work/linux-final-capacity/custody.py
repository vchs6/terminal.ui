import os, stat, json, hashlib, gzip, sys, time
from pathlib import Path

BASE = Path('/workspace/work/linux-final-capacity')
SOURCES = {
 'C': ('color-execution/repo','187e126fc20b13a4f5526a28a9189cc0acb4037f'),
 'L': ('layout-implementation/repo','09773a4de01b2b32f6a80ab9a7cdd001cdb58ea8'),
 'R': ('rich-text-implementation/source','91c22f82adcd2412d9509b9872ff63450ba81af9'),
 'T': ('rich-text-regression-tests/source','cc556f4e4548c51c3d99e5a06768e61b41932d75'),
 'W': ('widgets-composite-tests/final/source','e59d5c9fe8493c9ceadc9861fd865d933fe70450'),
}
DATA = '''C examples/colors 1587476 15619784 15622144 4538749 3da6dc0aeb03086c1d724827f172d5e5c502c7260030cb824be820af2d5dc612
C examples/layout 1582874 15614688 15618048 4536069 094b4d1a8c85bac49f35b190c6954b1655f87c1bc631f4c65e7f130475d658a6
C examples/minimal 1587700 15607008 15609856 4533559 e97d4512a2e6a2fbda9f7947ca761a340b987ed6170133e3b5f8819aa1e1192a
C tests/application-lifecycle 1583074 15606240 15609856 4534443 95fe64c230435d46ed10c54f6d8bf5571fe203220bd23e837f1af897306f0fc8
C tests/colors/session 1587375 15623608 15626240 4540435 10cfe76388e3cdb4baf799272e191962827422dbcbed7fe96e16da587d27c594
C tests/colors 1587176 15692176 15695872 4564634 b08f4febfcf32f5e605973cb0caef884c63090d0a7d897c7c12dc50238ece6e4
C tests/contract 1586667 15672560 15675392 4557456 b6a98ee65568b14f78fab56350334c9ea862d4c7c9d7fb6e5702964945676837
C tests/coordinate-boundary 1586778 15609776 15609856 4535019 2f3b1f609117f450ae807398ceaca6be2fcff981c6122d7ed803e04da036764c
C tests/decoration 1587014 15657888 15659008 4557370 b650a9b62f775f556ca320579f91f2681a5844c801dc8f852b4c5e01df3411e3
C tests/integration/fixture 1586899 15608000 15609856 4534243 52bdcb1f2663fddbe632df01458acfc956a78a8d1bf6916b0a6e3cb3269e4b6e
C tests/layout 1586974 15709048 15712256 4561051 feedeaa94d948af3451e28169719bc0a8a61ef4ae2e8b9fe4fee984e054e2d02
C tests/native-smoke 1586522 15605608 15605760 4535139 ee7effb67e0f73156143fac9ff7f19b40b9a89eb903b3abf666197203b452535
L tests/contract 1342760 15571176 15572992 4526582 0068fe8172f929f88c7b9bca8a4826dd6e74eb7b4e63f514157b22f73d57435d
L tests/coordinate-boundary 1343625 15508424 15511552 4507989 a5066b341a873b2e74e1f1ecd25592a5493f0a8773afcf32d2c6de378c3076d5
L tests/integration/fixture 1344020 15506680 15507456 4506888 e28719d0c600a4e1772c4015733b675f187a748d7a799835593a99f1ea93883b
L tests/layout 1342801 15607712 15609856 4529802 dd9c9e5ac743e2e77754bc44c6bd5bb8f8723f70cb65fef90655be4c86f89762
L tests/native-smoke 1343421 15509432 15511552 4508377 b3813f32aeff3971163ebbca711cff9ca6bd528cbff9d3dc63f05c71a96eabf4
R tests/runtime/macros 796248 16430832 16433152 4780265 70794acafa4a584a738cba11718e7d9dff62168307c517a8423db8a9b3f831de
T tests/rich-text 825631 16759120 16760832 4899535 443d3d4ce2828c7d2703c31c5e6647593b5000e285caf39e4de47233836db17f
W tests/widgets_composite/prerequisite 1139030 19041832 19042304 5500148 f09aac6d9e6e3ce6979002ed040cdf24c2abedc02eb953f568756399e2a37a3d'''

def sha_file(path, opener=open):
 h=hashlib.sha256();n=0
 with opener(path,'rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return h.hexdigest(),n

def durable_json(path,obj):
 with open(path,'x') as f:
  json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(path.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)

def identity(row):
 s=os.lstat(row['path'])
 assert stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==448
 for key,value in [('dev',s.st_dev),('inode',s.st_ino),('uid',s.st_uid),('size',s.st_size),('allocated',s.st_blocks*512),('nlink',s.st_nlink)]:
  assert row[key]==value,(row['path'],key,value,row[key])
 assert sha_file(row['path'])==(row['sha256'],row['size'])
 return s

def proc_scan(rows):
 paths={r['path'] for r in rows};ids={(r['dev'],r['inode']) for r in rows}
 pids=[p for p in os.listdir('/proc') if p.isdigit()];assert len(pids)<=8192
 result={'pid_count':len(pids),'zombies':0,'fd_read':0,'maps_read':0,'limits':[],'matches':[],'workloads':[]}
 for pid in sorted(pids,key=int):
  b='/proc/'+pid
  try:
   status=open(b+'/status').read();state=next(x for x in status.splitlines() if x.startswith('State:'))
   if '\tZ' in state:result['zombies']+=1;continue
   comm=open(b+'/comm').read().strip()
   cmd=open(b+'/cmdline','rb').read(65536)
   if comm in ['cjc','cjpm','main','clang','ld','lld']:
    result['workloads'].append({'pid':pid,'comm':comm})
   try:
    exe=os.readlink(b+'/exe')
    if exe in paths:result['matches'].append({'pid':pid,'kind':'exe','path':exe})
   except PermissionError:pass
   for kind in ['fd','maps']:
    try:
     if kind=='maps':
      with open(b+'/maps') as f:
       for line in f:
        if any(p in line for p in paths):result['matches'].append({'pid':pid,'kind':kind,'line':line.strip()})
      result['maps_read']+=1
     else:
      fds=os.listdir(b+'/fd');assert len(fds)<=8192
      for fd in fds:
       try:
        s=os.stat(b+'/fd/'+fd)
        if (s.st_dev,s.st_ino) in ids:result['matches'].append({'pid':pid,'kind':kind,'fd':fd})
       except FileNotFoundError:pass
       except PermissionError:result['limits'].append({'pid':pid,'comm':comm,'kind':'fd-stat'})
      result['fd_read']+=1
    except PermissionError:result['limits'].append({'pid':pid,'comm':comm,'kind':kind})
    except (FileNotFoundError,ProcessLookupError):pass
  except (FileNotFoundError,ProcessLookupError):pass
 assert not result['matches'] and not result['workloads'],result
 # Visibility limits are restricted to identifiable, unrelated platform processes.
 allowed={'tail','cloud-agent-log','caas-prefix-tra','runuser','rootlesskit','exe','slirp4netns','dockerd','containerd','codex','cloud-agent-des','cloud-agent-bro','sites-preview','cloud-agent-mcp','Xorg','xterm','dbus-run-sessio','dbus-daemon','xfce4-terminal','at-spi-bus-laun','bash','at-spi2-registr','codex-linux-san','bwrap','python3'}
 assert all(x['comm'] in allowed for x in result['limits']),result['limits']
 return result

def free():
 v=os.statvfs('/workspace');return v.f_bavail*v.f_frsize

if __name__=='__main__':
 rows=[]
 for i,line in enumerate(DATA.splitlines(),1):
  k,stem,ino,size,allocated,gz,sha=line.split();source,head=SOURCES[k]
  rows.append({'id':i,'path':'/workspace/work/'+source+'/'+stem+'/target/release/bin/main','dev':27,'inode':int(ino),'mode':448,'uid':1000,'nlink':1,'size':int(size),'allocated':int(allocated),'sha256':sha,'forecast_gzip_bytes':int(gz),'source_root':'/workspace/work/'+source,'git_head_at_inventory':head,'gzip_path':str(BASE/'gzip'/('%02d.gz'%i))})
 if sys.argv[1]=='inventory':
  for row in rows:identity(row)
  scan=proc_scan(rows)
  durable_json(BASE/'inventory.json',{'provenance':'Current bytes only; no retroactive compiler provenance. Original logical indices unchanged.','root_go':'Exact20 only, received in root agent task message','rows':rows,'sources':SOURCES,'initial_free':free()})
  durable_json(BASE/'proc-before.json',scan)
  lines=['Exact20 read-only inventory; ROOT GO applies only to these candidates.','Original allocated bytes: 317603840; gzip6 stream bytes: 92287753.','Forecast gzip allocated@4KiB: 92332032; net reclaim: 225271808 bytes.','All regular ELF dev27 uid1000 mode0700 nlink1; stat and SHA verified.','Valid owned git/worktree ancestry; source HEAD values in inventory.json.','No candidate in existing three custody plan.json manifests.','Current bytes only; historical compiler provenance not asserted.','Original logical indices remain unchanged; new restore-map provides aliases.','Known live cjc/cjpm/main/clang/ld/lld absent; no candidate FD/maps/exe match.','Finite proc scan capped8192 PIDs/8192FDs per PID; zombies skipped.','Unrelated nondumpable platform FD/maps limits recorded fully in proc-before.json.','Prior snapshot3665 PIDs:3631 maps readable,28 FDdirs readable,zero matches.','Prior workload-name matches29 were all zombies; no live workload found.','No source/raw/SDK/cache/sharedlib/archive changes authorized.','Additional hint roots are outside this GO; no expansion permitted.','Build capacity policy: abort64MiB/warn30MiB/hardstop12MiB; no restart.']
  with open(BASE/'inventory-report.txt','x') as f:f.write('\n'.join(lines)+'\n');f.flush();os.fsync(f.fileno())
  print(json.dumps({'status':'materialized','inventory_sha256':sha_file(BASE/'inventory.json')[0],'free':free()}))
 elif sys.argv[1]=='migrate':
  inv=json.load(open(BASE/'inventory.json'));assert inv['rows']==rows
  (BASE/'gzip').mkdir(mode=0o700);(BASE/'receipts').mkdir(mode=0o700)
  start=free();receipts=[]
  for row in rows:
   assert free()>64*1048576
   before=identity(row);scan=proc_scan(rows)
   archive=Path(row['gzip_path'])
   with open(archive,'xb') as out:
    with gzip.GzipFile(filename='',mode='wb',fileobj=out,compresslevel=6,mtime=0) as z:
     with open(row['path'],'rb') as f:
      while b:=f.read(1048576):z.write(b)
    out.flush();os.fsync(out.fileno())
   fd=os.open(archive.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
   assert archive.stat().st_size==row['forecast_gzip_bytes']
   assert sha_file(archive,gzip.open)==(row['sha256'],row['size'])
   after=identity(row);assert before.st_mtime_ns==after.st_mtime_ns
   scan2=proc_scan(rows)
   receipt={**row,'gzip_sha256':sha_file(archive)[0],'gzip_bytes':archive.stat().st_size,'gzip_allocated':archive.stat().st_blocks*512,'mtime_ns':before.st_mtime_ns,'gid':before.st_gid,'verified_decompressed_sha256':row['sha256'],'verified_decompressed_bytes':row['size'],'proc_before':scan,'proc_before_unlink':scan2,'verification_time_ns':time.time_ns(),'provenance':'Current bytes only; original logical evidence indices unchanged; archive alias recorded here.'}
   durable_json(BASE/'receipts'/('%02d-verified-before-unlink.json'%row['id']),receipt)
   os.unlink(row['path']);fd=os.open(Path(row['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
   durable_json(BASE/'receipts'/('%02d-unlinked.json'%row['id']),{'id':row['id'],'path':row['path'],'absent':not os.path.lexists(row['path']),'time_ns':time.time_ns()})
   receipts.append(receipt);print('migrated',row['id'],flush=True)
  total_old=sum(r['allocated'] for r in rows);total_gz=sum(r['gzip_allocated'] for r in receipts)
  durable_json(BASE/'restore-map.json',{'format':1,'provenance':'Lossless current-bytes custody only; original logical indices unchanged.','restore_helper':str(BASE/'restore.py'),'rows':receipts,'original_allocated':total_old,'gzip_allocated':total_gz,'net_file_reclaim':total_old-total_gz,'free_before':start,'free_after':free()})
  print(json.dumps({'status':'complete','count':len(receipts),'reclaim':total_old-total_gz,'free':free(),'restore_map_sha256':sha_file(BASE/'restore-map.json')[0]}))
