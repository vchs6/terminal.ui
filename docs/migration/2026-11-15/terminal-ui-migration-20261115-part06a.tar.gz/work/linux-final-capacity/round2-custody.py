import sys
sys.dont_write_bytecode=True
import importlib.util,os,stat,json,subprocess,gzip,hashlib,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('prior','/workspace/work/linux-final-capacity/custody.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
BASE=Path('/workspace/work/linux-final-capacity/round2')
ROOTS=['overlay-tests','viewport-tests','glyph-tests-refresh','rich-text-tests','layout-tests']
def write(name,obj):prior.durable_json(BASE/name,obj)
class Sink:
 def __init__(self):self.size=0
 def write(self,b):self.size+=len(b);return len(b)
 def flush(self):pass
def inventory():
 BASE.mkdir(mode=0o700)
 candidates=[];skipped=[]
 for root in ROOTS:
  for d,ds,fs in os.walk('/workspace/work/'+root):
   ds[:]=[x for x in ds if x not in ['.git','cache','raw','artifacts','.cjpm','sdk','SDK']]
   if not d.endswith('/target/release/bin'):continue
   for f in sorted(fs):
    p=d+'/'+f;s=os.lstat(p)
    if not(stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_mode&0o111):continue
    with open(p,'rb') as h:
     if h.read(4)!=b'\x7fELF':continue
    source=d
    while source!='/' and not os.path.lexists(source+'/.git'):source=os.path.dirname(source)
    proof=subprocess.run(['git','-C',source,'rev-parse','--show-toplevel','--absolute-git-dir','HEAD'],capture_output=True,text=True)
    if proof.returncode:
     skipped.append({'path':p,'reason':'No valid owned git/worktree ancestry; no original build receipt sought; ambiguity skipped','inode':s.st_ino,'allocated':s.st_blocks*512});continue
    fields=proof.stdout.splitlines()
    if len(fields)!=3 or fields[0]!=source or any(os.lstat(x).st_uid!=1000 for x in [source,source+'/.git',fields[1]]) or s.st_nlink!=1 or stat.S_IMODE(s.st_mode)!=448:
     skipped.append({'path':p,'reason':'Ownership/mode/link/source ancestry ambiguity'});continue
    candidates.append({'path':p,'dev':s.st_dev,'inode':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'size':s.st_size,'allocated':s.st_blocks*512,'mtime_ns':s.st_mtime_ns,'source_root':source,'git_proof':fields,'sha256':prior.sha_file(p)[0]})
 candidates.sort(key=lambda r:(ROOTS.index(r['path'].split('/')[3]),r['path']))
 assert len(candidates)<=40
 for i,row in enumerate(candidates,1):
  row['id']=i;row['gzip_path']=str(BASE/'gzip'/('%02d.gz'%i));prior.identity(row)
  sink=Sink()
  with gzip.GzipFile(filename='',mode='wb',compresslevel=6,mtime=0,fileobj=sink) as z:
   with open(row['path'],'rb') as f:
    while b:=f.read(1048576):z.write(b)
  row['forecast_gzip_bytes']=sink.size;prior.identity(row)
 scan=prior.proc_scan(candidates)
 write('inventory.json',{'root_go':'Separate round2 exact five roots; max40; stop free>=700MiB or exhausted','scope':ROOTS,'rows':candidates,'skipped':skipped,'provenance':'Current bytes only; no historical compiler provenance; original indices unchanged','free_before':prior.free(),'forecast_original_allocated':sum(r['allocated'] for r in candidates),'forecast_gzip_bytes':sum(r['forecast_gzip_bytes'] for r in candidates)})
 write('proc-before.json',scan)
 with open(BASE/'report.txt','x') as f:
  f.write('\n'.join(['Round2 separate ROOT GO: exact five roots only; max40; stop free>=700MiB or exhausted.',f'Qualified {len(candidates)} owned regular ELF executables; skipped {len(skipped)} ambiguous non-git outputs.','Every qualified original stat and SHA checked; exact stream gzip6 forecast in inventory.json.','All source/git/worktree metadata owned1000; git HEAD current source ancestry only.','Known live workload absence and candidate FD/maps/exe scan passed.','Bounded proc8192 PIDs/8192 FDs each; unrelated platform nondumpable limits in proc-before.json.','Full process limits repeated in each verified-before-unlink receipt.','Previous20 custody immutable; no source/raw/cache/SDK/sharedlib/nativearchive changes.','Original logical indices unchanged; new gzip aliases and restore helper in this directory.','Current bytes preservation only; no retroactive historical compiler provenance.'])+'\n');f.flush();os.fsync(f.fileno())
 print(json.dumps({'qualified':len(candidates),'skipped':len(skipped),'inventory_sha256':prior.sha_file(BASE/'inventory.json')[0]}),flush=True)

def migrate():
 inv=json.load(open(BASE/'inventory.json'));rows=inv['rows'];(BASE/'gzip').mkdir(mode=0o700);(BASE/'receipts').mkdir(mode=0o700);receipts=[]
 for row in rows:
  if prior.free()>=700*1048576:break
  assert prior.free()>64*1048576
  before=prior.identity(row);scan=prior.proc_scan(rows);archive=Path(row['gzip_path'])
  with open(archive,'xb') as dest:
   with gzip.GzipFile(filename='',mode='wb',compresslevel=6,mtime=0,fileobj=dest) as z:
    with open(row['path'],'rb') as source:
     while b:=source.read(1048576):z.write(b)
   dest.flush();os.fsync(dest.fileno())
  fd=os.open(archive.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
  assert archive.stat().st_size==row['forecast_gzip_bytes']
  assert prior.sha_file(archive,gzip.open)==(row['sha256'],row['size'])
  after=prior.identity(row);assert before.st_mtime_ns==after.st_mtime_ns==row['mtime_ns']
  scan2=prior.proc_scan(rows)
  receipt={**row,'gzip_sha256':prior.sha_file(archive)[0],'gzip_bytes':archive.stat().st_size,'gzip_allocated':archive.stat().st_blocks*512,'verified_decompressed_sha256':row['sha256'],'verified_decompressed_bytes':row['size'],'proc_before':scan,'proc_before_unlink':scan2,'verification_time_ns':time.time_ns(),'provenance':'Current bytes only; original logical indices unchanged; this receipt is durable restore alias before unlink.'}
  write('receipts/%02d-verified-before-unlink.json'%row['id'],receipt)
  os.unlink(row['path']);fd=os.open(Path(row['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
  write('receipts/%02d-unlinked.json'%row['id'],{'path':row['path'],'absent':not os.path.lexists(row['path']),'time_ns':time.time_ns()})
  receipts.append(receipt);print('migrated',row['id'],flush=True)
 write('restore-map.json',{'format':1,'provenance':'Current bytes only; original logical indices unchanged. Previous custody immutable.','restore_helper':str(BASE/'restore.py'),'rows':receipts})
 entries=[]
 for r in receipts:
  assert not os.path.lexists(r['path']);assert prior.sha_file(r['gzip_path'])[0]==r['gzip_sha256']
  rr=[]
  for suffix in ['verified-before-unlink','unlinked']:
   p=BASE/'receipts'/('%02d-%s.json'%(r['id'],suffix));rr.append({'path':str(p),'sha256':prior.sha_file(p)[0]})
  entries.append({'id':r['id'],'original':r['path'],'gzip_path':r['gzip_path'],'gzip_sha256':r['gzip_sha256'],'receipts':rr})
 write('receipt-index.json',{'restore_map_sha256':prior.sha_file(BASE/'restore-map.json')[0],'rows':entries})
 summary={'count':len(receipts),'scope_exhausted':len(receipts)==len(rows),'skipped':inv['skipped'],'original_bytes':sum(r['size'] for r in receipts),'original_allocated':sum(r['allocated'] for r in receipts),'gzip_bytes':sum(r['gzip_bytes'] for r in receipts),'gzip_allocated':sum(r['gzip_allocated'] for r in receipts),'net_file_reclaim':sum(r['allocated']-r['gzip_allocated'] for r in receipts),'free_after':prior.free(),'receipt_index_sha256':prior.sha_file(BASE/'receipt-index.json')[0],'restore_map_sha256':prior.sha_file(BASE/'restore-map.json')[0]}
 write('completion.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='skipped'}))
if __name__=='__main__':
 if sys.argv[1]=='inventory':inventory()
 elif sys.argv[1]=='migrate':migrate()
