# Actual current source and old member verification

Fixed scope: 62,422 catalog nodes / 353,182,240 bytes in `historical_exact_locator_source_SHA_pending`. Actual stable current source hashes: 62,271 nodes / 353,037,460 bytes, one source pass; zero catalog stat drift.

Closed current physical nodes: **62,238 / 348,096,121 bytes**.

- PASS_actual_source_and_recoverable_bytes: 54,996 nodes; 269,370,548 catalog bytes; 269,370,548 actual bytes.
- closed_current_curated_node: 7,242 nodes; 78,725,573 catalog bytes; 78,725,573 actual bytes.
- locator_pending: 33 nodes; 4,941,339 catalog bytes; 4,941,339 actual bytes.
- policy_excluded: 151 nodes; 144,780 catalog bytes; 0 actual bytes.

The separately closed current curated nodes have exact SHA/size equality with an actual recoverable member/blob. This closes only that physical node; it does not close another raw original or lineage path.

Actual recovery: 78 distinct a5 Git shards; 78 initial streaming passes plus two authorized new-target passes, 76,547,548 compressed bytes read. 60,636 unique target members / 330,005,299 bytes hashed, plus 617 direct Git copy blobs / 15,456,112 bytes. All compressed Git blob identities and gzip CRC/EOF checked. 125 baseline metadata inputs and 26 archive-v1 manifests verified. Source/metadata/shard errors: 0/0/0.

The supplementary passes measured only the 327 new R17/R22 targets (1,860,161 bytes) and closed 327 nodes. No source or old target payload was rehashed.

- locator_pending / copy_path_not_found_in_baseline_direct_blob_or_explicit_archive_member_map: 26.
- locator_pending / historical_exclusion_marker_is_not_an_archive_member: 7.

Seven `excluded-generated-runtime` labels are historical exclusion markers rather than real members. Exact paths, source SHA, and erroneous locator are listed in summary.json; they remain pending. One missing alternative member does not block a source with another measured valid locator.

151 environment-material paths were excluded. No authentication/Git metadata or forbidden source path was opened, and no source symlink component was traversed. No body values were printed, old index/database changed, public raw-log package created, build/VM/network/upload used, or child agent spawned. Detail records remain in RAM and are bound by artifact SHA/size in summary.json.

This is bounded current-node byte recovery evidence, not whole migration, group 6/group 7 completion, or Linux acceptance.
