# terminal.ui 旧归档缺口补传清单

33 个固定待定位原件中，新增候选 30 个、297,647 字节。06m 已有精确恢复证据 2 个、4,464,544 字节。暂挂 1 个、179,148 字节。 [逐项清单](queue.json)

- 新增候选含 26 份历史日志、4 份静态库和 0 份仓颉源码包。前次核验缺少这些原路径的已测恢复位置。
- 逐项读取普通文件，并与旧记录核对 SHA-256、字节数、原 POSIX 权限模式和纳秒修改时间。目录和文件打开时禁止跟随符号链接，并核对读取前后的文件身份及元数据。清单的归档路径以 work/ 开头，保留源目录下的原相对路径。
- 日志扫描涵盖常见服务凭据、私钥、认证头、URL 内凭据、口令赋值和环境转储形态。四份静态库核对 ar 结构、预期对象名和 x86-64 ELF 可重定位对象类型，并对原始字节检查常见凭据特征。排队项均未命中本轮扫描规则。
- libboundscheck.so 和 libcangjie-runtime.so 的大小及 SHA-256 匹配 06m1–06m3 固定输入支持的 SDK 独立恢复。两项的原位置及 0700 权限由该证据覆盖。纳秒修改时间保存在清单中，仍需依清单恢复。
- 本轮交付清单和核验报告。实际归档、接收端验收、其余迁移分类及 Linux 功能验收需各自的完成证据。

## 暂挂项

- work/theme-showcase-implementation/source/target/cjtui-0.0.0.cjp，原因 credential_or_environment_pattern。

## 核验记录

- [旧成员核验摘要](../migration-old-members-verify/summary.json)
- [06m 联合核验](../migration-part06m3/findings.json)
- [SDK 及 stdx 独立恢复再审](../migration-sdk-proof-review/revision-review/findings.json)
- [固定 SDK 成员身份](../migration-sdk-proof-revision/proposal.json)
