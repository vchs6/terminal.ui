package widgets_shape_consumer
import cjtui.*
func existingAxisConsumer(): ScrollAxes {
    let value: ScrollAxes = Horizontal
    value
}
