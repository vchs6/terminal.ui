// SHAPE ONLY: no product behavior is implemented.
package cjtui

public enum SurfaceMode { | Transparent | Opaque }
