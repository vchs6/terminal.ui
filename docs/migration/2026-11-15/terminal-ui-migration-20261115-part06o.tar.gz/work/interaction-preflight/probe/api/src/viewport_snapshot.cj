// SHAPE ONLY: no product behavior is implemented.
package cjtui

public struct ViewportSnapshot {
 public let width: Int64
 public let height: Int64
 public let contentWidth: Int64
 public let contentHeight: Int64
 public let offsetX: Int64
 public let offsetY: Int64
 public let axes: ScrollAxes
 init() { width=0; height=0; contentWidth=0; contentHeight=0; offsetX=0; offsetY=0; axes=ScrollAxes.Off }
}
