# Ended TASK027 producer target recovery

Source HEAD: `954d7492b91c2f490dcb15d2d42190af5dbe52ae`. Build-v3 completed; compiler/linker process check was empty before and after. Product ELF SHA-256: `92dd71989fe12658477dc9aceef8a62c633318f74d99bcc336aed62ce0398bb5` before and after. Product index is unsealed and task owner attested no `.a`/`.cjo` pins.

Removed 62 regular, single-link `.a`/`.cjo` files exclusively under `/workspace/work/theme-showcase-implementation/source/examples/theme_showcase/target`; 32,411,436 logical bytes and 32,546,816 allocated bytes. Each path, inode, size, and SHA-256 was checked before unlinking. All preserved producer evidence files, gzip map entries, and ELF have identical before/after metadata and hashes. Source, native products, metadata, configuration, SDK, and evidence remained in place.

Free bytes: 14,557,184 before; 47,087,616 after. Eight MiB floor: 8,388,608. Receipt index: `/workspace/work/validation/ended-027-producer-targets-prebundle-20261114.receipt-index.json`. Raw receipts are gzip files listed there. Source owner build remains on hold until root GO.
