# Ended TASK010 formal-test author target reclaim — 2026-11-14
Status: PASS; resource only; no builds/tests/source edits/push.
Reclaimed 32550912 allocated bytes (32413804 logical) from 62 intermediates.
Free before: 112934912; after receipt creation: 143966208 bytes (shared filesystem).
Only visible-snapshot-formal-tests/source/tests/visible_snapshot/target affected; source/target absent.
Fresh qualification: 69 scoped role metadata files; all 236 indexed bindings validated; no target process users.
Pinned candidate references skipped: 0; ELF/main/.so/CJP/native outside targets/cache/SDK/config/raw/source retained.
Author index cc495d55…853d4 and direct binary a127d3c0…93908 preserved.
All 305 protected target/reference/evidence files, including failed and green artifacts, preserve SHA256/inode/mtime/mode.
Git HEAD/index stages/full dirty and untracked status preserved; no directories removed.
Preservation bounded to affected targets, concrete index references, and own evidence; no other worktree rescan.
Receipts: ended-010-author-targets-20261114.{before,deletion,after}.json.gz.
Receipt index: ended-010-author-targets-20261114.receipts.json records compressed/raw SHA256 and bytes.
