from pathlib import Path
import hashlib,json,re,datetime,subprocess
root=Path('/workspace/work/resize-root-cause');repo=Path('/workspace/work/terminal.ui')
original=Path('/workspace/work/runtime-execution/evidence/lifecycle-raw/resize-success/session.raw').read_bytes()
expected=b'\x1b[0m\x1b[1;1HCJTUI_LI\x1b[2;1H01234567\x1b[3;1H        \x1b[0m'
results={}
for name in ['atomic-mixed','stty-intermediate','write-inflight','inflight-coherent']:
    raw=(root/'raw'/name/'session.raw').read_bytes(); final=raw[-len(expected):]
    rows=[]
    for m in re.finditer(rb'\x1b\[(\d+);1H([^\x1b]*)',final): rows.append(m.group(2).decode())
    results[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'identical_to_original':raw==original,'final_full_8x3_frame_exact':final==expected,'final_grid':rows}
(root/'raw'/'analysis.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
paths=[repo/'src/application.cj',repo/'native/cjtui_terminal.c',repo/'tests/application-lifecycle/pty.mjs',repo/'tests/application-lifecycle/src/main.cj',repo/'tests/application-lifecycle/native/close_wrap.c',Path('/workspace/work/runtime-execution/source/tests/application-lifecycle/target/release/bin/main')]
paths+=sorted((root/'probes').glob('*'))
(root/'sourcehash.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p)+'\n' for p in paths))
metadata={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixed_head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'requested_model':'Sol/high','actual_serving_model':'not independently verifiable in agent tool surface','systematic_debugging_skill':'c5/systematic-debugging','production_or_formal_test_edits':False,'subagents_spawned':False,'source_sdk':'/workspace/work/validation/sdk/cangjie/envsetup.sh','sdk_used_to_build_product':False,'stty_version':subprocess.check_output(['stty','--version'],text=True).splitlines()[0],'strace_version':subprocess.check_output(['strace','--version'],text=True).splitlines()[0],'executions':{'stty_ioctls.py':{'driver_exit':0,'stty_exit':0},'atomic_mixed.py':{'driver_exit':0,'strace_supervisor_exit':0,'app_exit':0},'stty_intermediate.py':{'driver_exit':0,'stty_exit':0,'app_exit':0},'inflight_coherent.py':{'driver_exit':1,'strace_supervisor_exit':-9,'app_exit':None,'outcome':'negative probe; no dirty work at gated second query, so no old repeated frame; expected count3 never occurred; timeout8s; retained without rerun'},'write_inflight.py':{'driver_exit':0,'strace_supervisor_exit':0,'app_exit':0},'analyze.py':{'driver_exit':0}}}
(root/'raw'/'metadata.json').write_text(json.dumps(metadata,indent=2))
