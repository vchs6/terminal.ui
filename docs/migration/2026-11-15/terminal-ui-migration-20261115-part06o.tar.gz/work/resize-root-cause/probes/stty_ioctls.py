import os,pty,fcntl,termios,struct,subprocess,json,datetime
from pathlib import Path
root=Path('/workspace/work/resize-root-cause/raw'); master,slave=pty.openpty(); tty=os.ttyname(slave)
def size(): return struct.unpack('HHHH',fcntl.ioctl(slave,termios.TIOCGWINSZ,b'\0'*8))
fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',5,24,0,0))
r=subprocess.run(['strace','-ttt','-yy','-e','trace=ioctl','-o',str(root/'stty.syscalls'),'stty','-F',tty,'rows','3','cols','8'],capture_output=True)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tty_owned_by_probe':tty,'initial_rows_cols':[5,24],'final':size(),'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}; (root/'stty.json').write_text(json.dumps(d,indent=2)); print(json.dumps(d)); print((root/'stty.syscalls').read_text()); os.close(slave);os.close(master)
