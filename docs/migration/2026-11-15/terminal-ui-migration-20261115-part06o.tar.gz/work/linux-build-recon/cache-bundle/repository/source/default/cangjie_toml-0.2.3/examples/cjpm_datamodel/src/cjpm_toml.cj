package cjpm_datamodel

import serialization.serialization.*
import cangjie_toml.cangjie_toml.*

func cjpmToml() {
    println("cjpm.toml:")
    // 解析 cjpm.toml 文件
    let dm = DataModel.fromTomlFile("cjpm.toml")

    let root = (dm as DataModelStruct).getOrThrow()
    // 解析 [dependencies]
    let dependencies = (root.get("dependencies") as DataModelStruct).getOrThrow()
    println("dependencies:")
    for (d in dependencies.getFields()) {
        let data = (d.getData() as DataModelStruct).getOrThrow()
        let git = (data.get("git") as DataModelString).getOrThrow().getValue()
        println("  ${d.getName()}: git = ${git}")
    }
    // 解析 [package]
    let pkg = (root.get("package") as DataModelStruct).getOrThrow()
    // package.cjc-version
    let cjcVersion = (pkg.get("cjc-version") as DataModelString).getOrThrow().getValue()
    // package.name
    let name = (pkg.get("name") as DataModelString).getOrThrow().getValue()
    println("cjc-version: ${cjcVersion}")
    println("name: ${name}")
    // 输出:
    // dependencies:
    //   cangjie_toml: git = https://gitcode.com/PermissionDog/cangjie_toml
    // cjc-version: 0.59.6
    // name: cjpm_datamodel
}