# TASK149 product implementation brief — admission waits root084 acceptance

Read first this brief, then exact formal design/specs openspec/changes/implement-session-extensions (S001–S012 including later repeat-restore clarification), AGENTS, engineering conventions. No redesign: execution of authorized finite Session extensions. Root will supply accepted BASE after084. Formal test-only original4093a7ab146f01ac60e0e447a487eaac55f82677 integratedc24f796 tests/session_extensions; never modify formal tests. Independent preflight /workspace/work/session-preflight design_reviewed. All full148 tests source already exists, use its README actual commands, not imagined commands. Runtime080 accepted, Rich084 root will confirm, default conservative glyph fix integrated. Session149 does not require Theme/Interaction A; no public-input/paint behavior added here.

Independent Sol/high (language-suitable) author /workspace/work/session-extension-implementation/source, report /workspace/work/session-extension-implementation/task-149-report.md. No subagents, no main/status edits. Isolated clone/branch, fixed BASE/test/contract/source+dep hashes. One entity/type/file following Cangjie package conventions. Read /workspace/work/CangjieSkills/.agents/skills/cangjie-coding/SKILL.md and only relevant cangjie-rules; use SDK1.2 and installed skills TDD/executing-plans/verification. Development tests are not independent acceptance. Root will review product-only diff through separate roles.

Public signatures/byte formulas/defaults/limits/context/order/deep-copy/title scopes exactly S002–S012. No second writer/runtime/queue/ANSI/Unicode engine; extend existing ownership/native I/O. Base64 minimal bounded RFC4648 encoder explicitly approved after SDK absent stdx check, not a new dependency. Strict UTF8 first invalid byte offset, title C0/DEL/C1 rejection, copy data escaped by Base64. No queries/OSC1/icon imitation/shell/host permission guessing. Current OSC complete write ONLY SentUnconfirmed, never Applied or fake confirmation. Cap declarations are not runtime evidence. Preserve existing nullable None compatibility and all existing API.

S008 must extend unique native writer accurate Int64 emitted count and process-global partial-outputUnsafe latch for every screen and extension write; any write failure stops run and preserves first error, partial failure forbids ALL subsequent device output and reopen in process even after close. Native resource cleanup must always run silently. Zero-byte failure stops run but afterclose may reopen. Prewrite encoding/allocation/argument unsupported failures healthy nonfatal. Do not blindly CAN/ST/reset/restore unsafe stream. Title ledger one push scope, validate/allocate save+set before writing, failed save no set, repeated restore after completepop NoSavedTitle/NotNeeded/no bytes, close no duplicatepop. Deep defensive copies include nested steps. Cleanup aggregation retains primary and all independentcleanup errors.

Actual scopes/tests: formal148 normalconsumer + native fault offsets/harness; affected existing core/lifecycle/post/runtime/colors/capabilities as source impact selects. Don't repeat unchanged cold tests just for role (AGENTS11.1 exactsource/deps/env/config/scope), preserve every failure and distinguish facility defects vs product. Normal build + direct binary (cjpm run masks exit), normal cjpm bundle includes mandatorylint, clean extract own config+cache normal public consumer. No full releasePASS claim when later composition/benchmark missing. No no-lint bypass/advisory suppression. Actual GUI/VT/mux/SSH independent151 later, author may develop minimal finite fixtures but not claim hostacceptance.

SDK: source /workspace/work/validation/sdk/cangjie/envsetup.sh; own ignored cjpm cache using /workspace/work/validation/replay-dependencies/cache seed and existing registry http://127.0.0.1:18973. No new relay. Product-only commit source/docs/product/examples public minimal example, exclude tests/cache/binaries/SDK/privateSSHkeys. Handoff exact commits, source/runtime/deps SHA manifest, raw commands trueexit/warnings/normalpackage/member proofs/cleanconsumer, concise DONE/DONE_WITH_CONCERNS report. Do not read independentreview/acceptance findings before formally handed back byroot. No productauthor selfacceptance.

## 4. Product Delivery

- [ ] 4.1 TASK-149：在现有Application/session/native writer中实施并提供正常公共消费者；AC-149要求契约结果/字节/状态/清理符合148冻结断言，源码职责与旧路径处置可审，作者自测仅开发证据。

| 字段 | 定义 |
|---|---|
| level / parent / parent_task / type | L3 / WP-004 / TASK-030 / implementation |
| classification / basis | execution；冻结合同确定全部外部语义；SDK不可表达或新架构冲突回主代理定点裁决 |
| requirement_refs / workflow_ref / openspec_change_ref | REQ010、NFR03/04、REQ004失败 / 本tasks / implement-session-extensions#4.1 |
| objective / scope | 单一可选会话扩展交付，按design S010文件职责；不实现编辑器/第二会话/通用宿主图标/额外OS |
| inputs / depends_on | TASK148固定测试；004子合同；当前runtime已验固定整合版本；R10 native恢复围栏；003精确SDK/依赖API |
| preconditions / planning_gaps | 148冻结、独立preflight和共享Application/runtime写屏障解除；149开始前固定base/test/contract SHA；当前未满足，planned |
| deliverables | S010产品源码、docs/product/session.md及README链接、最小公共使用例；native计数与unsafe闩；开发原始命令/消费者/失败证据 |
| acceptance / verification | AC149：copy/title/icon入口正常CJPM消费者可编译；完整发送唯SentUnconfirmed；不query/shell；所有预算零输出拒绝；title一次scope；short write后close与reopen闩；无第二session/runtime；148相关tests及既有R10受影响回归成功 |
| impact / compatibility | Application/runtime/native共享文件，旧public API/颜色/帧行为保留；真实writer故障语义同源一致，不弱化既有可恢复保证 |
| quality_governance | 必要与复杂度见S010；权威writer仍原native；旧路径保留扩展无fallback内核；不增加第三方依赖/用户手动刷新；每类型独立文件 |
| required_skills | OpenSpec apply、using-git-worktrees或批准独立clone、test-driven-development、executing-plans、verification-before-completion；异常时systematic-debugging |
| skill_evidence_refs / decision_refs | 本任务ready及实际执行记录；S001–S010，148固定消费者 |
| risks / blockers / evidence_refs | 共享文件漂移/strict UTF8原生行为；Applied误报/unsafe闩绕过阻断交付；当前无产品证据；status=planned |

L4：149.S1 核固定合同/test/base及共享写屏障，按S010建每类型文件与公开签名，正常CJPM编译；149.S2 在唯一writer增加byte计数与闩并接入同步结果/stop/异常围栏，检查旧writer只有一条；149.S3 实施纯编码/声明快照/title ledger、接入现有post域和cleanup副本；149.S4 跑148及受影响R10回归，固定产品SHA/可运行说明，提交原始证据供独立角色选择，不能自标AC030通过。


S007原文重点：完整push即产生需释放scope，即使随后set零字节失败，也需在安全输出条件下pop配平；不能因S008正常API Cancelled便漏掉安全内部title清理。部分unsafe时仍绝对禁pop并只保留诊断。以正式S007/S008及实际故障证据判断，不以某弱断言缺失当豁免。
