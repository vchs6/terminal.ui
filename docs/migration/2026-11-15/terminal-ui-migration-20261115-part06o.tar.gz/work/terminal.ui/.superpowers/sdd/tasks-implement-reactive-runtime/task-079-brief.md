# TASK079 — independent finite dynamic runtime execution

Read first. Requirements are tasks079/shared Globalconstraints and runtime design4/6 R001–019. Fixed product216b2ab5f2315f4be19467b7e49f4047aec78ab9, integrated5de716f. Formal tests original3ee1a9b plus supplement10c4ee3 (mainc066e99):34 groups. Initial167 reviewFAIL/DYN-F001+formalRED must stay; scoped-r1 review spec/quality PASS authorizes this independent execution. No product-author report/self-assessment input, no formal test/product/contract changes, no agents. Your directory /workspace/work/dynamic-execution.

Clone fixed product216 (has same formal tests via test-pin parent). Own cache and ignored configs for each required consumer, source SDK1.2.0. Existing live registry18973; do not start duplicate. Normal root build/check, formal dynamic34 directbinary true exit, affected A+B core255 and session12PTY, macro-positive, layout/decoration consumers; unchanged macro negative15/directFrame/color-only suites may reuse valid fixed-content evidence with explicit impact proof rather than repeat. Current RuntimeSession changed, so don't reuse old core/lifecycle blindly. Ordinary bundle no lint skips, clean unpack root/native build and same dynamic public consumer only manifest paths changed; product source content compare. Run public dynamic --smoke and actual terminal example. Full bundle checker still lacks future composition/benchmark and must not become a false release claim.

Raw command/cwd/argv/UTC/exit, source/test/deps/SDK/hash, true binary results, expected fault exit semantics, original exact termios/once-only close logs. No copied target/native archives/cache to clean product; normal public dependencies only. Reuse developer raw solely for facts/relevance, not self-assessment. Final onlyPASS if finite obligations actually met; deficiencies explicit. No all-Linux/parent AC closure;080 independent follows.

Actual different hosts: reuse working infrastructure at /workspace/work/runtime-execution/r12-execution-draft/commands/{gui-reactive.sh,execute-gui.sh,gui-key.c,env.sh}, original /workspace/work/runtime-execution environment/provenance, host tools fromR10; adapt only external recorder/driver to unmodified examples/dynamic. Real XTerm398 and XFCE1.1.4/VTE0.80.1, not TERM aliases. Normal public example native direct run, actual keys and resize, untouched original PNGs with versions/config/locale/grid/time/source/binary/hash/exit/restoration/raw. Use valid JSON serialization (oldVTE literalTAB metadata flaw has strict projection R12/acceptance; don't repeat it).

For actual GUI acceptance, use source-declared actions (no new app code needed):
- initial rows: title, declaration description, A,B,C.
- v hides If description: title,A,B,C.
- i then inserts manual before B: title,A,manual,B,C.
- r: title,C,manual,B,A.
- e: title,manual (declared list empty, manual survives).
- e: title,manual,D,E (stable empty-group marker refill).
- v: title,description,manual,D,E.
Record each settled raw full grid; capture original PNG at least mixed reordered and empty-refilled scenes. Actual100x28→120x34 resize, then q normal exit0 and exact before/after termios, process cleanup. CtrlC default coverage already in fresh12PTY; actual GUIq verifies public example normal close. A single old in-flight coherent frame afterresize is legal; usefinalsettled complete grid, not history-wide ban. If tool/host issue, diagnose specific existing fixture rather than fake image/replace host with TERM. Do not query real userclipboard.

Prepare report.md, scope/source manifests, all-file hashes; an optional curated repository archive directory must exclude binaries/cjp/target/cache/source snapshots/privatekeys. Original cjp stays external withSHA reported. All Markdown artifact links in archive must resolve at docs/reviews/R13/execution. Don't archive whole input checkouts/caches. Test counts aren't host counts. GUI evidence is new216 execution; oldc3R12 evidence never relabeled as216.
