import json,gzip,hashlib,tarfile,subprocess,stat,re,io,struct,zlib,collections
from pathlib import Path
W=Path('/workspace/work');base=W/'unit-d-archive';repo=base/'source';out=repo/'docs/reviews/R24/D'
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
def png(b):
 assert b[:8]==b'\x89PNG\r\n\x1a\n';pos=8;end=False
 while pos<len(b):
  n=struct.unpack('>I',b[pos:pos+4])[0];kind=b[pos+4:pos+8];chunk=b[pos+8:pos+8+n];crc=struct.unpack('>I',b[pos+8+n:pos+12+n])[0];assert zlib.crc32(kind+chunk)&0xffffffff==crc;pos+=n+12
  if kind==b'IEND':end=True;break
 assert end and pos==len(b);wh=struct.unpack('>II',b[16:24]);assert min(wh)>0;return wh
idx=json.load(open(out/'archive-index.json'));m=json.loads(gzip.decompress((out/'original-manifest.json.gz').read_bytes()))
for n,r in idx['files'].items():p=out/n;assert digest(p)==r['sha256']and p.stat().st_size==r['bytes']
member_checks={};package_data={};raw_png_count=0
with tarfile.open(out/'raw-evidence.tar.gz',mode='r|gz')as tar:
 for x in tar:
  assert x.isfile()and not x.name.startswith('/')and '..'not in Path(x.name).parts and x.name not in member_checks
  f=tar.extractfile(x);h=hashlib.sha256();n=0;prefix=b'';small=[] if x.name.endswith(('.cjp','.png'))else None
  while b:=f.read(1024*1024):
   if not prefix:prefix=b[:4]
   h.update(b);n+=len(b)
   if small is not None:small.append(b)
  assert n==x.size and prefix!=b'\x7fELF';assert not x.name.endswith(('.a','.cjo','.o','.bc','.so'));member_checks[x.name]={'sha256':h.hexdigest(),'bytes':n,'mode':x.mode}
  if small is not None:
   b=b''.join(small)
   if x.name.endswith('.png'):png(b);raw_png_count+=1
   else:package_data[x.name]=b
assert len(member_checks)==idx['archive_members']and len(package_data)==2 and len({sha(b)for b in package_data.values()})==2
original_member_set=set()
for r in m['originals']:
 a=member_checks[r['member']];assert all(a[k]==r[k]for k in ['sha256','bytes','mode']);original_member_set.add(r['member'])
assert original_member_set==set(member_checks)
for r in idx['browse']:
 p=out/r['path'];a=member_checks[r['member']];assert digest(p)==r['sha256']==a['sha256']and p.stat().st_size==a['bytes']and stat.S_IMODE(p.stat().st_mode)==r['mode']==a['mode']
# Exact logical Git bindings remain independent of later physical source bytes.
proc=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);cache={};trees={}
def fixedtree(c):
 if c not in trees:
  trees[c]={}
  for row in git('ls-tree','-r','-z',c).split(b'\0'):
   if row:meta,p=row.split(b'\t');mode,kind,oid=meta.decode().split();trees[c][p.decode()]={'oid':oid,'mode':int(mode,8)}
 return trees[c]
def blob(oid):
 if oid not in cache:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();b=proc.stdout.read(int(hdr[2]));assert proc.stdout.read(1)==b'\n';cache[oid]=b
 return cache[oid]
counts=collections.Counter();relocation_checks=0
for r in m['bindings']:
 s=r['status'];counts[s]+=1;assert s in ['included','included-package','included-relocation','included-historical-git','git-versioned','prior-publication','excluded']
 if s.startswith('included'):assert member_checks[r['member']]['sha256']==r['sha256']
 if s in ['git-versioned','included-historical-git']:
  assert fixedtree(r['git_commit'])[r['git_path']]['oid']==r['git_blob']and sha(blob(r['git_blob']))==r['sha256']
 if s=='included-relocation':assert digest(r['preserved_path'])==r['sha256'];relocation_checks+=1
 if s=='excluded':assert r['reason']and r['path']and r['sha256']
# Fixed final/historical role indices and independent report identity are unchanged.
for p,h in idx['fixed_intake_indices'].items():assert digest(p)==h
assert digest(W/'incremental-composition-execution/report.md')=='13c509935ee479b807b54c63b84b5ffbcfc8abc95b6fba593dc48b56ab35d246'
assert digest(W/'incremental-composition-acceptance/report.md')=='d0751f011a93e9c620ac96e945668389b1123ef078ad8edd0bba69cbb4c8b70f'
# Reuse prior canonical manifests without opening any old A/B/C raw archive.
prior_records={}
for p in m['prior_publications']:
 assert sha(git('show',p['git_commit']+':'+p['index_path']))==p['index_sha256'];name='original-manifest.json.gz';b=git('show',p['git_commit']+':'+str(Path(p['index_path']).parent/name));assert sha(b)==p['files'][name]['sha256'];prior_records[p['index_path']]={r['member']:r['sha256']for r in json.loads(gzip.decompress(b))['originals']}
for r in m['bindings']:
 if r['status']=='prior-publication':a=r['authority'];assert prior_records[a['index_path']][a['member']]==r['sha256']
# Both distinct complete source packages bind every regular member to their own commit.
package_checks=[]
for p in m['candidate_packages']:
 b=package_data[p['member']];assert sha(b)==p['sha256'];n=0
 with tarfile.open(fileobj=io.BytesIO(b))as tar:
  for x in tar:
   if x.isfile():rel=x.name.removeprefix('cjtui-0.0.0/');v=fixedtree(p['source_commit'])[rel];assert tar.extractfile(x).read()==blob(v['oid']);n+=1
 package_checks.append({'source_commit':p['source_commit'],'sha256':p['sha256'],'regular_members':n,'final':p['final']})
proc.stdin.close();assert proc.wait()==0
# Current producer and actual-execution runtime pins remain physical at publication.
prod=json.load(open(W/'incremental-composition-implementation/index-r1.json'));exe=json.load(open(W/'incremental-composition-execution/index.json'));acc=json.load(open(W/'incremental-composition-acceptance/index.json'));currentpins=[]
for r in prod['artifacts']+exe['executables']:
 p=Path(r['path']);assert p.is_file()and not p.is_symlink()and digest(p)==r['sha256']and p.stat().st_size==r['bytes'];currentpins.append({'path':str(p),'sha256':r['sha256'],'bytes':r['bytes']})
assert len(currentpins)==7
witness_payloads=0
for rec in m['local_runtime_witness_receipts']:
 assert digest(rec['index_path'])==rec['index_sha256']
 for r in rec['mapping']:
  p=Path(r['witness']);assert digest(p)==r['witness_sha256']and p.stat().st_size==r['witness_bytes'];assert not any(n.endswith(p.name)for n in member_checks)
  h=hashlib.sha256();n=0
  with gzip.open(p,'rb')as f:
   while b:=f.read(1024*1024):h.update(b);n+=len(b)
  assert h.hexdigest()==r['original_sha256']and n==r['original_bytes'];witness_payloads+=1
assert witness_payloads==5
# Actual final PNG bytes, original modes/dimensions and source capture metadata.
assert len(idx['captures'])==20;meta=json.load(open(out/'capture-metadata.json'));assert meta['hosts']==exe['hosts']and meta['source_index_sha256']==idx['fixed_intake_indices'][str(W/'incremental-composition-execution/index.json')]
for r in idx['captures']:
 p=out/r['path'];b=p.read_bytes();a=member_checks[r['member']];assert sha(b)==r['sha256']==a['sha256']and len(b)==a['bytes']==r['bytes']and png(b)==(r['width'],r['height']);assert stat.S_IMODE(p.stat().st_mode)==r['mode']==a['mode']
assert collections.Counter(r['host']for r in idx['captures'])=={'xterm-r3':10,'vte-r3':10};assert raw_png_count==idx['all_raw_png_count']==60
# Exact source integration and root's sealed acceptance remain bounded.
assert acc['verdict']=='PASS_UNIT_D'and acc['requirements_checked']==15 and not acc['blocking_findings']
subprocess.check_call(['git','-C',str(repo),'merge-base','--is-ancestor',idx['source_commit'],idx['accepted_main']]);assert git('diff',idx['source_commit'],idx['accepted_main'],'--','src','native','tests/incremental_composition')==b''
# Resolve new links against sparse files or exact canonical Git, never a full checkout.
md_count=0;links=0
for p in [*out.rglob('*.md'),out.parent/'README.md']:
 text=p.read_text();assert len(re.findall(r'^```',text,re.M))%2==0;md_count+=1
 for link in re.findall(r'\]\(([^)]+)\)',text):
  path=link.split('#')[0]
  if not path or re.match(r'^(?:https?:|app:|mailto:|<)',path):continue
  q=(p.parent/path).resolve();assert q.is_relative_to(repo)
  if not q.exists():subprocess.check_call(['git','-C',str(repo),'cat-file','-e','HEAD:'+str(q.relative_to(repo))])
  links+=1
result={'schema':'unit-d-publication-verification-v1','archive_members':len(member_checks),'original_records':len(m['originals']),'binding_count':len(m['bindings']),'binding_status_counts':dict(counts),'unresolved':0,'browse_files':len(idx['browse']),'raw_png_originals':raw_png_count,'final_browsable_pngs':20,'exact_git_blobs':len(cache),'source_packages':package_checks,'relocation_checks':relocation_checks,'prior_manifest_refs':counts['prior-publication'],'current_producer_execution_pins':currentpins,'historical_witness_payloads_stream_checked':witness_payloads,'markdown_files':md_count,'markdown_local_links':links,'checks':'All streamed raw members and browse copies byte/mode/SHA; safe unique regular; zero ELF/runtime-gzip/compiler/SDK payload; every file binding included/excluded/exact Git/package/relocation/prior/witness; all9 intake indices and final reports; both candidate CJP full member equality; seven current R1/141 artifact pins; five exact historical witness payloads; 20 actual final PNGs/capture metadata and60 raw PNG CRCs; source integration; new D/R24 Markdown closure. Root runs repository/OpenSpec checks after adoption. No builds/tests/acceptance reruns.'}
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'checksums.sha256').write_text(''.join(digest(p)+'  '+str(p.relative_to(out))+'\n'for p in sorted(out.rglob('*'))if p.is_file()and p.name!='checksums.sha256'))
print(json.dumps({k:v for k,v in result.items()if k!='current_producer_execution_pins'}))
