#!/usr/bin/env bash
set -u
label=$1
shift
check_dir=$1
shift
base=/workspace/work/dynamic-implementation-sol
source /workspace/work/validation/sdk/cangjie/envsetup.sh
{
  printf 'UTC-start=%s\ncwd=%s\n' "$(date -u +%FT%TZ)" "$check_dir"
  printf 'command='; printf '%q ' "$@"; printf '\n'
  git -C "$base/source" rev-parse HEAD
  git -C "$base/source" diff --binary | sha256sum
  find "$base/source/src" "$base/source/examples/dynamic" "$base/source/docs/product" -type f -not -path '*/target/*' -not -path '*/build-script-cache/*' -not -name cjpm.lock -not -name cangjie-repo.toml -print0 | sort -z | xargs -0 sha256sum | sha256sum
} > "$base/logs/$label.meta"
cd "$check_dir" || exit
"$@" > "$base/logs/$label.log" 2>&1
check_status=$?
{
  printf 'exit=%s\nUTC-end=%s\n' "$check_status" "$(date -u +%FT%TZ)"
  sha256sum "$base/logs/$label.log"
} >> "$base/logs/$label.meta"
cat "$base/logs/$label.meta"
tail -25 "$base/logs/$label.log"
exit "$check_status"
