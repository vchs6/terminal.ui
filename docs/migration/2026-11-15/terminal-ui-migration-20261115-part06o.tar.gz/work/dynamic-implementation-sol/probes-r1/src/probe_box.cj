package dynamic_boundaries

class ProbeBox<T> {
    var value: T
    init(value: T) { this.value = value }
}
