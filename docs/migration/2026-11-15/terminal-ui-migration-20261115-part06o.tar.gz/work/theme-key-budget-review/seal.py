from pathlib import Path
import json,hashlib,datetime,subprocess,shutil
r=Path(__file__).resolve().parent
p=Path('/workspace/work/terminal.ui/openspec/changes/implement-theme-styles/design.md')
sha=hashlib.sha256(p.read_bytes()).hexdigest()
assert sha=='084b1623937055426e0e7c57c2cc5b9cfa2e474a787ce7e81fee3cea286c30a4'
(r/'source-evidence/final-formal-design.md').write_bytes(p.read_bytes())
diff=subprocess.check_output(['git','-C','/workspace/work/terminal.ui','diff','HEAD','--','openspec/changes/implement-theme-styles/design.md'])
(r/'source-evidence/final-formal-design.patch').write_bytes(diff)
check=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit='51a22fee9732a6d53affd05dd1eaa63e3d58ce2e',path=str(p),sha256=sha,patch_sha256=hashlib.sha256(diff).hexdigest(),verdict='PASS_NARROW_FORMAL_WORDING',reason='Line139 conditions equal semantics on T009 admission; appended clarification defines UTF8 token.value including original escape spelling and excluding Lexer-removed delimiters, covers all key positions, excludes values, retains inclusive1024 and CapacityExceeded, forbids decoder/per-tokenParser, includes accurate1030/103 example and public documentation obligation. This meets KB01 formal wording condition. No product result inferred.')
(r/'final-wording-review.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n')
with (r/'report.md').open('a') as f:
 f.write('''\n## Final formal wording verification after lead decision\n\nThe lead selected A and requested a narrowly scoped reread of the actual formal wording. Checked the new line 139 plus the appended T009 key-segment clarification at the UTC in final-wording-review.json. **PASS_NARROW_FORMAL_WORDING**: the clarification accurately satisfies the formal wording condition above. It explicitly retains escapes, excludes Lexer-removed quotes, measures only key positions, includes every specified key context, distinguishes semantic name limits, and gives the correct 1030/103 representation example. The inline escape example contains one literal backslash, as required. The product-documentation obligation is explicitly recorded.\n\nFrozen final design SHA-256: `084b1623937055426e0e7c57c2cc5b9cfa2e474a787ce7e81fee3cea286c30a4`. Complete final design snapshot and exact diff against base commit are in source-evidence/final-formal-design.md and final-formal-design.patch. This subsequent verification closes the formal wording prerequisite described earlier; those paragraphs describe the original candidate review. Independent product test additions and eventual product documentation/implementation verification remain required, and this review still makes no product PASS claim.\n''')
f=json.loads((r/'findings.json').read_text())
f['conclusion']='A_SELECTED_BY_LEAD_FORMAL_WORDING_VERIFIED_NARROW_PASS'
f['final_wording_verification']=check
f['findings'][0]['status']='formal_wording_resolved_at_final_design_hash'
f['findings'][0]['resolution']='Lead selected A and applied formal wording; independent narrow verification passed at final design SHA. Product docs and tests remain handoff obligations, not reviewed implementation.'
(r/'findings.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
cur=r/'curated'
for name in ['report.md','findings.json','cases.json','probe-results.json','input-hashes.json','dependency-source-identity.json','candidate.md','final-wording-review.json','generate_inputs.py','run_probe.py','collect_evidence.py','build.sh','run_negative.sh']:
 shutil.copy2(r/name,cur/name)
for name in ['raw','inputs','source-evidence']:
 shutil.copytree(r/name,cur/name,dirs_exist_ok=True)
for name in ['probe','negative-key','negative-decode']:
 d=cur/name;d.mkdir(exist_ok=True)
 for filename in ['cjpm.toml','cjpm.lock','cangjie-repo.toml']:
  shutil.copy2(r/name/filename,d/filename)
 shutil.copytree(r/name/'src',d/'src',dirs_exist_ok=True)
files=sorted(x for x in cur.rglob('*') if x.is_file())
manifest=''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+str(x.relative_to(cur))+'\n' for x in files)
(r/'artifacts.sha256').write_text(manifest)
(cur/'artifacts.sha256').write_text(manifest)
print(json.dumps(dict(files=len(files),total_bytes=sum(x.stat().st_size for x in files),manifest_sha256=hashlib.sha256(manifest.encode()).hexdigest(),final_design_sha256=sha)))
