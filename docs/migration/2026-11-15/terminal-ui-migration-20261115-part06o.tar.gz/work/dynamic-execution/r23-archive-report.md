# R23 mechanical archive report

| Archive directory | Original files | Indices | Total |
| --- | ---: | ---: | ---: |
| docs/reviews/R23/preflight | 17 | 2 | 19 |
| docs/reviews/R23/test-design | 183 | 2 | 185 |

Total 204 files: 200 byte-identical/SHA256-identical original evidence copies +4 archive indices. Strict JSON: 48; relative Markdown links: 13, all resolve. No ELF/static archive/CJO/cache/private key/source Markdown snapshot/whole checkout copied.

Preflight includes original report/findings/DQ/reviewed hashes/manifest, actual public scalar consumer source/run command, compile stdout/stderr, execution/scalar-widths and raw provenance. Two compiled artifacts excluded with external source path/hash.

Test design retains fixed614d0a2f0e33e54ecc07bd783eaeb0b9957ca557 report/summary/author progress, original evidence manifest, commands, root build0/public34PASS/actually executed existing-only deviceRED/new private API24 diagnostic compilationRED, fixture oracle/cause controls/fresh physical facts and source hashes. No behavior GREEN or product implementation asserted. Both original reports copied without modification or deferred links.

The already delivered240 test files including70 PNG were not copied again.123 raw entries were excluded as cache or byte-identical original fixtures already present under tests/glyph_advance; index records external path/hash/reason and exact same-hash existing repository paths.0 PNG added by this archive.

Every original evidence manifest reference maps to an archived or external original, with omission reasons. All resolvable original hashes match; no copied-byte discrepancies.

npm run check exited0: repository/configuration/links/task mapping passed; strict OpenSpec23/23 passed. No product capability verified.

Problems:0. No product/tests/task state edits, commit or subagents. New product164 directory not accessed.
