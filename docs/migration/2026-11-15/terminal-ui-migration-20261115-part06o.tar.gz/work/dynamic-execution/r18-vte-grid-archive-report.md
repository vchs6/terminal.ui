# R18 VTE grid recon mechanical archive

Destination: /workspace/work/terminal.ui/docs/reviews/R18/vte-grid-recon

Original hashes.json has484 payload hash entries. 274 selected listed originals plus original hashes.json itself = 275 unchanged evidence files. Added README/index2. Total 277. Omitted listed originals: 210, individually mapped with original path/hash/bytes/reason.

Fresh checks: 275 original byte/SHA256-equal copies; all484 source manifest entries matched; 59 strict JSON; 3 relative Markdown links resolve; all57 original PNG preserved. No ELF/static archive/SDK/cache/private key/whole source checkout/temporary HOME copied.

Complete final-module and final-baseline normal/alternate/restored/scrollback captures, before/after reads and all original Save GUI failed attempts preserved. Superseded module1/module2/baseline1/baseline2 non-PNG details remain external; all their original PNGs retained. Native range alternate error and contents history/NUL counterexamples remain within complete final-module raw.

README explicitly documents native instrumentation, incomplete full-cell attributes, clipboard empty-owner0 metadata only/no payload reading, no uninstrumented product run, no product/148/151 PASS and no148 oracle modification.

Nonempty source→copy/SHA fresh list: /workspace/work/dynamic-execution/r18-vte-grid-source-copy.json

SHA256 of list: 11606be9cd083d3215ab5bb16e99204f45e691f9fbd9774c68999dc6690f530a

No npm check repeated, as requested; root will integrate and run repository checks. No product/tests/status edits, commits or subagents. Other agent/key-fix directories were not accessed.

Problems:0.
