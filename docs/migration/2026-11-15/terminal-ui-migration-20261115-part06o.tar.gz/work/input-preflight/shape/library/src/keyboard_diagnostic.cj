package cjtui
public class KeyboardDiagnostic { public let kind: KeyboardIssue = KeyboardIssue.InvalidUtf8; public let offset: Int64 = 0; init() { throw Exception("SHAPE ONLY: never execute") } }
