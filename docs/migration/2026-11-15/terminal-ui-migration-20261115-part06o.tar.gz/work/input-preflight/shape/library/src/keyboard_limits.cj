package cjtui
public class KeyboardLimits { public let maxPasteBytes: Int64 = 1048576; public let maxSequenceBytes: Int64 = 64
public init(maxPasteBytes!: Int64 = 1048576, maxSequenceBytes!: Int64 = 64) { throw Exception("SHAPE ONLY: never execute") } }
