package cjtui
public class Theme { public init() { throw Exception("SHAPE ONLY: never execute") } }
