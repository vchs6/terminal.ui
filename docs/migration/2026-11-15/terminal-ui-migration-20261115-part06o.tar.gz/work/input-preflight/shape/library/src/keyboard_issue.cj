package cjtui
public enum KeyboardIssue <: Equatable<KeyboardIssue> { | UnsupportedSequence | MalformedSequence | SequenceTooLong | InvalidUtf8 | IncompleteInput | PasteTooLarge | InvalidPasteEncoding | IncompletePaste | PasteTargetUnavailable
public operator func ==(other: KeyboardIssue): Bool { throw Exception("SHAPE ONLY: never execute") } }
