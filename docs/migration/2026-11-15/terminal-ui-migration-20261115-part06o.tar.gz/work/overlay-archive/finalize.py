from pathlib import Path
import json,hashlib
W=Path('/workspace/work');P=W/'terminal.ui/docs/reviews/interaction/C';mp=W/'overlay-archive/source-copy.json';m=json.load(open(mp));existing=[]
for p in sorted((P/'TASK-108').rglob('*')):
 if p.is_file():
  b=p.read_bytes();existing.append({'source':str(p),'destination':str(p),'relative_destination':str(p.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'status':'pre-existing archived TASK108 historical preparation, unchanged'})
m['pre_existing']=existing
# Every4639 original has a copy/exclusion record, and all copied files remain exact.
orig=json.load(open(W/'overlay-execution/stablemanifest.json'))['original_files']; covered={x['source'] for x in m['copied']+m['excluded']};assert all(str(W/'overlay-execution'/x['path']) in covered for x in orig)
for x in m['copied']+existing:
 b=Path(x['destination']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
mp.write_text(json.dumps(m,indent=2)+'\n')
pathmap=json.load(open(P/'evidence-path-map.json'));pathmap['pre_existing']=[{k:v for k,v in x.items() if k!='destination'} for x in existing];(P/'evidence-path-map.json').write_text(json.dumps(pathmap,indent=2)+'\n')
p=P/'README.md';s=p.read_text();s=s.replace('The [test preparation]','The pre-existing [TASK108 blocked preparation](TASK-108/manifest.json) and its66 files remain unchanged as earlier history; it is not current acceptance.\n\nThe [test preparation]');p.write_text(s)
lines=[
'PASS: Unit C finite archive prepared; no product/suite execution, staging or commit.',
'Public destination: /workspace/work/terminal.ui/docs/reviews/interaction/C',
'Copied originals: '+str(len(m['copied']))+'; bytes: '+str(sum(x['bytes'] for x in m['copied'])),
'Existing TASK108 historical archive: '+str(len(existing))+' unchanged files.',
'111 originals: 4639; every row has an exact copied or explicit external-exclusion entry.',
'111 stablemanifest SHA256: cda293604be2e912103e0358c3fcd28f7c24af4511337b591d1036ee0a592ad2',
'112 acceptance SHA256: 702cd9f253fbc005821920875eccc865f7cf1dfad4847c87ed13a27ef0d8c123',
'112 evidence-index SHA256: bde6a33222a6ac7ed3df86199209b97ef73ab057427be6d8739f4d71d9dab511',
'Accepted original7f431765 -> main283e59b15b6e6b094e409b185bbf01b38b9a9d79.',
'Images: final71 (H0151+nativecaret20), history125; all196 original PNGs preserved.',
'All copied bytes rehashed; source-copy mapping: /workspace/work/overlay-archive/source-copy.json',
'JSON813 and466 JSONL rows parsed; README/image links resolve; noELF/archive/bitcode magic or forbidden directories/extensions.',
'11 tar containers and11 serial base64 tar containers inspected; serial bytes equal sibling evidence tar; no forbidden ELF/SDK members.',
'Secret-pattern scan: zero private-key/API-token matches; benign config/log originals retained.',
'Historical mutable author manifest SHA71a/7d8 unavailable; not reconstructed; QA immutable pure raw preserved.',
'124 external intermediates preserve exact original/cleanup hashes and reasons;121same/3replaced.',
'VT physical hide remains insufficient_evidence with compliant I015Unknown fallback; QEMU is VM.',
'B-M01deferred024 and all wider pending work preserved. Root owns independent validation/commit/push.'
]
(W/'overlay-archive/archive-report.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
