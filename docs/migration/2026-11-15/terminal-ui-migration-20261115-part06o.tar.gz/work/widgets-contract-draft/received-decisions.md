# 主代理本轮消息裁决记录

来源：/root → /root/widgets_contract_draft 的任务消息，2026-11-10；这是起草角色记录的交接内容，不冒充主代理已提交的正式合同或用户精确签名选择。

## W006-S：StatusBar自然高度

主代理原文：

> StatusBar根由Row自然高度即可，主代理撤销粗稿严格默认高1工程建议，采用正常单行body自然1、空body/多行按Row原自然规则；不强行.height(1)压主题，也不新私有intrinsic规则。标准四主题role可配置height1作为主题值，自定义主题/组件显式可覆盖。API文档说明StatusBar参与普通布局不自动贴底、应用需要固定一行可显式height(1)。这不改变用户既定范围，只避免不必要新强制默认。Progress Canvas measure自然20x1则依然正确且不压主题。

## G001 / 交互A I012：同resolver合成真实行为态

主代理原文：

> 采纳统一resolver自动行为态方案，主代理将交互A追加I012：effective disabled = !祖先合取effectiveEnabled || declaredVisualStates.disabled；focused = 当前session真实焦点自身 || declaredVisualStates.focused；selected = declaredVisualStates.selected（业务拥有选中，不偷改）。这些是同resolver输入合成，显式visualStates仍仅可增加外观状态，绝不反写行为；false不屏蔽真实disabled/focus，想覆盖外观用现显式样式逐字段。detached render也有同Runtime effectiveEnabled，可自动disabled；无真实focus则nativeFocused=false，显式模拟focused仍可展示。控件不再调用reference读取enabled/focus来仿造外观，Checkbox/Radio只将业务selected映射到VisualStates，其余统一处理。此补充在A已验前不让widget产品准入，Theme原tests未启用行为槽时保持结果；不是新控件kind或私有访问。请草稿明确这条上游依赖与对应detached/ancestor-disabled/后链覆盖golden需求。

本记录不授予上游实现已完成状态。正式freeze时应将该裁决写入交互A正式合同并记录其固定hash/接受任务；本候选不得单方假定已有产品API。

## 最终补充：S直接等待117及公开入口

主代理最终原文：

> 主代理最终选择S也等117，避免先只code/text后再修改共享activation。PopupMenu仅可复用内容、默认surface(Opaque)、选择不自动close，业务显式handle.close；公开enabled仅属性槽，Checkbox/Radio仅getter受控均采纳。请你独立候选tasks把S等117确定、不再留选项，其余结束交接不用新探索。原键盘117不依赖标准控件，只需公共Text/Canvas focus fixture，保证无语义环。
