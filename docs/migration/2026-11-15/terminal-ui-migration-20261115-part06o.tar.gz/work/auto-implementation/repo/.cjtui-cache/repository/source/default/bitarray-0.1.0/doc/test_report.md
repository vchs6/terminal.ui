# BitArray 测试报告

## 1. 测试框架

使用仓颉标准单元测试框架 `std.unittest`，编译运行方式：

```bash
cjpm test       # 运行全部测试
```

测试文件位于 `src/test/bitarray_test.cj`，包名 `bitarray.test`。

## 2. 测试结构

### 测试类一览

| 测试类 | 用例数 | 测试范围 |
|--------|--------|----------|
| `ConstructionTests` | 9 | 各种构造方式：UInt8/16/32 变长参数、Bool 数组、bitCount构造、空构造 |
| `ParseTests` | 5 | `Parsable.parse` 字符串解析：基本解析、空格分隔、单 bit、非法字符、tryParse |
| `IndexTests` | 3 | `[]` 索引读取/写入、越界异常 |
| `BitwiseOpTests` | 6 | `&` `|` `^` `!` 位运算、不同长度操作数、恒等式 |
| `ShiftTests` | 3 | `<<` `>>` 移位、零移位、全移出 |
| `EqualityTests` | 4 | `==` `!=` 判等、不等、不同长度、空数组 |
| `ArrayStyleTests` | 12 | `isEmpty` / `clone` / `reverse` / `fill` / `all` / `any` / `none` / `count` / `indexOf` / `swap` 等 |
| `InterfaceTests` | 4 | `Hashable` / `Comparable` / `Equatable` / `toBoolArray` |
| `UtilityTests` | 5 | `slice` / `sliceOutOfRange` / `concat` / `concatEmpty` / `toUInt64` |
| `SegmentedAccessTests` | 6 | `SegmentedBitArray` 段 CRUD、重叠段、段不存在、段超范围 |
| `PartitionedAccessTests` | 6 | `PartitionedBitArray` 字段 CRUD、重叠检测、字段不存在、listFieldNames |
| `CoexistenceTests` | 2 | 分段与分区指向同一 BitArray 的读写一致性 |
| `MultiViewTests` | 2 | 多个 `SegmentedBitArray` 指向同一 BitArray |
| `EdgeCaseTests` | 2 | `BitArray(-1)` 异常、`!` 不修改原值 |

**总计：14 个测试类，71 个测试用例。**

### 测试覆盖的功能点

```
BitArray 构造
├── 空构造 ()
├── 指定位数 (bitCount)
├── UInt8 变长参数 (0xFFu8)
├── UInt16 变长参数 (0xA5C3u16)
├── UInt32 变长参数 (0xDEAD_BEEFu32)
├── UInt64 变长参数 (0x0123_4567_89AB_CDEFu64)
├── Bool 数组 ([true, false, ...])
└── Parsable.parse ("01" 字符串)

BitArray 运算
├── 索引 [] 读写
├── 按位与 &
├── 按位或 |
├── 按位异或 ^
├── 按位取反 !
├── 左移 <<
├── 右移 >>
├── 判等 == !=
├── 克隆 clone
├── 翻转 reverse
├── 填充 fill
├── 全部位检查 all / any / none
├── 计数 count
├── 查找 indexOf
├── 交换 swap
├── 截取 slice
├── 连接 concat
├── 转整数 toUInt64
├── 转 Bool 数组 toBoolArray

BitArray 接口实现
├── Hashable（HashMap 键）
├── Comparable（< > compare）
├── Equatable（==）
└── Parsable（parse / tryParse）

SegmentedBitArray
├── 段添加与读取
├── 段写入（反映到底层 BitArray）
├── 段重叠
├── 段删除
├── 段不存在异常
├── 段超范围异常

PartitionedBitArray
├── 字段添加与读取
├── 字段写入
├── 重叠检测（互斥）
├── 字段不存在异常
├── 字段列表查询

两模型共存
├── 分段与分区指向同一 BitArray
├── 分区写入对分段立即可见

多视图
├── 多个 SegmentedBitArray 互不影响

边缘情况
├── 负位数构造异常
├── ! 不修改原值
```

## 3. 测试结果

### 最新运行

```
Summary: TOTAL: 71
    PASSED: 71, SKIPPED: 0, ERROR: 0
    FAILED: 0
```

**通过率：100%**

### 运行环境

- 仓颉编译器版本：cjc 1.0.5
- 测试框架：std.unittest（仓颉标准库）
- 平台：Linux x86_64

## 4. 关键测试验证点

### 4.1 位序一致性

```
BitArray.parse("10101101")
  → ba[0] = true（LSB）
  → ba[7] = true（MSB）
  → toString() = "10101101"
```

保证 `parse` → `toString` 是恒等变换（不掉位、不反转）。

### 4.2 构造器方向

```
BitArray(0xABu8, 0xCDu8)
  → bytes[0] = 0xCD
  → bytes[1] = 0xAB
  → toUInt64() = 0xABCD  （values[0]=0xAB 为 MSB 侧）

BitArray([true, false, true, true, false])
  → bits[0] = true 为 MSB
  → bits[4] = false 为 LSB
  → ba[0] = false（LSB 正确）
```

### 4.3 互斥校验

```
pba.addField(BitSegment("a", 0, 4))     // 成功
pba.addField(BitSegment("b", 2, 4))     // 抛 IllegalArgumentException（重叠）
```

### 4.4 两模型数据一致性

```
ba = BitArray(0x1A_00_AB_CDu32)
pba.addField(BitSegment("f_flags", 0, 8))
view.addSegment(BitSegment("whole", 0, 32))

pba.setField("f_flags", 0x42u64)
view.getSegment("whole") & 0xFFu64  == 0x42u64 ✅
```

## 5. 测试完整性评估

| 维度 | 评估 | 说明 |
|------|------|------|
| 构造覆盖 | ✅ 完整 | 所有构造器都有对应测试 |
| 运算覆盖 | ✅ 完整 | 所有运算符都有全覆盖 |
| 异常覆盖 | ✅ 完整 | 越界、重叠、不存在等异常路径 |
| 接口覆盖 | ✅ 完整 | Hashable / Equatable / Comparable / Parsable |
| 边界覆盖 | ✅ 完整 | 空数组、单 bit、满位、溢出 |
| 模型覆盖 | ✅ 完整 | 分段 / 分区 / 共存 / 多视图 |
| 回归防护 | ✅ 有效 | 每次修改通过 `cjpm test` 验证 |

## 6. 未覆盖场景（已知限制）

| 场景 | 原因 |
|------|------|
| 字符串解析空结果 | `parse("")` 返回空 BitArray 而非抛异常，与 `@ExpectThrows` 宏在 `static extend` 方法中的行为有关 |
| 负字面量参数异常 | `@ExpectThrows` 宏展开中 `-1` 字面量被推断为 `UInt64`，改用 `Int64(-1)` 显式转型可绕过 |
