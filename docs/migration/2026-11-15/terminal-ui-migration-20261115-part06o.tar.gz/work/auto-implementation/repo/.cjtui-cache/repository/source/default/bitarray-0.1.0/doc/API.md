# BitArray — API 参考

## 包: `bitarray`

```
import bitarray.*
```

---

## struct BitSegment

位段/位字段描述符，统一用于视图模型和分区模型。

### 字段

| 名称 | 类型 | 说明 |
|---|---|---|
| `name` | `String` | 段/字段名称，用作 HashMap 的键 |
| `offset` | `Int64` | 起始位偏移（0 = LSB） |
| `width` | `Int64` | 位宽（范围 1..64） |

### 构造函数

```cangjie
public init(name: String, offset: Int64, width: Int64)
```

**异常：** `ArithmeticException` — width 不在 1..64 范围，或 offset < 0。

### 数据类型对照

| width | 对应类型 | 说明 |
|---|---|---|
| 1 | `Bool` | 单个标志位 |
| 2..8 | `UInt8` | 字节 |
| 9..16 | `UInt16` | 半字 |
| 17..32 | `UInt32` | 字 |
| 33..64 | `UInt64` | 双字 |

---

## class BitArray <: ToString

纯位存储容器。

### 构造函数

| 签名 | 说明 |
|---|---|
| `init()` | 空 BitArray（0 位） |
| `init(bitCount: Int64)` | 分配 n 位全 0 数组。`ArithmeticException` 若 `bitCount < 0` |
| `init(value: UInt8)` | 从 8 位无符号整数构造 |
| `init(value: UInt16)` | 从 16 位无符号整数构造 |
| `init(value: UInt32)` | 从 32 位无符号整数构造 |
| `init(value: UInt64)` | 从 64 位无符号整数构造 |
| `init(bytes: Array<UInt8>)` | 从字节数组构造（低位在前） |
| `init(bits: Array<Bool>)` | 从 Bool 数组构造（arr[0] = LSB） |
| `init(bits: String)` | 从 "01" 字符串构造（左=MSB，右=LSB，`_` 视为分隔符）。`IllegalArgumentException` 若字符串不含有效 `0`/`1` |
| `init(charBits: Array<Rune>)` | 从 Rune 字符数组构造（仅接受 `r'0'`/`r'1'`）。`IllegalArgumentException` 若含非法字符或为空 |
| `static func parse(s: String): BitArray` | 从 "01" 字符串解析，与 `init(bits: String)` 行为一致 |

### 属性

| 签名 | 类型 | 说明 |
|---|---|---|
| `prop size: Int64` | 只读 | 有效位数 |
| `prop data: Array<UInt8>` | 只读 | 内部字节数组副本 |

### 索引运算符

```cangjie
// 读取位
public operator func [](index: Int64): Bool
// 写入位
public operator func [](index: Int64, value!: Bool): Unit
```

`IndexOutOfBoundsException` 若 `index < 0 || index >= size`。

### 位运算符

返回新的 `BitArray`，长度取两操作数的较大值，短操作数高位视为 0。

| 运算符 | 语义 | 返回类型 |
|---|---|---|
| `a & b` | 按位与 | `BitArray` |
| `a \| b` | 按位或 | `BitArray` |
| `a ^ b` | 按位异或 | `BitArray` |
| `!a` | 按位取反 | `BitArray` |
| `a << n` | 左移 n 位（向 MSB），低位补 0 | `BitArray` |
| `a >> n` | 右移 n 位（向 LSB），高位补 0 | `BitArray` |

**异常：** `ArithmeticException` 若 `n < 0`。

### 判等运算符

| 运算符 | 说明 |
|---|---|
| `a == b` | 同长度且所有位相等 → `true` |
| `a != b` | `!(a == b)` |

### 工具方法

| 签名 | 说明 |
|---|---|
| `slice(start: Int64, end: Int64): BitArray` | 截取 `[start, end)` 子数组。`ArithmeticException` 若范围无效 |
| `concat(other: BitArray): BitArray` | 连接，`this` 在高位（MSB 侧），`other` 在低位（LSB 侧） |
| `toUInt64(): UInt64` | 转换为 `UInt64`（超出 64 位截断） |
| `toBoolArray(): Array<Bool>` | 转换为 Bool 数组（index 0 = LSB） |
| `toString(): String` | 二进制字符串表示（MSB 在左） |

---

## class SegmentedBitArray <: ToString

视图模型包装器。段允许重叠。

### 构造函数

```cangjie
public init(ba: BitArray)
```

### 属性

| 签名 | 类型 | 说明 |
|---|---|---|
| `prop underlying: BitArray` | 只读 | 底层 `BitArray` 引用 |
| `prop size: Int64` | 只读 | 底层位数（委托） |

### 段管理

| 签名 | 说明 |
|---|---|
| `addSegment(seg: BitSegment): Unit` | 添加段描述符。同名时覆盖旧定义 |
| `removeSegment(name: String): Unit` | 移除段描述符 |
| `getSegmentNames(): Array<String>` | 返回所有已注册段名 |

### 段读写

```cangjie
public func getSegment(name: String): UInt64
public func setSegment(name: String, value: UInt64): Unit
```

**异常：** `IllegalArgumentException` — 段名不存在或段超出 `underlying.size` 范围。

### 字符串

```cangjie
public func toString(): String
```

委托到底层 `BitArray.toString()`。

---

## class BitPartition

互斥分区方案。持有 `BitSegment` 集合，添加时自动检测重叠。

### 构造函数

```cangjie
public init()
```

### 字段管理

| 签名 | 说明 |
|---|---|
| `addField(field: BitSegment): Unit` | 添加字段，自动重叠检测。`IllegalArgumentException` 若与已有字段重叠 |
| `addField(all!: Array<BitSegment>): Unit` | 批量添加，原子性——先全部校验再写入。`IllegalArgumentException` 若存在重叠 |
| `removeField(name: String): Unit` | 移除字段 |
| `clear(): Unit` | 清空所有字段 |

### 查询

| 签名 | 返回 | 说明 |
|---|---|---|
| `findField(name: String)` | `Option<BitSegment>` | 按名称查找字段 |
| `listFields()` | `Array<(String, Int64, Int64)>` | 返回所有 `(name, offset, width)` 列表 |
| `getFieldNames()` | `Array<String>` | 返回所有字段名 |
| `contains(name: String)` | `Bool` | 判断字段是否存在 |
| `prop count: Int64` | `Int64` | 字段数量 |

---

## class PartitionedBitArray <: ToString

分区模型包装器。通过 `BitPartition` 管理互斥字段，位运算委托到底层 `BitArray`。

### 构造函数

```cangjie
public init(ba: BitArray)
```

内部创建 `BitPartition`，不接收外部传入。

### 属性

| 签名 | 类型 | 说明 |
|---|---|---|
| `prop size: Int64` | 只读 | 位数（委托到底层） |
| `prop underlying: BitArray` | 只读 | 底层 `BitArray` 引用 |
| `prop partitionScheme: BitPartition` | 只读 | 分区方案引用 |

### 字段管理

| 签名 | 说明 |
|---|---|
| `addField(field: BitSegment): Unit` | 添加字段，自动互斥校验。`IllegalArgumentException` 若重叠 |
| `removeField(name: String): Unit` | 移除字段 |

### 字段访问

```cangjie
public func getField(name: String): UInt64
public func setField(name: String, value: UInt64): Unit
public func listFieldNames(): Array<String>
public func containsField(name: String): Bool
```

**异常：** `IllegalArgumentException` — 字段名不存在或字段超出底层大小。

### 委托运算符

| 运算符 | 返回 | 语义 |
|---|---|---|
| `pba1 & pba2` | `BitArray` | 委托到底层 `&` |
| `pba1 \| pba2` | `BitArray` | 委托到底层 `\|` |
| `pba1 ^ pba2` | `BitArray` | 委托到底层 `^` |
| `!pba` | `BitArray` | 委托到底层 `!` |
| `pba << n` | `BitArray` | 委托到底层 `<<` |
| `pba >> n` | `BitArray` | 委托到底层 `>>` |
| `pba1 == pba2` | `Bool` | 比较底层 `BitArray` |
| `pba1 != pba2` | `Bool` | 比较底层 `BitArray` |

### 字符串

```cangjie
public func toString(): String
```

委托到底层 `BitArray.toString()`。

---

## 简易速查

```cangjie
// 1. 从无符号整数构造
let ba = BitArray(0xA5C3u16)        // 16 位

// 2. 从 "01" 字符串构造
let ba = BitArray("10101101")       // 支持 _ 分隔符

// 3. 位索引访问
ba[0] = true                        // 设 LSB
let b = ba[7]                       // 读 MSB

// 4. 位运算
let r = ba1 & ba2                   // 按位与

// 5. 视图模型（段可重叠）
let view = SegmentedBitArray(ba)
view.addSegment(BitSegment("flags", 0, 8))
let flags = view.getSegment("flags")
view.setSegment("flags", 0x42u64)

// 6. 分区模型（字段互斥）
let part = BitPartition()
part.addField(BitSegment("ver", 28, 4))
part.addField(BitSegment("type", 24, 4))
// part.addField(BitSegment("x", 26, 4))  // 重叠！抛异常
let pba = PartitionedBitArray(ba, part)
let ver = pba.getField("ver")

// 7. 两模型共存
let view = SegmentedBitArray(ba)           // 视图
let pba = PartitionedBitArray(ba, p)  // 分区，同一 ba

// 8. 工具
let sub = ba.slice(2, 6)             // 截取
let cc = ba1.concat(ba2)             // 连接
let val = ba.toUInt64()              // 转整数
```
