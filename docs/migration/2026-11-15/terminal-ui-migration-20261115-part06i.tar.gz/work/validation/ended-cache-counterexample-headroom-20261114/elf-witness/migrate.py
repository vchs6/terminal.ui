import pathlib,os,stat,json,hashlib,gzip,subprocess,sys
O=pathlib.Path('/workspace/work/validation/ended-cache-counterexample-headroom-20261114/elf-witness');M=pathlib.Path('/workspace/work/terminal.ui');TASKS=('incremental-cache-counterexamples',);ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def read(n):return json.loads((O/n).read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():
 s=os.statvfs(M);return s.f_bavail*s.f_frsize
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
def state():
 a={'main':{'head':git(M,'rev-parse','HEAD'),'tree':git(M,'rev-parse','HEAD^{tree}'),'config_sha256':sha(M/'.git/config')}}
 for t in TASKS:
  p=pathlib.Path('/workspace/work')/t/'source';a[t]={'head':git(p,'rev-parse','HEAD'),'tree':git(p,'rev-parse','HEAD^{tree}'),'status':git(p,'status','--porcelain=v1','--untracked-files=all')}

 head=a['incremental-cache-counterexamples']['head'];data=subprocess.check_output(['git','cat-file','commit',head],cwd=M,env=ENV)
 a['historical_source_commit']={'oid':head,'sha256':hashlib.sha256(data).hexdigest(),'tree':git(M,'rev-parse',head+'^{tree}')}
 assert a['main']['head']=='107ef32cde77fdd343fd8f6762132aa01df0143a'
 return a
def record(p):
 s=p.lstat();r={'path':str(p),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
 if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
 elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
 elif stat.S_ISFIFO(s.st_mode):r.update(type='preserved_raw_fifo')
 elif stat.S_ISSOCK(s.st_mode):r.update(type='preserved_raw_socket')
 else:raise AssertionError('unexpected special '+str(p))
 return r
def inventory(exclude):
 a=[]
 for root in [pathlib.Path('/workspace/work')/task for task in TASKS]:
  for d,ds,fs in os.walk(root,followlinks=False):
   ds[:]=[n for n in ds if n!='.git']
   for n in sorted(ds+fs):
    p=pathlib.Path(d)/n
    if p.is_dir() and not p.is_symlink():continue
    if str(p) not in exclude:a.append(record(p))
 return sorted(a,key=lambda r:r['path'])
def compress(src,sink):
 with gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as z,src.open('rb') as f:
  while b:=f.read(1024*1024):z.write(b)
def verify_gz(p,expected):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 assert h.hexdigest()==expected['sha256'] and n==expected['size'],'gzip verification mismatch'
class Count:
 def __init__(self):self.n=0
 def write(self,b):self.n+=len(b);return len(b)
 def flush(self):pass
def protected_physical_pins():
 P=pathlib.Path('/workspace/work/incremental-cache-counterexamples');ix=P/'index.json';assert sha(ix)=='12a096b9bffc9f46893e9f798cc0c767dc8a347b1279ca6ed8dc4e77b589042c';v=json.loads(ix.read_text());assert git(P/'source','rev-parse','HEAD')==v['test_only_commit']=='58d94a6d0d86bcec41c7abfb6ba0c3418b29dfc4'
 assert v['current_ELF']['sha256']=='53cc258f42ae8f9492092b7885f6f5ae78a4578a6a94aa07ff1a7e7a3984e5ef'
 rows=v['artifacts'];assert len(rows)==12
 for r in rows:
  p=pathlib.Path(r['path']);assert p.is_file() and sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
 return rows
if sys.argv[1]=='prepare':
 assert not (O/'plan.json').exists()
 plan=[]
 hashes=('12a096b9bffc9f46893e9f798cc0c767dc8a347b1279ca6ed8dc4e77b589042c',)
 for task,expected in zip(TASKS,hashes):
  ix=pathlib.Path('/workspace/work')/task/'index.json';assert sha(ix)==expected
  for item in [json.loads(ix.read_text())['current_ELF']]:
   p=pathlib.Path(item['path'])
   if p.suffix=='.cjp':continue
   assert p.resolve()==p and not p.is_symlink();r=record(p)
   assert r['type']=='file' and r['sha256']==item['sha256'] and r['size']==item['bytes'] and r['nlink']==1
   with p.open('rb') as f:assert f.read(4)==b'\x7fELF'
   r.update(source_index=str(ix),source_index_sha256=expected,witness=str(O/(r['sha256']+'.gz')));plan.append(r)
 assert len(plan)==1
 write('protected-physical-pins-before.json',protected_physical_pins())
 write('counterexample-disposition-before.json',{'test_source':'58d94a6d0d86bcec41c7abfb6ba0c3418b29dfc4','fixed_product':'f89d3726b76441e144ac501a5cba5a84549db6c8','runtime_result':'expected RED counterexamples; unchanged, no acceptance or rerun','original_index':'immutable; current ELF logical path resolves through verified gzip map aftermigration','C134_active_source':'not guarded, read, or modified'})
 counter=Count();compress(pathlib.Path(plan[0]['path']),counter)
 assert free()>=counter.n+1024*1024,'first gzip cannot fit with 1MiB receipt reserve'
 write('disk-gate-first.json',{'free_bytes':free(),'first_gzip_exact_bytes':counter.n,'reserve_bytes':1048576})
 write('plan.json',plan);write('preserved-before.json',inventory({r['path'] for r in plan}));write('state-before.json',state());write('progress.json',[]);write('free-before.json',{'bytes':free()})
 print(json.dumps({'prepared':1,'first_gzip_bytes':counter.n,'free_bytes':free()}),flush=True)
elif sys.argv[1]=='next':
 plan=read('plan.json');progress=read('progress.json');i=len(progress);assert i<len(plan)
 r=plan[i];src=pathlib.Path(r['path']);dest=pathlib.Path(r['witness']);assert not dest.exists()
 proc=read('process-final.json');assert not proc['busy'] and not proc['unexpected_denied']
 current=record(src);assert all(current[k]==r[k] for k in current),'original changed'
 assert state()==read('state-before.json'),'Git state changed'
 counter=Count();compress(src,counter);assert free()>=counter.n+256*1024,'gzip disk gate failed'
 beforefree=free();write(f'{i+1}-before.json',{'original':r,'free_bytes':beforefree,'gzip_expected_bytes':counter.n})
 # Exclusive create; original remains intact until compressed bytes pass full decompression proof and fsync.
 with dest.open('xb') as f:compress(src,f);f.flush();os.fsync(f.fileno())
 assert dest.stat().st_size==counter.n
 verify_gz(dest,r);assert sha(src)==r['sha256'] and src.stat().st_size==r['size']
 os.chmod(dest,0o444)
 write(f'{i+1}-verified-before-unlink.json',{'original_sha256':r['sha256'],'original_bytes':r['size'],'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'decompressed_equals_original':True})
 fd=os.open(src.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],r['size'],r['mtime_ns'])
  os.unlink(src.name,dir_fd=fd)
 finally:os.close(fd)
 result={'logical_original_path':r['path'],'physical_original_present':False,'original_sha256':r['sha256'],'original_bytes':r['size'],'original_mode':r['mode'],'original_uid':r['uid'],'original_gid':r['gid'],'original_mtime_ns':r['mtime_ns'],'witness':str(dest),'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'source_index':r['source_index'],'source_index_sha256':r['source_index_sha256'],'original_allocated_bytes':r['allocated_bytes'],'witness_allocated_bytes':dest.stat().st_blocks*512,'free_after_bytes':free(),'net_free_delta_bytes':free()-beforefree}
 progress.append(result);write('progress.json',progress);write(f'{i+1}-after.json',result);print(json.dumps(result),flush=True)
elif sys.argv[1]=='finish':
 plan=read('plan.json');progress=read('progress.json');assert len(progress)==1
 for r in plan:assert not pathlib.Path(r['path']).exists();verify_gz(pathlib.Path(r['witness']),r)
 after=inventory({r['path'] for r in plan});assert after==read('preserved-before.json'),'noncandidate files changed'
 assert state()==read('state-before.json'),'Git state changed'
 assert protected_physical_pins()==read('protected-physical-pins-before.json')
 write('protected-physical-pins-after.json',protected_physical_pins())
 write('preserved-after.json',after);write('state-after.json',state())
 summary={'state':'complete','witness_count':1,'all_original_bytes_preserved':True,'all_nonmigrated_files_unchanged':len(after),'allocated_recovered_bytes':sum(x['original_allocated_bytes']-x['witness_allocated_bytes'] for x in progress),'net_free_recovered_bytes':free()-read('free-before.json')['bytes'],'free_bytes':free(),'logical_artifact_mapping':'progress.json','restoration':'python3 restore.py ORIGINAL_PATH; refuses overwrite; verifies original bytes then applies mode/uid/gid/mtime; inode/ctime historical only'}
 write('summary.json',summary);print(json.dumps(summary),flush=True)
