import pathlib,json,os,stat,hashlib,subprocess,sys,tomllib
from pin_scan import scan
O=pathlib.Path(__file__).parent;ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};M=pathlib.Path('/workspace/work/terminal.ui')
def read(n):return json.loads((O/n).read_text())
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV,stderr=subprocess.DEVNULL).decode().strip()
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
def state(P,R):
 out={'main_head':git(M,'rev-parse','HEAD'),'main_tree':git(M,'rev-parse','HEAD^{tree}'),'main_config_sha256':sha(M/'.git/config')};assert out['main_head']=='107ef32cde77fdd343fd8f6762132aa01df0143a'
 manifest=R.parent.parent/'cjpm.toml';v=tomllib.loads(manifest.read_text());assert v['package']['cjc-version']=='1.2.0'
 src=(manifest.parent/v['dependencies']['cjtui']['path']).resolve();assert src.is_dir() and str(src).startswith(str(P)+'/')
 out['actual_source_input']=str(src);out['consumer_manifest_sha256']=sha(manifest);out['source_manifest_sha256']=sha(src/'cjpm.toml');out['SDK_requirement']='Cangjie1.2.0; preserve existing global SDK/stdx/cache/native inputs'
 try:out['source_git']={'head':git(src,'rev-parse','HEAD'),'tree':git(src,'rev-parse','HEAD^{tree}'),'status':git(src,'status','--porcelain=v1','--untracked-files=all')}
 except subprocess.CalledProcessError:out['source_git']='not Git-managed; exact local source filesystem snapshot preserves actual rebuild inputs'
 return out

def inventory(P,exclude):
 out=[]
 for d,ds,fs in os.walk(P,followlinks=False):
  ds[:]=[n for n in ds if n!='.git']
  for name in sorted(ds+fs):
   p=pathlib.Path(d)/name
   if str(p) in exclude:continue
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   r={'path':str(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
   if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
   elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
   elif stat.S_ISFIFO(s.st_mode):r.update(type='preserved_fifo')
   elif stat.S_ISSOCK(s.st_mode):r.update(type='preserved_socket')
   else:raise AssertionError('unexpected special '+str(p))
   out.append(r)
 return sorted(out,key=lambda r:r['path'])
r=read('old-root-selected.json')
if r is None:print('no eligible root; no older cleanup');sys.exit(0)
P=pathlib.Path(r['role']);R=pathlib.Path(r['release_root']);assert str(R) in ('/workspace/work/widgets-small-implementation/probe/target/release','/workspace/work/keyboard-implementation/phase-final-01/api/events-setter/target/release')
paths={f['path'] for f in r['files']}
if sys.argv[1]=='prepare':
 assert not scan(P,map(pathlib.Path,paths))['holds'];write('old-root-state-before.json',state(P,R));write('old-root-noncandidates-before.json',inventory(P,paths));print(json.dumps({'prepared':str(R),'files':len(paths),'free_bytes':free()}),flush=True)
elif sys.argv[1]=='reclaim':
 assert not (O/'old-root-result.json').exists(),'already processed one older root'
 assert state(P,R)==read('old-root-state-before.json')
 proc=read('old-process-final.json');assert not proc['busy'] and not proc['unexpected_denied']
 assert not scan(P,map(pathlib.Path,paths))['holds'];before=free()
 for f in r['files']:
  p=pathlib.Path(f['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)==(f['device'],f['inode'],f['bytes'],f['mtime_ns'],f['nlink']) and sha(p)==f['sha256']
  fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
  try:
   t=os.stat(p.name,dir_fd=fd,follow_symlinks=False);assert(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino);os.unlink(p.name,dir_fd=fd)
  finally:os.close(fd)
 afterfree=free();after=inventory(P,paths);assert after==read('old-root-noncandidates-before.json');assert state(P,R)==read('old-root-state-before.json')
 write('old-root-noncandidates-after.json',after);write('old-root-state-after.json',state(P,R));result={'state':'complete','only_older_root_removed':str(R),'removed_files':len(paths),'allocated_recovered_bytes':sum(f['allocated_bytes'] for f in r['files']),'observed_free_recovery_at_unlink_bytes':afterfree-before,'free_bytes':free(),'all_noncandidate_files_unchanged':len(after),'actual_source_SDK_recompile_recipe_preserved':True,'C134_active_tree_not_guarded_or_touched':True};write('old-root-result.json',result);print(json.dumps(result),flush=True)
