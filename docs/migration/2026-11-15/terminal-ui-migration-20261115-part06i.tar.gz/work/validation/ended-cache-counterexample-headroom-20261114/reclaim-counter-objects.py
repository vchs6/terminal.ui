import pathlib,json,os,stat,hashlib,subprocess,sys
from pin_scan import scan
O=pathlib.Path(__file__).parent;M=pathlib.Path('/workspace/work/terminal.ui');ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};ALLOWED={'cjtui','ansies','unicode','unicodewidth','cangjie_toml','bitarray'}
SPECS=[('incremental-cache-counterexamples','12a096b9bffc9f46893e9f798cc0c767dc8a347b1279ca6ed8dc4e77b589042c')]
def write(n,x):(O/n).write_text(json.dumps(x,separators=(',',':'))+'\n')
def read(n):return json.loads((O/n).read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
def source_state():
 out={}
 for role,_ in SPECS:
  p=pathlib.Path('/workspace/work')/role/'source';assert git(p,'rev-parse','--show-toplevel')==str(p)
  out[role]={'head':git(p,'rev-parse','HEAD'),'tree':git(p,'rev-parse','HEAD^{tree}'),'status':git(p,'status','--porcelain=v1','--untracked-files=all'),'diff_sha256':hashlib.sha256(git(p,'diff','--binary','HEAD').encode()).hexdigest()}
 out['main']={'head':git(M,'rev-parse','HEAD'),'tree':git(M,'rev-parse','HEAD^{tree}'),'config_sha256':sha(M/'.git/config')}
 assert out['main']['head']=='107ef32cde77fdd343fd8f6762132aa01df0143a'
 objects={}
 for rev in set(x['head'] for k,x in out.items() if k!='main')|{'f89d3726b76441e144ac501a5cba5a84549db6c8'}:
  data=subprocess.check_output(['git','cat-file','commit',rev],cwd=M,env=ENV);objects[rev]={'commit_bytes_sha256':hashlib.sha256(data).hexdigest(),'tree':git(M,'rev-parse',rev+'^{tree}')}
 out['historical_git_objects']=objects;return out

def verify_pins():
 P=pathlib.Path('/workspace/work/incremental-cache-counterexamples');ix=P/'index.json';assert sha(ix)==SPECS[0][1];v=json.loads(ix.read_text());assert v['test_only_commit']=='58d94a6d0d86bcec41c7abfb6ba0c3418b29dfc4';assert v['fixed_product_source']=='f89d3726b76441e144ac501a5cba5a84549db6c8'
 arts=v['artifacts'];elf=v['current_ELF'];assert elf['sha256']=='53cc258f42ae8f9492092b7885f6f5ae78a4578a6a94aa07ff1a7e7a3984e5ef'
 for a in arts+[elf]:
  p=pathlib.Path(a['path']);assert p.is_file() and sha(p)==a['sha256'] and p.stat().st_size==a['bytes']
 return [{'index':str(ix),'index_sha256':sha(ix),'artifacts':arts+[elf],'counterexample_disposition':'historical expectedRED; no acceptance or rerun'}]

def inventory(exclude):
 records=[]
 for role,_ in SPECS:
  P=pathlib.Path('/workspace/work')/role
  for d,ds,fs in os.walk(P,followlinks=False):
   ds[:]=[n for n in ds if n!='.git']
   for name in sorted(ds+fs):
    p=pathlib.Path(d)/name
    if str(p) in exclude:continue
    s=p.lstat()
    if stat.S_ISDIR(s.st_mode):continue
    r={'path':str(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
    if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
    elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
    elif stat.S_ISFIFO(s.st_mode):r.update(type='preserved_raw_fifo')
    elif stat.S_ISSOCK(s.st_mode):r.update(type='preserved_raw_socket')
    else:raise AssertionError('unexpected special '+str(p))
    records.append(r)
 return sorted(records,key=lambda r:r['path'])

if sys.argv[1]=='prepare':
 rows=[];pins=verify_pins();state=source_state()
 for role,_ in SPECS:
  P=pathlib.Path('/workspace/work')/role;R=P/'source/tests/incremental_layout/invalidation_cache/target/release';assert R.is_dir() and R.resolve()==R
  index=json.loads((P/'index.json').read_text());assert index['normal_build']['command']=='cjpm build' and index['normal_build']['workdir']==str(R.parent.parent)
  files=[];archives=[];skips=[]
  for pkg in sorted(ALLOWED):
   d=R/pkg
   if not d.is_dir():continue
   assert d.resolve()==d
   assert (R/'.build-logs'/pkg).is_dir()
   for p in sorted(d.iterdir()):
    if p.suffix not in ('.a','.cjo'):continue
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p
    if p.suffix=='.a':
     pair=p.with_name(p.name[3:-2]+'.cjo');assert pair.is_file() and not pair.is_symlink()
     with pair.open('rb') as f:assert f.read(8)[4:8]==b'CJOF'
     members=subprocess.check_output(['ar','t',str(p)]).decode().splitlines();assert members and all(m.startswith(pkg) and m.endswith('.o') and '/' not in m for m in members)
     archives.append({'path':str(p),'paired_cjo':str(pair),'archive_members':members})
    else:
     with p.open('rb') as f:assert f.read(8)[4:8]==b'CJOF'
    files.append({'path':str(p),'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512})
  pin=scan(P,map(lambda f:pathlib.Path(f['path']),files));held={x['path'] for x in pin['holds']};eligible=[f for f in files if f['path'] not in held]
  assert all(f['path'] not in {a['path'] for pin in pins for a in pin['artifacts']} for f in eligible)
  rows.append({'role':str(P),'release_root':str(R),'all_candidates':files,'eligible_files':eligible,'archive_provenance':archives,'proof_pin_scan':pin,'skipped_held_files':[f for f in files if f['path'] in held]})
 selected={f['path'] for r in rows for f in r['eligible_files']};assert selected
 write('candidate-plan.json',rows);write('source-main-before.json',state);write('sealed-pins-before.json',pins);write('noncandidate-files-before.json',inventory(selected));write('free-before.json',{'bytes':free()})
 print(json.dumps({'prepared_roots':1,'eligible_files':len(selected),'allocated_bytes':sum(f['allocated_bytes'] for r in rows for f in r['eligible_files']),'free_bytes':free()}),flush=True)
elif sys.argv[1]=='reclaim':
 rows=read('candidate-plan.json');assert source_state()==read('source-main-before.json');assert verify_pins()==read('sealed-pins-before.json')
 proc=read('process-final.json');assert not proc['busy'] and not proc['unexpected_denied']
 results=[]
 for i,r in enumerate(rows):
  assert not scan(r['role'],[pathlib.Path(f['path']) for f in r['eligible_files']])['holds']
  before=free();allocated=0
  for f in r['eligible_files']:
   p=pathlib.Path(f['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink,stat.S_IMODE(s.st_mode))==(f['device'],f['inode'],f['bytes'],f['mtime_ns'],f['nlink'],f['mode']) and sha(p)==f['sha256']
   fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
   try:
    t=os.stat(p.name,dir_fd=fd,follow_symlinks=False);assert (t.st_dev,t.st_ino)==(s.st_dev,s.st_ino);os.unlink(p.name,dir_fd=fd)
   finally:os.close(fd)
   allocated+=f['allocated_bytes']
  result={'release_root':r['release_root'],'removed_files':len(r['eligible_files']),'allocated_bytes_removed':allocated,'free_before_bytes':before,'free_after_bytes':free(),'observed_free_recovery_bytes':free()-before};results.append(result);write('root-'+str(i+1)+'-after.json',result);print(json.dumps(result),flush=True)
 selected={f['path'] for r in rows for f in r['eligible_files']};after=inventory(selected);assert after==read('noncandidate-files-before.json'),'noncandidate files changed'
 assert source_state()==read('source-main-before.json'),'source/main/historical Git guard changed'
 assert verify_pins()==read('sealed-pins-before.json'),'sealed artifacts changed'
 write('noncandidate-files-after.json',after);write('source-main-after.json',source_state());write('sealed-pins-after.json',verify_pins());write('results.json',results)
 s={'state':'complete','removed_files':len(selected),'allocated_recovered_bytes':sum(r['allocated_bytes_removed'] for r in results),'observed_free_recovery_bytes':sum(r['observed_free_recovery_bytes'] for r in results),'free_bytes':free(),'noncandidate_files_unchanged':len(after),'counterexample_sealed_proof_and_current_ELF_unchanged':True,'source_main_and_historical_git_objects_unchanged':True,'activeC134_not_guarded_or_touched':True,'reconstruction':'ordinary CJPM builds in the recorded original shared target using preserved source/test versions, locks/config, SDK and native dependencies; generated objects are not artifact authority'}
 write('summary.json',s);print(json.dumps(s),flush=True)
