Completed exactly the three authorized headroom operations; no new global scan. (1) Removed61 unindexed paired generated Cangjie compiler .a/.cjo files from the ended counterexample consumer release packages, releasing32,694,272B. (2) Preserved the sole current ELF53cc258f42ae8f9492092b7885f6f5ae78a4578a6a94aa07ff1a7e7a3984e5ef (19,595,496B) in deterministic verified gzip5,654,072B, releasing13,942,784B allocation. Indexed original bytes/metadata and no exe/fd holders were proven; full gzip decompression SHA/length matched before original unlink and again afterward. (3) The primary older widgets-small-implementation/probe release root passed paired CJOF/ar provenance and45 local JSON pin scans with zero holds; removed only its61 generated objects, releasing32,448,512B. Fallback was not selected or modified; no other old root was considered.

Total actual allocated recovery:79,085,568B (75.42 MiB). Free at sealing:169,287,680B (161.45 MiB), meeting150MiB hold threshold.

All381 other counterexample role files and1980 other older-role files remained exact, including source/raw/native/config/index/lock/manifests/CJP and all other ELF runtimes. Counterexample index12a096b9bffc9f46893e9f798cc0c767dc8a347b1279ca6ed8dc4e77b589042c and twelve proof artifacts remain immutable. Fixed test58d94a6d/productf89 counterexample results remain RED and unchanged; no acceptance or test rerun is claimed. Source58 HEAD/tree/status and exact f89 Git commit/tree objects, plus main107 HEAD/tree/config, stayed unchanged. C134 active source and unrelated code-worker refs were never guarded/read/modified.

The older consumer manifest specifies SDK1.2.0 and dependency cjtui at preserved ../source; actual source/SDK/config recipe and full source/native/evidence file snapshots are retained. Normal CJPM rebuild from preserved inputs recreates compiler representations; audit hashes are not new object-retention pins. Candidate came from the previously sealed inventory, not a new discovery scan.

The sole counterexample ELF path is now a logical historical artifact reference backed by elf-witness/progress.json. Its original SHA/bytes/mode/uid/gid/mtime are retained; inode/ctime are historical only. Restore safely with room for the original:

```sh
python3 /workspace/work/validation/ended-cache-counterexample-headroom-20261114/elf-witness/restore.py ORIGINAL_ABSOLUTE_PATH
```

The helper verifies compressed/original SHA+bytes, refuses existing destinations, restores mode/uid/gid/mtime, and publishes through an exclusive temporary file plus atomic nonoverwriting link. Witness remains intact. No huge gzip was published. Process proofs had no task holders/unexpected denial and only six prior explicit runtime-service exclusions (646 zombies skipped).
