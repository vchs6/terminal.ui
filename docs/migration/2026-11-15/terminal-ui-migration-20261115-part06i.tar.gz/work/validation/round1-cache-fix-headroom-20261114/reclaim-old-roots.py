import pathlib,json,os,stat,hashlib,subprocess,sys,tomllib,gzip,io,re
from pin_scan import scan
O=pathlib.Path(__file__).parent;ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};M=pathlib.Path('/workspace/work/terminal.ui');P=pathlib.Path('/workspace/work/keyboard-implementation')
def read(n):return json.loads((O/n).read_text())
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def writegz(n,v):
 with (O/n).open('wb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z,io.TextIOWrapper(z,encoding='utf-8') as t:json.dump(v,t,separators=(',',':'))
def readgz(n):
 with gzip.open(O/n,'rt') as f:return json.load(f)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV,stderr=subprocess.DEVNULL).decode().strip()
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
def state(R):
 out={'main_head':git(M,'rev-parse','HEAD'),'main_tree':git(M,'rev-parse','HEAD^{tree}'),'main_config_sha256':sha(M/'.git/config')};assert out['main_head']=='107ef32cde77fdd343fd8f6762132aa01df0143a'
 manifest=R.parent.parent/'cjpm.toml';v=tomllib.loads(manifest.read_text());assert v['package']['cjc-version']=='1.2.0';src=(manifest.parent/v['dependencies']['cjtui']['path']).resolve();assert src.is_dir() and str(src).startswith(str(P)+'/')
 out.update(actual_source_input=str(src),consumer_manifest_sha256=sha(manifest),source_manifest_sha256=sha(src/'cjpm.toml'),SDK_requirement='Cangjie1.2.0 with preserved local config/locks and existing SDK/stdx/cache/native inputs')
 try:out['source_git']={'head':git(src,'rev-parse','HEAD'),'tree':git(src,'rev-parse','HEAD^{tree}'),'status':git(src,'status','--porcelain=v1','--untracked-files=all')}
 except subprocess.CalledProcessError:out['source_git']='exact non-Git source filesystem snapshot preserves actual rebuild inputs'
 return out

def inventory(exclude):
 out=[]
 for d,ds,fs in os.walk(P,followlinks=False):
  ds[:]=[n for n in ds if n!='.git']
  for name in sorted(ds+fs):
   p=pathlib.Path(d)/name
   if str(p) in exclude:continue
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   r={'path':str(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
   if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
   elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
   elif stat.S_ISFIFO(s.st_mode):r.update(type='preserved_fifo')
   elif stat.S_ISSOCK(s.st_mode):r.update(type='preserved_socket')
   else:raise AssertionError('unexpected special '+str(p))
   out.append(r)
 return sorted(out,key=lambda r:r['path'])
def checksum_pins(paths):
 holds=[];count=0
 for d,ds,fs in os.walk(P,followlinks=False):
  ds[:]=[n for n in ds if n not in ('.git','target','cache','node_modules')]
  for name in fs:
   p=pathlib.Path(d)/name
   if p.is_symlink() or not (name.endswith(('.sha256','.sha','.sums')) or (any(k in name.lower() for k in ('checksum','hashes','manifest')) and name.endswith(('.txt','.tsv','.log')))):continue
   try:text=p.read_text()
   except (OSError,UnicodeError):continue
   count+=1
   for line in text.splitlines():
    m=re.match(r'^([0-9a-f]{64})\s+\*?(.+?)\s*$',line)
    if not m:continue
    digest,path=m.groups();q=pathlib.Path(path);candidates=[q] if q.is_absolute() else [P/q,P/'source'/q,p.parent/q]
    for q in candidates:
     if str(q) in paths:holds.append({'path':str(q),'manifest':str(p),'sha256':digest})
 return {'text_manifests_checked':count,'holds':holds}
rows=read('old-root-selected.json');assert len(rows)<=2
allowed={'/workspace/work/keyboard-implementation/phase-final-01/api/events-setter/target/release','/workspace/work/keyboard-implementation/phase-final-01/api/diagnostics-setter/target/release'}
assert all(r['release_root'] in allowed for r in rows);paths={f['path'] for r in rows for f in r['files']}
if sys.argv[1]=='prepare':
 assert not scan(P,map(pathlib.Path,paths))['holds'];extra=checksum_pins(paths);write('old-text-checksum-pin-scan.json',extra);assert not extra['holds'],'plaintext authority pins candidate'
 write('old-roots-state-before.json',[state(pathlib.Path(r['release_root'])) for r in rows]);writegz('old-roots-noncandidates-before.json.gz',inventory(paths));print(json.dumps({'prepared_roots':len(rows),'files':len(paths),'free_bytes':free()}),flush=True)
elif sys.argv[1]=='reclaim':
 assert not (O/'old-roots-result.json').exists()
 assert [state(pathlib.Path(r['release_root'])) for r in rows]==read('old-roots-state-before.json')
 proc=read('old-process-final.json');assert not proc['busy'] and not proc['unexpected_denied'];assert not scan(P,map(pathlib.Path,paths))['holds'] and not checksum_pins(paths)['holds']
 results=[]
 for i,r in enumerate(rows):
  before=free()
  for f in r['files']:
   p=pathlib.Path(f['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)==(f['device'],f['inode'],f['bytes'],f['mtime_ns'],f['nlink']) and sha(p)==f['sha256']
   fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
   try:
    t=os.stat(p.name,dir_fd=fd,follow_symlinks=False);assert(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino);os.unlink(p.name,dir_fd=fd)
   finally:os.close(fd)
  v={'release_root':r['release_root'],'removed_files':len(r['files']),'allocated_recovered_bytes':sum(f['allocated_bytes'] for f in r['files']),'observed_free_recovery_bytes':free()-before,'free_bytes':free()};results.append(v);write('old-root-'+str(i+1)+'-after.json',v);print(json.dumps(v),flush=True)
 after=inventory(paths);assert after==readgz('old-roots-noncandidates-before.json.gz');assert [state(pathlib.Path(r['release_root'])) for r in rows]==read('old-roots-state-before.json')
 writegz('old-roots-noncandidates-after.json.gz',after);write('old-roots-state-after.json',[state(pathlib.Path(r['release_root'])) for r in rows]);result={'state':'complete','only_named_roots_removed':[r['release_root'] for r in rows],'removed_files':len(paths),'allocated_recovered_bytes':sum(v['allocated_recovered_bytes'] for v in results),'observed_free_recovery_at_unlink_bytes':sum(v['observed_free_recovery_bytes'] for v in results),'free_bytes':free(),'all_noncandidate_files_unchanged':len(after),'source_SDK_rebuild_inputs_preserved':True};write('old-roots-result.json',result);print(json.dumps(result),flush=True)
