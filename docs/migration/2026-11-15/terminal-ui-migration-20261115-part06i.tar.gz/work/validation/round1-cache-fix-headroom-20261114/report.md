Completed exactly the bounded round-one capacity scope. Four executed sole round1 BIN ELF artifacts from immutable index09119b6a306fb444b6edbac514305d0d2275f9554fff5bc81b55308fffb22c5d/source4e30434a were preserved as deterministic gzip witnesses (mtime0, no filename). All77,059,048 original bytes remain in22,281,266 gzip bytes; every indexed original SHA/length and still-present payload matched full decompression before original unlink, and every witness passed another full decompression check at completion. CJP was excluded.

Only the two named old keyboard API roots (events-setter and diagnostics-setter) were removed:61 generated paired compiler .a/.cjo files per root,122 total. CJOF/ar package-object provenance, actual source/SDK1.2.0 consumer recipes and fresh process proof passed. Each root had zero holds after4,402 local JSON proof manifests; supplemental plaintext checksum-manifest audit also found no candidate pins. No other old root or fallback was considered. Discovery used only the already sealed inventory.

ELF allocation recovery54,779,904B plus old object recovery63,930,368B =118,710,272B (113.21 MiB). Free at sealing:172,433,408B (164.45 MiB), meeting150MiB. No expansion beyond this scope.

All611 other Cproducer files stayed exact, specifically retaining the entire C134 root compiler cache for incremental reuse, all CJP/source/raw/config/native files, original round1 and initial indices, prior gzip payloads/maps and immutable alias receipts. All30,303 other old-role files/ELFs/native/GCC archives/source/raw/indices/config stayed exact. Their complete before/after audit snapshots are losslessly compressed metadata rather than source copies. Actual source4e and main107 HEAD/tree/config plus historical Git objects stayed unchanged; unrelated worker refs were not frozen. New R1 counterexample, old58/f89/T133 and C/D workspaces were untouched. This storage migration makes no acceptance or test-rerun claim.

The four old round1 BIN paths are now historical logical artifact references resolved by elf-witness/progress.json, which records original SHA/bytes/mode/uid/gid/mtime and compressed witness SHA/bytes. Original inode/ctime are historical only. These BIN names are distinct from the unchanged initial failed-candidate transitive alias mappings. No huge gzip was published.

Safe exclusive restoration, with room for one original:

```sh
python3 /workspace/work/validation/round1-cache-fix-headroom-20261114/elf-witness/restore.py ORIGINAL_ABSOLUTE_ROUND1_BIN_PATH
```

The helper verifies witness/original SHA+bytes, refuses existing destinations, restores mode/uid/gid/mtime, and publishes atomically without overwrite. Witnesses remain intact. Old compiler objects can be rebuilt through ordinary CJPM in the recorded consumers using preserved local source/locks/config/SDK/native inputs; their hashes are deletion audit metadata, not artifact-retention pins. Process proofs had no holders/unexpected denial, with only the six documented unrelated container-service exclusions (647 zombies skipped).
