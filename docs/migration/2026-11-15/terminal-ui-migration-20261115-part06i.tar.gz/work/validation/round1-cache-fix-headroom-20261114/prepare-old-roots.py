import pathlib,json,os,stat,hashlib,subprocess
from pin_scan import scan
O=pathlib.Path(__file__).parent;inventory=json.loads(pathlib.Path('/workspace/work/validation/ended-129-bundle-intermediates-20261114/workspace-unapproved-candidates.json').read_text());allowed={'cjtui','ansies','unicode','unicodewidth','cangjie_toml','bitarray'};attempts=[];selected=None
specs=[('/workspace/work/keyboard-implementation','phase-final-01/api/events-setter/target/release'),('/workspace/work/keyboard-implementation','phase-final-01/api/diagnostics-setter/target/release')]
selected=[]
for role,rel in specs:
 P=pathlib.Path(role);R=P/rel;cached=next((r for r in inventory if r['release_root']==str(R)),None);assert cached,'not in existing approved inventory'
 if not R.is_dir() or R.resolve()!=R:
  attempts.append({'root':str(R),'skip':'missing or symlink root'});continue
 files=[];archives=[];bad=[]
 for pkg in sorted(allowed):
  d=R/pkg
  if not d.is_dir():continue
  if d.resolve()!=d:bad.append(str(d));continue
  for p in sorted(d.iterdir()):
   if p.suffix not in ('.a','.cjo'):continue
   s=p.lstat()
   if not stat.S_ISREG(s.st_mode) or p.resolve()!=p:bad.append(str(p));continue
   if p.suffix=='.a':
    pair=p.with_name(p.name[3:-2]+'.cjo')
    if not pair.is_file() or pair.is_symlink():bad.append(str(p));continue
    with pair.open('rb') as f:magic=f.read(8)
    if magic[4:8]!=b'CJOF':bad.append(str(pair));continue
    members=subprocess.check_output(['ar','t',str(p)]).decode().splitlines()
    if not members or not all(m.startswith(pkg) and m.endswith('.o') and '/' not in m for m in members):bad.append(str(p));continue
    archives.append({'path':str(p),'paired_cjo':str(pair),'members':members})
   else:
    with p.open('rb') as f:magic=f.read(8)
    if magic[4:8]!=b'CJOF':bad.append(str(p));continue
   with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   files.append({'path':str(p),'sha256':h,'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512})
 pin=scan(P,[pathlib.Path(f['path']) for f in files])
 attempt={'root':str(R),'role':str(P),'candidate_count':len(files),'candidate_allocated_bytes':sum(f['allocated_bytes'] for f in files),'artifact_holds':pin['holds'],'bad':bad,'pin_manifest_count':pin['json_manifests_checked']};attempts.append(attempt)
 if pin['holds'] or bad or not files:continue
 manifest=R.parent.parent/'cjpm.toml';assert manifest.is_file();recipe={'consumer_cwd':str(R.parent.parent),'cjpm_manifest_path':str(manifest),'cjpm_manifest_text':manifest.read_text(),'command':'source preserved SDK1.2.0 env then ordinary cjpm build from recorded consumer; preserved local cangjie-repo/lock/native and fixed dependency source inputs','native_and_SDK_cache':'untouched'}
 chosen={'role':str(P),'release_root':str(R),'files':files,'archive_provenance':archives,'pin_scan':pin,'source_sdk_recipe':recipe,'discovery':'exact root from previously recorded inventory; no new global scan'};selected.append(chosen)
(O/'old-root-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n');(O/'old-root-selected.json').write_text(json.dumps(selected,separators=(',',':'))+'\n')
print(json.dumps({'attempts':attempts,'selected_roots':[r['release_root'] for r in selected]},indent=2))
