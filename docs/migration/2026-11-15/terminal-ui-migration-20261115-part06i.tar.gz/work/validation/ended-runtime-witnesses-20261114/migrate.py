import pathlib,os,stat,json,hashlib,gzip,subprocess,sys
O=pathlib.Path('/workspace/work/validation/ended-runtime-witnesses-20261114');M=pathlib.Path('/workspace/work/terminal.ui');TASKS=('theme-showcase-execution','incremental-layout-tests','frame-cow-tests','incremental-layout-implementation');ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def write(n,v):(O/n).write_text(json.dumps(v,separators=(',',':'))+'\n')
def read(n):return json.loads((O/n).read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():
 s=os.statvfs(M);return s.f_bavail*s.f_frsize
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
def state():
 a={'main':{'head':git(M,'rev-parse','HEAD'),'tree':git(M,'rev-parse','HEAD^{tree}'),'config_sha256':sha(M/'.git/config'),'refs_sha256':hashlib.sha256(git(M,'for-each-ref').encode()).hexdigest()}}
 for t in TASKS:
  p=pathlib.Path('/workspace/work')/t/'source';a[t]={'head':git(p,'rev-parse','HEAD'),'tree':git(p,'rev-parse','HEAD^{tree}'),'status':git(p,'status','--porcelain=v1','--untracked-files=all')}
 return a
def record(p):
 s=p.lstat();r={'path':str(p),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
 if stat.S_ISREG(s.st_mode):r.update(type='file',sha256=sha(p))
 elif stat.S_ISLNK(s.st_mode):r.update(type='symlink',target=os.readlink(p))
 else:raise AssertionError('unexpected special '+str(p))
 return r
def inventory(exclude):
 a=[]
 for task in TASKS:
  root=pathlib.Path('/workspace/work')/task
  for d,ds,fs in os.walk(root,followlinks=False):
   for n in sorted(ds+fs):
    p=pathlib.Path(d)/n
    if p.is_dir() and not p.is_symlink():continue
    if str(p) not in exclude:a.append(record(p))
 return sorted(a,key=lambda r:r['path'])
def compress(src,sink):
 with gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as z,src.open('rb') as f:
  while b:=f.read(1024*1024):z.write(b)
def verify_gz(p,expected):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 assert h.hexdigest()==expected['sha256'] and n==expected['size'],'gzip verification mismatch'
class Count:
 def __init__(self):self.n=0
 def write(self,b):self.n+=len(b);return len(b)
 def flush(self):pass
if sys.argv[1]=='prepare':
 assert not (O/'plan.json').exists()
 plan=[]
 skips=[]
 themeix=pathlib.Path('/workspace/work/theme-showcase-execution/index.json');oldix=pathlib.Path('/workspace/work/incremental-layout-tests/source-and-artifact-hashes.json')
 assert sha(themeix)=='768d1ad0ad00f02c2e9d36a0b8732418173155d1f2782acdc1171cc8c7d0bd05'
 oldpath='/workspace/work/incremental-layout-tests/source/tests/incremental_layout/baseline/target/release/bin/main'
 oldbindings=[]
 def find(v):
  if isinstance(v,dict):
   if v.get('path')==oldpath:oldbindings.append(v)
   for x in v.values():find(x)
  elif isinstance(v,list):
   for x in v:find(x)
 find(json.loads(oldix.read_text()));assert len(oldbindings)==1
 specs=[('/workspace/work/theme-showcase-execution/source/examples/theme_showcase/target/release/bin/main','3887d29ff5728afae5cb9ab2b5a344ed10274645fd3079ae7a2a6659e50d4940',themeix,'accepted indexed theme ELF'),(oldpath,oldbindings[0]['sha256'],oldix,'historical true-RED123 indexed ELF'),('/workspace/work/frame-cow-tests/source/tests/incremental_layout/frame_cow/target/release/bin/unit-a-baseline',None,pathlib.Path('/workspace/work/frame-cow-tests/index.json'),'unindexed ended extra baseline runtime'),('/workspace/work/incremental-layout-implementation/source/target/release/unittest_bin/std.testrunner',None,pathlib.Path('/workspace/work/incremental-layout-implementation/index.json'),'unindexed generated SDK runner copy')]
 for name,expected,ix,why in specs:
  p=pathlib.Path(name)
  if not p.exists() or p.is_symlink() or p.resolve()!=p:
   skips.append({'path':name,'reason':'missing/symlink/path mismatch'});continue
  if not stat.S_ISREG(p.lstat().st_mode):
   skips.append({'path':name,'reason':'not regular'});continue
  r=record(p)
  if (expected and r['sha256']!=expected) or r['nlink']!=1:
   skips.append({'path':name,'reason':'indexed hash mismatch or shared inode','actual_sha256':r['sha256'],'expected_sha256':expected});continue
  with p.open('rb') as f:magic=f.read(4)
  if magic!=b'\x7fELF':
   skips.append({'path':name,'reason':'not ELF'});continue
  r.update(source_index=str(ix),source_index_sha256=sha(ix),provenance=why,witness=str(O/(r['sha256']+'.gz')));plan.append(r)
 write('skips.json',skips)
 assert plan,'no eligible runtime candidates'
 counter=Count();compress(pathlib.Path(plan[0]['path']),counter)
 assert free()>=counter.n+1024*1024,'first gzip cannot fit with 1MiB receipt reserve'
 write('disk-gate-first.json',{'free_bytes':free(),'first_gzip_exact_bytes':counter.n,'reserve_bytes':1048576})
 write('plan.json',plan);write('preserved-before.json',inventory({r['path'] for r in plan}));write('state-before.json',state());write('progress.json',[]);write('free-before.json',{'bytes':free()})
 print(json.dumps({'prepared':len(plan),'first_gzip_bytes':counter.n,'free_bytes':free()}),flush=True)
elif sys.argv[1]=='next':
 plan=read('plan.json');progress=read('progress.json');i=len(progress);assert i<len(plan)
 r=plan[i];src=pathlib.Path(r['path']);dest=pathlib.Path(r['witness']);assert not dest.exists()
 proc=read('process-final.json');assert not proc['busy'] and not proc['unexpected_denied']
 current=record(src);assert all(current[k]==r[k] for k in current),'original changed'
 assert state()==read('state-before.json'),'Git state changed'
 counter=Count();compress(src,counter);assert free()>=counter.n+256*1024,'gzip disk gate failed'
 beforefree=free();write(f'{i+1}-before.json',{'original':r,'free_bytes':beforefree,'gzip_expected_bytes':counter.n})
 # Exclusive create; original remains intact until compressed bytes pass full decompression proof and fsync.
 with dest.open('xb') as f:compress(src,f);f.flush();os.fsync(f.fileno())
 assert dest.stat().st_size==counter.n
 verify_gz(dest,r);assert sha(src)==r['sha256'] and src.stat().st_size==r['size']
 os.chmod(dest,0o444)
 write(f'{i+1}-verified-before-unlink.json',{'original_sha256':r['sha256'],'original_bytes':r['size'],'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'decompressed_equals_original':True})
 fd=os.open(src.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],r['size'],r['mtime_ns'])
  os.unlink(src.name,dir_fd=fd)
 finally:os.close(fd)
 result={'logical_original_path':r['path'],'physical_original_present':False,'original_sha256':r['sha256'],'original_bytes':r['size'],'original_mode':r['mode'],'original_uid':r['uid'],'original_gid':r['gid'],'original_mtime_ns':r['mtime_ns'],'witness':str(dest),'witness_sha256':sha(dest),'witness_bytes':dest.stat().st_size,'source_index':r['source_index'],'source_index_sha256':r['source_index_sha256'],'original_allocated_bytes':r['allocated_bytes'],'witness_allocated_bytes':dest.stat().st_blocks*512,'free_after_bytes':free(),'net_free_delta_bytes':free()-beforefree}
 progress.append(result);write('progress.json',progress);write(f'{i+1}-after.json',result);print(json.dumps(result),flush=True)
elif sys.argv[1]=='finish':
 plan=read('plan.json');progress=read('progress.json');assert len(progress)==len(plan)
 for r in plan:assert not pathlib.Path(r['path']).exists();verify_gz(pathlib.Path(r['witness']),r)
 after=inventory({r['path'] for r in plan});assert after==read('preserved-before.json'),'noncandidate files changed'
 assert state()==read('state-before.json'),'Git state changed'
 write('preserved-after.json',after);write('state-after.json',state())
 summary={'state':'complete','witness_count':len(plan),'all_original_bytes_preserved':True,'all_nonmigrated_files_unchanged':len(after),'allocated_recovered_bytes':sum(x['original_allocated_bytes']-x['witness_allocated_bytes'] for x in progress),'net_free_recovered_bytes':free()-read('free-before.json')['bytes'],'free_bytes':free(),'logical_artifact_mapping':'progress.json','restoration':'python3 restore.py ORIGINAL_PATH; refuses overwrite; verifies original bytes then applies mode/uid/gid/mtime; inode/ctime historical only'}
 write('summary.json',summary);print(json.dumps(summary),flush=True)
