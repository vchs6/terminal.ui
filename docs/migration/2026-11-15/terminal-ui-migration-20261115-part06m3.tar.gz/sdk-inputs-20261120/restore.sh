#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 4 ]]; then
  printf 'Usage: %s RESTORE_ROOT SDK_TAR STDX_ZIP ORIGINAL_STDX_RECEIPT\n' "$0" >&2
  exit 2
fi

check_sha256() {
  local checksum
  checksum=$(sha256sum < "$1")
  if [[ ${checksum%% *} != "$2" ]]; then
    printf 'SHA-256 mismatch for %s\n' "$1" >&2
    exit 1
  fi
}

restore_root=$(realpath -m -- "$1")
sdk_tar=$(realpath -- "$2")
stdx_zip=$(realpath -- "$3")
original_receipt=$(realpath -- "$4")
receipt_sha256=a8c7c4e5750cf9f5f2e381a24e3e8f47496a56cc8971318d634bd152f0830dec
check_sha256 "$original_receipt" "$receipt_sha256"
check_sha256 "$sdk_tar" 8c5fd944cd9cc51ee63d4a240e3ecc4f540345dae1468e8b47c927ecf2ba998f
check_sha256 "$stdx_zip" 0d35811d84a770315c6fa2d1090a10568b3f7c763a1d1d54a1433b324f76afc0

shopt -s nullglob dotglob
root_entries=("$restore_root"/*)
if [[ -L $1 || ( -e $restore_root && ! -d $restore_root ) || ${#root_entries[@]} -ne 0 ]]; then
  printf 'Restore destination must be a fresh, empty directory %s\n' "$restore_root" >&2
  exit 1
fi

umask 077
restore_parent=$(dirname -- "$restore_root")
staging=$(mktemp -d -- "$restore_parent/.sdk-restore.XXXXXXXX")
trap 'rm -rf -- "$staging"' EXIT
sdk_parent=$staging/validation/sdk
stdx_parent=$staging/linux-build-recon/stdx
stdx_name=cangjie-stdx-linux-x64-1.2.0-beta.02.1
stdx_layout=$staging/linux-build-recon/stdx-env
receipt_evidence_dir=$staging/migration-evidence/stdx
final_stdx=$restore_root/linux-build-recon/stdx/$stdx_name
mkdir -p -- "$sdk_parent" "$stdx_parent" "$stdx_layout" "$receipt_evidence_dir"
receipt_evidence=$receipt_evidence_dir/install.original.json
cp -- "$original_receipt" "$receipt_evidence"
chmod 0600 -- "$receipt_evidence"
check_sha256 "$receipt_evidence" "$receipt_sha256"

tar --extract --gzip --no-same-owner --no-same-permissions \
  --file "$sdk_tar" --directory "$sdk_parent"
python3 -I - "$stdx_zip" "$stdx_parent/$stdx_name" "$receipt_evidence" "$final_stdx" <<'PY'
import json
import sys
import tempfile
import zipfile
from pathlib import Path

archive, staged_installation, receipt_evidence = map(Path, sys.argv[1:4])
with tempfile.TemporaryDirectory(dir=staged_installation.parent) as scratch, zipfile.ZipFile(archive) as package:
    package.extractall(scratch)
    (Path(scratch) / 'linux_x86_64_cjnative').rename(staged_installation)

active_receipt = json.loads(receipt_evidence.read_bytes())
active_receipt['installation'] = sys.argv[4]
active_bytes = (json.dumps(active_receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
(staged_installation / 'install.json').write_bytes(active_bytes)
PY
ln -s -- "$final_stdx" "$stdx_layout/linux_x86_64_llvm"
mv -T -- "$staging" "$restore_root"
trap - EXIT
