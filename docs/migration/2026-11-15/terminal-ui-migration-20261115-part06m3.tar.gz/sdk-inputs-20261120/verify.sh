#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  printf 'Usage: %s RESTORE_ROOT\n' "$0" >&2
  exit 2
fi

python3 -I - "$1" <<'PY'
import hashlib
import json
import os
import stat
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve(strict=True)
sdk = root / 'validation/sdk/cangjie'
stdx = root / 'linux-build-recon/stdx/cangjie-stdx-linux-x64-1.2.0-beta.02.1'
layout = root / 'linux-build-recon/stdx-env'
evidence = root / 'migration-evidence/stdx/install.original.json'


def check(condition, message):
    if not condition:
        raise SystemExit(message)


def read_receipt(path):
    check(path.is_file() and not path.is_symlink(), f'Missing regular receipt {path}')
    check(stat.S_IMODE(path.lstat().st_mode) == 0o600, f'Expected receipt mode 0600 at {path}')
    return path.read_bytes()


def tree_digest(tree, include_mtime=False, exclude=()):
    rows = {}

    def visit(path):
        name = path.relative_to(tree).as_posix()
        if name in exclude:
            return
        meta = path.lstat()
        mode = stat.S_IMODE(meta.st_mode)
        if stat.S_ISDIR(meta.st_mode):
            rows[name] = [name, 'directory', mode, None, None]
            for child in path.iterdir():
                visit(child)
        elif stat.S_ISLNK(meta.st_mode):
            rows[name] = [name, 'symlink', mode, None, os.readlink(path)]
        elif stat.S_ISREG(meta.st_mode):
            with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
                sha = hashlib.file_digest(stream, 'sha256').hexdigest()
            rows[name] = [name, 'file', mode, meta.st_size, sha]
        else:
            raise SystemExit(f'Unexpected node type at {path}')
        if include_mtime:
            rows[name].append(meta.st_mtime_ns // 1_000_000_000)

    visit(tree)
    content = ''.join(json.dumps(rows[name], ensure_ascii=True, separators=(',', ':')) + '\n'
                      for name in sorted(rows))
    return hashlib.sha256(content.encode('ascii')).hexdigest()


original = read_receipt(evidence)
check(len(original) == 494, 'Original stdx receipt must be 494 bytes')
check(hashlib.sha256(original).hexdigest() == 'a8c7c4e5750cf9f5f2e381a24e3e8f47496a56cc8971318d634bd152f0830dec',
      'Original stdx receipt SHA-256 mismatch')
check(stat.S_IMODE(evidence.parent.lstat().st_mode) == 0o700, 'Expected evidence directory mode 0700')
active_path = stdx / 'install.json'
active = read_receipt(active_path)
check(not evidence.samefile(active_path), 'Original and active receipts must be separate files')
original_fields = json.loads(original)
check(original_fields['installation'] == '/workspace/work/linux-build-recon/stdx/cangjie-stdx-linux-x64-1.2.0-beta.02.1',
      'Invalid installation in historical stdx receipt')
active_fields = json.loads(active)
check(active_fields.pop('installation') == str(stdx), 'Active stdx receipt points outside the restored installation')
original_fields.pop('installation')
check(active_fields == original_fields, 'Active stdx receipt differs outside its installation field')
check(tree_digest(sdk, include_mtime=True) == 'cb382da18baa6fa71c678c13c2b1aa8c4a7a808274907baaffad1be86d51f4c2',
      'SDK tree digest mismatch')
check(tree_digest(stdx, exclude=('install.json',)) == '8fefa39b33e69e756fb7830f8e711052285a03aeba5c33c009a7a42302fd1c11',
      'stdx payload tree digest mismatch')
check(layout.is_dir() and not layout.is_symlink() and stat.S_IMODE(layout.lstat().st_mode) == 0o700,
      'Expected a stdx compatibility directory with mode 0700')
check(sorted(item.name for item in layout.iterdir()) == ['linux_x86_64_llvm'], 'Unexpected stdx compatibility entries')
link = layout / 'linux_x86_64_llvm'
check(link.is_symlink() and stat.S_IMODE(link.lstat().st_mode) == 0o777 and os.readlink(link) == str(stdx),
      'Invalid stdx compatibility symlink')
check((link / 'static/stdx/stdx.serialization.serialization.cjo').is_file(), 'Missing stdx serialization interface')
check((link / 'static/stdx/libstdx.serialization.serialization.a').is_file(), 'Missing stdx serialization archive')
print('SDK tree, stdx payload, original receipt, active receipt and compatibility link verified')
PY
