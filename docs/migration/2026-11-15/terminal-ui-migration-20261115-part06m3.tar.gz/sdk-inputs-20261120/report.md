# SDK 与 stdx 历史回执恢复修订

交付改为三个必需载荷，共 264993197 字节。原 SDK tar、原 stdx ZIP 及 494 字节的历史 stdx `install.json` 各自使用固定 SHA-256 验证。输入清单明确列出实际来源和交接文件名。本目录包含历史回执原字节。两份归档仍在原项目路径等待交接。接收侧校验三个载荷后可省去已核验的 SDK 和 stdx 展开树。 [输入清单](/workspace/work/migration-sdk-proof-revision/input-manifest.json) · [历史回执](/workspace/work/migration-sdk-proof-revision/stdx-install.original.json)

| 恢复内容（相对新根） | 字节与权限 |
|---|---|
| `migration-evidence/stdx/install.original.json` | 逐字节复制历史回执，494 B，`0600`，SHA-256 `a8c7c4e5750cf9f5f2e381a24e3e8f47496a56cc8971318d634bd152f0830dec`。历史绝对安装路径保存在原文中。 |
| `linux-build-recon/stdx/cangjie-stdx-linux-x64-1.2.0-beta.02.1/install.json` | 独立生成的活动回执，`0600`。唯一变更字段 `installation` 指向新根下的真实 stdx 安装。SHA-256 随目标路径而变。 |
| `linux-build-recon/stdx-env/linux_x86_64_llvm` | 兼容符号链接，模式 `0777`，使用新根下安装目录的绝对路径。 |

原命令的空根复现生成了活动回执。验收以退出码 1 报告历史回执文件缺失。修订后在另一个带空格的新 host RAM 根实际完成两份归档的纯离线解包和逐树验收。历史回执通过 `cmp` 与现场原件比较，模式、字节数和 SHA 均匹配。活动回执在该测试路径下为 546 字节，指向新根。将同长度篡改回执作为输入时，恢复在创建根之前拒绝。将该篡改内容写入临时验收根的历史回执位置时，验收也拒绝。换回原回执后验收再次通过。测试根已清理。 [校验记录](/workspace/work/migration-sdk-proof-revision/verification.json)

## 离线复现

使用 GNU tar、GNU coreutils、Bash 与 Python 3.11+。将命令中的四个路径替换为接收侧路径。恢复根可不存在或为空目录，其父目录必须已存在且可写。恢复脚本在同父目录内先解包到临时目录，成功后移入最终根。独立验收校验 SDK 完整树、stdx ZIP 的完整有效载荷、两份不同职责的回执、兼容链接和链接下的序列化文件。

```bash
bash /path/to/restore.sh \
  /absolute/empty/restore-root \
  /path/to/cangjie-sdk-linux-x64-1.2.0.tar.gz \
  /path/to/cangjie-stdx-linux-x64-1.2.0-beta.02.1.zip \
  /path/to/stdx-install.original.json
bash /path/to/verify.sh /absolute/empty/restore-root
```

此次修订的验证执行到解包和读取校验为止。SDK、编译器、`envsetup.sh`、应用与网络均未使用。SDK 和 stdx 归档原件未改，原清单和报告快照保存在 `original/`。历史来源、R7/R8 工具链记录、归档成员清单证据及元数据边界沿用原报告。源码缓存、负控及其他本机状态仍为 `unresolved`。 [机器可读方案](/workspace/work/migration-sdk-proof-revision/proposal.json) · [原报告快照](/workspace/work/migration-sdk-proof-revision/original/report.md) · [原方案快照](/workspace/work/migration-sdk-proof-revision/original/proposal.json)
