Lossless custody migration complete: 12 old ended test/public-consumer ELFs.
Original bytes 226563216; gzip bytes 65511501; net allocated reclaim 161058816 bytes.
Free before 86831104 bytes; after 247533568 bytes.
240 MiB minimum met: False; shortfall 4124672 bytes.
280 MiB goal met: False; shortfall 46067712 bytes; 12-file cap respected.
Each witness fsynced and fully decompressed to exact original SHA256/length before unlink.
Fresh original SHA/header/stat/UID/source recipe/index checks and readable-process FD/maps checks preceded unlink.
Finite unrelated runtime-supervisor visibility limits recorded; no claim of global process visibility.
Original indices remain immutable logical aliases; progress.json gives exact witness maps and restore.py restores original bytes.
Source/config/current CJP/critical benchmark ELF/provenance guards unchanged; excluded artifacts untouched.
Root must verify custody receipt before cold compiler starts.
