Lossless custody migration complete: 4 old ended test/public-consumer ELFs.
Original bytes 58981968; gzip bytes 17028381; net allocated reclaim 41951232 bytes.
Free before 247480320 bytes; after 289280000 bytes.
240 MiB minimum met: True; shortfall 0 bytes.
280 MiB goal met: False; shortfall 4321280 bytes; 4-additional-file cap respected; cumulative cap 16.
Each witness fsynced and fully decompressed to exact original SHA256/length before unlink.
Fresh original SHA/header/stat/UID/source recipe/index checks and readable-process FD/maps checks preceded unlink.
Finite unrelated runtime-supervisor visibility limits recorded; no claim of global process visibility.
Original indices remain immutable logical aliases; progress.json gives exact witness maps and restore.py restores original bytes.
Source/config/current CJP/critical benchmark ELF/provenance guards unchanged; excluded artifacts untouched.
Root must verify custody receipt before cold compiler starts.
