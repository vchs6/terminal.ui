import pathlib,os,stat,json,hashlib,gzip,subprocess,time,sys
O=pathlib.Path(__file__).parent;W=O/'witness';W.mkdir(exist_ok=True);M=pathlib.Path('/workspace/work/terminal.ui');G=json.loads(pathlib.Path('/workspace/work/validation/e146-runtime-headroom-20261114/guards.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,d):
 p=O/n
 with p.open('w') as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def free():
 s=os.statvfs(O);return s.f_bavail*s.f_frsize
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p,env=ENV).decode().strip()
HISTORY={n:sha(O.parent/n) for n in ['index.json','report.md','plan.json','progress.json','summary.json']}
assert HISTORY['index.json']=='93ed60afd84ff197fe4b9e5c70d58be5bd299fec7b15e1224797033c34b06cef'
def state():
 for n,h in HISTORY.items():assert sha(O.parent/n)==h

 assert git(M,'rev-parse','HEAD')==G['main_head'];assert not git(M,'status','--porcelain=v1','--untracked-files=no')
 S=pathlib.Path('/workspace/work/rendering-benchmark-implementation/source');assert git(S,'rev-parse','HEAD')==G['source_head'];assert not git(S,'status','--porcelain=v1','--untracked-files=no')
 for p,h in {**G['prior_and_current_sealed_indices'],**G['unchanged_source_CJP_config_pins']}.items():assert sha(pathlib.Path(p))==h,p
 for p,r in G['critical_ELF_stat_snapshot'].items():
  s=pathlib.Path(p).stat();assert all(getattr(s,k)==v for k,v in r.items()),p
 return {'main_head':G['main_head'],'candidate_head':G['source_head'],'main_and_candidate_tracked_clean':True,'reused_guard_sha256':sha(pathlib.Path('/workspace/work/validation/e146-runtime-headroom-20261114/guards.json')),'all_recorded_source_config_CJP_provenance_indices_and_critical_ELF_guards_unchanged':True,'original12_receipt_history_unchanged':HISTORY}
EXCLUDE=('rendering-benchmark','queued-input-regression','vte-protocol-counterexample','native-output-operator-fix','/validation/sdk/','/cache/','/stdx','process_cost','queued_input','diagnostic','input-timeout-implementation')
def rec(p):
 s=p.lstat();assert not any(x in str(p) for x in EXCLUDE);assert p.resolve()==p and '/target/release/bin/' in str(p) and stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and s.st_mode&0o111
 with p.open('rb') as f:h=f.read(64)
 assert h[:4]==b'\x7fELF' and h[4] in (1,2) and h[5] in (1,2) and int.from_bytes(h[16:18],'little' if h[5]==1 else 'big') in (2,3)
 return {'path':str(p),'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'sha256':sha(p),'ELF_header_hex':h.hex()}
def process(rows):
 paths={r['path'] for r in rows};inos={(r['device'],r['inode']) for r in rows};busy=[];limits=[];seen=[]
 expected={122:'runuser',151:'rootlesskit',161:'exe',186:'slirp4netns',195:'dockerd',214:'containerd'}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   status=(p/'status').read_text();comm=(p/'comm').read_text().strip();uids=next(x for x in status.splitlines() if x.startswith('Uid:')).split()[1:]
   if '\nState:\tZ' in status:continue
   if int(p.name) in expected:
    assert comm==expected[int(p.name)]
    limits.append({'pid':int(p.name),'comm':comm,'uids':uids,'status':next(x for x in status.splitlines() if x.startswith('State:')),'limit':'prior approved unrelated container runtime supervisor; inaccessible FDs not asserted unused'});continue
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if comm in ('cjc','cjpm','clang','clang++','ld','ld.lld','lld','llc','opt','cjnative','llvm-ar'):busy.append({'pid':int(p.name),'compiler':comm})
   maps=(p/'maps').read_text()
   if any(x in maps for x in paths):busy.append({'pid':int(p.name),'reason':'candidate mapped'})
   for t in [p/'cwd',p/'root',p/'exe']+list((p/'fd').iterdir()):
    try:
     v=os.readlink(t);s=t.stat()
     if v.removesuffix(' (deleted)') in paths or (s.st_dev,s.st_ino) in inos:busy.append({'entry':str(t),'target':v})
    except FileNotFoundError:continue
    except PermissionError:raise AssertionError('unknown process visibility denied '+str(t))
   seen.append({'pid':int(p.name),'comm':comm})
  except FileNotFoundError:continue
  except PermissionError:raise AssertionError('unknown potentially relevant process visibility denied '+str(p))
 r={'busy':busy,'finite_visibility_limits':limits,'readable_live_processes':seen,'epoch':time.time(),'scope':'no candidate FD/inode/maps among readable processes; known compilers absent; explicit unrelated runtime supervisor limits, no global all-proc claim'};write('process-latest.json',r);assert not busy,r;return r

def discover():
 P=M/'docs/reviews';sources=[]
 for role in ['R24/A','R24/B','R24/C','R16','R17','R18','R19','R20','widgets','interaction']:
  sources+=list((P/role).glob('**/index*.json'))
 pin=pathlib.Path('/workspace/work/validation/round1-cache-fix-headroom-20261114/old-roots-noncandidates-after.json.gz');sources.append(pin);sources.append(pathlib.Path('/workspace/work/overlay-execution/stablemanifest.json'));rows={};catalogs={}
 def visit(v,src):
  if isinstance(v,dict):
   name=v.get('path');h=v.get('sha256')
   if src==pathlib.Path('/workspace/work/overlay-execution/stablemanifest.json') and isinstance(name,str) and not name.startswith('/'):name=str(src.parent/name)
   if isinstance(name,str) and isinstance(h,str) and '/target/release/bin/' in name and not any(x in name for x in EXCLUDE):
    p=pathlib.Path(name)
    try:s=p.lstat()
    except FileNotFoundError:pass
    else:
     if stat.S_ISREG(s.st_mode) and s.st_uid==1000 and p.resolve()==p and s.st_mode&0o111:
      r=rows.setdefault(name,{'path':name,'expected_sha256':h,'expected_bytes':v.get('bytes',v.get('size',s.st_size)),'source_indices':[],'actual_stat_bytes':s.st_size});assert r['expected_sha256']==h
      r['source_indices'].append({'path':str(src),'sha256':catalogs[str(src)]})
   for x in v.values():visit(x,src)
  elif isinstance(v,list):
   for x in v:visit(x,src)
 for p in sources:
  b=p.read_bytes();catalogs[str(p)]=hashlib.sha256(b).hexdigest()
  if p==pin:assert catalogs[str(p)]=='2284f66e8075033bed4a583627db22dc33d616534bda621b4012cbdcaa43da9e';b=gzip.decompress(b)
  try:visit(json.loads(b),p)
  except json.JSONDecodeError:continue
 plan=[]
 for item in sorted(rows.values(),key=lambda r:r['actual_stat_bytes'],reverse=True)[:4]:
  p=pathlib.Path(item['path']);r=rec(p);assert r['sha256']==item['expected_sha256'] and r['bytes']==item['expected_bytes'],str(p)
  consumer=p.parents[3];manifest=consumer/'cjpm.toml';assert manifest.is_file() and manifest.resolve()==manifest
  sourcefiles=[manifest,*consumer.glob('*.lock'),*consumer.glob('cangjie-repo.toml'),*consumer.glob('src/*.cj')]
  proof={'consumer_cwd':str(consumer),'normal_build_command':'source /workspace/work/validation/sdk/cangjie/envsetup.sh; cjpm build','restoration':'exact gzip bytes, never rebuild','source_build_inputs':{str(q):sha(q) for q in sourcefiles if q.is_file()},'ownership':'ended old test/public-consumer normal Cangjie target, positively pinned by recorded prior index/custody catalog'}
  if '/frame-cow-execution/' in str(p):proof['recorded_normal_build_commands']=json.loads(pathlib.Path('/workspace/work/frame-cow-execution/index.json').read_text())['commands']
  r.update(source_indices=item['source_indices'],source_build_proof=proof,witness=str(W/(r['sha256']+'.gz')));plan.append(r)
 return plan

def verify_gz(p,r):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 assert n==r['bytes'] and h.hexdigest()==r['sha256'];return {'decompressed_sha256':h.hexdigest(),'decompressed_bytes':n}
def compress(src,p):
 with p.open('xb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as z,src.open('rb') as inp:
   while b:=inp.read(1048576):z.write(b)
  f.flush();os.fsync(f.fileno())
 os.chmod(p,0o444)
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)

def sourceguard(rows):
 for r in rows:
  for ix in r['source_indices']:assert sha(pathlib.Path(ix['path']))==ix['sha256']
  for name,h in r['source_build_proof']['source_build_inputs'].items():assert sha(pathlib.Path(name))==h,name
try:
 assert not (O/'progress.json').exists(),'no implicit repeated migration'
 before=free();write('free-before.json',{'bytes':before});write('state-before.json',state());plan=discover();write('plan.json',plan);assert plan and len(plan)<=4;sourceguard(plan);process(plan);progress=[];write('progress.json',progress)
 prior_roots=[pathlib.Path('/workspace/work/validation')/n for n in ['ended-runtime-witnesses-20261114','ended-more-runtime-witnesses-20261114','accepted-c-history-runtime-witnesses-20261114','accepted-d-runtime-headroom-20261114','accepted-unit-b-elf-witnesses-20261114','reviewed-e124-runtime-witnesses-20261114']]
 for r in plan:
  if free()>=280*1048576:break
  src=pathlib.Path(r['path']);assert rec(src)=={k:v for k,v in r.items() if k not in ('source_indices','source_build_proof','witness')};sourceguard([r]);state();pr=process([r]);dest=pathlib.Path(r['witness']);reuse=next((q for root in prior_roots if (q:=root/(r['sha256']+'.gz')).is_file()),None)
  i=len(progress)+1;write(str(i)+'-before.json',{'original':r,'free_bytes':free(),'process':pr})
  if reuse:dest=reuse
  else:
   assert free()>10*1048576,'reserve too small for witness';compress(src,dest)
  verification=verify_gz(dest,r);compressed_sha=sha(dest);compressed_bytes=dest.stat().st_size;assert compressed_bytes<r['allocated_bytes']
  assert rec(src)=={k:v for k,v in r.items() if k not in ('source_indices','source_build_proof','witness')};sourceguard([r]);state();pr=process([r]);assert sha(dest)==compressed_sha
  record={**r,'witness':str(dest),'witness_uri':str(dest),'witness_sha256':compressed_sha,'witness_bytes':compressed_bytes,'witness_allocated_bytes':dest.stat().st_blocks*512,'witness_reused':bool(reuse),'verified_before_unlink':verification,'preunlink_process':pr}
  write(str(i)+'-verified-before-unlink.json',record)
  fd=os.open(src.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
  try:
   s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_uid,s.st_nlink)==(r['device'],r['inode'],r['bytes'],r['mtime_ns'],r['ctime_ns'],r['uid'],1)
   os.unlink(src.name,dir_fd=fd);os.fsync(fd)
  finally:os.close(fd)
  record.update(physical_original_present=False,unlinked_epoch=time.time(),free_after_bytes=free());progress.append(record);write('progress.json',progress);print(json.dumps({'migrated':len(progress),'free_bytes':free(),'path':str(src)}),flush=True)
 sourceguard(plan);write('state-after.json',state())
 for r in progress:assert not pathlib.Path(r['path']).exists();assert sha(pathlib.Path(r['witness']))==r['witness_sha256']
 after=free();summary={'state':'complete','migrated_files':len(progress),'prior_migrated_files':12,'cumulative_migrated_files':12+len(progress),'original_bytes':sum(r['bytes'] for r in progress),'witness_bytes':sum(r['witness_bytes'] for r in progress),'allocated_reclaimed_bytes':sum(r['allocated_bytes']-(0 if r['witness_reused'] else r['witness_allocated_bytes']) for r in progress),'free_before_bytes':before,'free_after_bytes':after,'net_free_delta_bytes':after-before,'minimum240MiB_met':after>=240*1048576,'goal280MiB_met':after>=280*1048576,'minimum_shortfall_bytes':max(0,240*1048576-after),'goal_shortfall_bytes':max(0,280*1048576-after),'all_original_bytes_preserved':True,'logical_alias_map':'progress.json','original_indices_immutable':True,'root_verification_required_before_compiler':True};write('summary.json',summary)
 (O/'report.md').write_text('Lossless custody migration complete: '+str(len(progress))+' old ended test/public-consumer ELFs.\nOriginal bytes '+str(summary['original_bytes'])+'; gzip bytes '+str(summary['witness_bytes'])+'; net allocated reclaim '+str(summary['allocated_reclaimed_bytes'])+' bytes.\nFree before '+str(before)+' bytes; after '+str(after)+' bytes.\n240 MiB minimum met: '+str(summary['minimum240MiB_met'])+'; shortfall '+str(summary['minimum_shortfall_bytes'])+' bytes.\n280 MiB goal met: '+str(summary['goal280MiB_met'])+'; shortfall '+str(summary['goal_shortfall_bytes'])+' bytes; 4-additional-file cap respected; cumulative cap 16.\nEach witness fsynced and fully decompressed to exact original SHA256/length before unlink.\nFresh original SHA/header/stat/UID/source recipe/index checks and readable-process FD/maps checks preceded unlink.\nFinite unrelated runtime-supervisor visibility limits recorded; no claim of global process visibility.\nOriginal indices remain immutable logical aliases; progress.json gives exact witness maps and restore.py restores original bytes.\nSource/config/current CJP/critical benchmark ELF/provenance guards unchanged; excluded artifacts untouched.\nRoot must verify custody receipt before cold compiler starts.\n')
 files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name!='index.json'];write('index.json',{'schema':'input-fix-build-lossless-headroom-addendum-v1','state':'complete','summary':summary,'files':files});print(json.dumps({'receipt_sha256':sha(O/'index.json'),**summary}),flush=True)
except Exception as e:
 write('failure.json',{'type':type(e).__name__,'error':str(e),'free_bytes':free()});raise
