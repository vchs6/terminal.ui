# terminal.ui 第一批迁移包

本包是 **GitHub Clone 的补充包**，不是全部原始证据的备份。恢复时需要访问 GitHub。它不修改或删除原环境中的成果。

包含：

- 主仓库 52 个本地分支的引用清单，以及 90 个已注册工作树的固定提交。
- 255 个常规成果仓库及 1 个 bare provenance 仓库的 HEAD/本地分支/标签补充对象；已经能从基线取得的对象无需重复保存。7 个外部浅克隆仅保留版本记录。
- 独立的 c008 helper 完整 Git bundle，含最新 `6a399c88` 修复。
- 315 份未提交源码/测试文件的当前字节，其中 78 份为已跟踪文件的修改。
- 最新实际部署的测试工具、冻结测试契约、审核与交接材料。详细路径、字节和哈希见 `first-batch-files.json`。

恢复：

```bash
sha256sum -c SHA256SUMS
python3 restore.py /home/你的用户名/terminal-ui-migration
```

目标目录必须尚不存在。脚本建立 `目标/work/terminal.ui`，从 GitHub Clone 后导入补充提交并恢复 52 个本地分支；主分支固定为迁移时的 `a5aed68544d7681a522400d2f061e5cf64532ee4`。同时恢复 helper 仓库、测试工具和交接文件。

**不会自动重建全部历史工作树。** 它们的固定版本和源码对象已保存在 Git 中；未提交文件按原相对路径单独保存。需要恢复某个历史工作区时，从 `repository-refs.json` 或 `git-refs.json` 找出 SHA，在新的空目录中执行：

```bash
git -C /本地目标/work/terminal.ui worktree add --detach /另一个新的空目录 对应SHA
```

然后依据 `first-batch-files.json` 将对应原工作区的未提交文件复制到该新目录。当前文件字节和原 Git 状态被保存；原有索引的暂存/未暂存划分不自动重建。

继续工作前阅读 `HANDOFF.md`。原始终端日志、截图、大型归档、原 ELF/VM 镜像及工具链依赖属于后续批次；第一批中的索引可能仍引用这些尚未交付的文件。旧索引的 `/workspace/work` 绝对路径不会被改写，需要按恢复根目录映射。

归档与 Git bundle 已完成读取/校验，恢复脚本经过独立核查；这不等于已在新的电脑完成仓颉构建或终端验收。
