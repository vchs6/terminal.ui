# 第一批迁移包独立恢复核查

结论：固定 payload 核查通过，未发现需要修复的对象、文件缺失或现有路径覆盖问题。此结论不是一次完整新电脑恢复成功声明；未联网克隆主仓库、构建、启动 VM 或读取认证材料。SHA256SUMS 尚未生成，属已明确的后续封包步骤。

## 独立核验结果

- 对照原审计 inventory.json 的 315 个未提交源码/测试候选：315 个全部位于 first-batch-files.json 与 tar 正确 work/ 相对路径，原文件、manifest SHA256 与 tar 字节完全一致；合计 1,782,369 字节，其中 78 个 tracked 修改。
- tar 的 2,151 个成员全部为常规文件，没有绝对路径、..、非 work/ 根、symlink/hardlink、重复成员。2,151 个成员尺寸/hash 均与 manifest 相符；还独立读取全部 2,151 个原文件，hash 均一致。
- 主 main 与 helper 固定提交的 tracked 文件路径均不与 archive 成员冲突，archive 成员也没有位于其 Git symlink 祖先下。restore.py 会拒绝现有文件及 symlink 祖先，使用 xb 写入；现有固定内容没有发现触发该拒绝的冲突。
- 统一 bundle 实际 list-heads 为 2,703 refs；git bundle verify 成功。98 个 prerequisite 全部可从固定 main a5aed68544d7681a522400d2f061e5cf64532ee4 的历史取得。另将 bundle pack 字节送入 git unpack-objects -n -q 做不写入的完整压缩包读回，退出 0。随后在独立新 bare 临时库中，以原主库 objects 作为 alternate 执行真实 git bundle unbundle，完整解包/index-pack 成功；全部 2,703 个广告对象 cat-file 存在，逐 head 遍历共 27683 个对象成功。临时包大小约 10236730 字节，未修改交付包。
- repository-refs.json 的 exported refs：2,624 个映射精确存在于 bundle，另 2,568 个省略映射的提交全部属于固定 main 历史；不存在缺失或 SHA 不一致。共 255 个常规成果库/共享工作树与 1 个 bare 库；7 个外部浅克隆明确不导出，仅保留 pins。
- 52 个原本地分支：26 个 SHA 由 bundle 保留、26 个可从 main 取得。90 个固定工作树 HEAD：53 个在 bundle、37 个属于 main 历史，均可恢复。
- 独立 c008 helper bundle 实际克隆成功，HEAD 为 6a399c88ea231d307e365eeca12f1c35328dd128，git fsck --full 与 bundle verify 成功。克隆含 4 个可达 commits，与原 helper 的 --all 计数一致；完整 bundle 无基线依赖。

## 恢复行为与边界

restore.py 创建新目录，clone GitHub 主仓库，确认固定 main，导入 bundle 的 refs/heads 与 refs/migration，先 detach 后 update-ref 恢复 52 分支，最后 checkout main。该顺序可以避免主分支当前 checkout 对 update-ref 的干扰；固定 main 的 tracked 树未发现与 archive 的覆盖冲突。helper 单独完整 clone 后固定 HEAD。README/HANDOFF 对最新 helper 尚未安装到实际 operator、尚未真实 VT 验证的区别表述清楚。

脚本不会重建全部历史工作树、独立库或 bare 库的物理 Git 目录。原始相对路径中已提取的源码可能只是一组普通文件，需按 README 在另一个空目录创建 worktree 并复制选定修改。恢复的是当前文件字节，不是 index 的 staged/unstaged 划分。省略的 base 可达 refs 不会被 fetch 自动生成 refs/migration 别名；其 SHA 与原 ref 名必须从 repository-refs.json 查取。文档给出按 SHA 重建的做法，足以覆盖这一边界。

脚本中途失败会保留目标目录，而再次运行会拒绝已有目录；因此重试需换新的目标目录或显式清理失败输出。原始证据、SDK、缓存、二进制/VM 与运行进程不在第一批保证中。上述边界不阻断本次明确的 Clone+补充包目标。

最终封包必须生成并验证 SHA256SUMS。findings.json 记录本次核验所针对 payload 的 SHA256；本报告不替代最终封包校验，也未实际执行需要网络的整个 restore.py。
