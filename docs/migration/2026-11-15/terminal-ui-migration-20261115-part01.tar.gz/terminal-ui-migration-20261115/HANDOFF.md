# 接续工作交接

此文是迁移时最新状态；`work/LINUX-CONTINUATION-20261114.md` 是历史协调记录，不应以其较早结论覆盖本页和固定证据。

## 固定版本

- GitHub main：`a5aed68544d7681a522400d2f061e5cf64532ee4`，迁移前工作树干净。
- 已接受的产品核心：`d7e9d1445f98021a798d223de97b97b45239de93`；src tree `0121ec3815cef7971d325533fda66fdc57675d7a`。
- 独立 helper 最新：`6a399c88ea231d307e365eeca12f1c35328dd128`。公平调度修改的独立源码审核已接受，尚未安装进实际执行目录，尚未完成真实 VT 验证。
- 当前实际执行工具在 `work/linux-final-host-execution/operator`，包含已接受的 GUI PASTE002 修正与旧 R3 native 工具；它与最新 helper 仓库有意区分，不可误报为已安装最新修复。
- 正式交付检查的冻结测试：`8c20fb5c11d8a7d9f2b8033732f55adde3e63f1c`。

## 已完成与尚未完成

Linux 原定 34 项，23 项最终关闭，11 项仍开放：001、002、003、004、019、020、023、024、028、030、041。权威任务为主仓库 `openspec/changes/complete-linux-integration/tasks.md` 与相应原任务、验收条目；不能仅按支持活动数量计算功能完成度。

M2 A–E、局部刷新和原性能基准已独立验收。XTerm、VTE、tmux、screen、SSH 的 65 条实际执行命令已通过，但最终跨宿主独立验收尚未完成。原始截图/日志后续交付，不能把本包中的索引当作已包含其所有 payload。

接续顺序：

1. 对照 `work/c008-paste-helper-review/vt-fairness-review` 固定独立审核，把已接受的 native 最小差异集成到实际 operator；保留当前版本和安装哈希记录，不改 GUI 或产品核心。
2. 在原 15s/30s 时限下执行真实内核 VT bootstrap、控制 ACK/MAP_READY、适用交互矩阵、退出和 termios/键盘资源恢复。已证明旧日志 drain 无界可能饿死控制/reap，**没有证明原 MAP_READY 超时的完整原因**；源码审核不能替代这次真实运行。
3. 形成最终 C008 跨宿主证据并独立验收，完成平台/会话矩阵和 001–004、041 各自原验收，以及相关父任务的联合验收。
4. 修复 023 正式交付检查遗漏。已有真实 RED 记录在 `work/linux-release-tests/formal-red`。必须运行正常 `scripts/check-product.sh release`、普通 bundle/default tests/lint、新缓存解包构建、全部要求的公开示例/基准直接运行及失败负控；不能用一次 bundle 或仓库检查代替完整交付。
5. 独立完成 024 全部原 Linux AC/required NFR 与整体代码审核，再投影任务状态、推送 main。未获发布授权，不发布 release。

## 重要证据入口

- 五宿主阶段索引：`work/linux-final-host-actual/actual/runtime/paste002-five-host-index.json`，SHA256 `bfa760c616ef7f79919aa1d6b91be42d3e288c9adb7243b82c71149d46b52f84`。
- native 修复：`work/c008-paste-helper/vt-fairness`；hash-index SHA256 `f7b1ffb95856d10697c89c62b7b159f63a0ea87fe7a4ff009fd01890958d8862`。
- 最新审核：`work/c008-paste-helper-review/vt-fairness-review`。
- 冻结独立测试契约：`work/linux-final-host-test-contract`。
- M2 E 独立验收：`work/rendering-benchmark-acceptance`；公开主仓库 `docs/reviews/R24/E` 已归档完整已交付证据。
- 压缩原件的恢复映射：`work/c008-capacity/restore-map.json`、`work/linux-final-capacity` 及实际 runtime 的 `*restore-map.json`。对应 gzip payload 未全部在第一批中，后续按映射转存，禁止通过重新构建伪装恢复原二进制。

## 环境与继续工作规范

现有验证工具链为仓颉 SDK 1.2.0，框架版本号 `0.0.0`。工具链、stdx、中心仓依赖、Unicode/native 构建输入按主仓库 `docs/development/dependencies.md` 和最新依赖 manifest 恢复；第一批不含整个 SDK、缓存或原构建二进制。Linux 优先，其余平台不作为本阶段前置。

遵守主仓库 AGENTS.md。测试设计、实现、审核、执行和验收由独立子代理及固定上下文承担，主代理协调、集成。源码一个实体一个文件。已有效且输入未变的结果复用，勿为文档/提交重跑全部基准。真实终端测试使用实际宿主，不能换 TERM 冒充；截图不可重绘。

当前没有可迁移的活跃应用、VM、显示服务或 SSH 服务进程。运行中的代理会话也不迁移。旧环境仍保留原件；待所有后续批次在本地校验通过后再讨论清理。
