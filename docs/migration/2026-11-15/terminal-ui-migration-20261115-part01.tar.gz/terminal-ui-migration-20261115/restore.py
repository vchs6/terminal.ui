#!/usr/bin/env python3
"""Restore into a NEW directory. Requires Python 3, Git and GitHub access."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

package = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 restore.py /absolute/path/to/NEW-directory")
destination = Path(sys.argv[1]).expanduser().resolve()
if destination.exists():
    raise SystemExit("Destination already exists; choose a new directory.")

for line in (package / "SHA256SUMS").read_text().splitlines():
    expected, name = line.split("  ", 1)
    path = package / name
    if path.parent != package or not path.is_file():
        raise SystemExit("Invalid/missing package entry: " + name)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != expected:
        raise SystemExit("Checksum mismatch: " + name)

def run(arguments, cwd=None):
    subprocess.run(arguments, cwd=cwd, check=True)

destination.mkdir(parents=True)
work = destination / "work"
work.mkdir()
repository = work / "terminal.ui"
run(["git", "clone", "https://github.com/vchs6/terminal.ui.git", str(repository)])
metadata = json.loads((package / "git-refs.json").read_text())
base = metadata["base_main"]
run(["git", "cat-file", "-e", base + "^{commit}"], repository)
bundle = package / "terminal-ui-local-supplement.bundle"
run(["git", "bundle", "verify", str(bundle)], repository)
run(["git", "fetch", str(bundle),
     "+refs/heads/*:refs/remotes/migration/*",
     "+refs/migration/*:refs/migration/*"], repository)
run(["git", "checkout", "--detach", base], repository)
for entry in metadata["original_refs"]:
    run(["git", "cat-file", "-e", entry["sha"]], repository)
    run(["git", "update-ref", entry["ref"], entry["sha"]], repository)
run(["git", "checkout", "main"], repository)

helper = work / "c008-paste-helper" / "source"
helper.parent.mkdir(parents=True, exist_ok=True)
run(["git", "clone", str(package / "c008-helper-complete.bundle"), str(helper)])
run(["git", "checkout", "--detach", "6a399c88ea231d307e365eeca12f1c35328dd128"], helper)

with tarfile.open(package / "source-and-handoff.tar.gz", "r:gz") as archive:
    members = archive.getmembers()
    for member in members:
        parts = Path(member.name).parts
        if (not parts or parts[0] != "work" or ".." in parts
                or member.name.startswith("/") or not member.isfile()):
            raise SystemExit("Unsafe archive member: " + member.name)
        target = destination / member.name
        if any(parent.is_symlink() for parent in target.parents):
            raise SystemExit("Symlink parent: " + member.name)
        if target.exists():
            raise SystemExit("Refusing to overwrite: " + str(target))
    for member in members:
        target = destination / member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        with archive.extractfile(member) as source, target.open("xb") as sink:
            while chunk := source.read(1024 * 1024):
                sink.write(chunk)
        target.chmod(member.mode & 0o777)

print("Restored main:", base)
print("Restored source/handoff:", work)
print("Other fixed repositories/worktrees remain available through refs/migration and repository-refs.json.")
print("Read HANDOFF.md before continuing. Raw evidence batches and toolchain installation remain separate.")
