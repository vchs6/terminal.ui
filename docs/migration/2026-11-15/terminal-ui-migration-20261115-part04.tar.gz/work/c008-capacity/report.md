Archived 5 exact ended ELF executables; skipped 0.
Current-byte physical custody only; historical build/source/E147/R24 provenance unchanged.
Sealed index SHA values rechecked unchanged; logical aliases in restore-map.json.
UID1000 regular non-symlink nlink1 mode0700 executable PIE/PT_INTERP identities and historical SHA matched.
Readable bounded proc exe/FD/maps scans found no candidate reference before inventory or immediately before each unlink.
Finite limits: 8192 PIDs, 4096 FDs/PID, 2 MiB maps/PID, 8 KiB status/PID.
Unrelated nondumpable platform/desktop/SSHD/tool helpers limited visibility; no universal visibility claim.
Deterministic gzip level9, mtime0, empty filename; full decompression SHA/size and byte comparison before unlink.
Original stat/SHA rechecked immediately before unlink; archive rehashed afterward; fsynced archives/receipts/dirs.
Per-file forecast measured before writes; 12 MiB reserve enforced.
Allocated bytes reclaimed: 70922240; free before: 54497280; sampled free after: 124329984.
Restore one id: python3 -B /workspace/work/c008-capacity/restore.py ID; no overwrite, exact SHA/size/mode/mtime restoration.
