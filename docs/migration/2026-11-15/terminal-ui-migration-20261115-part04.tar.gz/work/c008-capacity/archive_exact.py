exec(open('/workspace/work/c008-capacity/custody_ops.py').read().split('rows=[];skips=[];before=free()')[0])
inv=json.load(open(B/'inventory.json'));rows=inv['rows'];(B/'gzip').mkdir();(B/'receipts').mkdir();done=[]
def compact(p,x):
 with open(p,'x') as f:json.dump(x,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
for r in rows:
 p=r['path'];a=r['gzip_path'];r['free_before_write']=free();assert r['free_before_write']-r['forecast_gzip_bytes']-1048576>FLOOR
 assert sig(os.lstat(p))==r['stat_signature'] and sha(p)==r['sha256']
 with open(a,'xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=9,mtime=0) as z:
   with open(p,'rb') as src:
    while block:=src.read(1048576):
     assert free()>FLOOR;z.write(block)
  raw.flush();os.fsync(raw.fileno())
 syncdir(B/'gzip');r['gzip_bytes']=os.stat(a).st_size;assert r['gzip_bytes']==r['forecast_gzip_bytes'];r['gzip_allocated']=os.stat(a).st_blocks*512;r['gzip_sha256']=sha(a)
 digest=hashlib.sha256();n=0
 with gzip.open(a,'rb') as restored,open(p,'rb') as original:
  while block:=restored.read(1048576):
   assert block==original.read(len(block));digest.update(block);n+=len(block)
  assert original.read(1)==b''
 assert digest.hexdigest()==r['sha256'] and n==r['size'];r['verified_decompressed_bytes']=n;r['verified_decompressed_sha256']=digest.hexdigest();r['full_byte_comparison']=True
 check=proc([r]);assert not check['references'];r['proc_immediately_before']=check
 compact(B/'receipts'/f"{r['id']:02d}-verified-before-unlink.json",r);syncdir(B/'receipts')
 assert sig(os.lstat(p))==r['stat_signature'] and sha(p)==r['sha256']
 assert sha(a)==r['gzip_sha256'];os.unlink(p);syncdir(Path(p).parent)
 assert sha(a)==r['gzip_sha256'];r['original_absent']=not os.path.lexists(p);r['free_after']=free();r['reclaimed_allocated_bytes']=r['allocated']-r['gzip_allocated'];r['status']='ARCHIVED_CURRENT_BYTES_ONLY'
 compact(B/'receipts'/f"{r['id']:02d}-complete.json",r);done.append(r)
 print(json.dumps({'id':r['id'],'bytes':n,'gzip_bytes':r['gzip_bytes'],'reclaimed':r['reclaimed_allocated_bytes'],'free':r['free_after']}),flush=True)
assert all(sha(p)==h for p,h in inv['sealed_indices'].items())
save(B/'restore-map.json',dict(format=1,hashscope=inv['hashscope'],logical_aliases='Each original path aliases its exact decompressed current bytes; sealed original indices unchanged.',restore_helper=str(B/'restore.py'),rows=done))
restore='''import gzip,hashlib,json,os,sys\nfrom pathlib import Path\nbase=Path(__file__).resolve().parent\nr=next(r for r in json.load(open(base/'restore-map.json'))['rows'] if r['id']==int(sys.argv[1]))\ndef sha(p):\n with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()\nassert sha(r['gzip_path'])==r['gzip_sha256']\nassert not os.path.lexists(r['path'])\ns=os.statvfs(Path(r['path']).parent);assert s.f_bavail*s.f_frsize>r['size']+12*1024*1024\nh=hashlib.sha256();n=0\nwith gzip.open(r['gzip_path'],'rb') as src,open(r['path'],'xb') as dst:\n while b:=src.read(1048576):dst.write(b);h.update(b);n+=len(b)\n assert n==r['size'] and h.hexdigest()==r['sha256']\n os.fchmod(dst.fileno(),r['mode']);dst.flush();os.fsync(dst.fileno())\nos.utime(r['path'],ns=(r['mtime_ns'],r['mtime_ns']))\nassert sha(r['path'])==r['sha256']\nfd=os.open(Path(r['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)\nprint(r['path'])\n'''
with open(B/'restore.py','x') as f:f.write(restore);f.flush();os.fsync(f.fileno())
reclaimed=sum(r['reclaimed_allocated_bytes'] for r in done)
report=f'''Archived {len(done)} exact ended ELF executables; skipped {len(inv['skips'])}.\nCurrent-byte physical custody only; historical build/source/E147/R24 provenance unchanged.\nSealed index SHA values rechecked unchanged; logical aliases in restore-map.json.\nUID1000 regular non-symlink nlink1 mode0700 executable PIE/PT_INTERP identities and historical SHA matched.\nReadable bounded proc exe/FD/maps scans found no candidate reference before inventory or immediately before each unlink.\nFinite limits: 8192 PIDs, 4096 FDs/PID, 2 MiB maps/PID, 8 KiB status/PID.\nUnrelated nondumpable platform/desktop/SSHD/tool helpers limited visibility; no universal visibility claim.\nDeterministic gzip level9, mtime0, empty filename; full decompression SHA/size and byte comparison before unlink.\nOriginal stat/SHA rechecked immediately before unlink; archive rehashed afterward; fsynced archives/receipts/dirs.\nPer-file forecast measured before writes; 12 MiB reserve enforced.\nAllocated bytes reclaimed: {reclaimed}; free before: {inv['free_before']}; sampled free after: {free()}.\nRestore one id: python3 -B {B}/restore.py ID; no overwrite, exact SHA/size/mode/mtime restoration.\n'''
with open(B/'report.md','x') as f:f.write(report);f.flush();os.fsync(f.fileno())
items=[B/'inventory.json',B/'restore-map.json',B/'restore.py',B/'report.md']+sorted((B/'receipts').glob('*.json'))
compact(B/'receipt-index.json',dict(count=len(done),skips=inv['skips'],reclaimed_allocated_bytes=reclaimed,free_after=free(),sealed_indices_unchanged=inv['sealed_indices'],files={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in items},archives={r['path']:{'gzip_path':r['gzip_path'],'sha256':r['sha256'],'gzip_sha256':r['gzip_sha256']} for r in done}));syncdir(B)
print('INDEX_SHA256',sha(B/'receipt-index.json'),'RECLAIMED',reclaimed,'FREE',free(),flush=True)
