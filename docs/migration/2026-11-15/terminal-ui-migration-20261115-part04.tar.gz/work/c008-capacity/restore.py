import gzip,hashlib,json,os,sys
from pathlib import Path
base=Path(__file__).resolve().parent
r=next(r for r in json.load(open(base/'restore-map.json'))['rows'] if r['id']==int(sys.argv[1]))
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(r['gzip_path'])==r['gzip_sha256']
assert not os.path.lexists(r['path'])
s=os.statvfs(Path(r['path']).parent);assert s.f_bavail*s.f_frsize>r['size']+12*1024*1024
h=hashlib.sha256();n=0
with gzip.open(r['gzip_path'],'rb') as src,open(r['path'],'xb') as dst:
 while b:=src.read(1048576):dst.write(b);h.update(b);n+=len(b)
 assert n==r['size'] and h.hexdigest()==r['sha256']
 os.fchmod(dst.fileno(),r['mode']);dst.flush();os.fsync(dst.fileno())
os.utime(r['path'],ns=(r['mtime_ns'],r['mtime_ns']))
assert sha(r['path'])==r['sha256']
fd=os.open(Path(r['path']).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(r['path'])
