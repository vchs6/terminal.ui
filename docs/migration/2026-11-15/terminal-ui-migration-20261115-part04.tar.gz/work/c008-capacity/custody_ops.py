import os,stat,json,hashlib,struct,gzip,zlib,time
from pathlib import Path
B=Path('/workspace/work/c008-capacity'); FLOOR=12*1024*1024
pairs=[('/workspace/work/rendering-benchmark-implementation/consumers/old/target/release/bin/old-r1-compat','6064d593e129a845d4b2e92dc82a17077e808c1bf4f2c6217f503ca6952efd5c'),('/workspace/work/rendering-benchmark-implementation/consumers/delivered/target/release/bin/delivered-r1-compat','b5344b1fb93ad74bd2ec308cebf5da6dc220a93679c918284ddeb2d56ceced32'),('/workspace/work/rendering-benchmark-implementation/consumers/delivered/target/release/bin/delivered-r1-diagnostic','b99c297590e1ae11c9774eec5b765611f8272cb0ff2d7d58e9f8cc79823679f1'),('/workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-compat','8a80880135436869bc4272322721ce51f8daabf8c550a3baf593374d858c854f'),('/workspace/work/input-timeout-execution/consumer/target/release/bin/final-d7e9-diagnostic','d52f443b32588013eafc814b73ce2e8ee5393698cc19caf3a5de99a3cb8e3b98')]
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():
 s=os.statvfs(B);return s.f_bavail*s.f_frsize
def save(p,x):
 with open(p,'x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def sig(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns]
def proc(rows):
 paths={r['path'] for r in rows}; keys={(r['dev'],r['inode']) for r in rows};out={'pid_limit':8192,'fd_per_pid_limit':4096,'maps_per_pid_byte_limit':2097152,'references':[],'limits':[],'zombies':0,'maps_read':0,'fd_read':0};pids=sorted([x for x in os.listdir('/proc') if x.isdigit()],key=int);assert len(pids)<=8192
 out['pid_count']=len(pids)
 for pid in pids:
  root='/proc/'+pid
  try:
   with open(root+'/status') as f:status=f.read(8193)
   assert len(status)<=8192
   comm=status.splitlines()[0][5:].strip();state=next(x for x in status.splitlines() if x.startswith('State:'))
   if 'Z (zombie)' in state:out['zombies']+=1;continue
  except FileNotFoundError:continue
  except PermissionError:out['limits'].append({'pid':pid,'kind':'status'});continue
  def limit(kind):out['limits'].append({'pid':pid,'comm':comm,'kind':kind})
  try:
   for name in ['exe']:
    try:
     s=os.stat(root+'/'+name)
     if (s.st_dev,s.st_ino) in keys:out['references'].append([pid,name])
    except FileNotFoundError:pass
    except PermissionError:limit(name)
   fds=os.listdir(root+'/fd');assert len(fds)<=4096
   for fd in fds:
    try:
     s=os.stat(root+'/fd/'+fd);out['fd_read']+=1
     if (s.st_dev,s.st_ino) in keys:out['references'].append([pid,'fd',fd])
    except FileNotFoundError:pass
    except PermissionError:limit('fd-stat')
  except FileNotFoundError:pass
  except PermissionError:limit('fd')
  try:
   with open(root+'/maps') as f:maps=f.read(2097153)
   assert len(maps)<=2097152;out['maps_read']+=1
   for line in maps.splitlines():
    fields=line.split(None,5)
    if len(fields)==6 and fields[5].removesuffix(' (deleted)') in paths:out['references'].append([pid,'maps',fields[5]])
  except FileNotFoundError:pass
  except PermissionError:limit('maps')
 out['visibility']='Readable proc only; nondumpable unrelated platform helpers restrict visibility. No universal visibility claim.'
 return out
rows=[];skips=[];before=free()
idx=Path('/workspace/work/input-timeout-execution/index.json'); adm=Path('/workspace/work/input-timeout-execution/actual/admission.json');guard=Path('/workspace/work/linux-final-host-actual/actual/runtime/screen-attempt3/host-guard.json')
sealed={str(p):sha(p) for p in [idx,adm,guard,Path('/workspace/work/rendering-benchmark-implementation/index.json')]}
assert sealed[str(guard)]=='70e7381f07c16c88e8696571d4556dd10812ad0ae2d9df5d363a349568f4e125'
assert json.load(open(idx))['executables']['diagnostic']['sha256']==pairs[-1][1]==json.load(open(adm))['executables']['diagnostic']['sha256']
gdata=json.load(open(guard))
def direct_paths(x):
 found=set()
 if isinstance(x,dict):
  for k,v in x.items():
   if k.startswith('/'):found.add(k)
   if k=='path' and isinstance(v,str):found.add(v)
   if isinstance(v,(dict,list)):found|=direct_paths(v)
 elif isinstance(x,list):
  for v in x:found|=direct_paths(v)
 return found
pins=direct_paths(gdata)
for i,(p,expected) in enumerate(pairs,1):
 try:
  s=os.lstat(p);assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and s.st_mode&0o111 and p not in pins
  assert sha(p)==expected
  with open(p,'rb') as f:
   h=f.read(64);assert h[:6]==b'\x7fELF\x02\x01';et=struct.unpack_from('<H',h,16)[0];assert et in [2,3]
   off=struct.unpack_from('<Q',h,32)[0];ents,n=struct.unpack_from('<HH',h,54);assert n<=128 and ents==56
   f.seek(off);ph=f.read(ents*n);assert len(ph)==ents*n
   assert any(struct.unpack_from('<I',ph,j*ents)[0]==3 for j in range(n)) # PT_INTERP: executable PIE, not a shared library
  compressor=zlib.compressobj(9,zlib.DEFLATED,-15);forecast=18
  with open(p,'rb') as f:
   while b:=f.read(1048576):forecast+=len(compressor.compress(b))
  forecast+=len(compressor.flush())
  rows.append(dict(id=i,path=p,sha256=expected,size=s.st_size,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,nlink=s.st_nlink,dev=s.st_dev,inode=s.st_ino,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated=s.st_blocks*512,stat_signature=sig(s),forecast_gzip_bytes=forecast,elf_type=et,pt_interp=True,gzip_path=str(B/'gzip'/f'{i:02d}.gz'),historical_sha_match=True,direct_guard_member=False))
 except Exception as e:skips.append({'path':p,'reason':repr(e)})
pcheck=proc(rows);assert not pcheck['references']
save(B/'inventory.json',dict(rows=rows,skips=skips,free_before=before,sealed_indices=sealed,proc_before=pcheck,hashscope='Current physical bytes only; no historical rebuild or provenance amendment.',authorization='Root exact-five archival GO in brief.md'))
print(json.dumps({'qualified':len(rows),'skips':skips,'free':before,'forecasts':[r['forecast_gzip_bytes'] for r in rows],'proc_limits':pcheck['limits'],'pid_count':pcheck['pid_count']},indent=2),flush=True)
